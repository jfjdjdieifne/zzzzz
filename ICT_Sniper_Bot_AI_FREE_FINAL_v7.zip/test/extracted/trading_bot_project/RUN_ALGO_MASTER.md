# 🚀 تشغيل الرادار الحي الخارق — `algo_master.py` (100% بدون AI)

ملف `algo_master.py` هاد هو **المسار التحليلي الكامل الخارق**: يحلّل الشارت
لايف متل مايكل هدلستون فعلياً ماسك الشارت — Top‑Down (Weekly/Daily → 4H →
15m → 5m)، يرصد السيولة + السحب + الـ FVG/OB + الهيكل + جودة الكسر، يمرّق
على موديلات الدخول A–F، وينتظر عند سعر محدّد، ويتابع الحالة كل دقيقة لكل
عملة 24/7 — **بدون أي نموذج لغوي (LLM) ولا أي طبقة AI**. كل التحليل رياضيات
بحتة حتمية 100% عين مايكل + مخ مايكل.

---

## 1) تجهيز البيئة (مرة وحدة)

```bash
# انسخ المشروع على جهازك وادخله
cd trading_bot_project

# أنشئ بيئة (اختياري بس منيح)
python3 -m venv .venv && source .venv/bin/activate

# ثبّت المتطلبات (numpy + pytz + yfinance + pandas + ...)
pip install -r requirements.txt
```

> ملاحظة: `algo_master.py` ما بيحتاج **أي مفتاح AI** (لا Gemini ولا
> OpenRouter). ملف `.env` اختياري تماماً لهاد المسار. السعر بيُجلب من
> OKX العام (public candles) مباشرةً عبر الإنترنت — ما بيحتاج API key
> لاي تحليل.

---

## 2) التشغيل الحي (الركض الفعلي)

```bash
python3 algo_master.py
```

بيشتغل حلقة لايف: بيمسح كل `SCAN_INTERVAL_SEC` (60 ثانية) كل العملات
`WATCHING_SYMBOLS` = BTC/ETH/SOL/BNB/XRP، وبطبعلك رادار تفصيلي عربي لكل
عملة فيه:
- الانحياز (Daily/4H) + تحدّي 4H للانحياز
- خريطة السيولة (BSL/SSL) + شو منستنا السعر يسحب
- السحب (Sweep) + نوعه (GENUINE_REVERSAL_SWEEP / LIQUIDITY_RUN)
- مناطق السعر (FVG + OB) + Premium/Discount/OTE
- الهيكل + جودة الكسر (Break Quality) + الأصالة (Authenticity)
- موديلات الدخول A–F + الحالة الكلية (READY / NO_MODEL_QUALIFIES)
- التتبّع عبر السكانات (شو صار من آخر سكان؟ شو جديد؟)

**بوابة Kill Zone صارمة**: ما بيصير أي دخول (تحديث صفقة) إلا جواه
`LONDON_KILLZONE` / `NY_AM_KILLZONE` / `NY_PM_KILLZONE`. خارج هالجلسات
بينطبع ⛔ ميتة - مراقبة فقط.

---

## 3) التعديل على الإعدادات (داخل `algo_master.py` أعلى الملف)

```python
WATCHING_SYMBOLS = ["BTC/USDT","ETH/USDT","SOL/USDT","BNB/USDT","XRP/USDT"]
ACCOUNT_BALANCE  = 100.0     # رصيد الحساب اللحظي (لحساب حجم الدخول)
RISK_PCT         = 0.01      # 1% خطر لكل صفقة
EXECUTABLE_SESSIONS = {"LONDON_KILLZONE","NY_AM_KILLZONE","NY_PM_KILLZONE"}
SCAN_INTERVAL_SEC    = 60    # كل دقيقة
```

---

## 3.5) أدوات التحقق المستقلة (تتأكد إنو البوت ما بيشلّف)

بعد كل تحليل، بتقدر تتأكد بنفسك بأداتين مدمجتين:

- **`verify_bot.py`** — تأكيد مستقل بالأرقام: بتجيب بيانات OKX الحقيقية وبتشغّل
  نفس دوال `algo_master`، فتقارن نتيجتها مع اللي طبعه البوت.
  ```bash
  python3 verify_bot.py            # يفحص الخمسة
  python3 verify_bot.py SOL --eyeball   # بيعرض آخر شموع للتأكد من السحب
  ```
- **`trace_read.py`** — تتبّع قراءة الشارت: بياخد كل رقم (FVG / OB / Sweep /
  Structure / الموديل B) ويطبع **شموع OHLC اللي انبنى عليها**، مع فحص منطقي
  تلقائي. هيك بتفتح شارت OKX وتتأكد بعينك.
  ```bash
  python3 trace_read.py SOL        # يتتبّع قراءة SOL على كل الطبقات
  python3 trace_read.py BNB        # بيوريك فحص منطق الـBSL
  python3 trace_read.py BTC --n 8  # سياق أكبر حول كل شمعة
  ```

ثلاث قواعد سريعة للتأكد إنو القراءة صح (مش عم يهلّس):
1. **جهة السحب = الانحياز:** صاعد ← سحب SSL (فتيل تحت قاع). هابط ← سحب BSL (فتيل فوق قمة).
2. **جهة الخطة = الانحياز:** صاعد ← BUY (دخول < TP1). هابط ← SELL (دخول > TP1).
3. **بوابة Kill Zone:** خارج الجلسات التنفيذية (LONDON/NY_AM/NY_PM) ما في تنفيذ — بس مراقبة.

---

## 3.6) خيارات التشغيل المتقدمة (أوامر)

- **تحليل عملة وحدة فوراً** (بدون تنفيذ):
  ```bash
  python3 algo_master.py --analyze SOL
  ```
- **تحليل السوق كامل** (ملخّص مرتّب حسب الجاهزية):
  ```bash
  python3 algo_master.py --mode market
  python3 algo_master.py --mode market --coins BTC/USDT,ETH/USDT,SOL/USDT,BNB/USDT,XRP/USDT,DOGE/USDT
  ```
- **تشغيل حي على أي عدد عملات** (مثلاً 20):
  ```bash
  python3 algo_master.py --coins BTC/USDT,ETH/USDT,SOL/USDT,BNB/USDT,XRP/USDT,DOGE/USDT,ADA/USDT,AVAX/USDT,LINK/USDT,DOT/USDT,MATIC/USDT,LTC/USDT,TRX/USDT,ATOM/USDT,NEAR/USDT,UNI/USDT,ICP/USDT,APT/USDT,AR/USDT,FIL/USDT
  ```
  (لـ20 عملة ننصح `--interval 120` لتخفيف التحميل على الجوال/الشبكة)
- **سكان واحد للاختبار**: `python3 algo_master.py --once`
- **تعطيل التيليغرام مؤقتاً**: `--no-telegram`

## 3.7) التيليغرام (إشعاراتك على تليغرام)

1. أنشئ بوتاً عبر @BotFather وخده التوكن.
2. أرسللو أي رسالة، ثم خد `chat_id` من @userinfobot.
3. انسخ `.env.example` إلى `.env` واملأ:
   ```
   TELEGRAM_BOT_TOKEN=123456:ABC...
   TELEGRAM_CHAT_ID=987654321
   ```
4. البوت بيبلّك: دخول صفقة (مع الاتجاه/الدخول/SL/TP1/TP2/الحجم/المخاطرة)، إغلاق صفقة (مع المصير والربح/الخسارة والتاريخ)، ورصيد دوري كل ~30 سكان. يشتغل بدون تيليغرام تماماً إذا ما حطيت التوكن.

## 3.8) سجل الصفقات (مصير كل صفقة بتواريخ وأسعار)

كل حدث (فتح/إغلاق) بيتسجّل بـ`data/trade_journal_live.jsonl` بصيغة JSON فيها:
الوقت (NY)، العملة، الاتجاه، الموديل، الدخول، SL، TP1، TP2، الخروج، الربح/الخسارة، الرصيد.
بتمرّق هاد الملف متل ما بتشوف مصير كل صفقة بدقّة.

## 3.9) التشغيل على Termux (أندرويد) 24/7

```bash
pkg update && pkg install python clang make
pip install -r requirements.txt
termux-wake-lock                      # يمنع النوم
nohup python3 algo_master.py > bot.log 2>&1 &    # يشتغل بالخلفية
tail -f bot.log                       # تتابع
```
بيشتغل لحالو 24/7 ويراقب كل العملات ويدخل صفقات وهمية (محاكاة) بـ$100، ويتابع ورا كل قمة/قاع (تماشي هيكلي)، ويرسللك كل شي عالتليغرام.

---

## 4) ملاحظات مهمة

- **التحليل فقط (Paper)**: النسخة الحالية بتحدّث `active_trades` داخلياً
  (تخيّل صفقة، تحرّك الستوب خلف القمم/القيعان، TP1 50%+BE، TP2 runner) بس
  **ما بتصرف أمر فعلي** على OKX/Binance. لربط التنفيذ الفعلي لازم نضيف
  طبقة `create_order` مربوطة بمفاتيحك السرية (بتبلّغني إذا بدك ياها).
- `telegram_algo_master.py` فيه خطأ صياغة قديم (ما بيخص هاد المسار) —
  تجاهله، المسار المعتمد هو `algo_master.py`.
- باقي المحركات (`ict_math_engine`, `ict_entry_checklist_engine`,
  `authenticity_engine`, `ict_sessions`) هي "مخ مايكل وعين مايكل" —
  ما تتعدّل لأنها محركات رياضية موثّقة.
