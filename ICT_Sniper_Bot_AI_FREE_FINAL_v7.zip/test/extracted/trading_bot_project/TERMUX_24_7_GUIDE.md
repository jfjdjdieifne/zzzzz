# 🤖 تشغيل البوت 24/7 على موبايل أندرويد قديم (Termux) + التيليغرام

دليل خطوة-بخطوة. البوت 100% رياضيات (بدون AI)، يتابع الشارت لايف Top-Down،
يفتح/يليحّق الصفقات ورقيًا ($100)، وبيرسللك كلشي ع التيليغرام.

> ⚠️ هام: البوت **محاكاة/ورقي فقط** — ما بيplaced أوامر حقيقية. OKX بيستعمل
> للقراءة العامة (public API) فقط. مافي خطر فلوس حقيقية.

---

## ١) تحضير التيليغرام (على أي جهاز، قبل الموبايل)

1. افتح @BotFather على التيليغرام → `/newbot` → أعطيه اسم → خده الـ **TOKEN**
   (شكلو `123456789:ABCdefGhIJK...`).
2. افتح محادثتك مع البوت الجديد وأرسلله أي رسالة (مثلاً `hi`).
3. خد الـ **CHAT_ID** بطريقتين:
   - الأسهل: افتح @userinfobot وأرسللو رسالة → بيعطيك `Your user ID: 987654321`.
   - أو من المتصفح:
     `https://api.telegram.org/bot<TOKEN>/getUpdates`
     (استبدل `<TOKEN>` بتوكنك) → تطلع رسالتك فيها `"chat":{"id":987654321}`.
4. احفظ الـ TOKEN والـ CHAT_ID — رح نحطهم بملف `.env` على الموبايل.

---

## ٢) تنزيل المشروع على الموبايل

- نزّل ملف `ICT_Sniper_Bot_AI_FREE_FINAL_v3.zip` (من الدردشة) على الكمبيوتر.
- أنقله ع الموبايل:
  - **_USB:** حطه بـ `Download` بالموبايل.
  - **_أو مباشرة بالموبايل:** نزّلو من المتصفح داخل الموبايل مباشرة لـ `Download`.

---

## ٣) تثبيت Termux (من F-Droid، مش Play Store)

> نسخة Termux على Play Store قديمة ومكسّرة. حمّلها من **F-Droid**:
> https://f-droid.org/packages/com.termux/  (وممكن Termux:API + Termux:Boot لنفس المصدر).

بالموبايل افتح Termux ونفّذ (ن copying سطر سطر):

```bash
pkg update && pkg upgrade -y
pkg install python unzip curl -y
termux-setup-storage        # بيدّيك صلاحية الوصول لذاكرة الموبايل
```

> ملاحظة: `yfinance` صار **اختياري** (البوت بيشتغل على OKX لحالو)، فما
> بتحتاج تثبّتو — هاد بيخفّف كتير على موبايل قديم.

---

## ٤) فك الضغط + تثبيت المكتبات

```bash
mkdir -p ~/bot && cd ~/bot
cp ~/storage/shared/Download/ICT_Sniper_Bot_AI_FREE_FINAL_v3.zip .
unzip ICT_Sniper_Bot_AI_FREE_FINAL_v3.zip
cd trading_bot_project

pip install -U pip
pip install requests python-dotenv pytz numpy
```

---

## ٥) إعداد التيليغرام (.env)

```bash
cp .env.example .env
nano .env
```

بداخل `nano` املأ السطرين (بدون أقواس، بدون مسافات زايدة):

```
TELEGRAM_BOT_TOKEN=123456789:ABCdefGhIJK...
TELEGRAM_CHAT_ID=987654321
```

احفظ: `Ctrl+O` ثم `Enter`، ثم اخرج `Ctrl+X`.

---

## ٦) تجربة سريعة قبل الـ 24/7

```bash
# تحليل عملة وحدة فوراً (بدون تيليغرام)
python algo_master.py --analyze SOL

# سكان واحد (يفتح لو في فرصة بجلسة تنفيذ) + بيطبع ع الشاشة
python algo_master.py --once --no-telegram

# تحليل السوق كامل (20 عملة) — مراقبة فقط
python algo_master.py --mode market
```

---

## ٧) التشغيل الحقيقي 24/7 مرتبط بالتيليغرام

أبسط أمر (5 عملات، مسح كل دقيقتين، مع التيليغرام):

```bash
python algo_master.py --coins BTC/USDT,ETH/USDT,SOL/USDT,BNB/USDT,XRP/USDT --interval 120 --telegram
```

لـ **20 عملة** (أنصح `--interval 120` ع الأقل ع موبايل قديم):

```bash
python algo_master.py --coins BTC/USDT,ETH/USDT,SOL/USDT,BNB/USDT,XRP/USDT,DOGE/USDT,ADA/USDT,AVAX/USDT,LINK/USDT,DOT/USDT,MATIC/USDT,LTC/USDT,TRX/USDT,ATOM/USDT,NEAR/USDT,UNI/USDT,ICP/USDT,APT/USDT,AR/USDT,FIL/USDT --interval 120 --telegram
```

---

## ٨) كيف يضل شغّال وأنت حاط الموبايل ع جنب (شاشة مطفية)

هاد أهم جزء. بدون هاد، أندرويد بيقتل البوت لما تسكّر الشاشة.

### أ) امنع أندرويد من قتل Termux (إلزامي)
```bash
termux-wake-lock
```
هاد بيمنع السكون العميق لوقت تشغيل Termux. (لإلغاء لاحقًا: `termux-wake-unlock`).

### ب) شغّلو داخل tmux عشان يضل عايش حتى لو سكّرت تطبيق Termux
```bash
pkg install tmux -y
tmux new -s bot
# هلأ رح تدخل بجلسة tmux، نفّذ أمر التشغيل:
python algo_master.py --coins BTC/USDT,ETH/USDT,SOL/USDT,BNB/USDT,XRP/USDT --interval 120 --telegram
```
- **افصل** عن الجلسة (تضل شغّالة بالخلفية): اضغط `Ctrl+B` ثم `D`.
- **رجّع تشوفها** لاحقًا: `tmux attach -t bot`.
- **لو انقطعت الكهربا/أعاد الموبايل:** `tmux attach -t bot` (إذا انقتل، أعد `tmux new -s bot` وشغّل الأمر).

### ج) إعدادات أندرويد (مهمة ع موبايل قديم)
- **بطارية:** حط تطبيق Termux بوضع **"غير مقيّد" / Unrestricted** (الإعدادات ← التطبيقات ← Termux ← البطارية).
- **عدّل تحسين البطارية:** أطفئه لـ Termux.
- **الشاحن:** خلّي الموبايل ع الشاحن طول الأسبوع (أو حدد الشحن بـ ~80% لحماية البطارية).
- مالك داعي تسكّر الشاشة؛ فيك تسكّرها والبوت شغّال بالخلفية.

### د) (اختياري) يشتغل تلقائي بعد إعادة التشغيل
نزّل **Termux:Boot** من F-Droid، واسمع هاد داخل Termux مرة وحدة:
```bash
echo '#!/data/data/com.termux/files/usr/bin/sh
termux-wake-lock
tmux new -s bot -d "python /data/data/com.termux/files/home/bot/trading_bot_project/algo_master.py --coins BTC/USDT,ETH/USDT,SOL/USDT,BNB/USDT,XRP/USDT --interval 120 --telegram"' > ~/.termux/boot/bot.sh
chmod +x ~/.termux/boot/bot.sh
```
هيك بعد أي ريستارت بيشتغل لحالو.

---

## ٩) شو رح تستلم ع التيليغرام؟

- 🚀 **رسالة إقلاع** فيا الرصيد ($100) وقائمة العملات.
- 🔔 **"الموديل جاهز بس الجلسة ميتة"** — بيعلمك فيو فرصة منتظرة لجلسة تنفيذ.
- 🔥 **فتح صفقة** (داين/شورت، الدخول، SL، TP1، الحجم، المخاطرة).
- 👁️ **تتبّع شمعة-بشمعة** (TP1، تأمين BE، تماشي خلف قمة/قاع، TP2).
- 🏁 **إغلاق صفقة** فيه **التاريخ/الوقت (NY) + السعر + الربح/الخسارة + الرصيد**.
- 💰 **نبضة رصيد** كل ~30 سكان.

---

## ١٠) كيف تراقب/تتأكد إنو شغّال صح (بدون التيليغرام)

- ملف السجل الحي بكل الأحداث + الأسعار + التواريخ:
  ```bash
  cat data/trade_journal_live.jsonl
  ```
- ترجع تشوف شاشة البوت الحية:
  ```bash
  tmux attach -t bot
  ```
- للتأكد إنو إدارة الصفقة "ك فهم" (تماشي/TP2) بدون تيليغرام، نفّذ:
  ```bash
  python proof_lifecycle.py
  ```

---

## ⚠️ ملاحظة بخصوص الرصيد عند إعادة التشغيل

كل تشغيل بيبدأ من **$100** (السجل `trade_journal_live.jsonl` بيضل محفوظ بس الرصيد
ما بيرجع لوين ما وصل لو الموبايل انطفأ). إذا بدك الرصيد يكمل من حيث انقطع،
قلي بضيفلك ميزة "استئناف الرصيد من السجل" قبل الأسبوع.

---

## الخلاصة
1. BotFather ← توكن + userinfobot ← chat_id.
2. Termux (F-Droid) + `termux-setup-storage` + `pip install requests python-dotenv pytz numpy`.
3. فك الضغط، حط التوكن/chat_id بـ `.env`.
4. `termux-wake-lock` + `tmux` + أمر التشغيل بـ `--telegram`.
5. ضل الموبايل ع الشاحن، شاشة مطفية، والبوت شغّال 24/7 وبيبعتلك ع التيليغرام.
