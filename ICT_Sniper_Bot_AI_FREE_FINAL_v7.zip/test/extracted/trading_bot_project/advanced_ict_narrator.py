import sys, datetime
sys.path.insert(0, ".")
from brain_core import BrainCore
from ict_math_engine import compute_mechanical_bias_anchor
from authenticity_engine import AuthenticityEngine
from ict_sessions import classify_session

brain = BrainCore()
ae = AuthenticityEngine()

def generate_human_like_narrative(symbol):
    data = brain.data_manager.get_ohlcv(symbol, "15m", 1000, output_format="dict")
    if not data or not data['closes']: return
    
    current_price = data['closes'][-1]
    last_ts = data['timestamps'][-1]
    
    session_info = classify_session(last_ts)
    current_session = session_info.get("session", "UNKNOWN")
    
    try:
        anchor = compute_mechanical_bias_anchor(data, lookback=150)
        bias = anchor.get("anchor_direction")
    except:
        bias = "NONE"

    sig = ae.detect_significant_swings(data, swing_window=1, lookback_candles=150)
    
    print(f"\n{'='*80}")
    print(f"👨‍🏫 [تحليل البوت المفصل] - يتحدث إليك مباشرة من قلب الشارت 📈")
    print(f"العملة: {symbol} | السعر الآن: {current_price:.2f} | الجلسة: {current_session}")
    print(f"{'='*80}\n")

    if bias not in ["BULLISH", "BEARISH"]:
        print("أهلاً بك! نظرت للتو إلى الشارت، وبصراحة لا يعجبني ما أراه.")
        print("السوق حالياً يفتقر إلى اتجاه يومي واضح (Daily Bias). نحن في حالة تذبذب (Chop).")
        print("حسب قواعد مايكل (ICT)، التداول في هذه الظروف هو مجرد مقامرة ومحرقة للأموال.")
        print("لذلك، قراري كبوت محترف هو: 🛑 الجلوس على يدي وعدم الدخول (HOLD). سأنتظر حتى تنجلي الرؤية.\n")
        return

    # استخراج مستويات السيولة
    if bias == "BULLISH":
        targets = [s for s in sig.get("all_lows_tiered", []) if s.get("tier") in ("MAJOR", "MODERATE")]
        target_type = "قيعان (Sell-Side Liquidity)"
        action = "شراء (LONG)"
        trap_direction = "هبوطاً مرعباً"
        fvg_direction = "صاعدة"
    else:
        targets = [s for s in sig.get("all_highs_tiered", []) if s.get("tier") in ("MAJOR", "MODERATE")]
        target_type = "قمم (Buy-Side Liquidity)"
        action = "بيع (SHORT)"
        trap_direction = "صعوداً مغرياً"
        fvg_direction = "هابطة"

    # صياغة الشرح بأسلوب المعلم (Human-like)
    print(f"أهلاً بك يا صديقي! لقد قمت بتشريح شارت {symbol} للتو، وإليك بالضبط ما أفكر فيه وكيف سأتصرف:\n")
    
    print(f"📊 1. الصورة الكبرى (كيف أقرأ الاتجاه؟)")
    print(f"لقد قمت بحساب القمم والقيعان لآخر 250 شمعة رياضياً، والنتيجة قاطعة: الاتجاه العام **{bias}**.")
    print(f"هذا يعني أنني منعت نفسي برمجياً من التفكير في أي صفقات معاكسة. تركيزي كله منصب على البحث عن فرصة {action} فقط.\n")

    if not targets:
        print("لكنني حالياً لا أرى مستويات سيولة قريبة وواضحة لكي يبني الماركت ميكر فخه عليها. سأستمر بالمراقبة.\n")
        return

    print(f"🔍 2. أين يختبئ الماركت ميكر؟ (تحديد الفخاخ)")
    print(f"بما أن الاتجاه {bias}، فأنا أعلم أن صانع السوق لن يدخل قبل أن يطرد المتداولين المبتدئين.")
    print(f"أنا أراقب بصمت هذه الـ {target_type} السابقة، لأن ستوبات الناس تتجمع هناك:")
    for i, t in enumerate(targets[:3]):
        print(f"   🎯 مستوى {t['price']:.2f} (تم تشكيله قبل {abs(t['index_from_end'])} شمعة).")
    
    print(f"\n⚙️ 3. خطة التنفيذ (متى وكيف سأضغط الزناد؟)")
    print(f"أنا لا أطارد السعر الحالي ({current_price:.2f}). ما أنتظره هو سيناريو محدد (If -> Then):")
    print(f"👉 **إذا** تحرك السعر {trap_direction} وكسر أحد المستويات المذكورة أعلاه...")
    print(f"👉 **وإذا** لم يغلق بقوة خلفه، بل شكل 'ذيلاً' (Wick) وارتد بسرعة صانعاً إزاحة (Displacement)...")
    print(f"👉 **عندها** سأعلم أن الفخ قد نُصب بنجاح (Judas Swing)!")
    
    print(f"\n🛡️ 4. الدخول وإدارة المخاطر (كيف سأحميك؟)")
    print(f"بمجرد تأكيد الفخ على فريم 5 دقائق، سأفعل التالي فوراً:")
    print(f"  - سأضع أمر {action} معلق (Limit Order) في منتصف الفجوة السعرية الـ {fvg_direction} (FVG CE).")
    print(f"  - سأضع الستوب لوس (SL) خلف ذيل الفخ مباشرة بمسافة أمان رياضية، ليكون الستوب صغيراً جداً.")
    print(f"  - لن أطمع! سأحدد أول سيولة داخلية تعطيني ربح (1.5 إلى 2 ضعف المخاطرة).")
    print(f"  - بمجرد ضربها، سأبيع 80% من الكمية (لأدفع لك راتبك)، وسأنقل ستوب الكمية الباقية إلى الدخول (Break-Even).")
    print(f"  - سأترك الكمية المتبقية (Runner) لتلاحق الترند بلا أي مخاطرة!")
    
    print("\nأنا الآن في وضع الاستعداد والمراقبة ⏳...\n")

for sym in ["ETH/USDT"]:
    generate_human_like_narrative(sym)
