import requests

url = "https://data-api.binance.vision/api/v3/klines"
params = {
    "symbol": "SOLUSDT",
    "interval": "15m",
    "limit": 5
}
resp = requests.get(url, params=params)
for c in resp.json():
    print(f"Time: {c[0]}, Open: {c[1]}, High: {c[2]}, Low: {c[3]}, Close: {c[4]}")
