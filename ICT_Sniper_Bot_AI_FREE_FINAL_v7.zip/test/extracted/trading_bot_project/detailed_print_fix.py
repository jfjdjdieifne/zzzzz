import re

with open("algo_master.py", "r", encoding="utf-8") as f:
    content = f.read()

# We want to replace the block starting at `valid_target = None` up to `dist = abs(current_p - target_lvl)`

new_block = """                valid_target = None
                ttype = ""
                recent_sweep_found = False
                swept_price = 0.0
                n_15m = len(closed_15m['closes'])
                
                if bias == "BULLISH":
                    lows_raw = [s for s in sig.get("all_lows_tiered", []) if s['price'] < current_p and s.get("tier") in ["MAJOR", "MODERATE"]]
                    lows = []
                    check_idx = n_15m - 1
                    for s in lows_raw:
                        s_idx = n_15m + s['index_from_end']
                        if s_idx < check_idx - 1:
                            min_before = min(closed_15m['lows'][s_idx+1 : check_idx])
                            if min_before < s['price']: continue
                        lows.append(s)
                    if lows:
                        lows.sort(key=lambda x: current_p - x['price'])
                        valid_target = lows[0]
                        ttype = "قاع سيولة (SSL)"
                        
                    for s in sig.get("all_lows_tiered", []):
                        if s.get("tier") in ["MAJOR", "MODERATE"]:
                            s_idx = n_15m + s['index_from_end']
                            check_start = max(s_idx + 1, n_15m - 10)
                            if check_start < n_15m:
                                min_recent = min(closed_15m['lows'][check_start : n_15m])
                                if min_recent < s['price']:
                                    for i in range(check_start, n_15m):
                                        if closed_15m['lows'][i] < s['price'] and closed_15m['closes'][i] > s['price']:
                                            recent_sweep_found = True
                                            swept_price = s['price']
                                            break
                        if recent_sweep_found: break
                else:
                    highs_raw = [s for s in sig.get("all_highs_tiered", []) if s['price'] > current_p and s.get("tier") in ["MAJOR", "MODERATE"]]
                    highs = []
                    check_idx = n_15m - 1
                    for s in highs_raw:
                        s_idx = n_15m + s['index_from_end']
                        if s_idx < check_idx - 1:
                            max_before = max(closed_15m['highs'][s_idx+1 : check_idx])
                            if max_before > s['price']: continue
                        highs.append(s)
                    if highs:
                        highs.sort(key=lambda x: x['price'] - current_p)
                        valid_target = highs[0]
                        ttype = "قمة سيولة (BSL)"
                        
                    for s in sig.get("all_highs_tiered", []):
                        if s.get("tier") in ["MAJOR", "MODERATE"]:
                            s_idx = n_15m + s['index_from_end']
                            check_start = max(s_idx + 1, n_15m - 10)
                            if check_start < n_15m:
                                max_recent = max(closed_15m['highs'][check_start : n_15m])
                                if max_recent > s['price']:
                                    for i in range(check_start, n_15m):
                                        if closed_15m['highs'][i] > s['price'] and closed_15m['closes'][i] < s['price']:
                                            recent_sweep_found = True
                                            swept_price = s['price']
                                            break
                        if recent_sweep_found: break

                print(f"\\n{'='*60}")
                print(f"🪙 تحليل الزوج: {symbol} | السعر اللحظي: {current_p:.4f}")
                print(f"📅 فريم اليوم (1D) -> الاتجاه العام: {'شراء صاعد 🟢 (BULLISH)' if bias == 'BULLISH' else 'بيع هابط 🔴 (BEARISH)'}")

                if recent_sweep_found:
                    print(f"🔍 فريم الربع ساعة (15m) -> ⚡ رصدت سحب سيولة قوي للتو!")
                    print(f"   لقد قام السعر بضرب مستوى السيولة {'(SSL)' if bias == 'BULLISH' else '(BSL)'} عند السعر [{swept_price:.4f}]، ثم ارتد وأغلق بنجاح (Sweep).")
                    print(f"   الآن أغوص لفريم الـ (5m) لفحص هيكل الدخول (Models)...")
                    
                    data_5m = brain.data_manager.fetch_ohlcv_up_to(symbol, "5m", int(time.time()*1000), limit=150)
                    res_5m = evaluate_all_entry_models(data_5m, bias)
                    
                    chosen = res_5m.get("chosen_model")
                    if chosen:
                        status_arb = "جاهز للدخول 🚀" if chosen['status'] == "READY" else "قيد التشكل والانتظار ⏳"
                        print(f"\\n🎯 الموديل المعتمد: {chosen.get('model')} | الحالة: {status_arb}")
                        print("📋 شروط الموديل التفصيلية:")
                        for cond in chosen.get("conditions", []):
                            status_ico = "✅ تحقق" if cond['status'] == True else ("❌ لم يتحقق" if cond['status'] == False else "⏳ قيد الانتظار")
                            print(f"   {status_ico} | {cond['name']}: {cond['detail']}")
                            
                    if res_5m.get("final_status") == "READY":
                        plan = res_5m.get("chosen_model", {}).get("plan", {})
                        entry, sl, tp1 = plan.get("entry"), plan.get("stop_loss"), plan.get("tp")
                        if entry and sl and tp1:
                            risk_dist = abs(entry - sl)
                            risk_usd = account * RISK_PCT
                            pos_size = risk_usd / risk_dist if risk_dist > 0 else 0
                            
                            print_banner(f"🔥 تم الدخول في الصفقة آلياً! {symbol} 🔥")
                            print(f"الاتجاه: {'بيع 🔴' if bias == 'BEARISH' else 'شراء 🟢'} | النموذج: {res_5m.get('chosen_model',{}).get('model')}")
                            print(f"نقطة الدخول: {entry:.4f} | الستوب: {sl:.4f} | الهدف (50%): {tp1:.4f}")
                            print(f"حجم العقد: {pos_size:.4f} | المخاطرة المحسوبة: {risk_usd:.2f}$")
                            
                            active_trades[symbol] = {
                                "bias": bias, "entry": entry, "sl": sl, "tp1": tp1,
                                "current_sl": sl, "be_activated": False, "tp1_hit": False,
                                "is_short": bias == "BEARISH", "risk": risk_dist, "size": pos_size,
                                "risk_usd": risk_usd
                            }
                    else:
                        print("\\n⏳ الخلاصة: الموديل لم يكتمل بعد. أراقب الشارت بانتظار الشروط المتبقية (مثلاً: فجوة FVG أو إغلاق تأكيدي).")
                    
                    print(f"{'='*60}\\n")
                    continue
                
                if not valid_target:
                    print(f"🔍 فريم الربع ساعة (15m) -> 👁️ أراقب. لا توجد فخاخ سيولة غير ملموسة أعلى/أسفل السعر حالياً.")
                    print(f"{'='*60}\\n")
                    continue
                    
                target_lvl = valid_target['price']
                dist = abs(current_p - target_lvl)
                print(f"🔍 فريم الربع ساعة (15m) -> 🎯 أنتظر بصمت أن يقوم السعر بضرب {ttype} غير الملموس عند السعر [{target_lvl:.4f}] (يبعد عنا {dist:.4f}$).")
                print(f"{'='*60}\\n")
"""

import re
# We locate the block using regular expressions matching our old block from the previous step
# Specifically, matching `valid_target = None` up to `dist = abs(current_p - target_lvl)`

start_str = "valid_target = None"
end_str = "dist = abs(current_p - target_lvl)"

start_idx = content.find(start_str)
end_idx = content.find(end_str)

if start_idx != -1 and end_idx != -1:
    end_idx += len(end_str)
    # We replace everything between start_idx and end_idx with new_block + "                dist = abs(current_p - target_lvl)" -> wait I removed dist calculation from after the block.
    content = content[:start_idx] + new_block + content[end_idx:]
    
    with open("algo_master.py", "w", encoding="utf-8") as f:
        f.write(content)
    print("algo_master.py updated with highly detailed prints.")
else:
    print("Could not find the block in algo_master.py")
