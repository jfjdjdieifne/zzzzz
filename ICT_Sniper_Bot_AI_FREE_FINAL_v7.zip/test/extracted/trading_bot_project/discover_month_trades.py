import json, datetime, sys
sys.path.insert(0, ".")
from brain_core import BrainCore
from ict_math_engine import compute_mechanical_bias_anchor, classify_sweep_or_run
from authenticity_engine import AuthenticityEngine

brain = BrainCore()
ae = AuthenticityEngine()
SYMBOL = "ETH/USDT"

print("جاري مسح الشهر الماضي بالكامل ببيانات كافية...")

# نجلب بيانات 5 أشهر لضمان أننا نغطي الشهر الماضي بكل أريحية
full_data = brain.data_manager.get_ohlcv(SYMBOL, "15m", 8000, output_format="dict")
n = len(full_data["closes"])
candidates = []
already_reported = set()

# شهر كامل على 15 دقيقة = 2880 شمعة
# سنفحص من (n - 2880) إلى n
start_idx = max(500, n - 3000)

for i in range(start_idx, n):
    window_data = {
        "opens": full_data["opens"][:i+1], "highs": full_data["highs"][:i+1],
        "lows": full_data["lows"][:i+1], "closes": full_data["closes"][:i+1],
        "timestamps": full_data["timestamps"][:i+1],
    }

    try:
        anchor = compute_mechanical_bias_anchor(window_data, lookback=150) # lookback أقل ليعطي اتجاه أسرع
    except Exception:
        continue
    daily_bias = anchor.get("anchor_direction")
    if daily_bias not in ("BULLISH", "BEARISH"):
        continue

    try:
        # نبحث عن السوينغات خلال آخر أسبوعين (lookback=500 شمعة 15m)
        sig = ae.detect_significant_swings(window_data, swing_window=2, lookback_candles=500)
    except Exception:
        continue

    n_window = len(window_data["closes"])
    current_ts = window_data["timestamps"][-1]

    if daily_bias == "BULLISH":
        important_levels = [s for s in sig.get("all_lows_tiered", []) if s.get("tier") in ("MAJOR", "MODERATE", "MINOR")]
        for candidate in important_levels:
            level_price = candidate["price"]
            key = round(level_price, 2)
            res = classify_sweep_or_run(window_data, level_price, level_is_high=False, check_from_idx=i)
            
            if res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP" and res.get("candle_index_from_end") >= -2:
                # نمنع تكرار الإشارة لنفس اليوم/المنطقة
                if not any(abs(c["timestamp"] - current_ts) < 12*3600*1000 for c in candidates):
                    dt = datetime.datetime.fromtimestamp(current_ts/1000, tz=datetime.timezone.utc)
                    candidates.append({
                        "timestamp": current_ts, "datetime_utc": dt.isoformat(),
                        "mechanical_bias": daily_bias, "sweep_type": "SSL_SWEPT_LOW", "swept_level_price": level_price
                    })
                    break
    else:
        important_levels = [s for s in sig.get("all_highs_tiered", []) if s.get("tier") in ("MAJOR", "MODERATE", "MINOR")]
        for candidate in important_levels:
            level_price = candidate["price"]
            key = round(level_price, 2)
            res = classify_sweep_or_run(window_data, level_price, level_is_high=True, check_from_idx=i)
            
            if res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP" and res.get("candle_index_from_end") >= -2:
                if not any(abs(c["timestamp"] - current_ts) < 12*3600*1000 for c in candidates):
                    dt = datetime.datetime.fromtimestamp(current_ts/1000, tz=datetime.timezone.utc)
                    candidates.append({
                        "timestamp": current_ts, "datetime_utc": dt.isoformat(),
                        "mechanical_bias": daily_bias, "sweep_type": "BSL_SWEPT_HIGH", "swept_level_price": level_price
                    })
                    break

candidates.sort(key=lambda c: c["timestamp"])
print(f"✅ تم اكتشاف {len(candidates)} صفقة محتملة خلال الشهر الماضي.")

with open('/tmp/month_candidates_real.json', 'w') as f:
    json.dump(candidates, f, indent=2)

