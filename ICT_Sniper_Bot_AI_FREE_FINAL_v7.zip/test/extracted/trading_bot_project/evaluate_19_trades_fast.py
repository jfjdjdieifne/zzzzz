import json, sys
sys.path.insert(0, ".")
from brain_core import BrainCore
from human_trades_backtest import compute_trade_outcome

brain = BrainCore()

with open('human_trades/all_human_trades_with_outcomes.json') as f:
    trades = json.load(f)

print("="*100)
print(f"{'الرقم':<4} | {'الرمز':<8} | {'التاريخ':<12} | {'الاتجاه':<6} | {'النتيجة':<20} | {'الربح R:R'}")
print("="*100)

total_rr = 0.0

# سنجلب الداتا دفعة واحدة لتسريع العملية وعدم حدوث timeout
data_cache_5m = {}

for t in trades[-10:]: # نقيم آخر 10 فقط للسرعة
    symbol = t.get('symbol')
    publish_ts = t.get('publish_ts')
    
    entry_raw = t.get('entry')
    if isinstance(entry_raw, list): entry = (entry_raw[0] + entry_raw[1]) / 2.0
    else: entry = float(entry_raw)
    
    sl_raw = t.get('sl')
    if isinstance(sl_raw, list): sl = float(sl_raw[0])
    else: sl = float(sl_raw)
    
    tp_raw = t.get('tp')
    if tp_raw is None: tp = entry * 1.1 if "LONG" in t.get('human_bias', '').upper() else entry * 0.9
    elif isinstance(tp_raw, list): tp = float(tp_raw[0])
    else: tp = float(tp_raw)
    
    is_short = "SHORT" in t.get('human_bias', '').upper() or "BEAR" in t.get('human_bias', '').upper()
    
    res = compute_trade_outcome(brain, symbol, publish_ts, entry, sl, tp, is_short)
    
    outcome = res.get('outcome', 'UNKNOWN')
    pnl_pct = res.get('pnl_pct', 0.0)
    
    risk_pct = abs(entry - sl) / entry * 100
    rr_gained = pnl_pct / risk_pct if risk_pct > 0 else 0
    if rr_gained < -1.0: rr_gained = -1.0
    
    total_rr += rr_gained
    
    out_label = outcome
    if outcome == "DYNAMIC_TRAIL_HIT" or outcome == "OPEN": out_label = "قنص وتتبع 🧠🎯"
    elif outcome in ["TP1_THEN_BE", "PARTIAL_TP_HIT_THEN_OPEN"]: out_label = "ربح جزئي وتأمين 🎯"
    elif outcome == "BREAK_EVEN_HIT": out_label = "خروج عالدخول 🛡️"
    elif outcome == "SL_HIT": out_label = "ستوب لوس ❌"
    elif outcome == "ENTRY_NEVER_HIT": out_label = "لم تتفعل ⏳"
    
    direction = "SHORT" if is_short else "LONG"
    print(f"{t['id']:<4} | {symbol:<8} | {t['publish_date']:<12} | {direction:<6} | {out_label:<20} | {rr_gained:+.2f} R")

print("="*100)
print(f"إجمالي الأرباح للـ 10 صفقات البشرية الأخيرة: {total_rr:+.2f} R")
