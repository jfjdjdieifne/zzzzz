import re

with open("algo_master.py", "r", encoding="utf-8") as f:
    lines = f.readlines()

start_idx = -1
end_idx = -1

for i, line in enumerate(lines):
    if "if bias == \"BULLISH\":" in line and "lows_raw" in lines[i+1]:
        start_idx = i
        break

for i in range(start_idx, len(lines)):
    if "res = classify_sweep_or_run" in lines[i]:
        end_idx = i
        break

new_block = """                valid_target = None
                ttype = ""
                recent_sweep_found = False
                n_15m = len(closed_15m['closes'])
                
                if bias == "BULLISH":
                    lows_raw = [s for s in sig.get("all_lows_tiered", []) if s['price'] < current_p and s.get("tier") in ["MAJOR", "MODERATE"]]
                    lows = []
                    check_idx = n_15m - 1
                    for s in lows_raw:
                        s_idx = n_15m + s['index_from_end']
                        if s_idx < check_idx - 1:
                            min_before = min(closed_15m['lows'][s_idx+1 : check_idx])
                            if min_before < s['price']: continue
                        lows.append(s)
                    if lows:
                        lows.sort(key=lambda x: current_p - x['price'])
                        valid_target = lows[0]
                        ttype = "قاع سيولة (SSL)"
                        
                    for s in sig.get("all_lows_tiered", []):
                        if s.get("tier") in ["MAJOR", "MODERATE"]:
                            s_idx = n_15m + s['index_from_end']
                            check_start = max(s_idx + 1, n_15m - 10)
                            if check_start < n_15m:
                                min_recent = min(closed_15m['lows'][check_start : n_15m])
                                if min_recent < s['price']:
                                    for i in range(check_start, n_15m):
                                        if closed_15m['lows'][i] < s['price'] and closed_15m['closes'][i] > s['price']:
                                            recent_sweep_found = True
                                            break
                        if recent_sweep_found: break
                else:
                    highs_raw = [s for s in sig.get("all_highs_tiered", []) if s['price'] > current_p and s.get("tier") in ["MAJOR", "MODERATE"]]
                    highs = []
                    check_idx = n_15m - 1
                    for s in highs_raw:
                        s_idx = n_15m + s['index_from_end']
                        if s_idx < check_idx - 1:
                            max_before = max(closed_15m['highs'][s_idx+1 : check_idx])
                            if max_before > s['price']: continue
                        highs.append(s)
                    if highs:
                        highs.sort(key=lambda x: x['price'] - current_p)
                        valid_target = highs[0]
                        ttype = "قمة سيولة (BSL)"
                        
                    for s in sig.get("all_highs_tiered", []):
                        if s.get("tier") in ["MAJOR", "MODERATE"]:
                            s_idx = n_15m + s['index_from_end']
                            check_start = max(s_idx + 1, n_15m - 10)
                            if check_start < n_15m:
                                max_recent = max(closed_15m['highs'][check_start : n_15m])
                                if max_recent > s['price']:
                                    for i in range(check_start, n_15m):
                                        if closed_15m['highs'][i] > s['price'] and closed_15m['closes'][i] < s['price']:
                                            recent_sweep_found = True
                                            break
                        if recent_sweep_found: break

                if recent_sweep_found:
                    print(f"🪙 {symbol:<9} | السعر: {current_p:.4f} | 🧭 {bias:<7} | ⚡ حدث سحب سيولة مؤخراً! أغوص لفريم 5m لأنتظر تشكل فجوة (FVG) للدخول.")
                    
                    data_5m = brain.data_manager.fetch_ohlcv_up_to(symbol, "5m", int(time.time()*1000), limit=150)
                    res_5m = evaluate_all_entry_models(data_5m, bias)
                    
                    if res_5m.get("final_status") == "READY":
                        plan = res_5m.get("chosen_model", {}).get("plan", {})
                        entry, sl, tp1 = plan.get("entry"), plan.get("stop_loss"), plan.get("tp")
                        if entry and sl and tp1:
                            risk_dist = abs(entry - sl)
                            risk_usd = account * RISK_PCT
                            pos_size = risk_usd / risk_dist if risk_dist > 0 else 0
                            
                            print_banner(f"🔥 تم الدخول في الصفقة آلياً! {symbol} 🔥")
                            print(f"الاتجاه: {'بيع 🔴' if bias == 'BEARISH' else 'شراء 🟢'} | النموذج: {res_5m.get('chosen_model',{}).get('model')}")
                            print(f"نقطة الدخول: {entry:.4f} | الستوب: {sl:.4f} | الهدف (50%): {tp1:.4f}")
                            print(f"حجم العقد: {pos_size:.4f} | المخاطرة المحسوبة: {risk_usd:.2f}$")
                            
                            active_trades[symbol] = {
                                "bias": bias, "entry": entry, "sl": sl, "tp1": tp1,
                                "current_sl": sl, "be_activated": False, "tp1_hit": False,
                                "is_short": bias == "BEARISH", "risk": risk_dist, "size": pos_size,
                                "risk_usd": risk_usd
                            }
                    continue
                
                if not valid_target:
                    print(f"🪙 {symbol:<9} | السعر: {current_p:.4f} | 🧭 {bias:<7} | 👁️ أراقب. لا توجد فخاخ غير ملموسة أسفل/أعلى السعر.")
                    continue
                    
                target_lvl = valid_target['price']
                dist = abs(current_p - target_lvl)
"""
if start_idx != -1 and end_idx != -1:
    lines[start_idx:end_idx] = [new_block + "\n"]
    with open("algo_master.py", "w", encoding="utf-8") as f:
        f.writelines(lines)
    print("Fixed algo_master.py correctly.")
else:
    print(f"Could not find block: {start_idx}, {end_idx}")

