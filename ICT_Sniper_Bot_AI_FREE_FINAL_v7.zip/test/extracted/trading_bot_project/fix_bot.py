import re

def fix_file(filepath):
    with open(filepath, "r", encoding="utf-8") as f:
        content = f.read()

    # Define the new logic to insert
    new_logic_bullish = """lows_raw = [s for s in sig.get("all_lows_tiered", []) if s['price'] < current_p and s.get("tier") in ["MAJOR", "MODERATE"]]
                            lows = []
                            n_closes = len(closed_15m['closes'])
                            check_idx = n_closes - 1
                            for s in lows_raw:
                                s_idx = n_closes + s['index_from_end']
                                if s_idx < check_idx - 1:
                                    min_before = min(closed_15m['lows'][s_idx+1 : check_idx])
                                    if min_before < s['price']:
                                        continue
                                lows.append(s)
                            if lows:
                                lows.sort(key=lambda x: current_p - x['price'])
                                valid_target = lows[0]
                                ttype = "قاع سيولة (SSL)\""""

    new_logic_bearish = """highs_raw = [s for s in sig.get("all_highs_tiered", []) if s['price'] > current_p and s.get("tier") in ["MAJOR", "MODERATE"]]
                            highs = []
                            n_closes = len(closed_15m['closes'])
                            check_idx = n_closes - 1
                            for s in highs_raw:
                                s_idx = n_closes + s['index_from_end']
                                if s_idx < check_idx - 1:
                                    max_before = max(closed_15m['highs'][s_idx+1 : check_idx])
                                    if max_before > s['price']:
                                        continue
                                highs.append(s)
                            if highs:
                                highs.sort(key=lambda x: x['price'] - current_p)
                                valid_target = highs[0]
                                ttype = "قمة سيولة (BSL)\""""

    # Pattern for BULLISH
    pattern_bullish = r'lows\s*=\s*\[s for s in sig\.get\("all_lows_tiered", \[\]\) if s\[\'price\'\] < current_p and s\.get\("tier"\) in \["MAJOR", "MODERATE"\]\]\s*if lows:\s*lows\.sort\(key=lambda x:\s*current_p\s*-\s*x\[\'price\'\]\)\s*valid_target\s*=\s*lows\[0\](?:\s*ttype\s*=\s*"[^"]+")?'
    
    # Pattern for BEARISH
    pattern_bearish = r'highs\s*=\s*\[s for s in sig\.get\("all_highs_tiered", \[\]\) if s\[\'price\'\] > current_p and s\.get\("tier"\) in \["MAJOR", "MODERATE"\]\]\s*if highs:\s*highs\.sort\(key=lambda x:\s*x\[\'price\'\]\s*-\s*current_p\)\s*valid_target\s*=\s*highs\[0\](?:\s*ttype\s*=\s*"[^"]+")?'

    # Determine indentation
    bullish_match = re.search(pattern_bullish, content)
    if bullish_match:
        indent = re.search(r'^(\s*)lows\s*=', content[content.rfind('\n', 0, bullish_match.start()):bullish_match.start()+10], re.MULTILINE)
        indent_str = indent.group(1) if indent else '                            '
        new_b = new_logic_bullish.replace('\n                            ', '\n' + indent_str)
        content = content[:bullish_match.start()] + new_b + content[bullish_match.end():]

    bearish_match = re.search(pattern_bearish, content)
    if bearish_match:
        indent = re.search(r'^(\s*)highs\s*=', content[content.rfind('\n', 0, bearish_match.start()):bearish_match.start()+10], re.MULTILINE)
        indent_str = indent.group(1) if indent else '                            '
        new_r = new_logic_bearish.replace('\n                            ', '\n' + indent_str)
        content = content[:bearish_match.start()] + new_r + content[bearish_match.end():]

    with open(filepath, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"Fixed {filepath}")

fix_file("algo_master.py")
fix_file("telegram_algo_master.py")
fix_file("human_trades_backtest.py") # Might not have it, but let's check
