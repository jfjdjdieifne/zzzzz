import re
with open("algo_master.py", "r") as f:
    content = f.read()

# Let's fix the loops to be perfectly matched.
# It seems my previous regex `content.replace('for i in range(start_idx, n, 8):', 'for i in range(start_idx, n, 2):')` failed or caused an issue.

old_str1 = """            for i in range(start_idx, n, 10): 
                current_step += 1
                if current_step % 20 == 0:
                    sys.stdout.write(f"\\r     -> فحص الشموع ({current_step}/{total_steps}) 진행...")
                    sys.stdout.flush()"""

new_str1 = """            for i in range(start_idx, n, 4): 
                current_step += 1
                if current_step % 50 == 0:
                    sys.stdout.write(f"\\r     -> فحص الشموع ({current_step}) 진행...")
                    sys.stdout.flush()"""

content = content.replace(old_str1, new_str1)

# And fix the loop in telegram_algo_master.py too
with open("algo_master.py", "w") as f:
    f.write(content)
print("تم")
