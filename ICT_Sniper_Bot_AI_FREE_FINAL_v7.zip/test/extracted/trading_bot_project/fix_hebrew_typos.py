import os

files = ["algo_master.py", "telegram_algo_master.py", "fix_live_print.py", "live_solana_check.py"]

for file in files:
    if os.path.exists(file):
        with open(file, 'r', encoding='utf-8') as f:
            content = f.read()
        content = content.replace("הסعر", "السعر")
        content = content.replace("מلموسة", "ملموسة")
        content = content.replace("הستوب", "الستوب")
        with open(file, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"Fixed typos in {file}")
