import re

with open("algo_master.py", "r") as f:
    content = f.read()

old_block = """                    if not levels:
                        print("   🔍 فريم (15m)   -> 👁️ لا توجد سيولة (Major/Moderate) قريبة. البوت يراقب تشكل قمم/قيعان جديدة.")
                        continue
                        
                    target_lvl = levels[0]['price']
                    dist = abs(current_p - target_lvl)
                    target_type = "قاع (Sell-Side Liquidity)" if bias == "BULLISH" else "قمة (Buy-Side Liquidity)"
                    
                    print(f"   🔍 فريم (15m)   -> 🎯 أنتظر ضرب {target_type} عند السعر [{target_lvl:.4f}] (المسافة: {dist:.4f}$)")
                    
                    # هل تم الضرب للتو؟
                    res = classify_sweep_or_run(data_15m, target_lvl, level_is_high=(bias=="BEARISH"), check_from_idx=len(data_15m['closes'])-1)
                    if res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP" and res.get("candle_index_from_end") >= -2:
                        print(f"   ⚠️ فريم (15m)   -> 🚨 الماركت ميكر ضرب السيولة للتو وشكل ذيلاً (Sweep)!")"""

new_block = """                    if not levels:
                        print("   🔍 فريم (15m)   -> 👁️ لا توجد سيولة (Major/Moderate) قريبة. البوت يراقب تشكل قمم/قيعان جديدة.")
                        continue
                        
                    target_lvl = levels[0]['price']
                    dist = abs(current_p - target_lvl)
                    target_type = "قاع (Sell-Side Liquidity)" if bias == "BULLISH" else "قمة (Buy-Side Liquidity)"
                    
                    res = classify_sweep_or_run(data_15m, target_lvl, level_is_high=(bias=="BEARISH"), check_from_idx=len(data_15m['closes'])-1)
                    
                    # الذكاء اللفظي: قراءة علاقة السعر بالهدف
                    is_crossing = (bias == "BEARISH" and current_p >= target_lvl) or (bias == "BULLISH" and current_p <= target_lvl)
                    
                    if res.get("classification") == "LIQUIDITY_RUN_CONTINUATION":
                        print(f"   ❌ فريم (15m)   -> تم اختراق {target_type} [{target_lvl:.4f}] بقوة مسبقاً (Run). هذا ليس فخاً! البوت يبحث عن سيولة جديدة.")
                    elif res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP" and res.get("candle_index_from_end") >= -2:
                        print(f"   ⚠️ فريم (15m)   -> 🚨 الماركت ميكر ضرب السيولة [{target_lvl:.4f}] للتو وشكل ذيلاً (Sweep)!")
                    elif is_crossing:
                        print(f"   🔥 فريم (15m)   -> السعر الآن ({current_p:.4f}) يتجاوز الهدف [{target_lvl:.4f}]! نراقب الشمعة الحية لنرى هل سترتد لتشكل פخاً (Wick) أم اختراقاً.")
                    else:
                        print(f"   🔍 فريم (15m)   -> 🎯 أنتظر ضرب {target_type} عند السعر [{target_lvl:.4f}] (المسافة المتبقية: {dist:.4f}$)")"""

content = content.replace(old_block, new_block)

# تحديث رسالة فريم 5 دقائق بناء على حالة 15 دقيقة
old_5m_wait = """                    else:
                        print("   🔫 فريم (5m)    -> ⏳ البوت في وضع الاستعداد بانتظار ضرب الهدف المبين أعلاه.")"""

new_5m_wait = """                    else:
                        if is_crossing and res.get("classification") != "LIQUIDITY_RUN_CONTINUATION":
                            print("   🔫 فريم (5m)    -> ⏳ ننتظر إغلاق شمعة الـ 15 دقيقة لتأكيد السحب، ثم سنبحث عن الفجوة هنا.")
                        elif res.get("classification") == "LIQUIDITY_RUN_CONTINUATION":
                            print("   🔫 فريم (5m)    -> 🛑 تم إلغاء المراقبة لأن الاختراق היה حقيقياً (Run).")
                        else:
                            print("   🔫 فريم (5m)    -> ⏳ البوت في وضع الاستعداد بانتظار وصول السعر للهدف المبين أعلاه.")"""

content = content.replace(old_5m_wait, new_5m_wait)

with open("algo_master.py", "w") as f:
    f.write(content)
print("تم إصلاح ذكاء الطباعة في الرادار الحي!")
