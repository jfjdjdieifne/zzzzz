import re

def insert_state_machine(filepath):
    with open(filepath, "r", encoding="utf-8") as f:
        content = f.read()

    # We need to find the section where the target logic is.
    # When NO TARGET is found, it says "أراقب".
    # BUT, we need to add logic: "Wait, did a sweep just happen recently? If so, I am not watching for a target, I am waiting for an FVG setup on the 5m chart!"
    
    # We will replace the logic where valid_target is checked.
    
    new_logic = """                # Check if a sweep recently happened in the last 20 candles!
                recent_sweep_found = False
                n_15m = len(closed_15m['closes'])
                if bias == "BULLISH":
                    for s in sig.get("all_lows_tiered", []):
                        if s.get("tier") in ["MAJOR", "MODERATE"]:
                            s_idx = n_15m + s['index_from_end']
                            # Did we sweep it recently? (Last 10 candles)
                            check_start = max(s_idx + 1, n_15m - 10)
                            if check_start < n_15m:
                                min_recent = min(closed_15m['lows'][check_start : n_15m])
                                if min_recent < s['price']:
                                    # Swept recently! Did it close above?
                                    for i in range(check_start, n_15m):
                                        if closed_15m['lows'][i] < s['price'] and closed_15m['closes'][i] > s['price']:
                                            recent_sweep_found = True
                                            break
                        if recent_sweep_found: break
                else:
                    for s in sig.get("all_highs_tiered", []):
                        if s.get("tier") in ["MAJOR", "MODERATE"]:
                            s_idx = n_15m + s['index_from_end']
                            check_start = max(s_idx + 1, n_15m - 10)
                            if check_start < n_15m:
                                max_recent = max(closed_15m['highs'][check_start : n_15m])
                                if max_recent > s['price']:
                                    for i in range(check_start, n_15m):
                                        if closed_15m['highs'][i] > s['price'] and closed_15m['closes'][i] < s['price']:
                                            recent_sweep_found = True
                                            break
                        if recent_sweep_found: break
                        
                if recent_sweep_found and not valid_target:
                    print(f"🪙 {symbol:<9} | السعر: {current_p:.4f} | 🧭 {bias:<7} | ⚡ حدث سحب سيولة مؤخراً! أغوص لفريم 5m لأنتظر تشكل فجوة FVG للدخول.")
                    
                    data_5m = brain.data_manager.fetch_ohlcv_up_to(symbol, "5m", int(time.time()*1000), limit=150)
                    res_5m = evaluate_all_entry_models(data_5m, bias)
                    
                    if res_5m.get("final_status") == "READY":
                        plan = res_5m.get("chosen_model", {}).get("plan", {})
                        entry, sl, tp1 = plan.get("entry"), plan.get("stop_loss"), plan.get("tp")
                        if entry and sl and tp1:
                            risk_dist = abs(entry - sl)
                            risk_usd = account * RISK_PCT
                            pos_size = risk_usd / risk_dist if risk_dist > 0 else 0
                            
                            print_banner(f"🔥 تم الدخول في الصفقة آلياً! {symbol} 🔥")
                            print(f"الاتجاه: {'بيع 🔴' if bias == 'BEARISH' else 'شراء 🟢'} | النموذج: {res_5m.get('chosen_model',{}).get('model')}")
                            print(f"نقطة الدخول: {entry:.4f} | الستوب: {sl:.4f} | الهدف (50%): {tp1:.4f}")
                            print(f"حجم العقد: {pos_size:.4f} | المخاطرة المحسوبة: {risk_usd:.2f}$")
                            
                            active_trades[symbol] = {
                                "bias": bias, "entry": entry, "sl": sl, "tp1": tp1,
                                "current_sl": sl, "be_activated": False, "tp1_hit": False,
                                "is_short": bias == "BEARISH", "risk": risk_dist, "size": pos_size,
                                "risk_usd": risk_usd
                            }
                    continue
"""
    
    # We will search for 'if not valid_target:'
    pattern = r'(\s*)if not valid_target:\n\s*print\(f"🪙 \{symbol:<9\} \| السعر.*'
    
    match = re.search(pattern, content)
    if match:
        original = match.group(0)
        replacement = original + "\n" + new_logic
        content = content.replace(original, replacement)
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(content)
        print(f"Updated {filepath} with recent sweep logic.")

insert_state_machine("algo_master.py")
insert_state_machine("telegram_algo_master.py")
