import re

def insert_state_machine_telegram(filepath):
    with open(filepath, "r", encoding="utf-8") as f:
        content = f.read()

    new_logic = """                        # Check if a sweep recently happened in the last 20 candles!
                        recent_sweep_found = False
                        n_15m = len(closed_15m['closes'])
                        if bias == "BULLISH":
                            for s in sig.get("all_lows_tiered", []):
                                if s.get("tier") in ["MAJOR", "MODERATE"]:
                                    s_idx = n_15m + s['index_from_end']
                                    check_start = max(s_idx + 1, n_15m - 10)
                                    if check_start < n_15m:
                                        min_recent = min(closed_15m['lows'][check_start : n_15m])
                                        if min_recent < s['price']:
                                            for i in range(check_start, n_15m):
                                                if closed_15m['lows'][i] < s['price'] and closed_15m['closes'][i] > s['price']:
                                                    recent_sweep_found = True
                                                    break
                                if recent_sweep_found: break
                        else:
                            for s in sig.get("all_highs_tiered", []):
                                if s.get("tier") in ["MAJOR", "MODERATE"]:
                                    s_idx = n_15m + s['index_from_end']
                                    check_start = max(s_idx + 1, n_15m - 10)
                                    if check_start < n_15m:
                                        max_recent = max(closed_15m['highs'][check_start : n_15m])
                                        if max_recent > s['price']:
                                            for i in range(check_start, n_15m):
                                                if closed_15m['highs'][i] > s['price'] and closed_15m['closes'][i] < s['price']:
                                                    recent_sweep_found = True
                                                    break
                                if recent_sweep_found: break
                                
                        if recent_sweep_found and not valid_target:
                            bot_status_lines.append(f"🪙 {symbol}  | السعر: {current_p:.4f} | 🧭 {bias:<7} | ⚡ سحب سيولة سابق! أنتظر تشكل FVG على (5m).")
                            
                            data_5m = brain.data_manager.fetch_ohlcv_up_to(symbol, "5m", int(time.time()*1000), limit=150)
                            res_5m = evaluate_all_entry_models(data_5m, bias)
                            
                            if res_5m.get("final_status") == "READY":
                                plan = res_5m.get("chosen_model", {}).get("plan", {})
                                entry, sl, tp1 = plan.get("entry"), plan.get("stop_loss"), plan.get("tp")
                                if entry and sl and tp1:
                                    risk_dist = abs(entry - sl)
                                    risk_usd = ACCOUNT_BALANCE * RISK_PCT
                                    pos_size = risk_usd / risk_dist if risk_dist > 0 else 0
                                    
                                    msg = f"🔥 <b>تم الدخول آلياً! {symbol}</b> 🔥\n"
                                    msg += f"الاتجاه: {'بيع 🔴' if bias == 'BEARISH' else 'شراء 🟢'}\n"
                                    msg += f"النموذج: {res_5m.get('chosen_model',{}).get('model')}\n"
                                    msg += f"الدخول: {entry:.4f} | הستوب: {sl:.4f} | الهدف: {tp1:.4f}\n"
                                    msg += f"المخاطرة: {risk_usd:.2f}$"
                                    bot.send_message(CHAT_ID, msg, parse_mode='HTML')
                                    
                                    active_trades[symbol] = {
                                        "bias": bias, "entry": entry, "sl": sl, "tp1": tp1,
                                        "current_sl": sl, "be_activated": False, "tp1_hit": False,
                                        "is_short": bias == "BEARISH", "risk": risk_dist, "size": pos_size,
                                        "risk_usd": risk_usd
                                    }
                            continue
"""

    pattern = r'(\s*)if not valid_target:\n\s*bot_status_lines\.append\(f"🪙 \{symbol\}.*'
    
    match = re.search(pattern, content)
    if match:
        original = match.group(0)
        replacement = original + "\n" + new_logic
        content = content.replace(original, replacement)
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(content)
        print(f"Updated {filepath} with recent sweep logic.")

insert_state_machine_telegram("telegram_algo_master.py")
