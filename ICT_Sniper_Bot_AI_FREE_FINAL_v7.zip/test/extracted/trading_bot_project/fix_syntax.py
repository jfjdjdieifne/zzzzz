with open("algo_master.py", "r", encoding="utf-8") as f:
    lines = f.readlines()

for i in range(len(lines)):
    if '. لا دخول.")' in lines[i]:
        lines[i] = '                        print(f"🪙 {symbol:<9} | الجلسة ميتة ({curr_session}). لا دخول.")\n'

with open("algo_master.py", "w", encoding="utf-8") as f:
    f.writelines(lines)
