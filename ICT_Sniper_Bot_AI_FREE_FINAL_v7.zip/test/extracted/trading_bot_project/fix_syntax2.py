with open("algo_master.py", "r", encoding="utf-8") as f:
    lines = f.readlines()

for i in range(len(lines)):
    if '                    ")\n' == lines[i]:
        lines[i] = '                    pass\n'

with open("algo_master.py", "w", encoding="utf-8") as f:
    f.writelines(lines)
