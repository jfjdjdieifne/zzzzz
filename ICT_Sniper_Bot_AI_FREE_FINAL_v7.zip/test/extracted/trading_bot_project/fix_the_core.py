import re

with open("algo_master.py", "r") as f:
    content = f.read()

# 1. Restore Sniper Swings (swing_window=3 ensures we only take major setups, stopping overtrading instantly)
content = content.replace('swing_window=1', 'swing_window=3')
content = content.replace('swing_window=2', 'swing_window=3')

# 2. Strict Killzone Filter (No dead zone trading)
old_filter = """                                dt = datetime.datetime.fromtimestamp(current_ts/1000, tz=datetime.timezone.utc)
                                candidates.append({"timestamp": current_ts, "datetime_utc": dt.isoformat(), "bias": bias, "symbol": symbol})"""

new_filter = """                                sess = classify_session(current_ts).get("session", "")
                                if sess in ["LONDON_KILLZONE", "NY_AM_KILLZONE", "NY_PM_KILLZONE"]:
                                    dt = datetime.datetime.fromtimestamp(current_ts/1000, tz=datetime.timezone.utc)
                                    candidates.append({"timestamp": current_ts, "datetime_utc": dt.isoformat(), "bias": bias, "symbol": symbol})"""

if "classify_session" not in content:
    content = content.replace("import pytz", "import pytz\nfrom ict_sessions import classify_session")
    
content = content.replace(old_filter, new_filter)

# 3. Fix the R:R logic and Partials. We want MINIMUM 2.5R, taking 50% partials (not 80%).
# Look for the calculation:
content = content.replace('profit = (abs(r[\'tp1\'] - r[\'entry\']) * pos_size) * 0.8', 'profit = (abs(r[\'tp1\'] - r[\'entry\']) * pos_size) * 0.5')
content = content.replace('base_profit = (abs(r[\'tp1\'] - r[\'entry\']) * pos_size) * 0.8 if r[\'tp1_hit\'] else 0.0', 'base_profit = (abs(r[\'tp1\'] - r[\'entry\']) * pos_size) * 0.5 if r[\'tp1_hit\'] else 0.0')

# 4. Decrease the limit to avoid timeouts but keep the step low enough.
content = content.replace('for i in range(start_idx, n, 4):', 'for i in range(start_idx, n, 10):')

with open("algo_master.py", "w") as f:
    f.write(content)
print("تم دمج شروط صندوق التحوط الصارمة.")
