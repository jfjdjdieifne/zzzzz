import json, datetime, sys
sys.path.insert(0, ".")
from brain_core import BrainCore
from ict_math_engine import compute_mechanical_bias_anchor, classify_sweep_or_run
from authenticity_engine import AuthenticityEngine
from ict_entry_checklist_engine import evaluate_all_entry_models

brain = BrainCore()
ae = AuthenticityEngine()
SYMBOL = "ETH/USDT"
ACCOUNT_BALANCE = 100.0
RISK_PCT = 0.01

print("جاري سحب التقرير المفصل الصارخ لكل صفقة (شمعة بشمعة)...\n")

full_data = brain.data_manager.get_ohlcv(SYMBOL, "15m", 3500, output_format="dict")
n = len(full_data["closes"])
start_idx = max(500, n - 2880)

candidates = []
reported_days = set()

# استخراج الصفقات
for i in range(start_idx, n, 4):
    window_data = {
        "opens": full_data["opens"][:i+1], "highs": full_data["highs"][:i+1],
        "lows": full_data["lows"][:i+1], "closes": full_data["closes"][:i+1],
        "timestamps": full_data["timestamps"][:i+1],
    }
    try:
        anchor = compute_mechanical_bias_anchor(window_data, lookback=100)
        daily_bias = anchor.get("anchor_direction")
        if daily_bias not in ("BULLISH", "BEARISH"): continue

        current_ts = window_data["timestamps"][-1]
        day_str = datetime.datetime.fromtimestamp(current_ts/1000, tz=datetime.timezone.utc).strftime('%Y-%m-%d')
        
        # لتقليل التخبيص واستخراج صفقات قوية ومقروءة للمستخدم، نأخذ إشارة واحدة كل 12 ساعة
        if any(abs(c["timestamp"] - current_ts) < 12*3600*1000 for c in candidates):
            continue

        sig = ae.detect_significant_swings(window_data, swing_window=2, lookback_candles=150)
        
        levels = sig.get("all_lows_tiered", []) if daily_bias == "BULLISH" else sig.get("all_highs_tiered", [])
        for cand in levels:
            res = classify_sweep_or_run(window_data, cand["price"], level_is_high=(daily_bias=="BEARISH"), check_from_idx=i)
            if res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP" and res.get("candle_index_from_end") >= -2:
                dt = datetime.datetime.fromtimestamp(current_ts/1000, tz=datetime.timezone.utc)
                candidates.append({"timestamp": current_ts, "datetime_utc": dt.isoformat(), "mechanical_bias": daily_bias})
                reported_days.add(day_str)
                break
    except Exception: pass

candidates.sort(key=lambda c: c["timestamp"])

# دالة محاكاة وتتبع تعيد جميع تفاصيل الشموع والأوقات
def simulate_smart_structure_detailed(data, entry, sl, tp, is_short):
    risk = abs(sl - entry)
    if risk == 0: return 0, "ERROR", 0, "", ""
    
    current_sl = sl
    be_activated = False
    tp1_hit = False
    exit_price = 0
    exit_time = ""
    activation_time = ""
    entry_hit = False
    
    for i in range(5, len(data['closes'])):
        h = data['highs'][i]
        l = data['lows'][i]
        ts_str = datetime.datetime.fromtimestamp(data['timestamps'][i]/1000, tz=datetime.timezone.utc).strftime('%Y-%m-%d %H:%M')
        
        if is_short:
            # هل تفعلت الصفقة أصلا؟
            if h >= entry and not entry_hit:
                entry_hit = True
                activation_time = ts_str
                
            if not entry_hit: continue
            
            if l <= tp and not tp1_hit:
                tp1_hit = True
                be_activated = True
                current_sl = entry
                
            if l < (entry - 1.5*risk) and not be_activated:
                current_sl = entry
                be_activated = True

            if h >= current_sl:
                exit_price = current_sl
                exit_time = ts_str
                if current_sl == sl: return -1.0, "SL_HIT", exit_price, exit_time, activation_time
                elif current_sl == entry: 
                    rr = (abs(tp - entry)/risk)*0.8 if tp1_hit else 0.0
                    return rr, "TP1_THEN_BE" if tp1_hit else "BREAK_EVEN_HIT", exit_price, exit_time, activation_time
                else: 
                    base_rr = (abs(tp - entry)/risk)*0.8 if tp1_hit else 0
                    rem_rr = ((entry - current_sl)/risk)*0.2
                    return base_rr + rem_rr, "DYNAMIC_TRAIL_HIT", exit_price, exit_time, activation_time
                    
            if data['highs'][i-1] > data['highs'][i-2] and data['highs'][i-1] > data['highs'][i]:
                swing_high = data['highs'][i-1]
                if l < data['lows'][i-1] and swing_high < current_sl and be_activated:
                    current_sl = swing_high + (risk * 0.1) 
        else:
            if l <= entry and not entry_hit:
                entry_hit = True
                activation_time = ts_str
                
            if not entry_hit: continue
            
            if h >= tp and not tp1_hit:
                tp1_hit = True
                be_activated = True
                current_sl = entry
                
            if h > (entry + 1.5*risk) and not be_activated:
                current_sl = entry
                be_activated = True

            if l <= current_sl:
                exit_price = current_sl
                exit_time = ts_str
                if current_sl == sl: return -1.0, "SL_HIT", exit_price, exit_time, activation_time
                elif current_sl == entry: 
                    rr = (abs(tp - entry)/risk)*0.8 if tp1_hit else 0.0
                    return rr, "TP1_THEN_BE" if tp1_hit else "BREAK_EVEN_HIT", exit_price, exit_time, activation_time
                else: 
                    base_rr = (abs(tp - entry)/risk)*0.8 if tp1_hit else 0
                    rem_rr = ((current_sl - entry)/risk)*0.2
                    return base_rr + rem_rr, "DYNAMIC_TRAIL_HIT", exit_price, exit_time, activation_time
                    
            if data['lows'][i-1] < data['lows'][i-2] and data['lows'][i-1] < data['lows'][i]:
                swing_low = data['lows'][i-1]
                if h > data['highs'][i-1] and swing_low > current_sl and be_activated:
                    current_sl = swing_low - (risk * 0.1)

    return 0, "ENTRY_NEVER_HIT" if not entry_hit else "OPEN", data['closes'][-1], "OPEN", activation_time

account = ACCOUNT_BALANCE
valid_results = []
counter = 1

# سنعرض آخر 15 صفقة منفذة فقط لتكون مقروءة وواضحة (Quality over Quantity)
for cand in candidates[-25:]: 
    sweep_ts = cand['timestamp']
    bias = cand['mechanical_bias']
    
    found_trade = False
    for k in range(0, 8):
        sim_ts = sweep_ts + (k * 15 * 60 * 1000)
        data_5m = brain.data_manager.fetch_ohlcv_up_to(SYMBOL, "5m", sim_ts, limit=150)
        try:
            res = evaluate_all_entry_models(data_5m, bias)
            status = res.get("final_status")
            if status in ["READY", "PENDING_SETUP"]:
                plan = res.get("chosen_model", {}).get("plan", {})
                entry, sl, tp1 = plan.get("entry"), plan.get("stop_loss"), plan.get("tp")
                
                if entry and sl and tp1:
                    is_short = (bias == "BEARISH")
                    future_data = brain.data_manager.fetch_ohlcv_up_to(SYMBOL, "5m", sim_ts + 24*3600*1000, limit=288)
                    rr, outcome, exit_p, exit_t, act_time = simulate_smart_structure_detailed(future_data, entry, sl, tp1, is_short)
                    
                    if outcome not in ["ENTRY_NEVER_HIT", "OPEN"]:
                        profit_usd = rr * RISK_PCT * account
                        account += profit_usd
                        valid_results.append({
                            "num": counter,
                            "bias": "بيع 🔴" if is_short else "شراء 🟢",
                            "act_time": act_time,
                            "entry": entry,
                            "sl": sl,
                            "tp1": tp1,
                            "exit_t": exit_t,
                            "exit_p": exit_p,
                            "outcome": outcome,
                            "rr": rr,
                            "profit": profit_usd,
                            "balance": account
                        })
                        counter += 1
                        found_trade = True
                        break
        except Exception: pass

for r in valid_results:
    print("="*60)
    print(f"📌 الصفقة رقم [{r['num']}] | {r['bias']}")
    print(f"⏱️ توقيت التفعيل (الدخول): {r['act_time']} UTC")
    print(f"💰 سعر الدخول: {r['entry']:.2f}")
    print(f"🛡️ الستوب لوس الأصلي: {r['sl']:.2f}")
    print(f"🎯 الهدف الأول (جني 80%): {r['tp1']:.2f}")
    print(f"⏱️ توقيت الإغلاق النهائي: {r['exit_t']} UTC")
    print(f"🚪 سعر الخروج النهائي: {r['exit_p']:.2f}")
    
    out_label = r['outcome']
    if out_label == "SL_HIT": out_label = "ضرب الستوب لوس ❌ (السعر انعكس تماماً وضرب الستوب الأصلي)."
    elif out_label == "BREAK_EVEN_HIT": out_label = "خروج على الدخول (أمان) 🛡️ (السعر تحرك 1.5R ثم عاد لنقطة الصفر)."
    elif out_label == "TP1_THEN_BE": out_label = "ربح جزئي ותأمين 🎯 (تم ضرب الهدف الأول وأخذ 80%، والـ 20% الباقية خرجت عالدخول)."
    elif out_label == "DYNAMIC_TRAIL_HIT": out_label = f"قنص ותتبع هيكلي 🧠🎯 (تم حلب السعر وراء القمم/القيعان، والـ 20% الباقية خرجت عند {r['exit_p']:.2f})."
    
    print(f"🏁 النتيجة: {out_label}")
    print(f"💵 الربح (R:R): {r['rr']:+.2f} R")
    print(f"💸 الربح بالدولار (مخاطرة 1%): {r['profit']:+.2f}$")
    print(f"🏦 رصيد الحساب: {r['balance']:.2f}$")

