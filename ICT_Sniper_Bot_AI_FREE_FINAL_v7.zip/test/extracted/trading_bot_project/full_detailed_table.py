import json, datetime, sys
sys.path.insert(0, ".")
from brain_core import BrainCore
from ict_math_engine import compute_mechanical_bias_anchor, classify_sweep_or_run
from authenticity_engine import AuthenticityEngine
from ict_entry_checklist_engine import evaluate_all_entry_models

brain = BrainCore()
ae = AuthenticityEngine()
SYMBOL = "ETH/USDT"
ACCOUNT_BALANCE = 100.0
RISK_PCT = 0.01

full_data = brain.data_manager.get_ohlcv(SYMBOL, "15m", 3500, output_format="dict")
n = len(full_data["closes"])
start_idx = max(500, n - 2880)

candidates = []
reported_days = set()

for i in range(start_idx, n, 6):
    window_data = {
        "opens": full_data["opens"][:i+1], "highs": full_data["highs"][:i+1],
        "lows": full_data["lows"][:i+1], "closes": full_data["closes"][:i+1],
        "timestamps": full_data["timestamps"][:i+1],
    }
    try:
        anchor = compute_mechanical_bias_anchor(window_data, lookback=100)
        daily_bias = anchor.get("anchor_direction")
        if daily_bias not in ("BULLISH", "BEARISH"): continue

        current_ts = window_data["timestamps"][-1]
        day_str = datetime.datetime.fromtimestamp(current_ts/1000, tz=datetime.timezone.utc).strftime('%Y-%m-%d')
        
        if day_str in reported_days: continue

        sig = ae.detect_significant_swings(window_data, swing_window=2, lookback_candles=150)
        
        levels = sig.get("all_lows_tiered", []) if daily_bias == "BULLISH" else sig.get("all_highs_tiered", [])
        for cand in levels:
            res = classify_sweep_or_run(window_data, cand["price"], level_is_high=(daily_bias=="BEARISH"), check_from_idx=i)
            if res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP":
                dt = datetime.datetime.fromtimestamp(current_ts/1000, tz=datetime.timezone.utc)
                candidates.append({"timestamp": current_ts, "datetime_utc": dt.isoformat(), "mechanical_bias": daily_bias})
                reported_days.add(day_str)
                break
    except Exception: pass

candidates.sort(key=lambda c: c["timestamp"])

results = []
account = ACCOUNT_BALANCE

def simulate_smart_structure(data, entry, sl, tp, is_short):
    risk = abs(sl - entry)
    if risk == 0: return 0, "ERROR", 0, 0
    
    current_sl = sl
    be_activated = False
    tp1_hit = False
    exit_price = 0
    exit_time = ""
    
    for i in range(5, len(data['closes'])):
        h = data['highs'][i]
        l = data['lows'][i]
        ts_str = datetime.datetime.fromtimestamp(data['timestamps'][i]/1000, tz=datetime.timezone.utc).strftime('%m-%d %H:%M')
        
        if is_short:
            if l <= tp and not tp1_hit:
                tp1_hit = True
                be_activated = True
                current_sl = entry
                
            if l < (entry - 1.5*risk) and not be_activated:
                current_sl = entry
                be_activated = True

            if h >= current_sl:
                exit_price = current_sl
                if current_sl == sl: return -1.0, "SL_HIT", exit_price, ts_str
                elif current_sl == entry: 
                    rr = (abs(tp - entry)/risk)*0.8 if tp1_hit else 0.0
                    return rr, "TP1_THEN_BE" if tp1_hit else "BREAK_EVEN_HIT", exit_price, ts_str
                else: 
                    base_rr = (abs(tp - entry)/risk)*0.8 if tp1_hit else 0
                    rem_rr = ((entry - current_sl)/risk)*0.2
                    return base_rr + rem_rr, "DYNAMIC_TRAIL_HIT", exit_price, ts_str
                    
            if data['highs'][i-1] > data['highs'][i-2] and data['highs'][i-1] > data['highs'][i]:
                swing_high = data['highs'][i-1]
                if l < data['lows'][i-1] and swing_high < current_sl and be_activated:
                    current_sl = swing_high + (risk * 0.1) 
        else:
            if h >= tp and not tp1_hit:
                tp1_hit = True
                be_activated = True
                current_sl = entry
                
            if h > (entry + 1.5*risk) and not be_activated:
                current_sl = entry
                be_activated = True

            if l <= current_sl:
                exit_price = current_sl
                if current_sl == sl: return -1.0, "SL_HIT", exit_price, ts_str
                elif current_sl == entry: 
                    rr = (abs(tp - entry)/risk)*0.8 if tp1_hit else 0.0
                    return rr, "TP1_THEN_BE" if tp1_hit else "BREAK_EVEN_HIT", exit_price, ts_str
                else: 
                    base_rr = (abs(tp - entry)/risk)*0.8 if tp1_hit else 0
                    rem_rr = ((current_sl - entry)/risk)*0.2
                    return base_rr + rem_rr, "DYNAMIC_TRAIL_HIT", exit_price, ts_str
                    
            if data['lows'][i-1] < data['lows'][i-2] and data['lows'][i-1] < data['lows'][i]:
                swing_low = data['lows'][i-1]
                if h > data['highs'][i-1] and swing_low > current_sl and be_activated:
                    current_sl = swing_low - (risk * 0.1)

    return 0, "OPEN", data['closes'][-1], "OPEN"

for idx, cand in enumerate(candidates[-30:]): # نعرض آخر 30 صفقة
    sweep_ts = cand['timestamp']
    bias = cand['mechanical_bias']
    dt_str = cand['datetime_utc'][:16].replace('T', ' ')
    
    found_trade = False
    for k in range(0, 12):
        sim_ts = sweep_ts + (k * 15 * 60 * 1000)
        data_5m = brain.data_manager.fetch_ohlcv_up_to(SYMBOL, "5m", sim_ts, limit=150)
        try:
            res = evaluate_all_entry_models(data_5m, bias)
            status = res.get("final_status")
            if status in ["READY", "PENDING_SETUP"]:
                plan = res.get("chosen_model", {}).get("plan", {})
                entry, sl, tp1 = plan.get("entry"), plan.get("stop_loss"), plan.get("tp")
                
                if entry and sl and tp1:
                    is_short = (bias == "BEARISH")
                    future_data = brain.data_manager.fetch_ohlcv_up_to(SYMBOL, "5m", sim_ts + 24*3600*1000, limit=288)
                    rr, outcome, exit_p, exit_t = simulate_smart_structure(future_data, entry, sl, tp1, is_short)
                    
                    if outcome != "OPEN":
                        profit_usd = rr * RISK_PCT * account
                        account += profit_usd
                        results.append({
                            "num": idx+1,
                            "date": dt_str,
                            "type": "SELL" if is_short else "BUY",
                            "entry": entry,
                            "sl": sl,
                            "tp1": tp1,
                            "exit_p": exit_p,
                            "exit_t": exit_t,
                            "outcome": outcome,
                            "rr": rr,
                            "profit_usd": profit_usd,
                            "account": account
                        })
                        found_trade = True
                        break
        except Exception: pass
            
    if not found_trade:
        results.append({
            "num": idx+1,
            "date": dt_str,
            "type": "-", "entry": 0, "sl": 0, "tp1": 0, "exit_p": 0, "exit_t": "-",
            "outcome": "HOLD", "rr": 0, "profit_usd": 0, "account": account
        })

print("="*160)
print(f"| {'رقم':<3} | {'التاريخ والوقت':<16} | {'نوع':<4} | {'الدخول':<8} | {'الستوب':<8} | {'الهدف1':<8} | {'وقت الخروج':<12} | {'سعر الخروج':<10} | {'نوع الخروج (النتيجة)':<16} | {'الربح R':<8} | {'الربح $':<8} | {'الرصيد':<8} |")
print("="*160)

for r in results:
    if r['outcome'] == "HOLD":
        print(f"| {r['num']:<3} | {r['date']:<16} | {'-':<4} | {'-':<8} | {'-':<8} | {'-':<8} | {'-':<12} | {'-':<10} | {'لم تتفعل ⏳':<16} | {'0.00':<8} | {'0.00$':<8} | {r['account']:>8.2f} |")
    else:
        out_col = ""
        if r['outcome'] == "SL_HIT": out_col = "ستوب لوس ❌"
        elif r['outcome'] == "BREAK_EVEN_HIT": out_col = "خروج عالدخول 🛡️"
        elif r['outcome'] == "TP1_THEN_BE": out_label = "ربح جزئي(80%) 🎯"
        elif r['outcome'] == "DYNAMIC_TRAIL_HIT": out_col = "تتبع هيكلي 🧠🎯"
        else: out_col = r['outcome']
        
        print(f"| {r['num']:<3} | {r['date']:<16} | {r['type']:<4} | {r['entry']:>8.2f} | {r['sl']:>8.2f} | {r['tp1']:>8.2f} | {r['exit_t']:<12} | {r['exit_p']:>10.2f} | {out_col:<16} | {r['rr']:+.2f} R  | {r['profit_usd']:>7.2f}$ | {r['account']:>8.2f} |")

print("="*160)
