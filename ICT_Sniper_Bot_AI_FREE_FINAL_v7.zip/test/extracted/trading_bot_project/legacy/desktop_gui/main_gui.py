# -*- coding: utf-8 -*-
"""MainGUI: الواجهة الرسومية الاختيارية (PyQt5) لبوت التداول"""
import logging

try:
    from PyQt5 import QtWidgets
except ImportError:
    QtWidgets = None


class MainGUI:
    """واجهة رسومية بسيطة لتشغيل الوظائف الرئيسية للبوت (BrainCore)."""

    def __init__(self):
        self.logger = logging.getLogger("MainGUI")
        self.logger.info("MainGUI initialized.")

    def launch(self, bot=None):
        """
        واجهة رسومية سهلة الاستخدام مع أزرار لكل وظيفة رئيسية.
        bot: كائن BrainCore (يوفر full_analysis, chat, backtest, self_evaluate...)
        """
        if not QtWidgets:
            self.logger.warning("PyQt5 غير مثبت - شغّل: pip install PyQt5")
            print("⚠️ PyQt5 غير مثبت. للاستخدام الرسومي: pip install PyQt5")
            return

        app = QtWidgets.QApplication([])
        window = QtWidgets.QWidget()
        window.setWindowTitle("بوت التداول الذكي")
        layout = QtWidgets.QVBoxLayout()

        label = QtWidgets.QLabel("مرحباً بك في عقل التداول الذكي!")
        layout.addWidget(label)

        output_box = QtWidgets.QTextEdit()
        output_box.setReadOnly(True)
        layout.addWidget(output_box)

        def show_result(result):
            output_box.setText(str(result))

        def safe(fn):
            def wrapper():
                if not bot:
                    show_result("⚠️ لا يوجد BrainCore متصل")
                    return
                try:
                    show_result(fn())
                except Exception as e:
                    show_result(f"❌ خطأ: {e}")
            return wrapper

        # أزرار مرتبطة فعلياً بدوال BrainCore الحقيقية
        btns = [
            ("تحليل كامل (Full Analysis)", safe(lambda: bot.full_analysis())),
            ("تحليل سريع (Quick Analysis)", safe(lambda: bot.quick_analysis())),
            ("دردشة مع البوت", safe(lambda: bot.chat("أعطني نظرة عامة عن السوق"))),
            ("تقييم ذاتي للأداء", safe(lambda: bot.self_evaluate())),
            ("عرض الإشارات المقترحة", safe(lambda: bot.get_proposed_signals())),
            ("معلومات قاعدة المعرفة", safe(lambda: bot.get_knowledge_info())),
        ]
        for text, func in btns:
            btn = QtWidgets.QPushButton(text)
            btn.clicked.connect(func)
            layout.addWidget(btn)

        window.setLayout(layout)
        window.show()
        self.logger.info("GUI launched.")
        app.exec_()