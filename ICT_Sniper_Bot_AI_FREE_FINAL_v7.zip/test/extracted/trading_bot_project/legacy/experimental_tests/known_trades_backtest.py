# -*- coding: utf-8 -*-
"""
KnownTradesBacktest - اختبار الكود على أحداث تاريخية حقيقية وموثّقة
════════════════════════════════════════════════════════════════════
الهدف: اختبار "صدق" الكود نفسه (مش أداء استراتيجية عشوائية) عبر
تشغيله على لحظات تاريخية حقيقية من BTC معروفة عالمياً بنتيجتها الفعلية،
والتحقق: هل تحليل البوت (على البيانات المؤدية للحدث فقط، دون معرفة
مسبقة بما سيحدث) يتماشى منطقياً مع ما حدث فعلاً بعدها؟

هذا "test للكود نفسه" كما طلبت - مو backtest إحصائي على مئات الصفقات
(هذا موجود بـ backtest_engine.py)، بل تحقق نوعي: هل البوت يقرأ نفس
القصة التي قرأها التاريخ الفعلي؟

الأحداث المُضمّنة (بيانات OKX حقيقية، تواريخ وأسعار موثقة عالمياً):

1. انهيار FTX (نوفمبر 2022):
   BTC هبط من ~$20,767 (6 نوفمبر) إلى ~$15,511 (9 نوفمبر) خلال 3 أيام
   بسبب انهيار بورصة FTX - أحد أكبر انهيارات الكريبتو الموثقة تاريخياً.
   التوقّع المنطقي: بيانات ما قبل 6 نوفمبر (البيانات المتاحة وقتها فقط)
   يجب أن تُظهر ضعف/عدم يقين، وليس بالضرورة "توقع الانهيار" (كان
   حدثاً خارجياً مفاجئاً - fundamental، ليس نمط فني بحت) - لكن لا يجب
   أن يعطي البوت إشارة BUY قوية جداً بثقة عالية في هذه اللحظة تحديداً.

2. أزمة البنوك الأمريكية / إنقاذ SVB (مارس 2023):
   BTC صعد من ~$20,000 (10 مارس) إلى ~$28,000+ (23 مارس) - ارتداد
   وصعود قوي وموثق بعد انهيار Silicon Valley Bank وتدخل الفيدرالي.

⚠️ حدود هذا الاختبار (صدق كامل):
  - هذه أحداث "fundamental" (أخبار خارجية) وليست بالضرورة أنماط ICT/SMC
    فنية بحتة - البوت مصمم لقراءة price action، فقد لا "يتوقع" الخبر
    نفسه، لكن يجب أن تنعكس آثاره بالبيانات السعرية بشكل يقرأه البوت
    بمنطقية (تذبذب، ضعف هيكلي، سيولة تُجرف بعنف...)
  - هذا الاختبار **لا** يثبت "دقة استراتيجية تداول" - فقط يثبت أن
    الكود يعمل بشكل متسق ومنطقي على بيانات تاريخية حقيقية معروفة،
    وأن نفس المدخلات تعطي نفس النوع من المخرجات (لا كسر بالكود)
"""
import logging


class KnownTradesBacktest:

    # كل حدث: بيانات كاملة من OKX (تواريخ Unix ms) + وصف/نتيجة موثقة
    KNOWN_EVENTS = [
        {
            "name": "FTX Collapse - Nov 2022",
            "symbol": "BTC/USDT",
            "timeframe": "1d",
            "analysis_end_ts": 1667692800000,  # نهاية 5 نوفمبر 2022 (قبل الانهيار)
            "documented_outcome": "BEARISH_CRASH",
            "outcome_description": (
                "BTC هبط من ~$20,767 (6 نوف) إلى ~$15,511 (9 نوف) خلال 3 أيام "
                "بسبب انهيار بورصة FTX. أحد أكبر انهيارات الكريبتو الموثقة."
            ),
            "actual_price_before": 20800,
            "actual_price_after_3days": 15511,
            "note": (
                "حدث fundamental مفاجئ (خبر) وليس نمط فني صرف - لا نتوقع من "
                "البوت 'التنبؤ' بانهيار بورصة، لكن نراقب هل كان واثقاً بشكل "
                "مفرط بالاتجاه الصاعد وقتها (علامة عمى عن هشاشة السوق)."
            ),
        },
        {
            "name": "SVB Banking Crisis Rally - Mar 2023",
            "symbol": "BTC/USDT",
            "timeframe": "1d",
            "analysis_end_ts": 1678665600000,  # نهاية 12 مارس 2023 (بداية الأزمة)
            "documented_outcome": "BULLISH_RALLY",
            "outcome_description": (
                "BTC صعد من ~$20,000 (10 مارس) إلى ~$28,000+ (23 مارس) بعد "
                "انهيار SVB وتدخل الفيدرالي - ارتداد قوي وموثق."
            ),
            "actual_price_before": 20200,
            "actual_price_after_10days": 28000,
            "note": (
                "أيضاً حدث fundamental (أزمة بنكية + تدخل حكومي) - نراقب هل "
                "قرأ البوت أي علامات فنية داعمة (تجميع، سيولة) في الأيام "
                "المؤدية للحدث، حتى لو لم يتوقع الخبر نفسه."
            ),
        },
    ]

    def __init__(self, brain_core, data_manager=None):
        self.brain = brain_core
        self.data_manager = data_manager or brain_core.data_manager
        self.logger = logging.getLogger("KnownTradesBacktest")

    def run_all(self):
        """يشغّل كل الأحداث المعروفة ويرجع تقرير مقارنة شامل"""
        results = []
        for event in self.KNOWN_EVENTS:
            self.logger.info(f"🕰️ اختبار: {event['name']}...")
            try:
                result = self.run_single_event(event)
                results.append(result)
            except Exception as e:
                self.logger.error(f"❌ {event['name']} فشل: {e}")
                results.append({"event": event["name"], "error": str(e)})
        return {"total_events": len(self.KNOWN_EVENTS), "results": results}

    def run_single_event(self, event):
        """
        يجلب البيانات التاريخية *فقط حتى لحظة الحدث* (بدون تسريب معلومات
        مستقبلية - lookahead bias)، يشغّل تحليل البوت عليها، ويقارن
        الناتج بالنتيجة الفعلية الموثقة.
        """
        symbol = event["symbol"]
        timeframe = event["timeframe"]
        end_ts = event["analysis_end_ts"]

        # نجلب بيانات تاريخية تنتهي بالضبط عند لحظة الحدث (before/after
        # split صارم - البوت لا يرى أي بيانات بعد هذه اللحظة)
        historical_data = self._fetch_historical_up_to(symbol, timeframe, end_ts)

        if not historical_data:
            return {
                "event": event["name"],
                "error": "فشل جلب البيانات التاريخية لهذا الحدث",
            }

        # نبني custom_data متوافق مع full_analysis (بدون تسريب مستقبل)
        custom_data = {"entry": historical_data}

        analysis = self.brain.full_analysis(
            symbol=symbol, timeframe=timeframe, custom_data=custom_data
        )

        ai_result = analysis.get("ai_analysis", {})

        # تقييم: هل اتجاه البوت (أو على الأقل عدم يقينه) يتماشى منطقياً
        # مع ما حدث فعلياً؟ (فحص نوعي وليس رقمياً صارماً - fundamental
        # events غير متوقعة بطبيعتها من price action وحده)
        bot_bias = ai_result.get("bias", "UNKNOWN")
        bot_signal = ai_result.get("signal", "UNKNOWN")
        bot_confidence = ai_result.get("confidence", 0)

        alignment_note = self._assess_alignment(
            event["documented_outcome"], bot_bias, bot_signal, bot_confidence
        )

        return {
            "event": event["name"],
            "documented_outcome": event["documented_outcome"],
            "outcome_description": event["outcome_description"],
            "data_points_used": historical_data.get("count"),
            "last_price_seen_by_bot": historical_data["closes"][-1],
            "bot_narrative": ai_result.get("narrative", ""),
            "bot_archetype": ai_result.get("archetype", ""),
            "bot_bias": bot_bias,
            "bot_signal": bot_signal,
            "bot_confidence": bot_confidence,
            "alignment_assessment": alignment_note,
            "note": event["note"],
        }

    def _fetch_historical_up_to(self, symbol, timeframe, end_ts, limit=200):
        """
        يجلب شموع تاريخية تنتهي عند timestamp محدد بالضبط (before/after
        split صارم لمنع تسريب معلومات مستقبلية إلى تحليل البوت).
        """
        inst_id = self.data_manager._to_okx_inst_id(symbol)
        bar = self.data_manager._convert_tf_okx(timeframe)

        try:
            resp = self.data_manager.session.get(
                f"{self.data_manager.okx_base}/api/v5/market/history-candles",
                params={"instId": inst_id, "bar": bar, "limit": limit, "after": end_ts},
                timeout=15,
            )
            if resp.status_code != 200:
                return None
            payload = resp.json()
            if payload.get("code") != "0":
                return None
            raw = list(reversed(payload.get("data", [])))  # الأقدم أولاً

            if not raw:
                return None

            data = {
                "timestamps": [int(c[0]) for c in raw],
                "opens": [float(c[1]) for c in raw],
                "highs": [float(c[2]) for c in raw],
                "lows": [float(c[3]) for c in raw],
                "closes": [float(c[4]) for c in raw],
                "volumes": [float(c[5]) for c in raw],
                "num_trades": [0] * len(raw),
                "taker_buy_volumes": [float(c[5]) * 0.5 for c in raw],
                "taker_buy_quote_volumes": [0.0] * len(raw),
                "buy_sell_ratio": [0.5] * len(raw),
                "symbol": symbol,
                "timeframe": timeframe,
                "count": len(raw),
                "source": "backtest",  # يفعّل backtest mode بـ brain_core (BUY/SELL إجباري)
            }
            return data
        except Exception as e:
            self.logger.error(f"❌ خطأ بجلب بيانات {symbol} حتى {end_ts}: {e}")
            return None

    def _assess_alignment(self, documented_outcome, bias, signal, confidence):
        """
        تقييم نوعي (وليس رقمي صارم) لمدى تماشي قراءة البوت مع النتيجة
        الفعلية الموثقة. لأن هذه أحداث fundamental، النجاح المطلوب هنا
        هو "عدم عمى واضح" وليس "توقع دقيق للخبر".
        """
        if documented_outcome == "BEARISH_CRASH":
            if bias == "BULLISH" and confidence and confidence > 75:
                return (
                    "⚠️ تحذير: البوت كان واثقاً جداً بالصعود (bias=BULLISH, "
                    f"confidence={confidence}%) قبيل انهيار فعلي كبير. "
                    "هذا متوقع جزئياً (الانهيار كان خبراً مفاجئاً غير مرئي "
                    "بالـ price action)، لكن يستحق المراجعة إن تكرر."
                )
            else:
                return (
                    f"✅ البوت لم يظهر ثقة صعودية مفرطة (bias={bias}, "
                    f"confidence={confidence}%) - سلوك حذر مناسب."
                )
        elif documented_outcome == "BULLISH_RALLY":
            if bias == "BEARISH" and confidence and confidence > 75:
                return (
                    "⚠️ تحذير: البوت كان واثقاً جداً بالهبوط قبيل ارتداد "
                    f"صعودي فعلي كبير (bias={bias}, confidence={confidence}%)."
                )
            else:
                return (
                    f"✅ البوت لم يظهر ثقة هبوطية مفرطة (bias={bias}, "
                    f"confidence={confidence}%) - سلوك حذر مناسب."
                )
        return "لا يوجد تقييم محدد لهذا النوع من الأحداث."