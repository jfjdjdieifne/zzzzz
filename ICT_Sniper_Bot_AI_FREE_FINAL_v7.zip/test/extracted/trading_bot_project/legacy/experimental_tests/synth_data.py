# -*- coding: utf-8 -*-
"""
مولّد بيانات اصطناعية بالكامل لاختبار "الفهم مقابل الحفظ" (Generalization Test)
════════════════════════════════════════════════════════════════════
الفكرة: نبني شموع OHLC وهمية 100% (رمز غير موجود، أسعار غريبة كلياً
لم يرها البوت بأي بيانات BTC/ETH حقيقية سابقاً)، لكن مبنية بدقة رياضية
لتحقيق **نفس الشروط المنطقية** لنمط ICT كلاسيكي معروف (Liquidity Sweep
ثم BOS انعكاسي - "Judas Swing" / "Turtle Soup"):

  1. اتجاه هابط أولي واضح (لبناء توقع "قاع سابق = سيولة بيع")
  2. كسر سيولة (سحب سعر تحت آخر قاع بفتيل، بدون إغلاق تحته - فخ حقيقي)
  3. اندفاع صاعد عنيف (displacement) يكسر آخر قمة متأرجحة = BOS صاعد

لو البوت "حافظ" أنماط BTC/ETH المحددة، لن يتعرف على هذا كإشارة صحيحة
(أرقام غريبة كلياً، رمز غير معروف). لو "فهم القاعدة" (سحب سيولة +
اندفاع = انعكاس محتمل)، يجب أن يتعرف على البنية المنطقية بغض النظر عن
الأرقام المحددة - هذا الفرق الجوهري بين "بصم" و"فهم" الذي طلبه المستخدم.

سعر الأساس: 47.3183 (رقم عشوائي غريب تماماً - ليس نطاق BTC ولا ETH ولا
أي عملة معروفة، بل أقرب لسهم غير مألوف - يمنع أي احتمال "تعرّف على
مجموعة بيانات محفوظة" حرفياً).
"""
import numpy as np
import random


def generate_bullish_reversal_setup(base_price=47.3183, n_candles=250, seed=42):
    """
    يبني سلسلة شموع اصطناعية بالكامل:
    - أول ~200 شمعة: اتجاه هابط تدريجي مع تذبذب طبيعي (يبني هيكل LH/LL
      وقاع سابق واضح يصير "هدف سيولة")
    - آخر ~15 شمعة: سحب سيولة (wick تحت القاع، إغلاق فوقه) ثم اندفاع
      صاعد عنيف يكسر آخر قمة متأرجحة (BOS صاعد حقيقي)

    Returns: dict بصيغة data_manager القياسية (opens/highs/lows/closes/
             volumes/timestamps) + "ground_truth_pattern" يشرح ما بُني
             عمداً (للمقارنة لاحقاً، هذا ليس شيئاً يُعطى للـAI أبداً)
    """
    rng = np.random.RandomState(seed)
    n_trend = n_candles - 15

    # ═══ الجزء 1: اتجاه هابط تدريجي طبيعي (بضجيج حقيقي، لا خط مستقيم) ═══
    trend = np.linspace(0, -0.30, n_trend)  # هبوط تدريجي 30% عبر الاتجاه
    noise = rng.normal(0, 0.012, n_trend).cumsum() * 0.15  # ضجيج تراكمي معتدل
    # موجات صعود/هبوط طبيعية (زي حركة سوق حقيقية، لا خط منحدر مستقيم بحت)
    waves = 0.04 * np.sin(np.linspace(0, 7 * np.pi, n_trend))
    closes_trend = base_price * (1 + trend + noise + waves)
    closes_trend = np.maximum(closes_trend, base_price * 0.55)  # حماية من قيم سالبة/شاذة

    opens, highs, lows, closes, volumes = [], [], [], [], []
    prev_close = base_price
    for i in range(n_trend):
        o = prev_close
        c = closes_trend[i]
        body_range = abs(c - o)
        wick = max(body_range * rng.uniform(0.15, 0.55), base_price * 0.0015)
        h = max(o, c) + wick * rng.uniform(0.3, 1.0)
        l = min(o, c) - wick * rng.uniform(0.3, 1.0)
        v = rng.uniform(800, 1500)
        opens.append(o); highs.append(h); lows.append(l); closes.append(c); volumes.append(v)
        prev_close = c

    # ═══ نحدد "القاع السابق المهم" وسط الاتجاه الهابط (سيولة مستهدفة) ═══
    # نبحث عن أدنى قاع بالربع الأخير من الاتجاه (قبل السحب) - هذا سيصبح
    # مستوى الـSSL (Sell-Side Liquidity) الذي سيُكسر بفخ مؤقت.
    search_start = int(n_trend * 0.7)
    prior_swing_low_idx = search_start + int(np.argmin(lows[search_start:]))
    prior_swing_low = lows[prior_swing_low_idx]

    # القمة المتأرجحة الأخيرة قبل السحب (سيُكسر عبرها الـBOS الصاعد)
    recent_high_search_start = max(0, n_trend - 20)
    recent_swing_high = max(highs[recent_high_search_start:])

    last_close = closes[-1]

    # ═══ الجزء 2: تجميع/تذبذب قصير قبل السحب (3 شموع) ═══
    for i in range(3):
        o = last_close
        c = o * (1 + rng.uniform(-0.004, 0.004))
        h = max(o, c) * 1.003
        l = min(o, c) * 0.997
        v = rng.uniform(700, 1100)
        opens.append(o); highs.append(h); lows.append(l); closes.append(c); volumes.append(v)
        last_close = c

    # ═══ الجزء 3: شمعة سحب السيولة (Liquidity Sweep) ═══
    # فتيل يخترق القاع السابق (prior_swing_low) بوضوح، لكن الإغلاق يعود
    # فوقه بقوة - هذا "الفخ" الكلاسيكي (Judas Swing / Turtle Soup)
    sweep_open = last_close
    sweep_low = prior_swing_low * 0.985  # اختراق واضح تحت القاع (1.5%)
    sweep_close = prior_swing_low * 1.008  # إغلاق فوق القاع المكسور بوضوح
    sweep_high = max(sweep_open, sweep_close) * 1.002
    opens.append(sweep_open); highs.append(sweep_high); lows.append(sweep_low)
    closes.append(sweep_close); volumes.append(rng.uniform(1800, 2500))  # فوليوم أعلى (زخم الفخ)
    last_close = sweep_close

    # ═══ الجزء 4: شمعة تأكيد صغيرة (استقرار بعد الفخ مباشرة) ═══
    confirm_close = last_close * (1 + rng.uniform(0.002, 0.008))
    confirm_open = last_close
    confirm_high = confirm_close * 1.004
    confirm_low = min(confirm_open, confirm_close) * 0.998
    opens.append(confirm_open); highs.append(confirm_high); lows.append(confirm_low)
    closes.append(confirm_close); volumes.append(rng.uniform(900, 1300))
    last_close = confirm_close

    # ═══ الجزء 5: شمعة الاندفاع (Displacement) - تكسر القمة المتأرجحة
    # الأخيرة بجسم كبير وحجم تداول مرتفع = BOS صاعد حقيقي ═══
    displacement_close = recent_swing_high * 1.025  # يتجاوز القمة بوضوح (2.5%)
    displacement_open = last_close
    displacement_high = displacement_close * 1.006
    displacement_low = min(displacement_open, displacement_close) * 0.997
    opens.append(displacement_open); highs.append(displacement_high)
    lows.append(displacement_low); closes.append(displacement_close)
    volumes.append(rng.uniform(2500, 3500))  # حجم ضخم يوافق الاندفاع الحقيقي
    last_close = displacement_close

    # ═══ الجزء 6: 8 شموع أخيرة (السعر يستمر أعلى بعد الاندفاع، تأكيد
    # أنه لم يكن استمراراً مؤقتاً بل انعكاس هيكلي فعلي - "held") ═══
    # ⚠️ تصميم مُصحّح: لا نجعل السعر يصعد بشكل مطّرد كل شمعة (خط
    # مستقيم غير واقعي) - هذا كان يخلق "سحب سيولة" منافس
    # أحدث زمنياً من الحدث المُصمّم عمداً عند الاندفاع، ويربك
    # أدوات الكشف الرياضي عن أي حدث تقصده فعلياً. الحل: تماسك/تراجع
    # بسيط بعد الاندفاع مباشرة (شمعتان)، ثم استمرار
    # صاعد متذبذب طبيعي - يحاكي سلوك سعري حقيقي بعد displacement
    # قوي (عادةً يحصل retracement جزئي قبل الاستمرار، لا صعود خطي أبداً).
    # ⚠️ تصميم مُصحّح إضافي (اكتشاف فعلي): التذبذب الواسع بعد الاندفاع
    # مباشرة كان يخلق فتيلاً عابراً لمستوى قديم قريب (36.33) يُصنّف
    # رياضياً كـ"سحب سيولة" منافس أحدث زمنياً من الحدث المقصود (السحب عند
    # -11)، فيربك تركيز الاختبار على الحدث المقصود بالضبط. الحل: استمرار صاعد
    # أكثر وضوحاً بعد الاندفاع (لا تذبذب قد يلمس مستويات قديمة بفتيل ثم
    # يرجع تحتها).
    for i in range(8):
        o = last_close
        drift = rng.uniform(0.001, 0.010)  # استمرار صاعد مع تذبذب بسيط جداً (لا تراجع)
        c = o * (1 + drift)
        h = max(o, c) * (1 + rng.uniform(0.001, 0.004))
        l = min(o, c) * (1 - rng.uniform(0.0005, 0.002))  # فتائل سفلية ضعيفة جداً
        v = rng.uniform(900, 1600)
        opens.append(o); highs.append(h); lows.append(l); closes.append(c); volumes.append(v)
        last_close = c

    n_total = len(closes)
    # timestamps وهمية (4h candles، تنتهي عند لحظة اصطناعية)
    end_ts = 1800000000000  # قيمة وهمية بعيدة تماماً عن أي تاريخ حقيقي مستخدم سابقاً
    timestamps = [end_ts - (n_total - 1 - i) * 4 * 3600 * 1000 for i in range(n_total)]

    data = {
        "timestamps": timestamps,
        "opens": [round(float(x), 4) for x in opens],
        "highs": [round(float(x), 4) for x in highs],
        "lows": [round(float(x), 4) for x in lows],
        "closes": [round(float(x), 4) for x in closes],
        "volumes": [round(float(x), 2) for x in volumes],
        "symbol": "SYNTH/USDT",
        "timeframe": "4h",
        "count": n_total,
        "source": "synthetic_generalization_test",
    }

    ground_truth_pattern = {
        "pattern_type": "BULLISH_LIQUIDITY_SWEEP_REVERSAL (Judas Swing / Turtle Soup)",
        "prior_swing_low_price": round(float(prior_swing_low), 4),
        "prior_swing_low_index_from_end": prior_swing_low_idx - n_total,
        "recent_swing_high_broken": round(float(recent_swing_high), 4),
        "sweep_candle_index_from_end": -(8 + 3 - 1),  # موقع شمعة السحب
        "sweep_low_price": round(float(sweep_low), 4),
        "sweep_close_price": round(float(sweep_close), 4),
        "displacement_candle_index_from_end": -9,
        "displacement_close_price": round(float(displacement_close), 4),
        "expected_bot_conclusion": (
            "genuine liquidity sweep below prior swing low, followed by "
            "strong bullish displacement breaking recent swing high = "
            "bullish structural reversal (BOS up), NOT a fake continuation"
        ),
    }

    return data, ground_truth_pattern


if __name__ == "__main__":
    import json
    data, gt = generate_bullish_reversal_setup()
    print("عدد الشموع المولدة:", data["count"])
    print("نطاق السعر:", min(data["lows"]), "-", max(data["highs"]))
    print()
    print("=== Ground Truth Pattern (ما بنيناه عمداً - لن يُعطى للـAI) ===")
    print(json.dumps(gt, indent=2, ensure_ascii=False))
    print()
    print("=== آخر 15 شمعة (المنطقة الحرجة: سحب سيولة + اندفاع) ===")
    for i in range(-15, 0):
        print(f"  idx={i}: O={data['opens'][i]:.4f} H={data['highs'][i]:.4f} "
              f"L={data['lows'][i]:.4f} C={data['closes'][i]:.4f} V={data['volumes'][i]:.0f}")