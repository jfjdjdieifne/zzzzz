# -*- coding: utf-8 -*-
import logging
from ai_client import AIClient


class NewsAnalyzer:
    def __init__(self):
        self.logger = logging.getLogger("NewsAnalyzer")
        self.ai = AIClient()

    def analyze(self, symbol="BTC"):
        prompt = f"""حلل العوامل الأساسية المؤثرة على {symbol} حالياً:
1. أهم 3 عوامل أساسية
2. تأثير كل عامل (إيجابي/سلبي/محايد)
3. مستوى التأثير (قوي/متوسط/ضعيف)
ملاحظة: أعطني تحليل عام للعوامل الاقتصادية والتنظيمية.
أجب JSON."""
        return self.ai.query_json(prompt)