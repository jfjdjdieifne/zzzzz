# -*- coding: utf-8 -*-
"""
KnowledgeGraph: محرك الرسم المعرفي الذكي
يخزن المفاهيم والعلاقات محلياً (networkx) ويستخدم AIClient الموحّد
(Gemini فقط) للاستنتاج والشرح - بدون أي مفتاح مكشوف بالكود.
"""
import logging
from datetime import datetime

try:
    import networkx as nx
except ImportError:
    nx = None

from ai_client import AIClient


class KnowledgeGraph:
    """
    رسم معرفي متقدم: كل مفهوم node، العلاقات edges
    (يسبب، يؤكد، يناقض، جزء من، نوع من...)
    """

    def __init__(self):
        self.logger = logging.getLogger("KnowledgeGraph")
        self.ai = AIClient()
        self.graph = nx.MultiDiGraph() if nx else None
        if self.graph is None:
            self.logger.warning("⚠️ networkx غير مثبت - الرسم المعرفي المحلي معطّل")
        self.logger.info("KnowledgeGraph initialized.")

    # ── AI-based reasoning (يمر عبر AIClient الموحّد) ──
    def ai_explain(self, concept_name):
        prompt = f"اشرح مفهوم '{concept_name}' التداولي بكلمات بسيطة مع أمثلة وسياق."
        return self.ai.query(prompt, max_tokens=512)

    def ai_reason(self, concepts):
        prompt = f"استنتج علاقات أو نتائج من المفاهيم التداولية التالية: {concepts}"
        return self.ai.query(prompt, max_tokens=512)

    # ── Local graph operations ──
    def add_concept(self, concept):
        """إضافة مفهوم تداولي: شرح، شروط، أمثلة، ثقة، مصدر، تاريخ، ارتباطات."""
        if self.graph is None:
            return
        name = concept.get("name")
        if not name:
            self.logger.warning("Concept missing name.")
            return
        node_data = {
            "شرح": concept.get("شرح", "لا يوجد شرح"),
            "شروط": concept.get("شروط", []),
            "أمثلة": concept.get("أمثلة", []),
            "ثقة": concept.get("ثقة", 0.5),
            "مصدر": concept.get("مصدر", ""),
            "تاريخ": concept.get("تاريخ", str(datetime.now())),
            "ارتباطات": concept.get("ارتباطات", []),
        }
        self.graph.add_node(name, **node_data)
        for rel in node_data["ارتباطات"]:
            self.graph.add_edge(
                name, rel["target"], relation=rel["type"],
                confidence=rel.get("confidence", 1.0)
            )
        self.logger.info(f"Concept added: {name}")

    def explain(self, concept_name):
        """شرح مفهوم من الرسم المحلي، وإلا يسأل الـ AI."""
        if self.graph is not None and concept_name in self.graph:
            شرح = self.graph.nodes[concept_name].get("شرح", "لا يوجد شرح")
            أمثلة = self.graph.nodes[concept_name].get("أمثلة", [])
            سياق = self.graph.nodes[concept_name].get("شروط", [])
            return f"{شرح}\nأمثلة: {أمثلة}\nسياق: {سياق}"
        return self.ai_explain(concept_name)

    def find_related(self, concept_name):
        if self.graph is None or concept_name not in self.graph:
            return []
        return list(self.graph.successors(concept_name))

    def reason(self, concepts):
        results = []
        for c in concepts:
            name = c.get("name", c) if isinstance(c, dict) else c
            related = self.find_related(name)
            results.append({"concept": name, "related": related})
        return results

    def update_belief(self, concept_name, new_confidence):
        if self.graph is not None and concept_name in self.graph:
            self.graph.nodes[concept_name]["ثقة"] = new_confidence
            self.logger.info(f"Belief updated for {concept_name}: {new_confidence}")

    def connect_new_knowledge(self, concept_name, related_name, relation_type):
        if self.graph is not None and concept_name in self.graph and related_name in self.graph:
            self.graph.add_edge(concept_name, related_name, relation=relation_type)
            self.logger.info(f"Connected {concept_name} -> {related_name} ({relation_type})")

    def find_contradictions(self):
        if self.graph is None:
            return []
        return [
            (u, v) for u, v, d in self.graph.edges(data=True)
            if d.get("relation") == "يناقض"
        ]

    def synthesize(self, concept_names):
        if self.graph is None:
            return {}
        return {
            name: self.graph.nodes[name]
            for name in concept_names if name in self.graph
        }