# -*- coding: utf-8 -*-
"""
NemotronClient - عميل مبسّط ومستقل لاستدعاء nvidia/nemotron-3-ultra-550b-a55b:free
عبر OpenRouter، بديل مؤقت لـ AIClient الأصلي (يلي مبني حول Gemini/Cloudflare)
لغرض باك تيست حقيقي على منهجية Top-Down الخمس-مراحل الأصلية
(multi_pass_analysis.py) لكن بموديل Nemotron.

الفرق الجوهري عن كل محاولات الجلسة السابقة الموثقة بـ"New Text Document.txt":
  - نستخدم بارامتر `reasoning` الرسمي من OpenRouter (effort: none/low/...)
    بدل الاعتماد فقط على max_tokens (يلي كان يخلي الموديل يكتب تفكيره
    الكامل داخل content نفسه ويقطع قبل ما يوصل للـ JSON).
  - نعيد استخدام نفس prompts/schemas الأصلية من multi_pass_analysis.py
    (Weekly->Daily->4H->1H->Entry, نفس knowledge_sections.py) - ما منخترع
    تحليل جديد من الصفر.
"""
import json
import re
import time
import requests


class NemotronClient:
    def __init__(self, api_key, reasoning_effort="none", max_tokens=4000,
                 temperature=0.1, timeout=150, backup_keys=None):
        self.api_key = api_key
        self.backup_keys = backup_keys or []
        self.reasoning_effort = reasoning_effort
        self.max_tokens = max_tokens
        self.temperature = temperature
        self.timeout = timeout
        self.model = "nvidia/nemotron-3-ultra-550b-a55b:free"
        self.url = "https://openrouter.ai/api/v1/chat/completions"
        self.total_requests = 0
        self.total_time = 0.0
        self.total_completion_tokens = 0
        self.total_reasoning_tokens = 0
        self.call_log = []

    @staticmethod
    def _gemini_schema_to_instructions(schema):
        """يحوّل Gemini-style schema (OBJECT/STRING/enum) لتعليمات JSON نصية،
        لأن Nemotron عبر OpenRouter ما بيدعم response_schema بنفس طريقة Gemini
        الأصلية - بنعتمد على التوجيه النصي الصريح بدل ضمان بنيوي (نفس القيد
        الموثق أصلاً بالمشروع لأي مزود لا يدعم responseSchema)."""
        props = schema.get("properties", {})
        required = schema.get("required", [])
        lines = ["Required JSON fields and their exact types/allowed values:"]
        for name, spec in props.items():
            req_mark = " (REQUIRED)" if name in required else " (optional)"
            t = spec.get("type", "STRING")
            if "enum" in spec:
                lines.append(f'  "{name}": one of {spec["enum"]}{req_mark}')
            elif t == "OBJECT":
                sub = spec.get("properties", {})
                sub_desc = ", ".join(f'"{k}":{v.get("type")}' for k, v in sub.items())
                lines.append(f'  "{name}": {{{sub_desc}}}{req_mark}')
            elif t == "ARRAY":
                lines.append(f'  "{name}": array of strings{req_mark}')
            else:
                desc = spec.get("description", "")
                lines.append(f'  "{name}": {t}{req_mark} - {desc}')
        return "\n".join(lines)

    def query_json(self, prompt, schema, extra_note="", max_retries=4, retry_keys=None):
        """يرسل طلب، مع إعادة محاولة تلقائية عند rate-limit/errors مؤقتة
        (502 ResourceExhausted من طرف NVIDIA نفسها - ليست مشكلة بمفتاحنا،
        شوهدت فعلياً بالاختبار الحي). retry_keys: قائمة اختيارية بمفاتيح
        احتياطية يُبدَّل لها عند فشل متكرر على نفس المفتاح.

        ⚠️ إصلاح استهلاك حصة غير ضروري (يوليو 2026، بطلب صريح من
        المستخدم بعد ملاحظة استهلاك الحصة اليومية بسرعة غير متوقعة):
        تحقق موثّق رسمياً (OpenRouter docs/limits + Zendesk support
        article): "Making additional accounts or API keys will not
        affect your rate limits, as we govern capacity globally" -
        و"Failed attempts still count toward your daily quota" - يعني
        الحصة اليومية (50 أو 1000 طلب) محسوبة على مستوى الحساب/الجهاز
        **عالمياً**، وأي محاولة فاشلة (حتى 429) **تُحسب من الحصة نفسها**.
        النسخة السابقة كانت تُعامل "429 استنفاد الحصة اليومية" (خطأ
        دائم، لا فائدة إطلاقاً من إعادة المحاولة على أي مفتاح - كلهم
        يتشاركون نفس السقف) بنفس منطق "502 ازدحام مؤقت" (خطأ عابر،
        إعادة المحاولة فعلاً منطقية) - فكانت تُعيد المحاولة 3-4 مرات
        إضافية بلا فائدة، كل واحدة منها "تستهلك" من الحصة نفسها بلا أي
        احتمال نجاح (تحقق فعلي موثّق: صفقة واحدة استهلكت 8 طلبات فاشلة
        متتالية جميعها 429 "free-models-per-day" من نفس السبب بالضبط).
        الإصلاح: تمييز صريح - عند اكتشاف رسالة "free-models-per-day"
        تحديداً (الحصة اليومية العالمية، لا علاقة بالمفتاح المحدد)،
        نتوقف فوراً بلا أي محاولة إضافية (سواء بنفس المفتاح أو غيره -
        لا فائدة مضمونة) - هذا **لا يقلل الدقة إطلاقاً** (الطلب كان
        سيفشل حتماً على أي حال)، فقط يوفر استهلاكاً عبثياً للحصة نفسها،
        يترك مجالاً أكبر لصفقات أخرى بنفس اليوم.
        """
        schema_instructions = self._gemini_schema_to_instructions(schema)
        full_prompt = (
            f"{prompt}\n\n{'='*40}\nOUTPUT FORMAT (STRICT)\n{'='*40}\n"
            f"{schema_instructions}\n\n"
            f"{extra_note}\n"
            "Reply with ONLY the JSON object. No markdown code fences, no "
            "explanation before or after it."
        )
        keys_to_try = [self.api_key] + (retry_keys or self.backup_keys)
        last_meta = None
        for attempt in range(max_retries):
            key = keys_to_try[attempt % len(keys_to_try)]
            parsed, meta = self._single_call(full_prompt, key)
            last_meta = meta
            if parsed is not None:
                return parsed, meta
            err = str(meta.get("error", "")) + str(meta.get("body", ""))
            if "free-models-per-day" in err:
                # ⚠️ حصة يومية عالمية مستنفدة - لا فائدة من أي محاولة
                # أخرى (لا بهذا المفتاح، لا بمفتاح احتياطي) - توقف فوري.
                break
            if "ResourceExhausted" in err or "502" in err or "429" in err or "TIMEOUT" in err:
                wait = 3 * (attempt + 1)
                time.sleep(wait)
                continue
            else:
                break
        return None, last_meta


    def _single_call(self, full_prompt, key):
        body = {
            "model": self.model,
            "messages": [{"role": "user", "content": full_prompt}],
            "max_tokens": self.max_tokens,
            "temperature": self.temperature,
            "reasoning": {"effort": self.reasoning_effort},
        }
        t0 = time.time()
        try:
            r = requests.post(
                self.url,
                headers={"Authorization": f"Bearer {key}",
                         "Content-Type": "application/json"},
                json=body, timeout=self.timeout,
            )
        except requests.Timeout:
            elapsed = time.time() - t0
            meta = {"error": "TIMEOUT", "elapsed": elapsed}
            self.call_log.append(meta)
            return None, meta
        elapsed = time.time() - t0
        self.total_requests += 1
        self.total_time += elapsed

        if r.status_code != 200:
            meta = {"error": f"HTTP {r.status_code}", "body": r.text[:300], "elapsed": elapsed}
            self.call_log.append(meta)
            return None, meta

        data = r.json()
        if "error" in data and data["error"]:
            meta = {"error": str(data["error"])[:300], "elapsed": elapsed}
            self.call_log.append(meta)
            return None, meta

        choice = data["choices"][0]
        msg = choice["message"]
        content = msg.get("content", "")
        finish = choice.get("finish_reason", "?")
        usage = data.get("usage", {})
        completion_tok = usage.get("completion_tokens", 0)
        reasoning_tok = usage.get("completion_tokens_details", {}).get("reasoning_tokens", 0)
        prompt_tok = usage.get("prompt_tokens", 0)

        self.total_completion_tokens += completion_tok
        self.total_reasoning_tokens += reasoning_tok

        meta = {
            "elapsed": elapsed, "finish": finish, "prompt_tokens": prompt_tok,
            "completion_tokens": completion_tok, "reasoning_tokens": reasoning_tok,
            "raw_content_len": len(content),
        }

        parsed = self._extract_json(content)
        if parsed is None:
            meta["error"] = "JSON_PARSE_FAILED"
            meta["content_tail"] = content[-400:]
        self.call_log.append(meta)
        return parsed, meta

    @staticmethod
    def _extract_json(content):
        try:
            return json.loads(content)
        except Exception:
            pass
        # code fence
        m = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", content, re.DOTALL)
        if m:
            try:
                return json.loads(m.group(1))
            except Exception:
                pass
        # brace counting from first {
        start = content.find("{")
        if start >= 0:
            depth = 0
            for i in range(start, len(content)):
                if content[i] == "{":
                    depth += 1
                elif content[i] == "}":
                    depth -= 1
                    if depth == 0:
                        try:
                            return json.loads(content[start:i + 1])
                        except Exception:
                            break
        return None

    def summary(self):
        return {
            "total_requests": self.total_requests,
            "total_time_sec": round(self.total_time, 1),
            "total_completion_tokens": self.total_completion_tokens,
            "total_reasoning_tokens": self.total_reasoning_tokens,
            "reasoning_effort_used": self.reasoning_effort,
        }
