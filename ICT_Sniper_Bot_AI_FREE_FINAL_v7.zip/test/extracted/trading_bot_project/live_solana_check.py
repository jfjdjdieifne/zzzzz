import sys, time, datetime
sys.path.insert(0, ".")
from brain_core import BrainCore
from ict_math_engine import compute_mechanical_bias_anchor, classify_sweep_or_run
from authenticity_engine import AuthenticityEngine
from ict_entry_checklist_engine import evaluate_all_entry_models
from ict_sessions import classify_session
import pytz

brain = BrainCore()
ae = AuthenticityEngine()
ny_tz = pytz.timezone('America/New_York')

SYMBOL = "SOL/USDT"

print(f"\n{'='*80}")
print(f"📡 تحليل مباشر من البوت لعملة {SYMBOL} الآن...")
print(f"{'='*80}")

current_ts_ms = int(time.time()*1000)
now_ny = datetime.datetime.now(datetime.timezone.utc).astimezone(ny_tz)
session_info = classify_session(current_ts_ms)
curr_session = session_info.get("session", "UNKNOWN")

print(f"توقيت نيويورك: {now_ny.strftime('%H:%M:%S')} | الجلسة الحالية: {curr_session}\n")

# 1. الاتجاه من הפريم اليومي الحقيقي (1D)
data_1d = brain.data_manager.fetch_ohlcv_up_to(SYMBOL, "1d", current_ts_ms, limit=100)
if data_1d and data_1d['closes']:
    anchor_1d = compute_mechanical_bias_anchor(data_1d, lookback=60)
    bias = anchor_1d.get("anchor_direction")
else:
    bias = "UNKNOWN"

# 2. البيانات اللحظية (15m)
data_15m = brain.data_manager.fetch_ohlcv_up_to(SYMBOL, "15m", current_ts_ms, limit=200)
if not data_15m or not data_15m['closes']:
    print("❌ لا توجد بيانات 15m!")
    sys.exit(1)

current_p = data_15m['closes'][-1]
print(f"السعر اللحظي: {current_p:.4f}")
print(f"الاتجاه اليومي (Daily Bias): {bias}")

if bias not in ["BULLISH", "BEARISH"]:
    print("\n🛑 القرار: HOLD - لا يوجد ترند يومي واضح. البوت لن يتداول.")
    sys.exit(0)

# 3. إيجاد السيولة الصالحة للاصطياد (Fresh Liquidity)
# استبعاد الشمعة المفتوحة حالياً من التحليل لتجنب ה- Repainting
closed_15m_data = {k: v[:-1] for k, v in data_15m.items() if isinstance(v, list)}
sig = ae.detect_significant_swings(closed_15m_data, swing_window=2, lookback_candles=150)

valid_target = None
if bias == "BULLISH":
    # نبحث عن قيعان (SSL) *تحت* السعر الحالي
    lows = [s for s in sig.get("all_lows_tiered", []) if s['price'] < current_p and s.get("tier") in ["MAJOR", "MODERATE"]]
    if lows:
        lows.sort(key=lambda x: current_p - x['price']) # الأقرب أولاً
        valid_target = lows[0]
        target_type = "قاع (Sell-Side Liquidity)"
else:
    # نبحث عن قمم (BSL) *فوق* السعر الحالي
    highs = [s for s in sig.get("all_highs_tiered", []) if s['price'] > current_p and s.get("tier") in ["MAJOR", "MODERATE"]]
    if highs:
        highs.sort(key=lambda x: x['price'] - current_p)
        valid_target = highs[0]
        target_type = "قمة (Buy-Side Liquidity)"

if not valid_target:
    print(f"\n👁️ لا توجد سيولة ({target_type}) قريبة وغير מضروبة. البوت يراقب تشكل قمم/قيعان جديدة.")
    sys.exit(0)

target_lvl = valid_target['price']
dist = abs(current_p - target_lvl)
print(f"🎯 الهدف المنتظر (الفخ): {target_type} عند {target_lvl:.4f}")
print(f"📏 المسافة للوصول للفخ: {dist:.4f}$ ({(dist/current_p)*100:.2f}%)")

# 4. هل تم ضرب הפخ للتو؟
res = classify_sweep_or_run(closed_15m_data, target_lvl, level_is_high=(bias=="BEARISH"), check_from_idx=len(closed_15m_data['closes'])-1)
state = res.get("classification")

print("\n--- حالة הפخ ---")
if state == "LIQUIDITY_RUN_CONTINUATION":
    print(f"❌ المستوى {target_lvl} تم اختراقه والإغلاق خلفه (Run). هذا ليس فخاً. البوت سيبحث عن سيولة أخرى.")
elif state == "GENUINE_REVERSAL_SWEEP" and res.get("candle_index_from_end") >= -2:
    print(f"🚨 عاجل: الماركت מيكر ضرب السيولة tại {target_lvl} وارتد مشكلاً ذيلاً (Sweep)!")
    
    # 5. التوجه لـ 5m للبحث عن الدخول
    print("🔫 البوت يغوص الآن في فريم 5 دقائق للبحث عن (FVG)...")
    data_5m = brain.data_manager.fetch_ohlcv_up_to(SYMBOL, "5m", current_ts_ms, limit=150)
    res_5m = evaluate_all_entry_models(data_5m, bias)
    status = res_5m.get("final_status")
    
    if status == "READY":
        plan = res_5m.get("chosen_model", {}).get("plan", {})
        print(f"✅ صفقة מكتملة: {'بيع 🔴' if bias == 'BEARISH' else 'شراء 🟢'}")
        print(f"دخول: {plan.get('entry')} | סטوب: {plan.get('stop_loss')} | هدف: {plan.get('tp')}")
    else:
        print("⏳ الفجوة السعرية (FVG) لم تتشكل بعد أو غير مكتملة الشروط. ننتظر.")
else:
    print(f"⏳ السعر لم يلامس المستوى بعد. البوت في وضع الاستعداد (Pending).")

