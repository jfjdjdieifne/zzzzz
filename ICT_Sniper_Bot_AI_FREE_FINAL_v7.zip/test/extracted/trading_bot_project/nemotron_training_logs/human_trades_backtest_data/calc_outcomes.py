# -*- coding: utf-8 -*-
"""
يحسب النتيجة الفعلية لكل صفقة بشرية موثقة، بشكل مستقل 100% عن أي AI:
- هل انلمس الدخول؟ متى؟
- بعد الدخول، شو انضرب أول: SL أو TP (وأي TP بالتحديد)؟
- الربح/الخسارة بالنسبة المئوية والدولار (مع افتراض حجم صفقة موحد لكل الاختبار)
"""
import json
import requests
import time
from datetime import datetime, timezone


def fetch_okx_range(inst_id, bar, start_ts, end_ts):
    url = "https://www.okx.com/api/v5/market/history-candles"
    all_candles = []
    after = end_ts + 1
    for _ in range(60):
        params = {"instId": inst_id, "bar": bar, "limit": "100", "after": str(after)}
        r = requests.get(url, params=params, timeout=20)
        d = r.json()
        batch = d.get("data", [])
        if not batch:
            break
        all_candles.extend(batch)
        oldest_ts = int(batch[-1][0])
        if oldest_ts <= start_ts:
            break
        after = oldest_ts
        time.sleep(0.12)
    filtered = [c for c in all_candles if start_ts <= int(c[0]) <= end_ts]
    filtered.sort(key=lambda c: int(c[0]))
    return filtered


def calc_trade_outcome(trade, max_days=25):
    symbol = trade["symbol"].replace("/USDT", "-USDT")
    entry = trade["entry"]
    entry_lo, entry_hi = (min(entry), max(entry)) if isinstance(entry, list) else (entry, entry)
    sl = trade["sl"]
    tp = trade["tp"]
    tp_list = tp if isinstance(tp, list) else ([tp] if tp else [])
    bias = trade["human_bias"]
    is_short = "SHORT" in bias.upper() and "LONG" not in bias.upper()

    start_ts = trade["publish_ts"]
    end_ts = start_ts + max_days * 24 * 3600 * 1000
    candles = fetch_okx_range(symbol, "1H", start_ts, end_ts)
    if not candles:
        return {"error": "NO_DATA"}

    # find entry hit
    entry_idx = None
    for i, c in enumerate(candles):
        lo, hi = float(c[3]), float(c[2])
        if lo <= entry_hi and hi >= entry_lo:
            entry_idx = i
            break

    result = {
        "candles_fetched": len(candles),
        "price_range": [min(float(c[3]) for c in candles), max(float(c[2]) for c in candles)],
        "entry_hit": entry_idx is not None,
    }

    if entry_idx is None:
        result["outcome"] = "ENTRY_NEVER_HIT"
        return result

    entry_ts = int(candles[entry_idx][0])
    result["entry_hit_time"] = datetime.fromtimestamp(entry_ts / 1000, tz=timezone.utc).isoformat()
    actual_entry_price = (entry_lo + entry_hi) / 2

    outcome = None
    exit_price = None
    exit_time = None
    for j in range(entry_idx, len(candles)):
        lo, hi = float(candles[j][3]), float(candles[j][2])
        if not is_short:
            # LONG: SL below entry, TP above entry
            hit_sl = lo <= sl
            hit_tp = tp_list and hi >= min(tp_list)
        else:
            # SHORT: SL above entry, TP below entry
            hit_sl = hi >= sl
            hit_tp = tp_list and lo <= max(tp_list)

        if hit_sl and hit_tp:
            outcome = "AMBIGUOUS_SAME_CANDLE"
            exit_price = sl
            exit_time = candles[j][0]
            break
        elif hit_sl:
            outcome = "SL_HIT"
            exit_price = sl
            exit_time = candles[j][0]
            break
        elif hit_tp:
            # find which TP hit first
            if not is_short:
                hit_tps = [t for t in tp_list if hi >= t]
                exit_price = min(hit_tps)
            else:
                hit_tps = [t for t in tp_list if lo <= t]
                exit_price = max(hit_tps)
            outcome = f"TP_HIT({exit_price})"
            exit_time = candles[j][0]
            break

    if outcome is None:
        outcome = "NEITHER_HIT_WITHIN_WINDOW"
        # use last close as mark-to-market
        exit_price = float(candles[-1][4])
        exit_time = candles[-1][0]

    result["outcome"] = outcome
    result["exit_price"] = exit_price
    result["exit_time"] = datetime.fromtimestamp(int(exit_time) / 1000, tz=timezone.utc).isoformat()
    result["actual_entry_price_used"] = actual_entry_price
    result["is_short"] = is_short

    # PnL calculation
    if not is_short:
        pnl_pct = (exit_price - actual_entry_price) / actual_entry_price * 100
    else:
        pnl_pct = (actual_entry_price - exit_price) / actual_entry_price * 100
    result["pnl_pct"] = round(pnl_pct, 3)

    return result


if __name__ == "__main__":
    trades = json.load(open("all_human_trades.json"))
    results = []
    for t in trades:
        print(f"Processing #{t['id']} {t['symbol']} {t['publish_date']}...")
        try:
            r = calc_trade_outcome(t)
        except Exception as e:
            r = {"error": str(e)}
        t["actual_outcome"] = r
        results.append(t)
        print(f"  -> {r.get('outcome', r.get('error'))}, pnl%={r.get('pnl_pct')}")

    with open("all_human_trades_with_outcomes.json", "w") as f:
        json.dump(results, f, indent=2, default=str, ensure_ascii=False)
    print("\nDone.")
