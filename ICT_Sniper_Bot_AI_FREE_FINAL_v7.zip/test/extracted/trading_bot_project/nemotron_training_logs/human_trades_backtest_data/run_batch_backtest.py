# -*- coding: utf-8 -*-
"""
run_batch_backtest.py
════════════════════════════════════════════════════════════════════
باك تيست حقيقي على 19 صفقة بشرية موثقة (Capital Street FX)، باستخدام
نفس محرك multi_pass_analysis.py الأصلي (Weekly->Daily->4H->1H->Entry)
عبر Nemotron 3 Ultra (OpenRouter)، بلا أي اختراع/توليد صفقات.

لكل صفقة:
  - end_ts = لحظة نشر التحليل البشري بالضبط (بلا lookahead)
  - نستخدم فريم 1h كـ Entry TF (نفس الفريم المستخدم بكل الاختبارات
    المرجعية السابقة بهذه الجلسة)
  - نحفظ النتيجة الكاملة (كل المراحل + التدقيق الحسابي + تدقيق الاستشهاد)
    بملف منفصل تحت backtest_results/

⚠️ مصمم ليكون "resumable": يقرأ backtest_progress.json ويتخطى أي صفقة
خلصت فعلاً (ملف نتيجتها موجود) - لأن العمليات بالخلفية بهالبيئة ما بتضل
عايشة بين رسائل المحادثة (قيد بيئي حقيقي، تم اكتشافه فعلياً بهالجلسة)،
فلازم كل تشغيل يكمل من حيث وقف السابق بدل ما يبلش من الصفر.
"""
import json
import sys
import time
import os

sys.path.insert(0, "/home/user/test/extracted/trading_bot_project")
os.chdir("/home/user/test/extracted/trading_bot_project")

from nemotron_backtest_driver import run_one_backtest

ALL_KEYS = [
    "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",
    "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",
    "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",
    "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",
    "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",
    "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",
]

TRADES_FILE = "/home/user/human_trades/all_human_trades_with_outcomes.json"
OUT_DIR = "/home/user/human_trades/backtest_results"
PROGRESS_FILE = "/home/user/human_trades/backtest_progress.json"

os.makedirs(OUT_DIR, exist_ok=True)


def load_progress():
    if os.path.exists(PROGRESS_FILE):
        try:
            return json.load(open(PROGRESS_FILE))
        except Exception:
            pass
    return {"done": [], "key_idx": 0}


def save_progress(p):
    json.dump(p, open(PROGRESS_FILE, "w"), indent=2)


def main(max_trades_this_run=None):
    trades = json.load(open(TRADES_FILE))
    progress = load_progress()
    done_ids = set(progress.get("done", []))
    key_idx = progress.get("key_idx", 0)

    processed_this_run = 0

    for t in trades:
        if max_trades_this_run and processed_this_run >= max_trades_this_run:
            print(f"\n⏸️  وصلنا حد {max_trades_this_run} صفقة بهالتشغيلة - نوقف هون (سكمل بتشغيلة تالية).")
            break

        tid = t["id"]
        out_path = f"{OUT_DIR}/trade_{tid:02d}.json"
        if tid in done_ids and os.path.exists(out_path):
            continue

        symbol = t["symbol"]
        end_ts = t["publish_ts"]
        label = f"HUMAN_TRADE_{tid:02d}_{symbol.replace('/', '')}_{t['publish_date']}"

        primary_key = ALL_KEYS[key_idx % len(ALL_KEYS)]
        backup_keys = ALL_KEYS[(key_idx + 1) % len(ALL_KEYS):] + ALL_KEYS[:(key_idx + 1) % len(ALL_KEYS)]
        key_idx += 1
        progress["key_idx"] = key_idx
        save_progress(progress)

        print(f"\n{'#'*72}\n# TRADE {tid}/19: {label}\n{'#'*72}", flush=True)

        try:
            result = run_one_backtest(
                symbol=symbol,
                timeframe="1h",
                end_ts=end_ts,
                api_key=primary_key,
                label=label,
                max_tokens=4000,
                timeout=200,
                backup_keys=backup_keys,
            )
        except Exception as e:
            print(f"❌ EXCEPTION على صفقة {tid}: {e}", flush=True)
            result = {"label": label, "error": str(e)}

        if not isinstance(result, dict):
            result = {"label": label, "error": "run_one_backtest returned None"}

        result["human_trade_data"] = t
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(result, f, indent=2, ensure_ascii=False, default=str)

        done_ids.add(tid)
        progress["done"] = sorted(done_ids)
        save_progress(progress)
        processed_this_run += 1

        sig = (result.get("result") or {}).get("signal", "?")
        conf = (result.get("result") or {}).get("confidence", "?")
        print(f"✅ Trade {tid} saved -> signal={sig} conf={conf}", flush=True)

        time.sleep(5)

    remaining = [t["id"] for t in trades if t["id"] not in done_ids]
    print(f"\n\n📊 تقدّم هالجلسة: {len(done_ids)}/{len(trades)} خلصو. المتبقي: {remaining}")


if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("--max", type=int, default=None)
    args = p.parse_args()
    main(max_trades_this_run=args.max)
