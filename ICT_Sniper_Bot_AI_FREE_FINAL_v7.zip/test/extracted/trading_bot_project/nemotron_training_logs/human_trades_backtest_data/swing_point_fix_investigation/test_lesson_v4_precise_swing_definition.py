"""
الدرس الرابع والأدق - السبب الجذري الحقيقي (بعد 3 مستويات تحقق):
البوت خلط بين "أدنى نقطة رأيتها بأثر رجعي بنافذة زمنية" و"قاع متأرجح
مؤكد رياضياً" (Swing Low بالتعريف الصارم: انخفاض ثم ارتداد فعلي قبل
أن ينخفض السعر مجدداً). في الحالة الحقيقية، القيعان اليومية المتتالية
كانت منخفضة باستمرار (بلا ارتداد بينها) - فلا نقطة منها كانت "قاعاً"
حقيقياً بالتعريف الرياضي، كانت جزءاً من انحدار متواصل. البوت أطلق
تسمية "Higher Low" على نقطة لم تكن حتى قاعاً متأرجحاً من الأساس.
"""
import sys, json
sys.path.insert(0, "/home/user/test/extracted/trading_bot_project")
import os
os.chdir("/home/user/test/extracted/trading_bot_project")

from nemotron_openrouter_client import NemotronClient
import lesson_learning

KEY = "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"

trade_context = {
    "symbol": "BTC/USDT",
    "bot_claim": (
        "Labeled a specific daily candle's low as a 'Higher Low' (HL) "
        "and used it as the structural reference for stop-loss placement."
    ),
}

outcome_summary = {
    "outcome": "VERIFIED_MECHANICAL_ERROR",
    "detail": (
        "Direct mechanical verification against the raw OHLC sequence "
        "showed the cited low did NOT qualify as a swing low at all, by "
        "the basic definition (a candle's low must be lower than "
        "candles on BOTH sides - i.e. price must decline TO it and then "
        "genuinely bounce AWAY from it before declining again). In the "
        "actual data, the low the bot cited was immediately followed by "
        "an EVEN LOWER low on the very next candle - meaning price never "
        "bounced away from the cited level at all; it was one point in "
        "an uninterrupted sequence of consecutively lower lows (a "
        "continuous decline), not a genuine turning point. The bot "
        "appears to have confused 'the lowest point visible in a recent "
        "lookback window at a glance' with 'a mechanically confirmed "
        "swing low' - these are NOT the same thing. A true swing low "
        "requires confirmation candles on the right side showing a "
        "genuine bounce; a point immediately undercut by the next candle "
        "was never a swing low to begin with, regardless of how the "
        "bias narrative framed it. This mislabeling then propagated: a "
        "stop-loss was justified by reference to a level that was never "
        "actually a proven support point, so it offered no real "
        "structural protection."
    ),
    "was_decision_correct_in_hindsight": False,
}

nc = NemotronClient(KEY, reasoning_effort="none", max_tokens=1500, timeout=120)
print("جارٍ استخراج الدرس الدقيق الرابع (تعريف Swing Low الصارم)...")
lesson = lesson_learning.extract_lesson(nc, trade_context, outcome_summary)

if lesson:
    print()
    print("=== الدرس الجديد ===")
    print(json.dumps(lesson, indent=2, ensure_ascii=False))
    with open("/home/user/human_trades/lesson_v4_extracted.json", "w", encoding="utf-8") as f:
        json.dump(lesson, f, indent=2, ensure_ascii=False)
else:
    print("❌ فشل الاستخراج")
