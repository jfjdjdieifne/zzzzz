"""
اختبار حي نهائي شامل بعد كل الإصلاحات الجذرية الثلاثة:
1. تنسيق البيانات المحقونة بالبرومبت بصيغة نص عادي (لا Python repr)
2. تحقق صارم من نجاح JSON parsing بكل مرحلة (لا قبول raw_response صامت)
3. حماية صريحة لمرحلة entry عند فشلها بالكامل (HOLD موثق بدل فراغ)
"""
import sys, json
sys.path.insert(0, "/home/user/test/extracted/trading_bot_project")
import os
os.chdir("/home/user/test/extracted/trading_bot_project")
from nemotron_backtest_driver import run_one_backtest

trades = json.load(open("/home/user/human_trades/all_human_trades_with_outcomes.json"))
t1 = next(t for t in trades if t["id"] == 1)

result = run_one_backtest(
    symbol=t1["symbol"], timeframe="1h", end_ts=t1["publish_ts"],
    label="TEST_ROOT_FIX_FINAL_TRADE1", max_tokens=4000, timeout=200,
)
with open("/home/user/human_trades/test_root_fix_final_result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, ensure_ascii=False, default=str)
print("done, signal:", (result or {}).get("result",{}).get("signal"))
