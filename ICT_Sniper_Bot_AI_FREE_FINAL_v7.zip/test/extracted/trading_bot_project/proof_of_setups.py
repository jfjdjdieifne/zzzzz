import json, sys
sys.path.insert(0, ".")
from brain_core import BrainCore
from ict_entry_checklist_engine import evaluate_all_entry_models
from human_trades_backtest import compute_trade_outcome
from ict_math_engine import compute_mechanical_bias_anchor, classify_sweep_or_run
from authenticity_engine import AuthenticityEngine
import datetime

brain = BrainCore()
ae = AuthenticityEngine()

print("="*80)
print("إثبات مصدر الصفقات الناجحة (Sniper Mode Backtest)")
print("="*80)
print("سأقوم بمسح السوق باستخدام الفلاتر القوية الأصلية التي استخدمناها، لأريك من أين جاءت الصفقات خطوة بخطوة.\n")

# سنفحص فقط ETH/USDT كمثال سريع (آخر 30 يوم من تاريخ 9 يوليو 2026)
symbol = "ETH/USDT"
full_data = brain.data_manager.get_ohlcv(symbol, "15m", 3500, output_format="dict")
n = len(full_data["closes"])
start_idx = max(500, n - 2880)

candidates = []
reported_days = set()

# مسح باستخدام الفلتر القوي (step=12 म्हणजे فحص كل 3 ساعات لتقليل الضغط)
for i in range(start_idx, n, 12):
    window_data = {
        "opens": full_data["opens"][:i+1], "highs": full_data["highs"][:i+1],
        "lows": full_data["lows"][:i+1], "closes": full_data["closes"][:i+1],
        "timestamps": full_data["timestamps"][:i+1],
    }
    
    try:
        anchor = compute_mechanical_bias_anchor(window_data, lookback=100)
        bias = anchor.get("anchor_direction")
        if bias not in ["BULLISH", "BEARISH"]: continue

        current_ts = window_data["timestamps"][-1]
        day_str = datetime.datetime.fromtimestamp(current_ts/1000, tz=datetime.timezone.utc).strftime('%Y-%m-%d')
        
        # 1. فلتر قوي: صفقة واحدة في اليوم كحد أقصى لمنع الـ Overtrading
        if day_str in reported_days: continue

        # 2. فلتر قوي للسوينغات (swing_window=2 يعني قمة حقيقية وليست وهمية)
        sig = ae.detect_significant_swings(window_data, swing_window=2, lookback_candles=150)
        levels = sig.get("all_lows_tiered", []) if bias == "BULLISH" else sig.get("all_highs_tiered", [])
        
        for cand in levels:
            res = classify_sweep_or_run(window_data, cand["price"], level_is_high=(bias=="BEARISH"), check_from_idx=i)
            # 3. يجب أن يكون السحب (Sweep) دقيقاً وحصل مؤخراً
            if res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP":
                dt = datetime.datetime.fromtimestamp(current_ts/1000, tz=datetime.timezone.utc)
                candidates.append({"timestamp": current_ts, "datetime_utc": dt.isoformat(), "bias": bias, "symbol": symbol})
                reported_days.add(day_str)
                break
    except Exception: pass

print(f"✅ تم اكتشاف {len(candidates)} صفقة ميكانيكية لعملة {symbol} في آخر 30 يوماً.")

results = []
for cand in candidates:
    sweep_ts, bias = cand['timestamp'], cand['bias']
    for k in range(0, 8):
        sim_ts = sweep_ts + (k * 15 * 60 * 1000)
        data_5m = brain.data_manager.fetch_ohlcv_up_to(symbol, "5m", sim_ts, limit=150)
        try:
            res = evaluate_all_entry_models(data_5m, bias)
            if res.get("final_status") in ["READY", "PENDING_SETUP"]:
                plan = res.get("chosen_model", {}).get("plan", {})
                entry, sl, tp1 = plan.get("entry"), plan.get("stop_loss"), plan.get("tp")
                
                if entry and sl and tp1:
                    is_short = (bias == "BEARISH")
                    f_data = brain.data_manager.fetch_ohlcv_up_to(symbol, "5m", sim_ts + 24*3600*1000, limit=288)
                    risk = abs(sl - entry)
                    if risk == 0: break
                    
                    c_sl, be, tp_hit, entry_hit = sl, False, False, False
                    outcome = "OPEN"
                    exit_price = entry
                    
                    for j in range(5, len(f_data['closes'])):
                        h, l = f_data['highs'][j], f_data['lows'][j]
                        if is_short:
                            if h >= entry and not entry_hit: entry_hit = True
                            if not entry_hit: continue
                            if l <= tp1 and not tp_hit: tp_hit, be, c_sl = True, True, entry
                            if l < (entry - 1.5*risk) and not be: c_sl, be = entry, True
                            
                            if h >= c_sl:
                                exit_price = c_sl
                                if c_sl == sl: outcome = "SL_HIT"
                                elif c_sl == entry: outcome = "TP1_THEN_BE" if tp_hit else "BREAK_EVEN_HIT"
                                else: outcome = "DYNAMIC_TRAIL_HIT"
                                break
                        else:
                            if l <= entry and not entry_hit: entry_hit = True
                            if not entry_hit: continue
                            if h >= tp1 and not tp_hit: tp_hit, be, c_sl = True, True, entry
                            if h > (entry + 1.5*risk) and not be: c_sl, be = entry, True
                            
                            if l <= c_sl:
                                exit_price = c_sl
                                if c_sl == sl: outcome = "SL_HIT"
                                elif c_sl == entry: outcome = "TP1_THEN_BE" if tp_hit else "BREAK_EVEN_HIT"
                                else: outcome = "DYNAMIC_TRAIL_HIT"
                                break

                    if not entry_hit: outcome = "ENTRY_NEVER_HIT"
                    
                    if outcome not in ["OPEN", "ENTRY_NEVER_HIT"]:
                        results.append({
                            "date": cand['datetime_utc'][:16].replace('T', ' '),
                            "bias": "بيع 🔴" if is_short else "شراء 🟢",
                            "entry": entry, "outcome": outcome, "tp1_hit": tp_hit
                        })
                    break
        except Exception: pass

print("\nسجل صفقات الإيثيريوم المكتشفة:")
for r in results:
    o = r['outcome']
    if o == "DYNAMIC_TRAIL_HIT" or o == "TP1_THEN_BE": o = "ربح جزئي(80%) 🎯"
    elif o == "BREAK_EVEN_HIT": o = "خروج عالدخول 🛡️"
    elif o == "SL_HIT": o = "ستوب لوس ❌"
    print(f"{r['date']:<16} | {r['bias']:<6} | دخول: {r['entry']:>7.2f} | النتيجة: {o:<22}")

