# -*- coding: utf-8 -*-
import logging
from datetime import datetime
from data_manager import DataManager
from signal_repository import SignalRepository


class SignalTracker:
    """
    يفحص الصفقات المقترحة ويشوف إذا كانت نجحت أو فشلت أو جزئياً.
    """

    def __init__(self):
        self.logger = logging.getLogger("SignalTracker")
        self.data_manager = DataManager()
        self.repo = SignalRepository()

    def evaluate_signal(self, signal):
        symbol = signal["symbol"]
        timeframe = signal["timeframe"]

        future_data = self.data_manager.get_ohlcv(symbol, timeframe, limit=200)
        if not future_data:
            return {"error": "No data"}

        entry = signal.get("entry", 0)
        sl = signal.get("stop_loss", 0)
        tp1 = signal.get("tp1", 0)
        tp2 = signal.get("tp2", 0)
        tp3 = signal.get("tp3", 0)
        side = signal.get("signal", "HOLD")

        if side not in ["BUY", "SELL"] or entry == 0:
            return {
                "result": "ignored",
                "reason": "Not executable signal"
            }

        highs = future_data["highs"]
        lows = future_data["lows"]
        closes = future_data["closes"]

        entered = False
        hit_sl = False
        hit_tp1 = False
        hit_tp2 = False
        hit_tp3 = False

        max_favorable = None
        max_adverse = None

        entry_index = None
        exit_reason = None
        exit_price = None

        for i in range(len(closes)):
            high = highs[i]
            low = lows[i]

            # تحقق من الدخول
            if not entered:
                if side == "BUY" and low <= entry <= high:
                    entered = True
                    entry_index = i
                elif side == "SELL" and low <= entry <= high:
                    entered = True
                    entry_index = i
                else:
                    continue

            if entered:
                if side == "BUY":
                    favorable = high - entry
                    adverse = entry - low
                else:
                    favorable = entry - low
                    adverse = high - entry

                max_favorable = favorable if max_favorable is None else max(max_favorable, favorable)
                max_adverse = adverse if max_adverse is None else max(max_adverse, adverse)

                if side == "BUY":
                    if not hit_tp1 and high >= tp1:
                        hit_tp1 = True
                    if not hit_tp2 and high >= tp2:
                        hit_tp2 = True
                    if not hit_tp3 and high >= tp3:
                        hit_tp3 = True
                        exit_reason = "tp3_hit"
                        exit_price = tp3
                        break
                    if low <= sl:
                        hit_sl = True
                        exit_reason = "sl_hit"
                        exit_price = sl
                        break

                elif side == "SELL":
                    if not hit_tp1 and low <= tp1:
                        hit_tp1 = True
                    if not hit_tp2 and low <= tp2:
                        hit_tp2 = True
                    if not hit_tp3 and low <= tp3:
                        hit_tp3 = True
                        exit_reason = "tp3_hit"
                        exit_price = tp3
                        break
                    if high >= sl:
                        hit_sl = True
                        exit_reason = "sl_hit"
                        exit_price = sl
                        break

        if not entered:
            return {
                "result": "not_triggered",
                "details": "Price never reached entry"
            }

        if hit_tp3:
            result = "full_win"
        elif hit_tp2:
            result = "strong_win"
        elif hit_tp1:
            result = "partial_win"
        elif hit_sl:
            result = "loss"
        else:
            result = "open_or_unclear"

        return {
            "result": result,
            "entered": entered,
            "entry_index": entry_index,
            "hit_tp1": hit_tp1,
            "hit_tp2": hit_tp2,
            "hit_tp3": hit_tp3,
            "hit_sl": hit_sl,
            "exit_reason": exit_reason,
            "exit_price": exit_price,
            "max_favorable_move": round(max_favorable, 2) if max_favorable is not None else None,
            "max_adverse_move": round(max_adverse, 2) if max_adverse is not None else None,
            "checked_at": str(datetime.now())
        }

    def check_all_unchecked(self):
        signals = self.repo.get_unchecked_signals()
        reports = []

        for s in signals:
            report = self.evaluate_signal(s)
            self.repo.mark_checked(s["id"], report)
            reports.append({
                "signal_id": s["id"],
                "symbol": s["symbol"],
                "timeframe": s["timeframe"],
                "report": report
            })

        return reports