import json, datetime, sys, time
sys.path.insert(0, ".")
from brain_core import BrainCore
from ict_math_engine import compute_mechanical_bias_anchor, classify_sweep_or_run
from authenticity_engine import AuthenticityEngine
from ict_entry_checklist_engine import evaluate_all_entry_models
from ict_sessions import classify_session
import pytz

brain = BrainCore()
ae = AuthenticityEngine()
ACCOUNT_BALANCE = 100.0
RISK_PCT = 0.01

print("\n" + "="*80)
print("🎯 جاري اختبار (وضع القناص الأسطوري - Sniper Mode) لآخر 30 يوماً")
print("الشروط: اتجاه يومي + جلسات لندن/نيويورك فقط + قمم/قيعان رئيسية جداً")
print("="*80)

bt_symbols = ["BTC/USDT", "ETH/USDT", "SOL/USDT", "BNB/USDT", "XRP/USDT"]
all_results = []
bt_account = ACCOUNT_BALANCE

for symbol in bt_symbols:
    try:
        full_data = brain.data_manager.get_ohlcv(symbol, "15m", 3500, output_format="dict")
        if not full_data or len(full_data['closes']) < 1000: continue
        
        n = len(full_data["closes"])
        start_idx = max(500, n - 2880)
        candidates = []
        
        for i in range(start_idx, n, 4): 
            window_data = {k: v[:i+1] for k, v in full_data.items() if isinstance(v, list)}
            try:
                # 1. فلتر الاتجاه
                anchor = compute_mechanical_bias_anchor(window_data, lookback=150)
                bias = anchor.get("anchor_direction")
                if bias not in ["BULLISH", "BEARISH"]: continue

                current_ts = window_data["timestamps"][-1]
                
                # 2. فلتر الجلسات (Kill Zones Only)
                sess = classify_session(current_ts).get("session", "")
                if sess in ["ASIAN_RANGE", "DEAD_ZONE", "UNKNOWN"]: 
                    continue # تجاهل الأوقات الميتة وآسيا تماماً

                # 3. فلتر القمم والقيعان الصارمة جداً (swing_window=3)
                sig = ae.detect_significant_swings(window_data, swing_window=3, lookback_candles=200)
                levels = sig.get("all_lows_tiered", []) if bias == "BULLISH" else sig.get("all_highs_tiered", [])
                
                for cand in levels:
                    # يجب أن يكون القاع أو القمة MAJOR أو MODERATE
                    if cand.get("tier") not in ["MAJOR", "MODERATE"]: continue
                    
                    res = classify_sweep_or_run(window_data, cand["price"], level_is_high=(bias=="BEARISH"), check_from_idx=i)
                    if res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP":
                        # 4. فترة التبريد (12 ساعة)
                        if not any(c["symbol"] == symbol and abs(c["timestamp"] - current_ts) < 12*3600*1000 for c in candidates):
                            dt = datetime.datetime.fromtimestamp(current_ts/1000, tz=datetime.timezone.utc)
                            candidates.append({"timestamp": current_ts, "datetime_utc": dt.isoformat(), "bias": bias, "symbol": symbol})
                        break
            except Exception: pass

        for cand in candidates:
            sweep_ts, bias, sym = cand['timestamp'], cand['bias'], cand['symbol']
            
            # نعطيه 3 ساعات فقط لتشكيل الفجوة والتأكيد
            for k in range(0, 12):
                sim_ts = sweep_ts + (k * 15 * 60 * 1000)
                data_5m = brain.data_manager.fetch_ohlcv_up_to(sym, "5m", sim_ts, limit=150)
                try:
                    res = evaluate_all_entry_models(data_5m, bias)
                    if res.get("final_status") in ["READY", "PENDING_SETUP"]:
                        plan = res.get("chosen_model", {}).get("plan", {})
                        entry, sl, tp1 = plan.get("entry"), plan.get("stop_loss"), plan.get("tp")
                        if entry and sl and tp1:
                            is_short = (bias == "BEARISH")
                            f_data = brain.data_manager.fetch_ohlcv_up_to(sym, "5m", sim_ts + 24*3600*1000, limit=288)
                            risk = abs(sl - entry)
                            if risk == 0: break
                            
                            c_sl, be, tp_hit, entry_hit = sl, False, False, False
                            outcome = "OPEN"
                            exit_price = entry
                            
                            for j in range(5, len(f_data['closes'])):
                                h, l = f_data['highs'][j], f_data['lows'][j]
                                if is_short:
                                    if h >= entry and not entry_hit: entry_hit = True
                                    if not entry_hit: continue
                                    if l <= tp1 and not tp_hit: tp_hit, be, c_sl = True, True, entry
                                    if l < (entry - 1.5*risk) and not be: c_sl, be = entry, True
                                    
                                    if h >= c_sl:
                                        exit_price = c_sl
                                        if c_sl == sl: outcome = "SL_HIT"
                                        elif c_sl == entry: outcome = "TP1_THEN_BE" if tp_hit else "BREAK_EVEN_HIT"
                                        else: outcome = "DYNAMIC_TRAIL_HIT"
                                        break
                                        
                                    if f_data['highs'][j-1] > f_data['highs'][j-2] and f_data['highs'][j-1] > f_data['highs'][j]:
                                        swing_high = f_data['highs'][j-1]
                                        if l < f_data['lows'][j-1] and swing_high < c_sl and be:
                                            c_sl = swing_high + (risk * 0.1) 
                                else:
                                    if l <= entry and not entry_hit: entry_hit = True
                                    if not entry_hit: continue
                                    if h >= tp1 and not tp_hit: tp_hit, be, c_sl = True, True, entry
                                    if h > (entry + 1.5*risk) and not be: c_sl, be = entry, True
                                    
                                    if l <= c_sl:
                                        exit_price = c_sl
                                        if c_sl == sl: outcome = "SL_HIT"
                                        elif c_sl == entry: outcome = "TP1_THEN_BE" if tp_hit else "BREAK_EVEN_HIT"
                                        else: outcome = "DYNAMIC_TRAIL_HIT"
                                        break
                                        
                                    if f_data['lows'][j-1] < f_data['lows'][j-2] and f_data['lows'][j-1] < f_data['lows'][j]:
                                        swing_low = f_data['lows'][j-1]
                                        if h > f_data['highs'][j-1] and swing_low > c_sl and be:
                                            c_sl = swing_low - (risk * 0.1)

                            if not entry_hit: outcome = "ENTRY_NEVER_HIT"
                            
                            if outcome not in ["OPEN", "ENTRY_NEVER_HIT"]:
                                all_results.append({
                                    "date": cand['datetime_utc'][:16].replace('T', ' '),
                                    "symbol": sym, "bias": "بيع 🔴" if is_short else "شراء 🟢",
                                    "entry": entry, "outcome": outcome, "tp1_hit": tp_hit,
                                    "risk": risk, "exit": exit_price, "tp1": tp1
                                })
                            break
                except Exception: pass
    except Exception: pass

all_results.sort(key=lambda x: x["date"])
for r in all_results:
    risk_usd = bt_account * RISK_PCT
    pos_size = risk_usd / r['risk'] if r['risk'] > 0 else 0
    profit = 0.0
    
    if r['outcome'] == "SL_HIT": profit = -risk_usd
    elif r['outcome'] == "BREAK_EVEN_HIT": profit = 0.0
    elif r['outcome'] in ["TP1_THEN_BE", "PARTIAL_TP_HIT_THEN_OPEN"]: 
        profit = (abs(r['tp1'] - r['entry']) * pos_size) * 0.8
    elif r['outcome'] == "DYNAMIC_TRAIL_HIT":
        base_profit = (abs(r['tp1'] - r['entry']) * pos_size) * 0.8 if r['tp1_hit'] else 0.0
        rem_profit = (abs(r['exit'] - r['entry']) * pos_size) * 0.2
        profit = base_profit + rem_profit
        
    bt_account += profit
    r['profit_usd'] = profit
    r['balance'] = bt_account

print(f"{'التاريخ':<16} | {'العملة':<8} | {'النوع':<6} | {'الدخول':<8} | {'النتيجة':<22} | {'الربح':<8} | {'الرصيد':<8}")
print("-" * 90)
for r in all_results:
    o = r['outcome']
    if o == "DYNAMIC_TRAIL_HIT": o = "تتبع هيكلي 🧠🎯"
    elif o == "TP1_THEN_BE" or o == "PARTIAL_TP_HIT_THEN_OPEN": o = "ربح جزئي(80%) 🎯"
    elif o == "BREAK_EVEN_HIT": o = "خروج عالدخول 🛡️"
    elif o == "SL_HIT": o = "ستوب لوس ❌"
    print(f"{r['date']:<16} | {r['symbol']:<8} | {r['bias']:<6} | {r['entry']:>7.2f} | {o:<22} | {r['profit_usd']:>6.2f}$ | {r['balance']:>6.2f}$")

wins = sum(1 for r in all_results if r['profit_usd'] > 0)
losses = sum(1 for r in all_results if r['profit_usd'] < 0)
bes = sum(1 for r in all_results if r['profit_usd'] == 0)
total_trades = wins + losses + bes

print("="*90)
print(f"عدد الصفقات الإجمالي (لأفضل 5 عملات خلال 30 يوماً): {total_trades}")
print(f"✅ رابحة: {wins} | 🛡️ تعادل: {bes} | ❌ خاسرة: {losses}")
if (wins + losses) > 0:
    win_rate = (wins / (wins + losses)) * 100
    print(f"🏆 نسبة النجاح الصافية (Win Rate): {win_rate:.1f}%")
print(f"💰 الرصيد النهائي: {bt_account:.2f}$ (النمو: +{((bt_account-100)/100)*100:.2f}%)")
print("="*90)
