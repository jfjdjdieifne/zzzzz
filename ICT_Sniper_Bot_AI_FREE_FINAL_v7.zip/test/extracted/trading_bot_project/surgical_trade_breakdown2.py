import json, datetime, sys
sys.path.insert(0, ".")
from brain_core import BrainCore
from ict_math_engine import compute_mechanical_bias_anchor, detect_fair_value_gaps
from authenticity_engine import AuthenticityEngine
from ict_entry_checklist_engine import evaluate_all_entry_models

brain = BrainCore()
ae = AuthenticityEngine()
SYMBOL = "ETH/USDT"
# وقت الصفقة الرابعة (بيع) التي ضربت ستوب المتداولين ولكنها نجحت بالـ Trailing Stop
# 11 يونيو الساعة 14:45 UTC
target_ts = 1781189100000 

print("="*80)
print("التشريح الجراحي لصفقة ETH/USDT (شمعة بشمعة، سنت بسنت)")
print("="*80)

data_15m = brain.data_manager.fetch_ohlcv_up_to(SYMBOL, "15m", target_ts, limit=200)

anchor = compute_mechanical_bias_anchor(data_15m, lookback=150)
print(f"1. الرياضيات خلف الاتجاه (The Bias):")
print(f"   النتيجة الميكانيكية = {anchor.get('anchor_direction')}")
print(f"   كيف؟ البوت قرأ 150 شمعة ووجد سلسلة من הקمم المنخفضة (Lower Highs) والقيعان المنخفضة (Lower Lows).\n")

sig = ae.detect_significant_swings(data_15m, swing_window=1, lookback_candles=150)
highs = [s for s in sig.get("all_highs_tiered", []) if s.get("tier") in ["MAJOR", "MODERATE"]]
target_high = highs[0]
print(f"2. صيد السيولة (The Trap):")
print(f"   - السعر المستهدف (Buy-Side Liquidity): {target_high['price']}")
print(f"   - متى تشكلت هذه القمة؟ قبل {abs(target_high['index_from_end'])} شمعة على فريم 15 دقيقة.")
print(f"   - ماذا حدث؟ السعر صعد فجأة وكسر هذا الرقم صعوداً، ثم ارتد تاركاً 'ذيلاً' (Sweep).\n")

data_5m = brain.data_manager.fetch_ohlcv_up_to(SYMBOL, "5m", target_ts, limit=150)
res_5m = evaluate_all_entry_models(data_5m, "BEARISH")
plan = res_5m.get("chosen_model", {}).get("plan", {})

fvgs = detect_fair_value_gaps(data_5m, lookback=20).get("bearish_fvgs", [])
if fvgs:
    fvg = fvgs[-1]
    print(f"3. حسابات الدخول والستوب (Entry & SL Math):")
    print(f"   - الفجوة السعرية الهابطة (FVG) على فريم 5 دقائق:")
    print(f"      * قمة الفجوة: {fvg['top']}")
    print(f"      * قاع الفجوة: {fvg['bottom']}")
    print(f"      * المعادلة (CE): ({fvg['top']} + {fvg['bottom']}) / 2 = {fvg['ce']}")
    print(f"   - الدخول المبرمج (Limit Order) = {plan['entry']}")
    print(f"   - الستوب لوس: {plan['stop_loss']} (تم وضعه فوق القمة بـ Buffer صغير).\n")

print(f"4. حساب الهدف (TP1 Math):")
print(f"   - الهدف المبرمج: {plan['tp']}")
print(f"   - التبرير: هذه أقرب سيولة سفلية (Internal Liquidity) تم اكتشافها بعملية حسابية لتعطي أكثر من 1.5R.\n")

print("5. التنفيذ الحي (شمعة بشمعة):")
data_fwd = brain.data_manager.fetch_ohlcv_up_to(SYMBOL, "5m", target_ts + 2*3600*1000, limit=25)
entry = plan['entry']
sl = plan['stop_loss']
tp = plan['tp']
risk = abs(sl - entry)

current_sl = sl
be_activated = False

for i in range(len(data_fwd['closes'])):
    if data_fwd['timestamps'][i] < target_ts: continue
    
    t_str = datetime.datetime.fromtimestamp(data_fwd['timestamps'][i]/1000, tz=datetime.timezone.utc).strftime('%H:%M')
    h, l = data_fwd['highs'][i], data_fwd['lows'][i]
    
    action = ""
    # دخول
    if h >= entry and "تفعل" not in str(locals()):
        action = f" 🔴 <-- تفعيل دخول البيع هنا (السعر وصل {h:.2f} ولمس {entry})!"
        entry_hit = True
        
    # حماية (Break-Even) عند 1.5R
    if l <= (entry - 1.5*risk) and not be_activated:
        be_activated = True
        current_sl = entry
        action += f" 🛡️ <-- السعر هبط بقوة مسافة 1.5R. نقل الستوب لوس للدخول ({entry})!"
        
    # تتبع هيكلي (Trailing)
    if i >= 2 and data_fwd['highs'][i-1] > data_fwd['highs'][i-2] and data_fwd['highs'][i-1] > h:
        swing_h = data_fwd['highs'][i-1]
        if l < data_fwd['lows'][i-1] and swing_h < current_sl and be_activated:
            current_sl = swing_h + (risk*0.1)
            action += f" 🧠 <-- تشكلت قمة هابطة جديدة! نقل الستوب لوس إلى {current_sl:.2f}."
            
    print(f"   [{t_str}] High: {h:.2f} | Low: {l:.2f} {action}")
