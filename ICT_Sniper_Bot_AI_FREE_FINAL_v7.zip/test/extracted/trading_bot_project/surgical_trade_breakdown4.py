import json, datetime, sys
sys.path.insert(0, ".")
from brain_core import BrainCore
from ict_math_engine import compute_mechanical_bias_anchor
from authenticity_engine import AuthenticityEngine

brain = BrainCore()
ae = AuthenticityEngine()
SYMBOL = "ETH/USDT"
# وقت الصفقة الرابعة (بيع) التي ناقشناها
target_ts = 1781189100000 

print("="*80)
print("التشريح الجراحي لصفقة ETH/USDT (شمعة بشمعة، سنت بسنت)")
print("="*80)

data_15m = brain.data_manager.fetch_ohlcv_up_to(SYMBOL, "15m", target_ts, limit=200)

anchor = compute_mechanical_bias_anchor(data_15m, lookback=150)
print(f"1. الرياضيات خلف الاتجاه (The Bias):")
print(f"   النتيجة الميكانيكية = {anchor.get('anchor_direction')}")
print(f"   التفسير: البوت قرأ 150 شمعة وقارن القمم والقيعان، واستنتج أن الاتجاه هابط.\n")

sig = ae.detect_significant_swings(data_15m, swing_window=1, lookback_candles=150)
highs = [s for s in sig.get("all_highs_tiered", []) if s.get("tier") in ["MAJOR", "MODERATE"]]
target_high = highs[0]
print(f"2. صيد السيولة (The Trap):")
print(f"   - السعر المستهدف للضرب (Buy-Side Liquidity): {target_high['price']}")
print(f"   - متى تشكلت هذه القمة؟ قبل {abs(target_high['index_from_end'])} شمعة.")
print(f"   - ماذا حدث؟ السعر صعد واخترق هذا الرقم صعوداً، ليضرب ستوبات البائعين ويجمع السيولة.\n")

print(f"3. حسابات الدخول والستوب (Entry & SL Math):")
# بناءً على الكود الميكانيكي المستخرج مسبقاً
entry = 1654.58
sl = 1657.89
tp = 1648.69
risk = abs(sl - entry)
print(f"   - الدخول المبرمج (Limit Order) = {entry:.2f}")
print(f"   - الستوب لوس: {sl:.2f} (تم حسابه ليكون فوق ذيل الاختراق الكاذب تماماً + Buffer صغير).")
print(f"   - مسافة المخاطرة: {risk:.2f} دولار فقط!\n")

print(f"4. حساب الهدف (TP1 Math):")
print(f"   - الهدف الأول: {tp:.2f}")
print(f"   - التبرير: هذه السيولة السفلية تم اختيارها رياضياً لأنها تعطي مسافة (1.78 R:R)، وهي آمنة.\n")

print("5. التنفيذ الحي (شمعة بشمعة):")
data_fwd = brain.data_manager.fetch_ohlcv_up_to(SYMBOL, "5m", target_ts + 3*3600*1000, limit=40)

current_sl = sl
be_activated = False
entry_hit = False

for i in range(len(data_fwd['closes'])):
    if data_fwd['timestamps'][i] < target_ts: continue
    
    t_str = datetime.datetime.fromtimestamp(data_fwd['timestamps'][i]/1000, tz=datetime.timezone.utc).strftime('%H:%M')
    h, l = data_fwd['highs'][i], data_fwd['lows'][i]
    
    action = ""
    # دخول
    if h >= entry and not entry_hit:
        action = f" 🔴 <-- تفعيل دخول البيع هنا (السعر وصل {h:.2f} ولمس {entry})!"
        entry_hit = True
        
    if entry_hit:
        # وصول للهدف
        if l <= tp and "هدف" not in str(locals()):
            action += f" 🎯 <-- ضرب الهدف الأول (أخذ 80% أرباح وتأمين الباقي)!"
            be_activated = True
            current_sl = entry
            
        # تتبع هيكلي (Trailing)
        if i >= 2 and data_fwd['highs'][i-1] > data_fwd['highs'][i-2] and data_fwd['highs'][i-1] > h:
            swing_h = data_fwd['highs'][i-1]
            if l < data_fwd['lows'][i-1] and swing_h < current_sl and be_activated:
                current_sl = swing_h + (risk*0.1)
                action += f" 🧠 <-- تشكلت قمة هابطة جديدة! نقل الستوب لوس إلى {current_sl:.2f}."
                
        # ضرب الستوب المتتبع
        if h >= current_sl and be_activated and current_sl != entry:
            action += f" 🛡️ <-- الماركت ميكر كسر الهيكل وضرب الستوب المتتبع! (خروج آمن بربح)."
            print(f"   [{t_str}] High: {h:.2f} | Low: {l:.2f} {action}")
            break
                
    print(f"   [{t_str}] High: {h:.2f} | Low: {l:.2f} {action}")
