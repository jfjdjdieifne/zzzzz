import sys, time, threading, datetime, os
sys.path.insert(0, ".")
import telebot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from brain_core import BrainCore
from ict_math_engine import compute_mechanical_bias_anchor, classify_sweep_or_run
from authenticity_engine import AuthenticityEngine
from ict_entry_checklist_engine import evaluate_all_entry_models
from ict_sessions import classify_session
from flask import Flask
import pytz

# ================= الإعدادات =================
TELEGRAM_BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "8996304796:AAHK6RMV9jLKUS43oOX9I72jdJBNy0NOz1M")
CHAT_ID = None

brain = BrainCore()
ae = AuthenticityEngine()
bot = telebot.TeleBot(TELEGRAM_BOT_TOKEN)
ny_tz = pytz.timezone('America/New_York')

WATCHING_SYMBOLS = ["BTC/USDT", "ETH/USDT", "SOL/USDT", "BNB/USDT", "XRP/USDT"]

# بيانات المحاكاة الحية الآلية 100%
live_account = 100.0
risk_pct = 0.01
active_trades = {}
reported_pending = set()
is_live_active = False

app = Flask(__name__)
@app.route('/')
def home():
    return "Autonomous ICT Bot is Running 24/7!", 200

# ================= واجهة التيليجرام =================
def main_menu():
    markup = InlineKeyboardMarkup(row_width=1)
    markup.add(
        InlineKeyboardButton("🟢 تشغيل التداول الآلي (Auto-Trading)", callback_data="toggle_live"),
        InlineKeyboardButton("📊 كشف حساب (الرصيد والصفقات المفتوحة)", callback_data="check_status"),
        InlineKeyboardButton("🧠 ماذا يرى البوت الآن؟ (تحديث لحظي)", callback_data="live_thoughts")
    )
    return markup

@bot.message_handler(commands=['start'])
def send_welcome(message):
    global CHAT_ID
    CHAT_ID = message.chat.id
    msg = "مرحباً يا سيدي 🤖\n\n"
    msg += "أنا الآن **روبوت تداول آلي بالكامل**. لستُ مجرد مقدم إشارات!\n"
    msg += f"لقد استلمت محفظتك الوهمية، الرصيد الحالي: <code>{live_account}$</code>.\n"
    msg += "بمجرد ضغطك على (تشغيل)، سأقوم بالبحث، הדخول، التتبع، وجني الأرباح بمفردي 24/7.\n"
    msg += "سأرسل לך تحديثات حية بكل دولار أربحه أو أخسره."
    bot.reply_to(message, msg, reply_markup=main_menu(), parse_mode='HTML')

# ================= المحرك الآلي (The Autonomous Engine) =================
def auto_trading_thread():
    global live_account, is_live_active, CHAT_ID
    cycle = 0
    
    while True:
        if is_live_active and CHAT_ID:
            try:
                now_ny = datetime.datetime.now(datetime.timezone.utc).astimezone(ny_tz)
                current_ts_ms = int(time.time()*1000)
                
                # 1. مسح الأسواق (كل 5 دقائق)
                if cycle % 5 == 0:
                    sess = classify_session(current_ts_ms).get("session", "UNKNOWN")
                    
                    for symbol in WATCHING_SYMBOLS:
                        if symbol in active_trades: continue # نتداولها بالفعل
                        
                        data_15m = brain.data_manager.fetch_ohlcv_up_to(symbol, "15m", current_ts_ms, limit=200)
                        if not data_15m or not data_15m['closes']: continue
                        current_p = data_15m['closes'][-1]
                        closed_15m = {k: v[:-1] for k, v in data_15m.items() if isinstance(v, list)}
                        
                        anchor = compute_mechanical_bias_anchor(data_15m, lookback=150)
                        bias = anchor.get("anchor_direction")
                        if bias not in ["BULLISH", "BEARISH"]: continue
                        
                        sig = ae.detect_significant_swings(closed_15m, swing_window=3, lookback_candles=150)
                        valid_target = None
                        ttype = ""
                        recent_sweep_found = False
                        swept_price = 0.0
                        n_15m = len(closed_15m['closes'])
                        
                        if bias == "BULLISH":
                            lows_raw = [s for s in sig.get("all_lows_tiered", []) if s['price'] < current_p and s.get("tier") in ["MAJOR", "MODERATE"]]
                            lows = []
                            check_idx = n_15m - 1
                            for s in lows_raw:
                                s_idx = n_15m + s['index_from_end']
                                if s_idx < check_idx - 1:
                                    min_before = min(closed_15m['lows'][s_idx+1 : check_idx])
                                    if min_before < s['price']: continue
                                lows.append(s)
                            if lows:
                                lows.sort(key=lambda x: current_p - x['price'])
                                valid_target = lows[0]
                                ttype = "قاع سيولة (SSL)"
                                
                            for s in sig.get("all_lows_tiered", []):
                                if s.get("tier") in ["MAJOR", "MODERATE"]:
                                    s_idx = n_15m + s['index_from_end']
                                    check_start = max(s_idx + 1, n_15m - 10)
                                    if check_start < n_15m:
                                        min_recent = min(closed_15m['lows'][check_start : n_15m])
                                        if min_recent < s['price']:
                                            for i in range(check_start, n_15m):
                                                if closed_15m['lows'][i] < s['price'] and closed_15m['closes'][i] > s['price']:
                                                    recent_sweep_found = True
                                                    swept_price = s['price']
                                                    break
                                if recent_sweep_found: break
                        else:
                            highs_raw = [s for s in sig.get("all_highs_tiered", []) if s['price'] > current_p and s.get("tier") in ["MAJOR", "MODERATE"]]
                            highs = []
                            check_idx = n_15m - 1
                            for s in highs_raw:
                                s_idx = n_15m + s['index_from_end']
                                if s_idx < check_idx - 1:
                                    max_before = max(closed_15m['highs'][s_idx+1 : check_idx])
                                    if max_before > s['price']: continue
                                highs.append(s)
                            if highs:
                                highs.sort(key=lambda x: x['price'] - current_p)
                                valid_target = highs[0]
                                ttype = "قمة سيولة (BSL)"
                                
                            for s in sig.get("all_highs_tiered", []):
                                if s.get("tier") in ["MAJOR", "MODERATE"]:
                                    s_idx = n_15m + s['index_from_end']
                                    check_start = max(s_idx + 1, n_15m - 10)
                                    if check_start < n_15m:
                                        max_recent = max(closed_15m['highs'][check_start : n_15m])
                                        if max_recent > s['price']:
                                            for i in range(check_start, n_15m):
                                                if closed_15m['highs'][i] > s['price'] and closed_15m['closes'][i] < s['price']:
                                                    recent_sweep_found = True
                                                    swept_price = s['price']
                                                    break
                                if recent_sweep_found: break

                        msg_block = f"\n{'='*40}\n"
                        msg_block += f"🪙 <b>{symbol}</b> | السعر: {current_p:.4f}\n"
                        msg_block += f"📅 <b>الاتجاه (1D):</b> {'شراء صاعد 🟢' if bias == 'BULLISH' else 'بيع هابط 🔴'}\n"

                        if recent_sweep_found:
                            msg_block += f"🔍 <b>تحليل (15m):</b> ⚡ رصدت سحب سيولة قوي للتو! السعر ضرب مستوى {'(SSL)' if bias == 'BULLISH' else '(BSL)'} عند [{swept_price:.4f}] وارتد. أغوص لـ (5m) لفحص الدخول...\n"
                            
                            data_5m = brain.data_manager.fetch_ohlcv_up_to(symbol, "5m", int(time.time()*1000), limit=150)
                            res_5m = evaluate_all_entry_models(data_5m, bias)
                            
                            chosen = res_5m.get("chosen_model")
                            if chosen:
                                status_arb = "جاهز 🚀" if chosen['status'] == "READY" else "قيد الانتظار ⏳"
                                msg_block += f"🎯 <b>الموديل:</b> {chosen.get('model')} | الحالة: {status_arb}\n"
                                msg_block += "📋 <b>الشروط:</b>\n"
                                for cond in chosen.get("conditions", []):
                                    status_ico = "✅" if cond['status'] == True else ("❌" if cond['status'] == False else "⏳")
                                    msg_block += f"   {status_ico} {cond['name']}: {cond['detail']}\n"
                                    
                            if res_5m.get("final_status") == "READY":
                                plan = res_5m.get("chosen_model", {}).get("plan", {})
                                entry, sl, tp1 = plan.get("entry"), plan.get("stop_loss"), plan.get("tp")
                                if entry and sl and tp1:
                                    risk_dist = abs(entry - sl)
                                    risk_usd = live_account * risk_pct
                                    pos_size = risk_usd / risk_dist if risk_dist > 0 else 0
                                    
                                    msg_exe = f"🔥 <b>تم الدخول آلياً! {symbol}</b> 🔥\n"
                                    msg_exe += f"الدخول: {entry:.4f} | الستوب: {sl:.4f} | الهدف: {tp1:.4f}\n"
                                    bot.send_message(CHAT_ID, msg_exe, parse_mode='HTML')
                                    
                                    active_trades[symbol] = {
                                        "bias": bias, "entry": entry, "sl": sl, "tp1": tp1,
                                        "current_sl": sl, "be_activated": False, "tp1_hit": False,
                                        "is_short": bias == "BEARISH", "risk": risk_dist, "size": pos_size,
                                        "risk_usd": risk_usd
                                    }
                            else:
                                msg_block += "⏳ <i>الخلاصة: الموديل لم يكتمل. أراقب بانتظار الشروط المتبقية (مثلاً FVG).</i>"
                            
                        elif not valid_target:
                            msg_block += f"🔍 <b>تحليل (15m):</b> 👁️ أراقب. لا توجد فخاخ سيولة قريبة."
                        else:
                            target_lvl = valid_target['price']
                            dist = abs(current_p - target_lvl)
                            msg_block += f"🔍 <b>تحليل (15m):</b> 🎯 أنتظر ضرب {ttype} غير الملموس عند [{target_lvl:.4f}] (يبعد {dist:.4f}$)."
                            
                        bot_status_lines.append(msg_block)
