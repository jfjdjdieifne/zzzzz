import sys, time, threading, datetime
sys.path.insert(0, ".")
import telebot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from brain_core import BrainCore
from ict_math_engine import compute_mechanical_bias_anchor, classify_sweep_or_run
from authenticity_engine import AuthenticityEngine
from ict_entry_checklist_engine import evaluate_all_entry_models

# ================= الإعدادات =================
TELEGRAM_BOT_TOKEN = "ضع_توكن_البوت_هنا" # سنطلب من المستخدم وضع التوكن الخاص به
CHAT_ID = None # سيتم حفظه تلقائياً عند أول رسالة للمستخدم

brain = BrainCore()
ae = AuthenticityEngine()
bot = telebot.TeleBot(TELEGRAM_BOT_TOKEN)

# قواعد البيانات الحية في الذاكرة
WATCHING_SYMBOLS = ["ETH/USDT", "BTC/USDT", "SOL/USDT"]
active_trades = {}    # الصفقات التي دخلها المستخدم
pending_signals = {}  # الإشارات الجاهزة بانتظار موافقة المستخدم

# ================= دوال التحليل والردود =================
def scan_market_for_opportunities():
    global CHAT_ID
    if not CHAT_ID: return
    
    for symbol in WATCHING_SYMBOLS:
        try:
            data_15m = brain.data_manager.fetch_ohlcv_up_to(symbol, "15m", int(time.time()*1000), limit=200)
            if not data_15m or not data_15m['closes']: continue
            
            # 1. فحص الاتجاه
            anchor = compute_mechanical_bias_anchor(data_15m, lookback=100)
            bias = anchor.get("anchor_direction")
            if bias not in ["BULLISH", "BEARISH"]: continue
            
            # 2. فحص السحب (Sweep)
            sig = ae.detect_significant_swings(data_15m, swing_window=1, lookback_candles=100)
            is_swept = False
            swept_level = 0
            
            if bias == "BULLISH":
                lows = [s for s in sig.get("all_lows_tiered", [])]
                for cand in lows:
                    res = classify_sweep_or_run(data_15m, cand["price"], level_is_high=False, check_from_idx=len(data_15m['closes'])-1)
                    if res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP" and res.get("candle_index_from_end") >= -2:
                        is_swept = True
                        swept_level = cand["price"]
                        break
            else:
                highs = [s for s in sig.get("all_highs_tiered", [])]
                for cand in highs:
                    res = classify_sweep_or_run(data_15m, cand["price"], level_is_high=True, check_from_idx=len(data_15m['closes'])-1)
                    if res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP" and res.get("candle_index_from_end") >= -2:
                        is_swept = True
                        swept_level = cand["price"]
                        break
            
            if is_swept:
                # 3. فحص التأكيد (FVG/OB)
                data_5m = brain.data_manager.fetch_ohlcv_up_to(symbol, "5m", int(time.time()*1000), limit=150)
                res_5m = evaluate_all_entry_models(data_5m, bias)
                status = res_5m.get("final_status")
                
                if status == "PENDING_SETUP":
                    bot.send_message(CHAT_ID, f"👀 <b>تحديث {symbol}</b>:\nالسعر قام بسحب سيولة عند {swept_level} والاتجاه {bias}.\n⏳ أنا الآن أراقب فريم 5 دقائق بانتظار تأكيد الإزاحة والفجوة السعرية...", parse_mode='HTML')
                    
                elif status == "READY":
                    plan = res_5m.get("chosen_model", {}).get("plan", {})
                    entry = plan.get("entry")
                    sl = plan.get("stop_loss")
                    tp1 = plan.get("tp")
                    if entry and sl and tp1:
                        trade_id = f"{symbol}_{int(time.time())}"
                        pending_signals[trade_id] = {
                            "symbol": symbol, "bias": bias, "entry": entry, 
                            "sl": sl, "tp1": tp1, "is_short": bias=="BEARISH"
                        }
                        
                        msg = f"🚨 <b>اكتمل التأكيد! فرصة جاهزة لـ {symbol}</b> 🚨\n\n"
                        msg += f"القرار: <b>{'بيع (SELL LIMIT)' if bias=='BEARISH' else 'شراء (BUY LIMIT)'}</b>\n"
                        msg += f"🔵 الدخول: <code>{entry}</code>\n"
                        msg += f"🔴 الستوب: <code>{sl}</code>\n"
                        msg += f"🟢 الهدف الأول: <code>{tp1}</code> (لجني 80%)\n\n"
                        msg += f"قم بوضع الأمر في منصتك، ثم اضغط على الزر بالأسفل لأقوم بمتابعة الصفقة لك حياً!"
                        
                        markup = InlineKeyboardMarkup()
                        btn = InlineKeyboardButton("✅ لقد وضعت الأمر (بدأ التتبع)", callback_data=f"enter_{trade_id}")
                        markup.add(btn)
                        bot.send_message(CHAT_ID, msg, reply_markup=markup, parse_mode='HTML')
                        
        except Exception as e:
            pass

def manage_active_trades():
    global CHAT_ID
    if not CHAT_ID or not active_trades: return
    
    for t_id, t_data in list(active_trades.items()):
        try:
            symbol = t_data['symbol']
            is_short = t_data['is_short']
            entry = t_data['entry']
            sl = t_data['sl']
            risk = abs(entry - sl)
            
            data_5m = brain.data_manager.fetch_ohlcv_up_to(symbol, "5m", int(time.time()*1000), limit=20)
            if not data_5m or not data_5m['closes']: continue
            
            current_price = data_5m['closes'][-1]
            h = data_5m['highs'][-1]
            l = data_5m['lows'][-1]
            
            # التحقق من ضرب الستوب
            if is_short and h >= t_data['current_sl']:
                bot.send_message(CHAT_ID, f"❌ صفقة {symbol}: انضرب الوقف عند {t_data['current_sl']}. تم إغلاق التتبع.")
                del active_trades[t_id]
                continue
            elif not is_short and l <= t_data['current_sl']:
                bot.send_message(CHAT_ID, f"❌ صفقة {symbol}: انضرب الوقف عند {t_data['current_sl']}. تم إغلاق التتبع.")
                del active_trades[t_id]
                continue

            # التحقق من 1.5R للـ Break-Even
            if not t_data['be_activated']:
                if is_short and l <= (entry - 1.5*risk):
                    t_data['be_activated'] = True
                    t_data['current_sl'] = entry
                    bot.send_message(CHAT_ID, f"🛡️ <b>تأمين صفقة {symbol}!</b>\nالسعر تجاوز 1.5R. يرجى نقل الستوب لوس إلى نقطة الدخول (Break-Even) فوراً: {entry}", parse_mode='HTML')
                elif not is_short and h >= (entry + 1.5*risk):
                    t_data['be_activated'] = True
                    t_data['current_sl'] = entry
                    bot.send_message(CHAT_ID, f"🛡️ <b>تأمين صفقة {symbol}!</b>\nالسعر تجاوز 1.5R. يرجى نقل الستوب لوس إلى نقطة الدخول (Break-Even) فوراً: {entry}", parse_mode='HTML')

            # التتبع الهيكلي (Smart Trailing)
            if t_data['be_activated']:
                if is_short:
                    if len(data_5m['highs']) >= 3:
                        if data_5m['highs'][-2] > data_5m['highs'][-3] and data_5m['highs'][-2] > data_5m['highs'][-1]:
                            swing_high = data_5m['highs'][-2]
                            if l < data_5m['lows'][-2] and swing_high < t_data['current_sl']:
                                new_sl = swing_high + (risk * 0.1)
                                if new_sl < t_data['current_sl']:
                                    t_data['current_sl'] = new_sl
                                    bot.send_message(CHAT_ID, f"🧠 <b>تحديث الستوب {symbol}</b>:\nالسوق شكل قمة هابطة جديدة. انزل الستوب لوس إلى <code>{new_sl:.2f}</code> لحماية الأرباح!", parse_mode='HTML')
                else:
                    if len(data_5m['lows']) >= 3:
                        if data_5m['lows'][-2] < data_5m['lows'][-3] and data_5m['lows'][-2] < data_5m['lows'][-1]:
                            swing_low = data_5m['lows'][-2]
                            if h > data_5m['highs'][-2] and swing_low > t_data['current_sl']:
                                new_sl = swing_low - (risk * 0.1)
                                if new_sl > t_data['current_sl']:
                                    t_data['current_sl'] = new_sl
                                    bot.send_message(CHAT_ID, f"🧠 <b>تحديث الستوب {symbol}</b>:\nالسوق شكل قاع صاعد جديد. ارفع الستوب لوس إلى <code>{new_sl:.2f}</code> لحماية الأرباح!", parse_mode='HTML')

        except Exception as e:
            pass

# ================= الـ Threads الخلفية =================
def background_scanner():
    while True:
        scan_market_for_opportunities()
        time.sleep(900) # يمسح السوق كل 15 دقيقة

def background_manager():
    while True:
        manage_active_trades()
        time.sleep(60) # يتابع الصفقات المفتوحة كل دقيقة

# ================= أوامر البوت =================
@bot.message_handler(commands=['start'])
def send_welcome(message):
    global CHAT_ID
    CHAT_ID = message.chat.id
    msg = "أهلاً بك يا سيدي! أنا <b>المساعد الافتراضي ICT</b> الخاص بك. 👔\n\n"
    msg += "لقد بدأتُ الآن بمراقبة أسواق الكريبتو بالنيابة عنك بصمت.\n"
    msg += "- سأخبرك عند اقتراب فرصة (السعر يسحب سيولة).\n"
    msg += "- سأعطيك إشارة الدخول والستوب بالمليمتر.\n"
    msg += "- وسأراقب الشارت كل دقيقة لأخبرك متى تحرك الستوب (Trailing)!\n\n"
    msg += "استرخِ، وسأراسلك قريباً..."
    bot.reply_to(message, msg, parse_mode='HTML')
    
@bot.message_handler(commands=['status'])
def check_status(message):
    global CHAT_ID
    CHAT_ID = message.chat.id
    if not active_trades:
        bot.reply_to(message, "لا توجد صفقات مفعلة أتابعها حالياً. أنا فقط أراقب السوق 🧐")
    else:
        msg = "📊 <b>الصفقات التي أتابعها لك الآن:</b>\n\n"
        for t_id, t in active_trades.items():
            msg += f"🪙 <b>{t['symbol']}</b> {'(بيع)' if t['is_short'] else '(شراء)'}\n"
            msg += f"الستوب الحالي: {t['current_sl']:.2f}\n"
            msg += f"تم تأمين الدخول: {'نعم 🛡️' if t['be_activated'] else 'ليس بعد ⏳'}\n"
            msg += "-"*20 + "\n"
        bot.reply_to(message, msg, parse_mode='HTML')

@bot.callback_query_handler(func=lambda call: call.data.startswith('enter_'))
def handle_trade_entry(call):
    trade_id = call.data.split('enter_')[1]
    if trade_id in pending_signals:
        trade_data = pending_signals[trade_id]
        trade_data['current_sl'] = trade_data['sl']
        trade_data['be_activated'] = False
        active_trades[trade_id] = trade_data
        del pending_signals[trade_id]
        
        bot.answer_callback_query(call.id, "✅ تم استلام الأمر!")
        bot.edit_message_text(f"✅ <b>تم استلام الأمر لـ {trade_data['symbol']}</b>\n\nأنا الآن أنظر إلى شارت الـ 1 دقيقة و 5 دقائق وأراقب صفقتك.. لا تغلق الشاشة بعيداً، سأرسل لك إشعاراً بمجرد أن يتحرك السعر لنقل الستوب!", call.message.chat.id, call.message.message_id, parse_mode='HTML')
    else:
        bot.answer_callback_query(call.id, "❌ هذه التوصية قديمة أو تم تفعيلها مسبقاً.")

if __name__ == "__main__":
    if TELEGRAM_BOT_TOKEN == "ضع_توكن_البوت_هنا":
        print("⚠️ الرجاء فتح الملف telegram_assistant.py ووضع التوكن الخاص بك!")
        sys.exit(1)
        
    print("🚀 جاري تشغيل بوت التيليجرام...")
    t1 = threading.Thread(target=background_scanner, daemon=True)
    t2 = threading.Thread(target=background_manager, daemon=True)
    t1.start()
    t2.start()
    
    bot.infinity_polling()
