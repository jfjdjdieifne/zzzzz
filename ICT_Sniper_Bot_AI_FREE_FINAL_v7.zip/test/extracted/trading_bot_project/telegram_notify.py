# -*- coding: utf-8 -*-
"""
telegram_notify.py — طبقة إشعارات التيليغرام النظيفة للرادار الحي.
══════════════════════════════════════════════════════════════════
تقرأ التوكن + معرّف الشات من متغيّرات البيئة أو ملف .env:
    TELEGRAM_BOT_TOKEN=123456:ABC-DEF...
    TELEGRAM_CHAT_ID=987654321
(أنشئ ملف .env بنسخ .env.example واملأه — ما بنحتاج أي مفتاح AI).

الرسائل بصيغة HTML، مفصّلة: فتح صفقة، إغلاق صفقة (مع مصيرها وأرقامها
وتاريخها)، ورصيد دوري. إذا ما في توكن → الوحدة معطّلة بهدوء (البوت
يشتغل طبيعي بدون تيليغرام).
"""
import os
import json
import time
import requests

try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass


def _esc(s):
    """يهرّب نص HTML حتى ما يكسّر الرسالة."""
    return (str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


class TelegramNotifier:
    def __init__(self, token=None, chat_id=None):
        self.token = token or os.getenv("TELEGRAM_BOT_TOKEN")
        self.chat_id = chat_id or os.getenv("TELEGRAM_CHAT_ID")
        self.enabled = bool(self.token and self.chat_id)
        self._api = (f"https://api.telegram.org/bot{self.token}/sendMessage"
                     if self.enabled else None)
        self._last = 0  # لمنع الفلود (حد أدنى ثانية بين الإرسالات)

    def send(self, text, parse="HTML"):
        if not self.enabled:
            return False
        # نقسّم الرسالة الطويلة (حد تيليغرام ~4096 حرف)
        chunks = self._split(text, 3800)
        ok = True
        for ch in chunks:
            # احترام حدود rate-limit البسيطة
            now = time.time()
            wait = 1.0 - (now - self._last)
            if wait > 0:
                time.sleep(wait)
            try:
                r = requests.post(self._api, json={
                    "chat_id": self.chat_id, "text": ch,
                    "parse_mode": parse, "disable_web_page_preview": True,
                }, timeout=12)
                if r.status_code != 200:
                    ok = False
            except Exception:
                ok = False
            self._last = time.time()
        return ok

    def _split(self, text, n):
        if len(text) <= n:
            return [text]
        out = []
        cur = ""
        for line in text.split("\n"):
            if len(cur) + len(line) + 1 > n:
                out.append(cur)
                cur = line
            else:
                cur = (cur + "\n" + line) if cur else line
        if cur:
            out.append(cur)
        return out

    # ── صياغات الرسائل ──
    def open_msg(self, symbol, t):
        side = "🔴 بيع SHORT" if t["is_short"] else "🟢 شراء LONG"
        body = (
            f"🚀 <b>دخول جديد (محاكاة)</b>\n"
            f"🪙 <b>{_esc(symbol)}</b> | {side}\n"
            f"📐 الموديل: {_esc(t.get('model','-'))}\n"
            f"🎯 الدخول: {t['entry']:.2f}\n"
            f"🛡️ الستوب: {t['sl']:.2f}\n"
            f"🎯 TP1: {t['tp1']:.2f}\n"
            f"🏁 TP2 (runner): {t.get('tp2') or '—'}\n"
            f"📦 الحجم: {t['size']:.4f}\n"
            f"💸 المخاطرة: {t['risk_usd']:.2f}$\n"
            f"⏱️ {_esc(time.strftime('%Y-%m-%d %H:%M NY'))}"
        )
        return body

    def close_msg(self, symbol, t, exit_price, pnl, reason, balance):
        sign = "+" if pnl >= 0 else "-"
        col = "🟢" if pnl >= 0 else "🔴"
        body = (
            f"{col} <b>إغلاق صفقة — {_esc(symbol)}</b>\n"
            f"📌 المصير: {_esc(reason)}\n"
            f"💰 الخروج: {exit_price:.2f}\n"
            f"📊 الربح/الخسارة: {sign}{abs(pnl):.2f}$\n"
            f"💼 الرصيد الحالي: {balance:.2f}$\n"
            f"⏱️ {_esc(time.strftime('%Y-%m-%d %H:%M NY'))}"
        )
        return body

    def balance_msg(self, balance, open_count, day):
        return (
            f"💼 <b>تقرير رصيد</b> — يوم {day}\n"
            f"الرصيد: {balance:.2f}$\n"
            f"🔓 صفقات مفتوحة: {open_count}\n"
            f"⏱️ {_esc(time.strftime('%Y-%m-%d %H:%M NY'))}"
        )

    def startup_msg(self, balance, coins):
        return (
            f"🚀 <b>الرادار الحي شغّال</b>\n"
            f"💼 الرصيد الابتدائي: {balance:.2f}$\n"
            f"🪙 عدد العملات: {len(coins)}\n"
            f"📲 رح توصلك التحديثات هنا."
        )

    def info(self, text):
        return self.send(text)
