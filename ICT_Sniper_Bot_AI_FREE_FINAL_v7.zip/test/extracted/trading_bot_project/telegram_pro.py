import sys, time, threading, datetime, os
sys.path.insert(0, ".")
import telebot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from brain_core import BrainCore
from ict_math_engine import compute_mechanical_bias_anchor, classify_sweep_or_run
from authenticity_engine import AuthenticityEngine
from ict_entry_checklist_engine import evaluate_all_entry_models
from flask import Flask, request

# ================= الإعدادات الأساسية =================
# جلب التوكن من السيرفر (Environment Variables) للحماية
TELEGRAM_BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "8996304796:AAHK6RMV9jLKUS43oOX9I72jdJBNy0NOz1M")
CHAT_ID = None 

brain = BrainCore()
ae = AuthenticityEngine()
bot = telebot.TeleBot(TELEGRAM_BOT_TOKEN)

# ================= خادم الويب (لخداع Render وإبقائه مستيقظاً) =================
app = Flask(__name__)

@app.route('/')
def home():
    return "ICT Trading Bot is Alive and Running 24/7!", 200

# ================= قواعد البيانات الحية =================
WATCHING_SYMBOLS = ["ETH/USDT", "BTC/USDT", "SOL/USDT"]
active_trades = {}    
reported_pending = set()

# ================= دوال الذكاء اللغوي =================
def format_pending_narrative(symbol, bias, swept_level, is_short):
    direction = "هابط (Bearish) 📉" if is_short else "صاعد (Bullish) 📈"
    target_liq = "ستوبات المشترين (Buy-Side Liquidity)" if is_short else "ستوبات البائعين (Sell-Side Liquidity)"
    
    msg = f"👀 <b>مراقبة ذكية لسوق {symbol}</b>\n"
    msg += f"────────────────\n"
    msg += f"🧠 <b>قراءة الاتجاه:</b> السوق حالياً {direction}.\n"
    msg += f"🕵️‍♂️ <b>ماذا رأيت للتو؟</b> الماركت ميكر قام بحركة سريعة لضرب {target_liq} عند مستوى <code>{swept_level}</code>.\n\n"
    msg += f"⏳ <b>ماذا أنتظر الآن لأعطيك التوصية؟</b>\n"
    msg += f"1️⃣ أنتظر إغلاق شمعة 5 دقائق لتؤكد الكسر الهيكلي (MSS).\n"
    msg += f"2️⃣ يجب أن تترك هذه الحركة فجوة سعرية (FVG) خلفها.\n"
    msg += f"💡 <i>(إذا تحققت هذه الشروط، سأرسل لك إشعاراً بأرقام الدخول والستوب فوراً.)</i>"
    return msg

def format_ready_narrative(symbol, plan, model_name):
    entry = plan['entry']
    sl = plan['stop_loss']
    tp1 = plan['tp']
    is_short = "SELL" in plan['direction']
    risk = abs(entry - sl)
    
    msg = f"🚨 <b>اكتمل الفخ! التوصية جاهزة - {symbol}</b> 🚨\n"
    msg += f"────────────────\n"
    msg += f"🧠 <b>تحديث الهيكل:</b> لقد تشكل الكسر الهيكلي وترك فجوة سعرية! (النموذج: {model_name}). صانع السوق جاهز للانطلاق.\n\n"
    msg += f"📋 <b>خطة التنفيذ (أوامر معلقة):</b>\n"
    msg += f"القرار: <b>{'🔴 بيع (SELL LIMIT)' if is_short else '🟢 شراء (BUY LIMIT)'}</b>\n"
    msg += f"📍 <b>نقطة الدخول:</b> <code>{entry:.2f}</code> (عند منتصف الفجوة)\n"
    msg += f"🛡️ <b>وقف الخسارة:</b> <code>{sl:.2f}</code> (محمي هيكلياً)\n"
    msg += f"💰 <b>الهدف الأول:</b> <code>{tp1:.2f}</code> (لجني 80% من الأرباح)\n"
    msg += f"📏 مسافة المخاطرة: {risk:.2f} نقطة.\n\n"
    msg += f"👇 <i>ضع الأوامر في منصتك، ثم اضغط على الزر أدناه لأبدأ التتبع اللحظي للصفقة وإدارة الستوب!</i>"
    return msg

# ================= محرك المسح (Scanner) =================
def scan_market(manual=False):
    global CHAT_ID
    if not CHAT_ID: return
    
    found_something = False
    for symbol in WATCHING_SYMBOLS:
        try:
            data_15m = brain.data_manager.fetch_ohlcv_up_to(symbol, "15m", int(time.time()*1000), limit=200)
            if not data_15m or not data_15m['closes']: continue
            
            anchor = compute_mechanical_bias_anchor(data_15m, lookback=100)
            bias = anchor.get("anchor_direction")
            if bias not in ["BULLISH", "BEARISH"]: continue
            
            sig = ae.detect_significant_swings(data_15m, swing_window=1, lookback_candles=100)
            is_swept, swept_level = False, 0
            
            levels = sig.get("all_lows_tiered", []) if bias == "BULLISH" else sig.get("all_highs_tiered", [])
            for cand in levels:
                res = classify_sweep_or_run(data_15m, cand["price"], level_is_high=(bias=="BEARISH"), check_from_idx=len(data_15m['closes'])-1)
                if res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP" and res.get("candle_index_from_end") >= -3:
                    is_swept, swept_level = True, cand["price"]
                    break
            
            if is_swept:
                found_something = True
                data_5m = brain.data_manager.fetch_ohlcv_up_to(symbol, "5m", int(time.time()*1000), limit=150)
                res_5m = evaluate_all_entry_models(data_5m, bias)
                status = res_5m.get("final_status")
                
                sig_id = f"{symbol}_{swept_level}"
                
                if status == "PENDING_SETUP" and sig_id not in reported_pending:
                    msg = format_pending_narrative(symbol, bias, swept_level, bias=="BEARISH")
                    bot.send_message(CHAT_ID, msg, parse_mode='HTML')
                    reported_pending.add(sig_id)
                    
                elif status == "READY":
                    plan = res_5m.get("chosen_model", {}).get("plan", {})
                    if plan.get("entry") and sig_id not in active_trades:
                        msg = format_ready_narrative(symbol, plan, res_5m.get("chosen_model", {}).get("model"))
                        
                        markup = InlineKeyboardMarkup()
                        btn1 = InlineKeyboardButton("✅ لقد دخلت! (ابدأ التتبع 👁️)", callback_data=f"track_{symbol}_{plan['entry']}_{plan['stop_loss']}_{plan['tp']}_{bias}")
                        btn2 = InlineKeyboardButton("❌ تجاهل الفرصة", callback_data="ignore_trade")
                        markup.add(btn1)
                        markup.add(btn2)
                        
                        bot.send_message(CHAT_ID, msg, reply_markup=markup, parse_mode='HTML')
                        reported_pending.add(sig_id)
                        
        except Exception as e:
            pass
            
    if manual and not found_something:
        bot.send_message(CHAT_ID, "🔎 لقد قمت بمسح السوق اللحظي. لا توجد أي فخاخ أو سيولة يتم ضربها حالياً. البوت في وضع الانتظار (HOLD).")

# ================= محرك التتبع اللحظي (Trade Manager) =================
def manage_active_trades():
    global CHAT_ID
    if not CHAT_ID or not active_trades: return
    
    for t_id, t_data in list(active_trades.items()):
        try:
            symbol = t_data['symbol']
            is_short = t_data['is_short']
            entry = float(t_data['entry'])
            sl = float(t_data['sl'])
            tp1 = float(t_data['tp1'])
            risk = abs(entry - sl)
            
            data_5m = brain.data_manager.fetch_ohlcv_up_to(symbol, "5m", int(time.time()*1000), limit=20)
            h = data_5m['highs'][-1]
            l = data_5m['lows'][-1]
            
            # 1. فحص الستوب
            if (is_short and h >= t_data['current_sl']) or (not is_short and l <= t_data['current_sl']):
                bot.send_message(CHAT_ID, f"⚠️ <b>تنبيه إغلاق - {symbol}</b>\nلقد تم ضرب الستوب لوس عند <code>{t_data['current_sl']:.2f}</code>. تم إنهاء تتبع الصفقة.", parse_mode='HTML')
                del active_trades[t_id]
                continue

            # 2. Break-Even عند 1.5R
            if not t_data['be_activated']:
                if (is_short and l <= (entry - 1.5*risk)) or (not is_short and h >= (entry + 1.5*risk)):
                    t_data['be_activated'] = True
                    t_data['current_sl'] = entry
                    bot.send_message(CHAT_ID, f"🛡️ <b>تأمين الأرباح! - {symbol}</b>\nالسعر تجاوز مسافة 1.5R. قمت بحسابها ووجدت أنه يجب <b>نقل الستوب إلى نقطة الدخول ({entry}) فوراً!</b>", parse_mode='HTML')

            # 3. التتبع الهيكلي للقمم والقيعان (Structural Trailing)
            if t_data['be_activated']:
                if is_short:
                    if len(data_5m['highs']) >= 3 and data_5m['highs'][-2] > data_5m['highs'][-3] and data_5m['highs'][-2] > data_5m['highs'][-1]:
                        swing_high = data_5m['highs'][-2]
                        if l < data_5m['lows'][-2] and swing_high < t_data['current_sl']:
                            new_sl = swing_high + (risk * 0.1)
                            t_data['current_sl'] = new_sl
                            bot.send_message(CHAT_ID, f"🧠 <b>ذكاء التتبع - {symbol}</b>\nلقد لاحظت تشكل 'قمة هابطة جديدة' (Lower High). \n👇 <b>قم بإنزال الستوب لوس إلى <code>{new_sl:.2f}</code> لحجز المزيد من الأرباح!</b>", parse_mode='HTML')
                else:
                    if len(data_5m['lows']) >= 3 and data_5m['lows'][-2] < data_5m['lows'][-3] and data_5m['lows'][-2] < data_5m['lows'][-1]:
                        swing_low = data_5m['lows'][-2]
                        if h > data_5m['highs'][-2] and swing_low > t_data['current_sl']:
                            new_sl = swing_low - (risk * 0.1)
                            t_data['current_sl'] = new_sl
                            bot.send_message(CHAT_ID, f"🧠 <b>ذكاء التتبع - {symbol}</b>\nلقد لاحظت تشكل 'قاع صاعد جديد' (Higher Low). \n☝️ <b>قم برفع الستوب لوس إلى <code>{new_sl:.2f}</code> لحجز المزيد من الأرباح!</b>", parse_mode='HTML')

        except Exception as e:
            pass

# ================= Threads =================
def background_scanner():
    while True:
        scan_market(manual=False)
        time.sleep(600)

def background_manager():
    while True:
        manage_active_trades()
        time.sleep(60)

# ================= واجهة تيليجرام =================
def main_menu():
    markup = InlineKeyboardMarkup(row_width=2)
    markup.add(
        InlineKeyboardButton("🔎 فحص السوق الآن", callback_data="cmd_scan"),
        InlineKeyboardButton("📊 صفقاتي المتتبعة", callback_data="cmd_status")
    )
    markup.add(InlineKeyboardButton("🛑 إيقاف كافة التتبعات", callback_data="cmd_clear"))
    return markup

@bot.message_handler(commands=['start'])
def send_welcome(message):
    global CHAT_ID
    CHAT_ID = message.chat.id
    msg = "مرحباً أيها القناص 🎯\nأنا <b>مساعدك الآلي המبرمج بعقلية مايكل ICT</b>.\n\nأنا أعمل على سيرفر مجاني 24/7 دون توقف.\nسأرسل لك الإشعارات هنا بمجرد توفر فرص."
    bot.reply_to(message, msg, reply_markup=main_menu(), parse_mode='HTML')

@bot.callback_query_handler(func=lambda call: True)
def handle_query(call):
    global CHAT_ID
    CHAT_ID = call.message.chat.id
    
    if call.data == "cmd_scan":
        bot.answer_callback_query(call.id, "جاري فحص الشموع اللحظية...")
        bot.send_message(CHAT_ID, "⚙️ أقوم بمسح العملات وقراءة هياكل السيولة الآن...")
        scan_market(manual=True)
        
    elif call.data == "cmd_status":
        if not active_trades:
            bot.answer_callback_query(call.id, "لا توجد صفقات.")
            bot.send_message(CHAT_ID, "لا توجد صفقات أقوم بتتبعها حالياً.", reply_markup=main_menu())
        else:
            msg = "📋 <b>صفقاتك تحت المراقبة:</b>\n\n"
            for k, v in active_trades.items():
                msg += f"🪙 <b>{v['symbol']}</b> | {'بيع🔴' if v['is_short'] else 'شراء🟢'}\n"
                msg += f"الدخول: {v['entry']} | الستوب المحدث: {v['current_sl']:.2f}\n"
                msg += f"تأمين الدخول (BE): {'مفعل ✅' if v['be_activated'] else 'قيد الانتظار ⏳'}\n"
                msg += "─"*20 + "\n"
            bot.send_message(CHAT_ID, msg, parse_mode='HTML', reply_markup=main_menu())
            
    elif call.data == "cmd_clear":
        active_trades.clear()
        bot.answer_callback_query(call.id, "تم المسح!")
        bot.send_message(CHAT_ID, "تم مسح جميع الصفقات من ذاكرة التتبع.", reply_markup=main_menu())
        
    elif call.data.startswith("track_"):
        parts = call.data.split("_")
        symbol, entry, sl, tp1, bias = parts[1], parts[2], parts[3], parts[4], parts[5]
        trade_id = f"{symbol}_{entry}"
        active_trades[trade_id] = {
            "symbol": symbol, "entry": entry, "sl": sl, "tp1": tp1, 
            "is_short": (bias=="BEARISH"), "current_sl": float(sl), "be_activated": False
        }
        bot.answer_callback_query(call.id, "تم التفعيل!")
        bot.edit_message_text(f"👁️ <b>تم استلام الأمر لـ {symbol}!</b>\n\nلقد فتحت شارت الدقيقة والـ 5 دقائق في الخلفية. أنتظر الآن انطلاق السعر لأخبرك بنقل الستوب لوس. اذهب واشرب قهوتك ☕", call.message.chat.id, call.message.message_id, parse_mode='HTML')
        
    elif call.data == "ignore_trade":
        bot.answer_callback_query(call.id, "تم التجاهل.")
        bot.edit_message_text("❌ تم تجاهل هذه الفرصة. سأستمر في مراقبة السوق.", call.message.chat.id, call.message.message_id)

def run_flask():
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 8080)))

if __name__ == "__main__":
    print("🚀 جاري تشغيل مساعد ICT والسيرفر الوهمي...")
    # تشغيل Flask في ثريد (لكي يعمل على Render)
    t_flask = threading.Thread(target=run_flask, daemon=True)
    t_flask.start()
    
    t1 = threading.Thread(target=background_scanner, daemon=True)
    t2 = threading.Thread(target=background_manager, daemon=True)
    t1.start()
    t2.start()
    
    # تشغيل البوت
    try:
        bot.infinity_polling()
    except Exception as e:
        print(f"حدث خطأ في تيليجرام: {e}")
