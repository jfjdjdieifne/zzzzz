import sys
import time
sys.path.insert(0, ".")
from data_manager import DataManager
from authenticity_engine import AuthenticityEngine
from ict_math_engine import classify_sweep_or_run

dm = DataManager()
data_15m = dm.fetch_ohlcv_up_to("SOLUSDT", "15m", 1783694700000, limit=200) # Ends exactly at 14:45 UTC
closed_15m = {k: v[:-1] for k, v in data_15m.items() if isinstance(v, list)}

print(f"Last closed candle timestamp: {closed_15m['timestamps'][-1]}")

ae = AuthenticityEngine()
sig = ae.detect_significant_swings(closed_15m, swing_window=3, lookback_candles=150)

lows = [s for s in sig.get("all_lows_tiered", []) if s.get("tier") in ["MAJOR", "MODERATE"]]
lows.sort(key=lambda x: closed_15m['closes'][-1] - x['price'])

print(f"Target: {lows[0]}")
target_lvl = lows[0]['price']

res = classify_sweep_or_run(closed_15m, target_lvl, level_is_high=False, check_from_idx=len(closed_15m['closes'])-1)
print(f"Sweep result: {res}")
