import sys
sys.path.insert(0, ".")
from data_manager import DataManager
from ict_entry_checklist_engine import evaluate_all_entry_models

dm = DataManager()
data_5m = dm.fetch_ohlcv_up_to("SOLUSDT", "5m", 1783694701000, limit=150)
res = evaluate_all_entry_models(data_5m, "BULLISH")
print(res)
