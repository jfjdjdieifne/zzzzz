import sys
import time
sys.path.insert(0, ".")
from data_manager import DataManager
from authenticity_engine import AuthenticityEngine
from ict_math_engine import classify_sweep_or_run

dm = DataManager()
data_15m = dm.fetch_ohlcv_up_to("SOLUSDT", "15m", 1783694701000, limit=200) # Slightly after 14:45
closed_15m = {k: v[:-1] for k, v in data_15m.items() if isinstance(v, list)}

print(f"Last closed candle timestamp: {closed_15m['timestamps'][-1]}")

res = classify_sweep_or_run(closed_15m, 77.32, level_is_high=False, check_from_idx=len(closed_15m['closes'])-1)
print(f"Sweep result: {res}")
