import sys
sys.path.insert(0, ".")
from data_manager import DataManager
from ict_math_engine import classify_sweep_or_run
from authenticity_engine import AuthenticityEngine

dm = DataManager()
data_15m = dm.get_ohlcv("SOLUSDT", "15m", 200, output_format="dict")
closed_15m = {k: v[:-1] for k, v in data_15m.items() if isinstance(v, list)}

res = classify_sweep_or_run(closed_15m, 77.32, level_is_high=False, check_from_idx=len(closed_15m['closes'])-1)
print(res)
