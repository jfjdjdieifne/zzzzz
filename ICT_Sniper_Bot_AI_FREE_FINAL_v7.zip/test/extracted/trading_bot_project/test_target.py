import sys
sys.path.insert(0, ".")
from data_manager import DataManager
from authenticity_engine import AuthenticityEngine

dm = DataManager()
data_15m = dm.get_ohlcv("SOLUSDT", "15m", 200, output_format="dict")
closed_15m = {k: v[:-1] for k, v in data_15m.items() if isinstance(v, list)}
ae = AuthenticityEngine()
sig = ae.detect_significant_swings(closed_15m, swing_window=3, lookback_candles=150)

lows = [s for s in sig.get("all_lows_tiered", []) if s['price'] < closed_15m['closes'][-1] and s.get("tier") in ["MAJOR", "MODERATE"]]
lows.sort(key=lambda x: closed_15m['closes'][-1] - x['price'])
print(f"Nearest SSL: {lows[0]}")
print(f"Is it 77.32? Price={lows[0]['price']}")
