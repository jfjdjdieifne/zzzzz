import sys, datetime
sys.path.insert(0, ".")
from brain_core import BrainCore

brain = BrainCore()
SYMBOL = "ETH/USDT"

trades = [
    {"num": 1, "sweep_time": "2026-06-10 11:30", "ts": 1781091000000, "type": "LONG", "entry": 1632.57, "tp1": 1639.33, "sl": 1629.30},
    {"num": 2, "sweep_time": "2026-06-10 13:30", "ts": 1781098200000, "type": "LONG", "entry": 1632.57, "tp1": 1639.33, "sl": 1629.30},
    {"num": 3, "sweep_time": "2026-06-10 16:45", "ts": 1781109900000, "type": "LONG", "entry": 1627.09, "tp1": 1633.37, "sl": 1623.83},
    {"num": 4, "sweep_time": "2026-06-11 14:45", "ts": 1781189100000, "type": "SHORT", "entry": 1654.58, "tp1": 1648.69, "sl": 1657.89},
    {"num": 5, "sweep_time": "2026-06-11 23:00", "ts": 1781218800000, "type": "SHORT", "entry": 1678.79, "tp1": 1673.47, "sl": 1682.14}
]

for t in trades:
    print(f"\nTrade {t['num']} ({t['sweep_time']}):")
    data = brain.data_manager.fetch_ohlcv_up_to(SYMBOL, "5m", t['ts'] + 24*60*60*1000, limit=400) 
    
    entry_hit_time = None
    tp1_hit_time = None
    
    for i in range(len(data['closes'])):
        if data['timestamps'][i] < t['ts']: continue
        
        low = data['lows'][i]
        high = data['highs'][i]
        ctime = datetime.datetime.fromtimestamp(data['timestamps'][i]/1000, tz=datetime.timezone.utc)
        
        if not entry_hit_time:
            if t['type'] == "LONG" and low <= t['entry']:
                entry_hit_time = ctime
            elif t['type'] == "SHORT" and high >= t['entry']:
                entry_hit_time = ctime
                
        if entry_hit_time and not tp1_hit_time:
            if t['type'] == "LONG" and high >= t['tp1']:
                tp1_hit_time = ctime
                break
            elif t['type'] == "SHORT" and low <= t['tp1']:
                tp1_hit_time = ctime
                break

    if entry_hit_time and tp1_hit_time:
        duration = tp1_hit_time - entry_hit_time
        print(f"Entry hit at: {entry_hit_time}")
        print(f"TP1 hit at: {tp1_hit_time}")
        print(f"Duration: {duration}")
    else:
        print("Did not hit entry or TP1 in the window.")
