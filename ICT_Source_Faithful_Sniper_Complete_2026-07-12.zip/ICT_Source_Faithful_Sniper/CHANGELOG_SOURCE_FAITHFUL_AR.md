# تغييرات نسخة Source-Faithful Sniper

## القاعدة

بُنيت هذه الحزمة على الفرع المدقق `arena/019f4a24-b`، لا على أي ZIP قديم. لم يتم نسخ `Fixed 3R` أو `BE 1.5R` أو محاسبات 80/20 القديمة إلى مسار التنفيذ الافتراضي.

## تغييرات تنفيذية

- الافتراضي الآن: `TP1=50%` و`POST_TP1_STOP_POLICY=STRUCTURE_ONLY`.
- لا ينقل المسار الافتراضي SL إلى BE لأن السعر وصل رقماً ثابتاً.
- يحرك Runner فقط بعد HL/LH مؤكد؛ التعديل يصبح فعالاً من الشمعة التالية.
- أضيف `ict_source_policy.py` ليعطي قراراً صريحاً: `EXECUTABLE` / `WAIT` / `REJECT`.
- تضاف بوابة تكلفة اختيارية: إن أدخل المستخدم رسوم+spread+slippage، يمكنها رفض SL ضيق تجعل فيه التكلفة كبيرة بوحدة R. لا تحرك هذه البوابة SL.
- `SnapshotAnalyzer` يعرض عقد الإدارة ونتيجة بوابة التنفيذ مع الـcandidate نفسه، ويمنع تفعيل خطة مرفوضة عندما `SOURCE_EXECUTION_REQUIRED=true`.
- الافتراضات في Console/Web/Walk-forward تغيرت إلى `STRUCTURE_ONLY`.
- السجلات القديمة التي لا تملك policy تستخدم `Config.POST_TP1_STOP_POLICY` بدلاً من فرض `BE_THEN_STRUCTURE`.

## تغييرات توثيق وفحص

- أضيف `ICT_SOURCE_CONSTITUTION_AR.md` لفصل ما هو قاعدة تنفيذ، وما هو انتظار، وما هو رفض.
- أضيف `scripts/self_check.py`: يفحص غياب `.env`، الملفات الجوهرية، syntax، السياسة الافتراضية، ثم يشغل `pytest`.
- أضيفت اختبارات `tests/test_source_execution_policy.py` لبنود WAIT/REJECT/cost floor/management contract.

## ما لم ندّعه

- لا توجد ضمانات ربح أو Win Rate مستقبلي.
- لا يعد المشروع تمثيلاً كاملاً لتقدير متداول بشري؛ كل قرار يحتاج دليلاً من OHLC مسجلاً.
- آخر 17 حالة استخدمت فقط كتدقيق regression، وليست مجموعة نضبط القواعد لتفوز عليها.
