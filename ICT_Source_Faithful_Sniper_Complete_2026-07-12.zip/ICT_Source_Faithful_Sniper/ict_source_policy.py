# -*- coding: utf-8 -*-
"""Deterministic execution constitution for the paper-only ICT project.

This module deliberately does not predict prices.  It answers only:
    Is a named, evidence-backed setup executable now?

It centralizes the rules selected for this project version:
- no entry without aligned higher-timeframe context, a READY named model,
  lower-timeframe displacement/structure confirmation and an executable session;
- SL remains where causal invalidation puts it; position size changes instead;
- TP1 is a real liquidity level, not a made-up R multiple;
- default management is 50% TP1 + STRUCTURE_ONLY runner, without an automatic
  1.5R break-even rule.

Every result includes its evidence so that callers can show WAIT/REJECT rather
than inventing a BUY/SELL signal.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any, Mapping


DEFAULT_TP1_ALLOCATION_PCT = 50.0
DEFAULT_POST_TP1_POLICY = "STRUCTURE_ONLY"
VALID_POST_TP1_POLICIES = frozenset({"ICT_RANGE_PROGRESS", "BE_THEN_STRUCTURE", "STRUCTURE_ONLY"})


@dataclass(frozen=True)
class GateResult:
    state: str  # EXECUTABLE | WAIT | REJECT
    approved: bool
    reasons_ar: tuple[str, ...]
    evidence: dict[str, bool]
    cost_to_r: float | None

    def to_dict(self) -> dict[str, Any]:
        out = asdict(self)
        out["reasons_ar"] = list(self.reasons_ar)
        return out


def _status(condition: Mapping[str, Any] | None) -> Any:
    return None if not condition else condition.get("status")


def execution_cost_to_r(entry: float | None, stop_loss: float | None,
                        round_trip_cost_pct: float | None) -> float | None:
    """Return the round-trip execution cost in R, or None when disabled.

    Cost is a policy gate, never a reason to pull a structural SL closer.  A
    venue-specific fee/spread/slippage estimate must be supplied by the user or
    environment; zero means the gate is shown as unavailable, not silently
    assumed to be free execution.
    """
    try:
        entry = float(entry)
        stop_loss = float(stop_loss)
        cost_pct = float(round_trip_cost_pct or 0.0)
    except (TypeError, ValueError):
        return None
    risk_pct = abs(entry - stop_loss) / entry if entry > 0 else 0.0
    if risk_pct <= 0 or cost_pct <= 0:
        return None
    return cost_pct / risk_pct


def evaluate_source_execution_gate(*, bias_state: str, model_status: str | None,
                                  ltf_displacement_confirmed: bool,
                                  executable_session: bool,
                                  has_structural_stop: bool,
                                  has_tp1_liquidity: bool,
                                  entry: float | None,
                                  stop_loss: float | None,
                                  round_trip_cost_pct: float = 0.0,
                                  max_cost_r: float = 0.25) -> GateResult:
    """Evaluate an explicit source-faithful execution gate.

    A missing timing/confirmation is WAIT rather than a forced trade.  A broken
    plan (no structural stop or no genuine TP1) is REJECT.  This distinction is
    important: a pending setup is not an executed position.
    """
    evidence = {
        "daily_h4_aligned": bias_state == "ALIGNED",
        "named_model_ready": model_status == "READY",
        "ltf_displacement_confirmed": bool(ltf_displacement_confirmed),
        "executable_session": bool(executable_session),
        "structural_stop": bool(has_structural_stop),
        "tp1_real_liquidity": bool(has_tp1_liquidity),
    }
    reasons: list[str] = []

    if not evidence["structural_stop"]:
        reasons.append("رفض: لا يوجد SL سببي خلف invalidation هيكلي حقيقي.")
    if not evidence["tp1_real_liquidity"]:
        reasons.append("رفض: لا يوجد TP1 سيولة حقيقي؛ لا نخترع هدف R ثابت.")

    cost_r = execution_cost_to_r(entry, stop_loss, round_trip_cost_pct)
    if cost_r is not None and cost_r > float(max_cost_r):
        evidence["execution_cost_acceptable"] = False
        reasons.append(
            f"رفض: تكلفة التنفيذ التقديرية {cost_r:.2f}R أكبر من حد السياسة {float(max_cost_r):.2f}R."
        )
    else:
        evidence["execution_cost_acceptable"] = True

    if reasons:
        return GateResult("REJECT", False, tuple(reasons), evidence, cost_r)

    waits = []
    if not evidence["daily_h4_aligned"]:
        waits.append("انتظار: Daily و4H غير متفقين؛ لا نفرض انحيازاً.")
    if not evidence["named_model_ready"]:
        waits.append("انتظار: نموذج الدخول المسمّى لم يصبح READY بعد.")
    if not evidence["ltf_displacement_confirmed"]:
        waits.append("انتظار: لا يوجد MSS/BOS حديث مع displacement على فريم التنفيذ.")
    if not evidence["executable_session"]:
        waits.append("انتظار: خارج نافذة تنفيذ النموذج؛ لا ندخل فقط لأن الاتجاه صحيح.")
    if waits:
        return GateResult("WAIT", False, tuple(waits), evidence, cost_r)

    return GateResult(
        "EXECUTABLE", True,
        ("كل بوابات السياق والموقع والهيكل والتوقيت والهدف اجتمعت؛ التنفيذ الورقي فقط.",),
        evidence, cost_r,
    )


def management_contract(tp1_allocation_pct: float | None = None,
                        post_tp1_policy: str | None = None) -> dict[str, Any]:
    """Return the active management contract, validating policy names."""
    allocation = DEFAULT_TP1_ALLOCATION_PCT if tp1_allocation_pct is None else float(tp1_allocation_pct)
    policy = (post_tp1_policy or DEFAULT_POST_TP1_POLICY).upper()
    if not 1.0 <= allocation <= 100.0:
        raise ValueError("TP1 allocation must be between 1 and 100")
    if policy not in VALID_POST_TP1_POLICIES:
        raise ValueError(f"Unknown post-TP1 policy: {policy}")
    return {
        "tp1_allocation_pct": allocation,
        "runner_allocation_pct": 100.0 - allocation,
        "post_tp1_stop_policy": policy,
        "automatic_fixed_r_be": False,
        "trail_activation": "confirmed HL/LH only; active from the following candle",
        "target_rule": "TP1/TP2 come from real liquidity; R:R is a viability check, not target generation",
    }
