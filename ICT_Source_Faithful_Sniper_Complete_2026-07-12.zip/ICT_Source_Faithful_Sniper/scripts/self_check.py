#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Offline release check for the Source-Faithful paper simulator."""
from __future__ import annotations

import compileall
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def fail(message: str) -> None:
    print(f"❌ {message}")
    raise SystemExit(1)


def main() -> None:
    if (ROOT / ".env").exists():
        fail("وجدت .env داخل حزمة الإصدار. احذفه من ZIP؛ استخدم .env.example فقط.")

    required = [
        "ict_source_policy.py", "ICT_SOURCE_CONSTITUTION_AR.md", "snapshot_analyzer.py",
        "ict_math_engine.py", "trade_monitor.py", "walk_forward_backtest.py",
        "tests/test_source_execution_policy.py", "tests/test_structure_trailing.py",
    ]
    missing = [name for name in required if not (ROOT / name).is_file()]
    if missing:
        fail("ملفات أساسية مفقودة: " + ", ".join(missing))

    if not compileall.compile_dir(str(ROOT), quiet=1, rx=None):
        fail("فشل compileall؛ يوجد خطأ Python قبل التشغيل.")
    print("✅ compileall: لا أخطاء syntax")

    from config import Config
    from ict_source_policy import management_contract
    contract = management_contract(Config.TP1_ALLOCATION_PCT, Config.POST_TP1_STOP_POLICY)
    if contract["post_tp1_stop_policy"] != "STRUCTURE_ONLY":
        fail("الافتراضي ليس STRUCTURE_ONLY؛ راجع .env أو config.py")
    if contract["tp1_allocation_pct"] != 50.0:
        fail("الافتراضي ليس 50% عند TP1؛ راجع .env أو config.py")
    print("✅ policy default: 50% TP1 + STRUCTURE_ONLY runner")

    result = subprocess.run([sys.executable, "-m", "pytest", "-q"], cwd=ROOT, text=True)
    if result.returncode:
        fail("فشل pytest")
    print("✅ pytest: كل الاختبارات نجحت")
    print("✅ RELEASE CHECK PASSED")


if __name__ == "__main__":
    main()
