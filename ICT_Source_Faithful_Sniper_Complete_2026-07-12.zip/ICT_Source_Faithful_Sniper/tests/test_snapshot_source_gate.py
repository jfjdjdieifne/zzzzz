from snapshot_analyzer import SnapshotAnalyzer


def _model(status="READY", stop_rationale=None):
    return {
        "chosen_model": {
            "model": "MODEL_B_SWEEP_FVG",
            "status": status,
            "conditions": [],
            "plan": {
                "direction": "BUY",
                "entry": 100.0,
                "stop_loss": 95.0,
                "tp": 110.0,
                "tp1": {"price": 110.0, "kind": "EQH_DOUBLE", "rr": 2.0, "detail": "real liquidity"},
                "tp2": {"mode": "OPEN_TRAILING"},
                "basis": "MODEL_B causal plan",
                "stop_rationale": stop_rationale if stop_rationale is not None else {"anchor": "sweep low"},
            },
        }
    }


def _entry_frame():
    return {
        "latest_structural_breaks": [
            {"direction": "BULLISH", "displacement_confirmed": True, "break_candle_index_from_end": -2}
        ]
    }


def _entry_data():
    return {
        "closes": [100.0], "close_timestamps": [1_000], "symbol": "BTC/USDT",
        "source": "okx", "timeframe": "5m",
    }


def test_snapshot_candidate_exposes_source_execution_contract():
    analyzer = SnapshotAnalyzer()
    candidate = analyzer._candidate_report(
        _model(), "BULLISH", _entry_data(), _entry_frame(),
        {"is_executable_window": True}, 100.0, 1.0, "ALIGNED", 50.0,
    )
    assert candidate["decision"]["state"] == "READY_NOW"
    assert candidate["checks"]["source_execution_gate"]["state"] == "EXECUTABLE"
    assert candidate["management_contract"]["post_tp1_stop_policy"] == "STRUCTURE_ONLY"
    assert candidate["runner"]["allocation_pct"] == 50.0


def test_snapshot_candidate_rejects_missing_structural_stop():
    analyzer = SnapshotAnalyzer()
    # Remove both forms of causal-stop proof and ensure the source gate
    # protects execution rather than emitting an order-ready candidate.
    candidate = analyzer._candidate_report(
        {"chosen_model": {**_model()["chosen_model"], "plan": {**_model()["chosen_model"]["plan"], "basis": None, "stop_rationale": None}}},
        "BULLISH", _entry_data(), _entry_frame(),
        {"is_executable_window": True}, 100.0, 1.0, "ALIGNED", 50.0,
    )
    assert candidate["decision"]["state"] == "REJECTED"
    assert candidate["checks"]["source_execution_gate"]["state"] == "REJECT"
