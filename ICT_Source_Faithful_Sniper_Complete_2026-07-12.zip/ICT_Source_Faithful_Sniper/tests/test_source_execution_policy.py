from ict_source_policy import (
    evaluate_source_execution_gate,
    management_contract,
)


def _base(**updates):
    payload = dict(
        bias_state="ALIGNED",
        model_status="READY",
        ltf_displacement_confirmed=True,
        executable_session=True,
        has_structural_stop=True,
        has_tp1_liquidity=True,
        entry=100.0,
        stop_loss=99.0,
        round_trip_cost_pct=0.0,
        max_cost_r=0.25,
    )
    payload.update(updates)
    return payload


def test_full_evidence_is_executable():
    gate = evaluate_source_execution_gate(**_base())
    assert gate.state == "EXECUTABLE"
    assert gate.approved is True
    assert gate.evidence["tp1_real_liquidity"] is True


def test_missing_confirmation_waits_instead_of_forcing_entry():
    gate = evaluate_source_execution_gate(**_base(ltf_displacement_confirmed=False))
    assert gate.state == "WAIT"
    assert gate.approved is False
    assert any("MSS/BOS" in x for x in gate.reasons_ar)


def test_missing_structural_stop_is_rejected():
    gate = evaluate_source_execution_gate(**_base(has_structural_stop=False))
    assert gate.state == "REJECT"
    assert gate.approved is False


def test_cost_floor_rejects_tight_stop_when_cost_is_material():
    # 0.08% round trip / 0.10% initial risk = 0.80R cost, too large.
    gate = evaluate_source_execution_gate(**_base(
        entry=100.0, stop_loss=99.9, round_trip_cost_pct=0.0008, max_cost_r=0.25,
    ))
    assert gate.state == "REJECT"
    assert round(gate.cost_to_r, 8) == 0.8


def test_default_contract_is_source_structure_only_not_fixed_r_be():
    contract = management_contract()
    assert contract["tp1_allocation_pct"] == 50.0
    assert contract["runner_allocation_pct"] == 50.0
    assert contract["post_tp1_stop_policy"] == "STRUCTURE_ONLY"
    assert contract["automatic_fixed_r_be"] is False
