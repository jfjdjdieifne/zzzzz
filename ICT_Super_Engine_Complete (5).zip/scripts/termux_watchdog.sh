#!/bin/bash
# Auto-Restart & Crash Recovery Script - Daemon/Watchdog Process inside Termux
# Watches main Python process, if bot stops for any reason, automatically restarts from zero
# With calling last variables stored locally in trades_log.json to resume hunting second by second without intervention
# Sends emergency message on Telegram: ⚠️ [TERMUX AUTORUN: SYSTEM CRASHED AND SUCCESSFULLY RECOVERY ACTIVE]

SESSION="ict_engine"
SCRIPT="/data/data/com.termux/files/home/ICT_Super_Engine_Complete/engine/final_integrated_engine.py"
# Alternative script path for standalone live trading
LIVE_SCRIPT="/data/data/com.termux/files/home/live_trading.py"
LOG_FILE="/data/data/com.termux/files/home/termux_watchdog.log"
TRADES_LOG="/data/data/com.termux/files/home/trades_log.json"
PID_FILE="/data/data/com.termux/files/home/engine.pid"

# Telegram config (set via environment variables)
BOT_TOKEN="${TELEGRAM_BOT_TOKEN:-}"
CHAT_ID="${TELEGRAM_CHAT_ID:-}"

send_telegram_alert() {
    local message="$1"
    if [ -n "$BOT_TOKEN" ] && [ -n "$CHAT_ID" ]; then
        curl -s -X POST "https://api.telegram.org/bot${BOT_TOKEN}/sendMessage" \
            -d chat_id="${CHAT_ID}" \
            -d text="${message}" \
            -d parse_mode="Markdown" > /dev/null 2>&1
    fi
    echo "[$(date)] ${message}" >> "$LOG_FILE"
}

# Function to check if main engine is running
is_engine_running() {
    if [ -f "$PID_FILE" ]; then
        local pid=$(cat "$PID_FILE")
        if ps -p "$pid" > /dev/null 2>&1; then
            return 0  # running
        fi
    fi
    # Also check via pgrep
    if pgrep -f "final_integrated_engine.py" > /dev/null || pgrep -f "live_trading.py" > /dev/null; then
        return 0
    fi
    return 1  # not running
}

# Function to start engine
start_engine() {
    echo "[$(date)] Starting ICT Super Engine..." >> "$LOG_FILE"
    
    # Acquire wake lock to prevent Android killing Termux
    if command -v termux-wake-lock > /dev/null; then
        termux-wake-lock
        echo "[$(date)] Wake lock acquired" >> "$LOG_FILE"
    fi
    
    # Check if trades_log.json exists to resume
    if [ -f "$TRADES_LOG" ]; then
        echo "[$(date)] Found existing trades log, resuming from last state: $TRADES_LOG" >> "$LOG_FILE"
        # Engine will load this file internally to resume hunting second by second
    fi
    
    # Start engine in tmux session for persistence
    if command -v tmux > /dev/null; then
        # Check if session exists
        if tmux has-session -t "$SESSION" 2>/dev/null; then
            echo "[$(date)] tmux session $SESSION already exists, killing old" >> "$LOG_FILE"
            tmux kill-session -t "$SESSION"
        fi
        
        # Create new tmux session with restart loop
        tmux new-session -d -s "$SESSION" "while true; do python3 $LIVE_SCRIPT 2>&1 | tee -a $LOG_FILE; echo '[$(date)] Script crashed. Restarting in 5s...' >> $LOG_FILE; send_telegram_alert '⚠️ [TERMUX AUTORUN: SYSTEM CRASHED AND SUCCESSFULLY RECOVERY ACTIVE] - Restarting in 5s'; sleep 5; done"
        
        # Save PID of tmux
        pgrep -f "tmux.*$SESSION" > "$PID_FILE"
        echo "[$(date)] Engine started in tmux session $SESSION" >> "$LOG_FILE"
    else
        # Fallback without tmux - direct run with restart loop
        (
            while true; do
                python3 "$LIVE_SCRIPT" >> "$LOG_FILE" 2>&1
                echo "[$(date)] Script crashed. Restarting in 5s..." >> "$LOG_FILE"
                send_telegram_alert "⚠️ [TERMUX AUTORUN: SYSTEM CRASHED AND SUCCESSFULLY RECOVERY ACTIVE] - Restarting in 5s"
                sleep 5
            done
        ) &
        echo $! > "$PID_FILE"
    fi
    
    send_telegram_alert "✅ [TERMUX AUTORUN: ENGINE STARTED] - ICT Super Engine is now running 24/7 monitoring"
}

# Main watchdog loop
echo "=== Termux Watchdog Started at $(date) ===" >> "$LOG_FILE"
echo "Monitoring engine, auto-restart on crash, resume from $TRADES_LOG" >> "$LOG_FILE"

# Initial start if not running
if ! is_engine_running; then
    start_engine
fi

# Watchdog loop - check every 30 seconds
while true; do
    sleep 30
    
    if ! is_engine_running; then
        echo "[$(date)] Engine not running detected! Crash or WiFi loss or battery reboot" >> "$LOG_FILE"
        send_telegram_alert "⚠️ [TERMUX AUTORUN: SYSTEM CRASHED DETECTED] - Engine stopped, attempting recovery..."
        
        # Try to restore network? Wait for WiFi
        # Check internet connectivity
        for i in {1..12}; do  # Try for 2 minutes (12*10s)
            if ping -c 1 8.8.8.8 > /dev/null 2>&1; then
                echo "[$(date)] Internet connectivity restored" >> "$LOG_FILE"
                break
            fi
            echo "[$(date)] Waiting for internet... attempt $i" >> "$LOG_FILE"
            sleep 10
        done
        
        start_engine
        send_telegram_alert "⚠️ [TERMUX AUTORUN: SYSTEM CRASHED AND SUCCESSFULLY RECOVERY ACTIVE] - Resumed from $TRADES_LOG"
    fi
done
