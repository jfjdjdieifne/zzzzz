# المحطة الرابعة والأخيرة: هندسة التنفيذ - Order Blocks و FVG في منطقة الخصم

## غرفة العمليات - قناص رقمي متناهي الدقة

هنا يتحول البوت من محلل سياق إلى قناص يحدد السعر بالمليمتر والسنت.

---

## 1. التفكيك الفلسفي - الآثار الفيزيائية الصامتة للحوت

السعر الآن يرقد داخل منطقة الخصم الديناميكية من المحطة 3. الحوت ترك آثار:

### أ- FVG: المغناطيس السعري

**معناها السلوكي:** عندما ضخ الحوت ملايين دفعة واحدة، صعد السعر بسرعة جنونية لدرجة البائعين لم يجدوا وقتاً لعرض طلباتهم. هذا عدم توازن Imbalance أو فراغ. السوق يكره الفراغ؛ يعود كالمغناطيس لملئه.

**التعريف الرقمي الصارم عبر 3 شموع:**
```
إذا كانت الشمعة 1 و 2 و 3 صاعدة بعنف أثناء BOS:
High[C1] < Low[C3]
Gap = Low[C3] - High[C1]  (المسافة الفارغة)
High[C1] = نهاية الفجوة والتوازن الكلي
Low[C3] = بداية الفجوة خط المغناطيس والدخول الأول (IOFED)
```

- الشمعة 3 (Low) -> [بداية الفجوة: خط المغناطيس والدخول الأول]
- فراغ سعري Imbalance
- الشمعة 1 (High) -> [نهاية الفجوة والتوازن الكلي]

**المصدر:** FVG 3-candle imbalance High C1 < Low C3 [innercircletrader FVG][zaye][tradezella: two main reactions]
- Bullish FVG: high of C1 below low of C3

### ب- Bullish Order Block: الجدار الحوتي

**معناها السلوكي:** آخر شمعة هابطة (حمراء) رعاها الحوت عمداً لجمع آخر كميات البيع، قبل إطلاق صعوده الصاروخي الذي كسر الهيكل. الحوت ترك آلاف أوامر شراء معلقة Limit Orders لم تُفعل لأن السعر طار بسرعة. عودة السعر هنا لتفعيلها.

**التعريف الرقمي:**
- الشمعة الهابطة التي سبقت الشمعة الضخمة المسببة للـ FVG والـ BOS
- حدودها: من High الشمعة إلى Low الشمعة الهابطة
- **الشروط الأربعة المثبتة [innercircletrader OB]:**
  1. الشمعة الثانية (صاعدة) تسحب low الشمعة الهابطة السابقة
  2. تغلق فوق high الشمعة الهابطة - engulf كامل body+wick
  3. Imbalance على LTF داخل أو فوق OB
  4. Market Structure Shift صاعد على LTF

**المصدر:** Bullish OB is last bearish candle before bullish impulse [phidias][zaye][innercircletrader OB]

---

## 2. ميكانيكية التنفيذ الذكي - Confluence Entry Point

**المحركات الغبية:** تضع أمر شراء فور ملامسة FVG أو OB وتنام - خطأ قاتل، الحوت قد يسحق OB ويهبط إذا التصفية لم تنته.

### حساب نقطة التوازن الفائقة - Confluence

المحرك يبحث عن **التقاطع الرقمي Overlap** - يدمج مستطيل FVG مع مستطيل OB.

- **السيناريو المثالي:** الفجوة تنتهي مباشرة عند High of OB => يدمج المنطقتين ويحدد الدخول عند خط التماس.
- **CE - Consequent Encroachment:** إذا الفجوة ضخمة، الحوت يكتفي بملء نصفها:
  ```
  CE = (Low[C3] + High[C1]) / 2
  ```
  يتم اعتماده كأمر شراء معلق ذكي.

**المصدر CE:**
- CE = 50% midpoint of FVG, most reactive level [quantum-algo][fxnx][innercircletrader CE]
- CE is minimum mitigation required by algorithm [simpleict: "price does not need to fill entire FVG — only needs to rebalance to CE"]
- IOFED = very edge of FVG earliest entry [innercircletrader IOFED], CE = 50% midpoint

### الفلترة السلوكية اللحظية - Execution Trigger

بمجرد هبوط السعر وملامسة النطاق، لا يطلق أمر فوراً؛ بل يفتح خلية فحص على فريم صغير 1m/5m:

- **Spot CVD:** يجب أن يرى تحول فجائي من هبوط إلى صعود Aggressive Buying Absorption => أوامر الحوت بدأت تبتلع بائعي الذعر.
  - Proxy: (Close-Low)/(High-Low) delta * Volume, cumulative
  - Flip: CVD قبل اللمس سالب، بعد اللمس يتحول إيجابي مع close في النصف العلوي

- **Micro Wick Rejection:** شمعة الدقيقة التي لمست OB يجب أن تسحب ذيل سفلي سريع وتغلق في النصف العلوي لمداها.

**المصدر:** CVD absorption + failed auction [tradingview All-in-One CVD][orderflow trading: delta footprint][traderdale volume profile]

---

## 3. كتالوج الخدع في محطة التنفيذ

### الفخ الأول: كتلة الأوامر المخترقة والمثقوبة - Mitigated/Failed OB Trap

**السيناريو:** يهبط السعر إلى OB وبدلاً من الارتداد يخترقه بسلاسة وينهار، صفقة السبوت تعلق.

**كشف المحرك - طاقة الهبوط التصحيحي Retracement Delivery Efficiency:**
- يحسب عدد الشموع الحمراء المتتالية من القمة إلى OB + هل حجمها يتزايد + هل أجسامها ضخمة > ATR*0.8
- إذا شموع حمراء متتالية ضخمة بفوليوم متزايد خارج المعتاد => ليس تراجع هادئ لتفعيل الأوامر؛ بل هجوم بيعي حقيقي كاسر للاتجاه Order Flow Reversal
- **القرار:** إلغاء أمر الشراء المعلق فوراً والتنحي جانباً، لأن OB سيتم ثقبه.

**المصدر:** Order block dies when decisive close through it, wick piercing and snap back = mitigation, body close firm other side = failure [mql5][plisio breaker block: "body close beyond boundary, wick piercing and close back inside is rejection OB held"]

### الفخ الثاني: فجوة القيمة العادلة الوهمية - Induced FVG Trap

**السيناريو:** يتشكل FVG أثناء صعود المحطة 2 لكن الصعود نفسه ضعيف بدون فوليوم مؤسسي (تلاعب صغار). عند عودة السعر تفشل الفجوة.

**كشف المحرك:** يربط قوة FVG بشمعة الكسر الأصلية Parent Candle
- إذا حجم تداول الشمعة التي ولدت FVG أقل من انحراف معياري للحجم العام => Ghost FVG فجوة زئبقية وهمية
- يحظر الشراء منها وينتظر مناطق خصم أعمق.

**المصدر:** High-probability FVG characterized by strong displacement and HTF trend alignment, low-quality salami slice without displacement [fxnx][tradezella]

---

## 4. معادلة الحماية الصارمة والخروج

```json
{
  "Trade_Status": "EXECUTED_SPOT_BUY",
  "Entry_Price": 150.00,
  "Protected_Invalidation_Price (Stop Loss)": 147.90,
  "Take_Profit_Target_1": 159.00,
  "Risk_Reward_Ratio": "1:4.2"
}
```

1. **خط الأمان المطلق Stop Loss:** يوضع سنت واحد أسفل أدنى ذيل حقيقي تشكل في Protected Swing Low المحطة 1. إذا كسر بإغلاق جسم شمعة، يخرج فوراً بخسارة تقنية <=1% لحماية سيولة السبوت من التجميد.

   **المصدر:** Stop loss below OB low for bullish [phidias][innercircletrader OB], beyond wick of swept extreme [innercircletrader breaker]

2. **هدف جني الأرباح الديناميكي:** بما أننا في اتجاه صاعد عام قوي، الهدف الرئيسي هو أعلى نقطة في القمة التي تشكلت في المحطة 2 Termination Point، لأن ميكانيكية الهيكل تفرض أن السعر سيذهب لكسر هذه القمة وصنع قمة جديدة.

   **المصدر:** Take profit at next draw on liquidity [innercircletrader OB][innercircletrader CE]

---

## بروتوكول التشغيل التفكيري

```
[سعر في Discount Zone + Target OTE] 
  -> [رصد FVG: High C1 < Low C3] + [رصد OB: آخر شمعة هابطة قبل Displacement]
  -> [حساب التداخل: Overlap FVG & OB => Confluence Level أو CE=(Low C3+High C1)/2]
  -> [فحص الفخاخ: Ghost FVG? Parent Vol < avg? => BAN | Retracement Efficiency ATTACK? 3 reds increasing vol + huge body => CANCEL]
  -> [انتظار لمس: سعر يلمس Confluence]
  -> [فتح خلية LTF 1m: Spot CVD flip من سالب إلى موجب + Micro Wick Rejection close upper half]
  -> [تنفيذ Spot Buy + Stop Loss سنت تحت Protected Low + Take Profit Termination High]
```

بهذا تم تقفيل الخريطة الأولى بالكامل داخل خلايا المحرك الإدراكية. أصبح الانجن يعرف متى يتحرك، أين يقع الفخ، وكيف يقتنص الأرباح بأمان رياضي خالص وديناميكي.

---

## الخريطة الأولى اكتملت - 4 محطات

1. **القاع المحمي الحقيقي** - Selling Velocity + Rejection Filter + Ghost + Trendline Trap + Under Verification BOS/CHoCH
2. **BOS للاستمرار** - Triple Energy Check Close_Pos>0.75 + Volume Bollinger Outlier + Effort vs Result + Displacement ATR*0.2 + Sweep Trap
3. **Discount Array** - POC via VPVR + Dynamic Equilibrium (POC+50%)/2 + Adaptive OTE Hyper 50-61.8% vs Weak 70.5-79% + Induced FVG + Bleeding CVD traps
4. **التنفيذ** - FVG High C1<Low C3 + OB 4 conditions + Confluence + CE + CVD flip + Micro Wick Rejection + Retracement Efficiency Attack + Ghost FVG + SL/TP

الانجن الآن يمتلك عين تحليلية رقمية فائقة المرونة.

الخطوة القادمة: **الخريطة الثانية: هيكل الارتداد التصحيحي الصاعد في السوق الهابط (Counter-Trend Setup Map)**
