# المحطة الأولى من الخريطة الثانية: رصد جرف السيولة التاريخي HTF SFP

## المعنى الفلسفي: ماذا يحدث في القاع التاريخي الهابط؟

عندما ينهار الكريبتو بعنف Bear Market / Flash Crash، تسيطر سيكولوجيا الرعب المطلق.

- الصغار الذين اشتروا سابقاً يضعون ستوبات أسفل آخر قاع يومي/أسبوعي رئيسي Major Swing Low
- Short Sellers يضعون أوامر بيع ماركت عند كسر القاع للحاق بالانهيار Breakout Sellers
- **الحقيقة الصادمة:** أسفل هذا القاع ترقد أضخم بركة سيولة بيعية على كوكب الأرض **Sell-Side Liquidity SSL**
- الحيتان يحتاجون تجميع سبوت ضخم رخيص جداً، لن يجدوا من يبيعهم الطين إلا هنا. يدفعون السعر عمداً لكسر القاع، تتفعل ستوبات الصغار وتتحول إلى أوامر بيع إجبارية بالماركت، يمتصها الحوت ويشتري كل المعروض في ثوانٍ.

**المصدر:** SSL sits below swing lows, equal lows, previous session lows [ictkillzone], 73% liquidation events within 2% of recent swing highs/lows [Hyblock Capital via thrive.fi]

---

## التشريح الرقمي الديناميكي عبر OHLCV - SFP

المحرك يراقب فريم السياق الكبير 4H أو Daily، ويخزن سعر أعمق قاع تاريخي: `HTF_Major_Low`

يهبط السعر بعنف، تأتي الشمعة [X] على 4H وتخترق HTF_Major_Low لأسفل. ليعلن المحرك جرف سيولة حقيقي، يجب شرط هندسي صارم **Swing Failure Pattern SFP**:

```
Low[X] < HTF_Major_Low AND Close[X] > HTF_Major_Low
```

- أدنى سعر للشمعة تحت خط القاع (ليتفجر مسبح السيولة)
- قبل انتهاء 4H، يرتد بسرعة فائقة ويغلق فوق القاع التاريخي بالكامل
- الاختلاف بين الذيل المخترق والجسم المستقر فوق الخط هو البصمة الرياضية القاطعة بأن الحوت أخذ الأموال وهرب للأعلى

```
جسم شمعة 4H (مستقر في الأعلى)
┏━━━━━━━┓
┃       ┃
القاع التاريخي ─┸───────┸─ HTF_Major_Low
              ┃   │   ┃
                  │  <---- الذيل اخترق وسحب السيولة بقوة
                  ▼
              أدنى سعر (تصفية الصغار)
```

**المصدر:** SFP = Price trades beyond level but closes back inside range [thrive.fi: Bullish SFP Sweep Below Close Above], Low < prev low AND Close > prev low + Volume Spike [thrive.fi], Sweep + close back inside = liquidity grab [CandelaCharts SFP Model]

---

## فلتر الحجم ودلتا السبوت اللحظية

### أ- انحراف الحجم الشاذ Adaptive Volume Spike

حجم شمعة SFP Volume[X] يجب أن يكون خارج تماماً عن النطاق الطبيعي لآخر 50 شمعة.

```
Upper_Band = Mean(Volume last 50) + 2.5*StdDev
Is_Spike = Volume[X] > Upper_Band
Volume Ratio = Volume[X] / Mean
```

الرقم 2.5 انحراف معياري يثبت أن هذه الثواني شهدت أضخم معركة مالية في الدورة الحالية.

**المصدر:** Volume Spike 1.5x+ average [thrive.fi], Unusual Volume Scanner 4 StdDev [tosindicators], Volume Bollinger

### ب- دلتا حجم السبوت المتراكم Spot CVD Divergence - الفلتر الأذكى

**CVD = Cumulative Volume Delta = running total of aggressive buying minus aggressive selling**

```
Delta per candle = Volume * ((Close-Low)/(High-Low) -0.5)*2  => -Volume to +Volume
CVD = cumulative sum Delta
Rising CVD = buyers aggressive, Falling = sellers aggressive
```

**سيناريو Bullish Divergence:**
- السعر يضرب قاع جديد لأسفل، لكن Spot CVD ترتفع بحدة أو تتوقف عن الهبوط وتصنع انحراف إيجابي
- **الاستنتاج:** بائعو التجزئة يبيعون بالماركت خوفاً (CVD تهبط في الفيوتشر)، لكن هناك أوامر شراء سبوت خفية وعنيفة Limit Buy Orders تمتص البيوع وتمنع الاستقرار في الأسفل

**المصدر:**
- Bullish Divergence: Price new Low but CVD higher low = selling exhaustion, absorption, trap for sellers [trdr.io][backquant][bitget: "Price new low but CVD higher low indicates selling exhaustion"][coinglass: "Price making new lows inducing panic selling but CVD line refuses to continue lower stabilizing higher low signals bullish divergence absorption market bottom"]
- Spot CVD rising = Real demand bullish [trdr.io: Spot CVD rising Real demand], Perpetuals CVD rising without Spot = Fake move [trdr.io]
- Cross-venue Spot vs Perp divergence [backquant, bitget]

---

## كتالوج الفخاخ الخارقة في القيعان

### الفخ الأول: الجرف الممتد والسكين المفتوحة - Continuous Liquidation Trap

**السيناريو:** تنزل الشمعة تحت القاع، يبدو ذيل يرتد، يتسرع البوت ويشتري، لكن الانهيار يستمر وتغلق الشمعة في الأسفل (BOS هابط حقيقي).

**كيف يفلت المحرك؟** قاعدة مقدسة من ICT: **يمنع الشراء اللحظي أثناء حركة الشمعة**. ينتظر حتى تنتهي 4H بالكامل ويغلق المؤقت Candle Clock=0.

```
IF Low[X] < Major_Low AND Close[X] < Major_Low => REAL_BREAK
Record [Real Structural Break - No Buy], step aside, collapse continues to abyss lows
```

### الفخ الثاني: الارتداد الخالي من الأوكسجين - Low Liquidity SFP

**السيناريو:** يحدث SFP رقمياً، تغلق الشمعة فوق القاع بذيل طويل، لكن بحجم ضعيف جداً وبدون انحراف CVD.

**كيف يفلت؟**
```
IF SFP geometric true BUT Volume NOT spike AND No CVD divergence => FAKE_SWEEP
Reason: rebound because lack of sellers/server pause, no real buying power, price will return and break easily
Mark as Fake Sweep and refuse trade
```

---

## بروتوكول تحول الحالة

```
[4H Chart: رصد انهيار حاد نحو القاع التاريخي]
           │
           ▼
[4H Chart: إغلاق الشمعة فوق خط القاع مع ذيل ضرب في الأسفل وفوليوم شاذ 2.5 StdDev + CVD Bullish Divergence]
           │
           ▼
[تحديث الذاكرة: تفعيل وضع قناص الفريم الصغير والانتقال فوراً للمحطة الثانية]
```

المحرك لم يفتح صفقة شراء بعد؛ فقط ثبت في ذاكرته الرقمية أن **المجزرة الكبرى انتهت والحوت ملأ حقائبه بالسبوت الرخيص**. الآن يغلق 4H وينتقل كالثعلب إلى 15m و 5m لبدء المحطة الثانية: رصد CHoCH.

---

## اختبارات سلوكية - Engine Output

**Valid SFP Weak:**
- Index10 Low95<100 Close102>100 Volume 200k 6.6x avg upper band, CVD divergence false (in simple data) => VALID_SFP_WEAK (volume spike alone acceptable adaptive)

**Real Break:**
- Index12 Low95<100 Close98<100 => REAL_BREAK - BOS bearish continuation, No Buy, wait Clock=0

**Fake Sweep:**
- Index13 Low95<100 Close101>100 Volume 40k 0.6x not spike No CVD divergence => FAKE_SWEEP - rebound because lack of sellers

**State Transition:**
- If valid SFPS found => ACTIVATE_SMALL_TIMEFRAME_HUNTER
- Move to LTF 15m/5m for CHoCH

---

## التكامل مع الخريطة الأولى

الخريطة الأولى كانت في سوق صاعد عام تبحث عن Discount Array. الخريطة الثانية هي **عكسها تماماً**: سوق هابط عنيف، ننتظر HTF Sweep، ثم ننتقل لـ LTF CHoCH، ثم شراء سبوت خاطف، ثم خروج عند Bearish FVG 4H.

القوعد المحفورة لا تنسى: No Lookahead, Spot Only, Volume 2.5 StdDev, CVD Divergence, SFP Low<High AND Close>High, Real Break Close<High = No Buy.
