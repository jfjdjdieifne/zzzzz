# المحطة الثالثة من الخريطة الثانية: مناطق الخصم الارتدادية وكتل الأوامر الفرعية LTF

## الفلسفة: لماذا تختلف مناطق الخصم هنا؟

في الاتجاه الصاعد العام (الخريطة الأولى)، يمكن للسعر أن يصحح ببطء ويمنح وقت كافي. أما هنا في الخريطة الثانية (الارتداد ضد الاتجاه العام)، الحركة خاطفة ومستعجلة.

- **سلوك الحوت:** الحوت الذي جرف السيولة في القاع التاريخي HTF Sweep وضخ سيولة CHoCH، يريد رفع السعر بسرعة لملء الفراغات في الأعلى والتصريف هناك. سيعود لأسفل فقط لتخفيف وموازنة عقوده المعلقة Mitigation، وغالباً لن ينتظر طويلاً.
- **وظيفة المحرك:** حساب النطاق السعري الفرعي فوراً، وتحديد كتل الأوامر الفورية LTF OB المخبأة بدقة، وتصفية الفخاخ الخوارزمية التي تحاول استدراج البوت للشراء من مناطق غير آمنة.

---

## آلية الحساب الديناميكي للنطاق الارتدادي - LTF Discount Matrix

بمجرد أن يتشكل أول قاع فرعي حقيقي بعد CHoCH وتتوقف الموجة الاندفاعية الأولى عند قمة مؤقتة، يبدأ المحرك:

### 1. حدود المعركة الصغرى Micro Bounds
- LTF_Origin_Low = أعمق قاع فرعي تشكل أثناء جرف السيولة =0%
- LTF_Validation_High = أعلى قمة وصل إليها الارتداد الصاروخي للـ CHoCH وبدأ يتراجع منها =100%

### 2. الحد الفاصل الديناميكي لجاذبية السيولة Equilibrium Shift
بدلاً من 50% ثابت، يحسب نقطة السيطرة السعرية للموجة الصغرى Micro-POC عبر تتبع مستويات الأسعار التي شهدت أعلى ضخ فوليوم في شمعة CHoCH نفسها.

```
LTF_Dynamic_Equilibrium = (Micro-POC + Median_Price(50%))/2
```
القاعدة الصارمة: يحظر الشراء الفوري Spot Buy نهائياً فوق LTF_Dynamic_Equilibrium

**المصدر:** POC = price with highest volume magnet [tradingwyckoff][futureshive], Micro-POC via VWAP of displacement leg, Dynamic Equilibrium (POC+50%)/2 per your spec

---

## التشريح الجنائي لكتل أوامر الفريم الصغير LTF OB - فلتر الحصانة المزدوج

المحرك يبحث عن Bullish OB على 15m أو 5m داخل منطقة الخصم المستهدفة. لكي لا ينخدع بأي شمعة هابطة عادية، يجب أن يمر عبر فلتر الحصانة المؤسسي المزدوج:

### 1. شرط الاستحواذ على السيولة الفرعية Internal Liquidity Grab
الشمعة الهابطة المستهدفة كـ OB يجب أن يكون ذيلها السفلي قد كسر أو سحب سيولة شمعة فرعية سابقة لها مباشرة قبل الانطلاق. هذا يثبت رقمياً أن هذه الشمعة بالذات تمت رعايتها من الحوت لتنظيف الستوبات المحلية الصغرى.

```
Curr Low < Prev Low OR Curr Low < Recent Min Low (last 5)
```

### 2. شرط الابتلاع والاندفاع الصارم Engulfing & Displacement Rule
الشمعة اللاحقة لها مباشرة (أو خلال شمعتين) يجب أن تبتلع سعر افتتاح الشمعة الهابطة بالكامل، وتغلق بجسم ممتلئ، وتترك خلفها فجوة قيمة عادلة LTF FVG غير ملموسة.

```
Next Close > Curr Open (engulf)
Close Position >0.6 (full body)
Body > ATR*0.5 (displacement)
Curr High < Low of candle after next => Bullish FVG gap
```

**المصدر:** OB = last bearish candle before bullish impulse [phidias][zaye], 4 conditions engulf + imbalance + MSS [innercircletrader OB], FVG High C1 < Low C3 [innercircletrader FVG]

---

## كتالوج الخدع والمصايد في قيعان الارتداد

### الفخ الأول: الخصم الزائف والتجميع المستنزف Premium Churning Trap

**السيناريو:** بعد CHoCH، يتوقف السعر عن الصعود ويبدأ بالتحرك عرضياً بشموع صغيرة جداً وفوليوم ميت فوق خط LTF_Dynamic_Equilibrium. تظن البوتات الغبية أن هذا تجميع علمي صاعد وتشتري سبوت، وفجأة ينهار السعر ليكسر القاع بالكامل.

**كيف يكتشف المحرك؟** يراقب معدل تناقص الفوليوم بالنسبة للمدى Volume-to-Range Decay

```
Premium candles = candles with Close > DynamicEq in last 10
Avg Range = mean(High-Low) of premium candles
ATR = mean(High-Low) last 14
Sideways = Avg Range < ATR*0.5
Vol Decay = Premium Vol Avg < Total Avg *0.4 (less than avg by 60%)
Is Trap = Sideways AND Vol Decay
```

إذا وجد أن السعر يتحرك جانبياً في منطقة الغلاء Premium بحجم تداول يقل عن المتوسط بـ60%، يستنتج: "لا توجد طلبات شراء حيتانية جديدة تدعم استمرار الارتداد؛ هذا خمول قاتل ناتج عن غياب المشترين". يحظر الشراء فوراً ويلغي فكرة الصفقة مؤقتاً.

### الفخ الثاني: سحق كتل الأوامر الضعيفة OB Breaker Trap

**السيناريو:** يهبط السعر إلى LTF OB، ولكن الهبوط يكون عبارة عن شمعة حمراء واحدة عملاقة مفرطة الزخم Marubozu هابطة، تثقب OB بسلاسة وتغلق أسفله.

**كيف يكتشف؟** يحسب طاقة الهجوم البيعي عبر قياس نسبة أجساد الشموع الهابطة لآخر 3 شموع تصحيحية

```
Bodies = |Close-Open| of last 3 bearish
Slope Body = LinearRegression bodies increasing?
Volumes = volumes of bearish
Slope Vol = LinearRegression volumes increasing?
Last bearish Body Ratio = Body / HL Range >0.8 => Marubozu
Vol Rising outside StdDev: Last Vol > Mean+2*Std
Is Trap = Body Increasing AND Vol Rising AND Marubozu
```

إذا كانت نسبة الأجساد تتزايد بحدة والفوليوم البيعي يرتفع خارج الانحراف المعياري، تشتعل خلية الإنذار: "هذا ليس تراجعاً ناعماً للتخفيف؛ البائعون على الفريم الكبير استعادوا السيطرة وهجومهم كاسر للجدار". يقوم بإعدام وإلغاء أمر الشراء المعلق فوراً ليتنحى ويتفرج صامتاً دون تعليق أي دولار.

---

## تحديث بنية الذاكرة

بمجرد استقرار السعر داخل منطقة الخصم الفرعية المحددة وتباطؤ زخم الهبوط هندسياً:

```json
{
  "Market_Context": "Bearish_HTF_But_LTF_Counter_Rally",
  "Target_LTF_OB_Zone": {"High": 84.50, "Low": 83.10},
  "Dynamic_Equilibrium_Line": 85.80,
  "Action_Status": "ALLOW_MONITORING_FOR_EXECUTION_TRIGGERS"
}
```

---

## اختبار سلوكي أوتوماتيكي - Engine Output

```
Origin 80 Validation High 95 Micro-POC 94 Median 87.5 DynamicEq 90.75
Premium 90.75-95 NO BUY Discount 80-90.75 Watch
Target LTF OB Zone High 87.5 Low 82
Action ALLOW_MONITORING_FOR_EXECUTION_TRIGGERS State IN_DISCOUNT_VALID_OB
Num Valid OBs 1 Num Breaker Traps 0
```

الانجن حسب Micro Bounds فوراً بعد CHoCH، وجد POC عبر VWAP لشمعة CHoCH نفسها، وحدد DynamicEq (Micro-POC+Median)/2، ومنع الشراء فوقه، وكشف OB بفلتر الحصانة المزدوج Internal Grab + Engulf Displacement، وفحص فخاخ Premium Churning (Volume-to-Range Decay <40% avg) و OB Breaker (Bodies increasing + Vol rising + Marubozu) ولم يجدهما، فسمح بالمراقبة للتنفيذ المليمتري.

---

## التكامل

- Station1 HTF Sweep: Valid SFP Volume Spike 2.5 StdDev + CVD Divergence
- Station2 LTF CHoCH: Body Close + Momentum 2x + Distance>1.5 ATR + Volume Spike + CVD Rising
- Station3 LTF Discount: Micro Bounds Origin/Validation + Micro-POC + DynamicEq (POC+50)/2 + Double Immunity OB + Churning Trap + Breaker Trap

المحرك الآن في منطقة خصم فرعية مع OB صالح، جاهز للمحطة الرابعة: التنفيذ المليمتري والخروج الحتمي عند أول Bearish FVG 4H.
