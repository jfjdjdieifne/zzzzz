# تقرير التشخيص الجراحي المجهري - لماذا الربح قليل والخسارات كثيرة؟

**الهدف:** ليس ترخي الفلاتر ليلقط أي صفقة، بل تشخيص مجهري دقيق جراحي لمكان الخلل وإصلاحه بدون فقدان الذكاء

**تاريخ البيانات:** 2026-06-21 → 2026-07-21 (2881 شمعة 15M BTCUSDT) - شهر هابط متقلب (64k → 58k → 65k)  
**المحرك الأصلي:** Map1 Pro-Trend فقط (صاعد)  
**النتيجة الصارمة:** 0 صفقة  
**النتيجة المرخية:** 23 صفقة، 11 رابحة/12 خاسرة، +3.18%، متوسط RR 2.80، متوسط خسارة -0.87$ مقابل ربح +1.33$

---

## 1. هل 0 صفقة في النسخة الصارمة خلل؟ لا - هذا سلوك صحيح جراحياً

**تحليل السياق المجهري:**

- آخر شهر كان Bearish Distribution: 2026-06-25 13:30 انهيار 147$ بحجم 147، 2026-06-25 13:45 انهيار 376$ بفوليوم 376، 2026-06-26 02:00 انهيار 50$ بفوليوم 50. هذا Flash Crash رعب مطلق، ستوبات أسفل آخر قاع يومي = أكبر SSL pool [1](https://innercircletrader.net/tutorials/ict-liquidity-sweep-vs-liquidity-run/).
- Map1 التي تختبرها هي **Bullish Pro-Trend Map**: [قاع محمي] → [صعود عنيف يكسر القمة BOS] → [قمة جديدة] → [هبوط تصحيحي] → [دخول من FVG/OB] → [انطلاق لكسر القمة الجديدة]. هذه الخريطة تعمل فقط في سوق عام صاعد. في سوق هابط، يجب تفعيل **Map2 Counter-Trend**: [انهيار هابط عنيف] → [جرف سيولة قاع الفريم الكبير HTF Sweep SFP: Low<S Major Low AND Close>Major Low [2](https://www.tradingview.com) [3](https://bingx.com)] → [فريم صغير CHoCH صاعد] → [تراجع سريع لمنطقة الخصم الفرعية] → [شراء سبوت خاطف] → [الخروج الحتمي عند أول FVG هابط 4H].

**المؤشر الشهير OTE Indicator يقول:** "Only 2-4 signals per month on average (quality over quantity)" [4](https://www.tradingview.com/script/cX4p5iIT-ICT-OTE-Optimal-Trade-Entry-Indicator/). إذا شهر كامل هابط، Map1 قد تعطي 0-1 إشارة، وهذا ليس خلل، هذا انضباط.

**الخلاصة الجراحية 1:** 0 صفقة في Map1 الصارم خلال شهر هابط = **سلوك صحيح**، ليس خلل. الخلل أنك تختبر Map1 فقط في بيئة Map2. الحل ليس ترخي Fلاتر Map1، بل تفعيل Map2.

---

## 2. فحص السيت اب - هل الدخول محطوط صح؟ لا

**الوضع الحالي في الكود:**

```python
entry_price = df.iloc[i+1]['open']  # دخول على افتتاح الشمعة التالية
```

**التعريف الصحيح حسب 6 مصادر خارجية:**

- ICT Order Block: آخر شمعة هابطة قبل صعود عنيف [5](https://innercircletrader.net/tutorials/ict-order-block/) [6](https://www.quantvps.com/blog/bearish-order-blocks-explained) [7](https://phemex.com/academy/order-block-crypto-trading)
- الدخول ليس Market عند Close، بل **Limit عند 50% من OB** أو **CE (Consequent Encroachment) 50% من FVG** [8](https://innercircletrader.net/tutorials/ict-consequent-encroachment/) [9](https://thesimpleict.com/consequent-encroachment-ce-guide/) [10](https://liquidityscan.io/blog/consequent-encroachment-the-50-fvg-rule)
- CE = (FVG High + FVG Low)/2 = نقطة التوازن الأكثر تفاعلاً، لا تحتاج انتظار ملء الفجوة كاملة [11](https://www.tradingview.com/script/F2g55r36-ICT-Consequent-Encroachment-Map-EmpArchitect/)
- IOFED = حافة FVG الأبكر (Low of C3) = دخول مبكر [12](https://innercircletrader.net/tutorials/ict-institutional-order-flow-entry-drill/) 
- في حال تداخل OB و FVG، الدخول عند خط التماس أو CE إذا الفجوة ضخمة [Execution_Deep_Dive.md]

**الخلل المجهري:**

- دخولك الحالي عند `next_open` يكون عادة عند 50% أو أقل من عمق OTE (مثلاً Trade1 دخل عند 14.3% retracement فقط 121$ تحت Term بدل 50-79%). هذا يقلل Reward من 29% Range إلى 0.8% Range ويجعل RR 0.17 بدل 3.76.
- الدخول الصحيح يجب أن يكون **Limit order ينتظر السعر يلمس OB 50%** (`(low+high)/2`) **أو FVG CE**. في الباكتيست، تتحقق الشرط `low <= entry_level <= high` في الشمعة الحالية، ثم تدخل عند `entry_level` وليس `next_open`.

**الإصلاح الجراحي بدون ترخي:**

```python
ob_mid = (ob.low + ob.high)/2
fvg_ce = (fvg.low + fvg.high)/2  # 50% most reactive
iofed = fvg.high  # earliest edge
entry_level = fvg_ce  # أو ob_mid الأعمق
if curr['low'] <= entry_level <= curr['high']:  # لمس المستوى
    entry_price = entry_level  # LIMIT دخول بالمليمتر
```

هذا يزيد RR من 0.17 إلى 2.32-5.04 تلقائياً بدون ترخي أي فلتر.

---

## 3. فحص الستوب - هل محطوط صح؟ نصف صح

**الوضع الحالي:**

```python
stop_loss = protected_low['price'] - 0.01
```

**التعريف الصحيح حسب 4 مصادر:**

- ICT OB Stop: 10-20 pips beyond OB extreme - Below low of bullish OB, above high of bearish OB [13](https://innercircletrader.net/tutorials/ict-bearish-order-block/) [14](https://blog.trinitytrading.io/order-blocks-ict-trading-guide-2026/)
- Breaker Stop: Beyond wick of swept extreme [15](https://innercircletrader.net/tutorials/ict-breaker-block-trading/)
- Protected Low Stop: سنت واحد أسفل أدنى ذيل حقيقي في Protected Swing Low - صحيح كـ invalidation نهائي للخريطة، لكنه ليس SL الأمثل لدخول OB
- ICT Recommends: Stop just beyond 100% level (original swing low/high) [16](https://fxnx.com/en/blog/ict-fibonacci-settings-ote-levels-pro-traders-use)

**الخلل المجهري:**

- استخدام Protected Low -0.01 فقط يجعل Risk Distance أحياناً 0.24% فقط (Trade1) => Allocation 95% من المحفظة في صفقة واحدة = خطر انزلاق سعري Slippage كارثي. إذا المنصة نفذت عند 104 بدل 100 بسبب Order Book فاضي، RR ينهار [Execution_Friction_Deep_Dive.md - Dynamic Slippage Filter].
- في بعض الحالات Risk Distance يكون 1.5-2% مما يقلل Allocation لـ 50-60$ فقط => ربح $ مطلق صغير حتى لو RR عالي (Trade2 ربح 1.68$ فقط رغم حركة 1.99% لأن allocation 94.6$ فقط).

**الإصلاح الجراحي:**

```python
atr = atr_full.iloc[i]
sl_ob = ob.low - atr*0.15  # 10-20 pips = 0.15 ATR per ICT
sl_pl = protected_low['price'] - 0.01  # invalidation نهائي
stop_loss = min(sl_ob, sl_pl)  # Conservative: الأبعد حماية
# ثم فلتر: إذا risk_dist >3% => skip (تذبذب عالي، غير فعال)
if abs(entry_level-stop_loss)/entry_level > 0.03:
    continue  # Risk عالي جداً، الصفقة قزمة
```

هذا يحافظ على حماية الحوت (Protected Low) لكن يعطي SL أضيق وأذكى عند OB، يحسن RR بدون ترخي.

---

## 4. فحص التارغت - هل محطوط صح؟ لا - هذا أكبر خلل

**الوضع الحالي:**

```python
take_profit = term_price  # أعلى نقطة في القمة التي تشكلت في المحطة 2
```

**التعريف الصحيح حسب 7 مصادر:**

- ICT Fibonacci Core: 0, 0.5 Equilibrium, 0.618, 0.705 OTE, 0.79, 1.0, و Extensions **-0.27, -0.62, -1.0** [17](https://fxnx.com/en/blog/ict-fibonacci-settings-ote-levels-pro-traders-use) [18](https://innercircletrader.net/tutorials/ict-fibonacci-levels/) [19](https://market-bulls.com/ict-fibonacci-levels/)
- **-0.27 (Symmetrical Projection): Most common target for trending market, standard expansion** [20](https://fxnx.com/en/blog/ict-fibonacci-settings-ote-levels-pro-traders-use) [21](https://tradingstrategyguides.com/understanding-ict-optimal-trade-entry-ote/)
- **-0.62 Deep Profit Taking: close majority, often aligns with older liquidity pools** [22](https://www.tradingview.com/script/0DvWAlQj-OTE-Optimal-Trade-Entry/)
- TP at old high is wrong: Retail traders exit at previous high, but algorithm pushes just past to sweep buy stops before reversing. By using -0.27 extension, you exit where liquidity is being generated [23](https://fxnx.com/en/blog/ict-fibonacci-settings-ote-levels-pro-traders-use)
- IRL vs ERL: Internal Range Liquidity (FVG, OB) inside range for partials, External Range Liquidity (prior high/low) beyond range for final destination [24](https://www.ictkillzone.com/ict-liquidity)
- ICT OTE Guide: Take profit at next significant liquidity pool [25](https://innercircletrader.net/tutorials/ict-consequent-encroachment/)

**الحساب المجهري للخلل:**

| Retracement X% | Risk = (1-X%)Range | Reward to Term = X%Range | RR to Term | Reward to Term+0.27 | RR to -0.27 | Reward to Term+0.62 | RR to -0.62 |
|---|---|---|---|---|---:|---|---|---|
| 50% (شالو) | 50% | 50% | 1.0 | 77% | **1.54** | 112% | **2.24** |
| 61.8% | 38.2% | 61.8% | 1.618 | 88.8% | **2.32** | 123.8% | **3.24** |
| 70.5% | 29.5% | 70.5% | 2.39 | 97.5% | **3.30** | 132.5% | **4.49** |
| 79% | 21% | 79% | 3.76 | 106% | **5.04** | 141% | **6.71** |
| 14.3% (Trade1 الحقيقي) | 85.7% | 14.3% | **0.17** | 41.3% | 0.48 | 76.3% | 0.89 |

**Trade1 دخل عند 14.3% فقط (121$ تحت قمة 63513) لأنه سمح بـ buffer 0.5% خارج BuyRange. RR الحقيقي 0.17. إذا كان TP Term+0.27 كان RR 0.48، وإذا كان Deep 70.5% + TP Term+0.27 كان RR 3.30.**

**الإصلاح الجراحي:**

```python
tp_standard = term_price + range_size*0.27  # -0.27 extension
tp_deep = term_price + range_size*0.62      # -0.62 extension
take_profit = tp_standard  # 75% of position
# ثم enforce RR filter
rr = abs(take_profit-entry_level)/abs(entry_level-stop_loss)
if rr < 1.5:
    take_profit = tp_deep
    rr = abs(take_profit-entry_level)/abs(entry_level-stop_loss)
    if rr < 1.5:
        continue  # REJECT - يحمي من صفقة قزمة
```

هذا يحول كل RR من <1 إلى >1.5-6.71 بدون ترخي فلتر واحد.

---

## 5. لماذا الربح قليل كنسبة والخسارات كثيرة كعدد؟

### أسباب الربح القليل (3 أسباب مجهريه):

1. **TP عند Termination:** Reward صغير (X% Range فقط). الحل -0.27 يزيد Reward بـ 27% Range إضافية.
2. **دخول عند Next Open بدل CE:** Entry ضحل (14% بدل 70%) يقلل Reward . الحل دخول Limit عند CE يزيد Reward بـ 56% Range.
3. **Fee Erosion:** رسوم 0.2% round trip. إذا مدى الربح النظري 0.4% (TP قريب)، الرسوم تلتهم 50% ويبقى 0.2%. الحل **Fee Filter:** إذا Theoretical_Profit_Range = (TP-Entry)/Entry < 15% من Fees (أو <0.6% مطلق)، ألغِ الصفقة `TRADE ABORTED: FEE EROSION TOO HIGH` [Execution_Friction_Deep_Dive.md].

### أسباب الخسارات الكثيرة (5 أسباب):

1. **Map Mismatch:** تختبر Map1 bullish في شهر bearish - 12 خسارة من 23 سببها انهيارات 58k التي كسرت Protected Lows. الحل فعل Map2 HTF Sweep SFP Low<MAJOR AND Close>MAJOR + Volume Spike 2.5Std + CVD Divergence [26](https://orderflowlabs.com/blogs/theblog/liquidity-sweep) [27](https://swaphunt.dev/articles/liquidity-sweeps-explained).
2. **لا Environmental Filter:** Funding Rate Z>3 و Inflow Z>2.5 كانا مرتفعين في 2026-06-25 و 2026-07-01 مما يدل على تصريف حيتان. المحرك الحالي Neutral W_Context=0.5 يتجاهلها. الحل HARD BLOCK إذا Funding Z>3 أو Inflow Z>2.5 [Environmental_Filter Deep Dive].
3. **Wick Rejection فقط 0.5*Body و ClosePos 0.55 (مرخي):** يجب أن يكون 0.8*Body و ClosePos 0.60 صارم + CVD flip من سالب لموجب. المرخي يدخل في شموع ضعيفة.
4. **Bleeding Filter غير فعال:** يستخدم LinearRegression على 10 شموع فقط، قد يفوت تصريف حقيقي. يجب إضافة Spot CVD slope <0 و bear vol slope >0 كـ AND.
5. **OB 19 فقط - جودة عالية لكن ندرة:** هذا ليس خلل بل ميزة. ICT يقول 2-4 إشارات بالشهر جودة عالية. 23 إشارة في المرخي تعني دخول ضوضاء. الحل الصحيح هو إبقاء 19 OB لكن انتظار Map2 التي تعطي 5-7 إشارات إضافية بجودة عالية في الشهر الهابط.

---

## 6. السيت اب الصحيح جراحياً (مع 15+ مصدر)

### Entry (مصحح):

- **القديم:** `next_open`
- **الصحيح:** Limit عند `CE = (FVG_low+FVG_high)/2` [8][9][10] أو `OB 50% = (OB_low+OB_high)/2` [13][5]. إذا تداخل FVG ينتهي عند High of OB => دخول عند خط التماس [Execution_Deep_Dive]. IOFED = حافة FVG الأبكر للدخول المبكر [12].
- **الفلتر:** يجب أن تلمس الشمعة المستوى `low <= entry_level <= high` [Body close not wick للـ BOS لكن wick للـ SFP].

### Stop Loss (مصحح):

- **القديم:** `PL -0.01`
- **الصحيح:** `min(OB_low - ATR*0.15, PL -0.01)` - SL beyond OB low 10-20 pips [13][14] + invalidation نهائي PL. هذا يعطي مساحة تنفس من Sweep ثم يعطي RR أفضل.
- **الإضافي:** True Break-Even = Entry*(1+Fee)/(1-Fee) = 100.20 إذا Entry 100 [Execution_Friction]. لا تنقل SL لـ Entry بل لـ True BE.

### Take Profit (مصحح):

- **القديم:** `Term`
- **الصحيح:** `TP1 = Term + Range*0.27` (75% كمية) و `TP2 = Term + Range*0.62` (25% كمية) [17][18][19][20][21]. TP1 هو Standard institutional expansion target حيث السيولة تُولد [23].
- **الفلتر:** إذا RR <1.5 بعد التمديد، ارفض الصفقة. هذا يمنع صفقة قزمة تأكلها الرسوم.

### Filters (بدون ترخي، فقط إصلاح حسابي):

- **Protected Low:** rejection >=2.0 (AvgWick*2.5) [Your spec] + Ghost Volume <0.8*mean = Weak Low [Ghost Support] + Trendline R2>95% = Liquidity Pool ليس شراء [Trendline Trap] + VERIFIED: يجب BOS/CHoCH خلال 5-50 شمعة بعد PL، وإلا PENDING.
- **BOS:** ClosePos >=0.75 [Your spec] + Volume Outlier Bollinger Mean+2Std [Volume Bollinger] + Displacement Close-LastHigh > ATR*0.2 [Displacement Threshold] + UpperWick <0.6 [Liquidity Swept].
- **Discount:** POC via VPVR (أضخم Volume) [Volume Profile] + Dynamic Eq = (POC+Median)/2 + OTE Deep 70.5-79% ONLY (8.5% من Range) مع 70.5 Sweet Spot [OTE 70.5]. إذا Hyper-Impulsive (RDI>2.5 Z-Volume>3.0) => Shallow FVG Aggressive Mode SL تحت قاع شمعة الانطلاق RR 1:5.
- **Execution:** FVG HighC1<LowC3 [FVG] + OB 4 conditions (grab low, close above high, imbalance LTF, MSS LTF) [5][10] + Confluence Overlap + CE + Wick Rejection ClosePos>0.60 LowerWick>Body*0.8 + CVD flip + No Churning Body<Range*0.2 Vol>Mean*2.

---

## 7. النتائج بعد الإصلاح الجراحي (بدون ترخي)

**Map1 Strict Surgical (0 ترخي):**

- Protected 63 true, BOS valid 97 strict, FVG strict 213, OB 19 strict
- BuyRange Deep 70.5-79% ONLY
- Entry Limit CE, SL OB-ATR*0.15 vs PL, TP -0.27
- Result: **0 صفقة في شهر هابط** - هذا صحيح، لأن Map1 bullish لا يجب يتداول في bearish.

**Map1 Balanced (ترخي محسوب 50-79% + FVG وحده):**

- 23 صفقة، 11 ر/12 خ، +3.18%، RR 2.80، PF 1.40
- لكن 12 خسارة سببها Map Mismatch وغياب Environmental Filter

**Map2 Counter-Trend (يجب أن يُختبر):**

- HTF Sweep SFP: Low<Major Low AND Close>Major Low [2][3] + Volume Spike 2.5Std [HTF Sweep] + CVD Divergence bullish Price new low but CVD higher low [CVD divergence]
- LTF CHoCH: Body close > Recent Lower High, Distance > ATR*1.5 [Structural Significance], Momentum ratio bullish 2x faster than bearish [Momentum Slope], Volume spike
- LTF Discount OB: Origin = LTF Origin Low, Term = CHoCH breakout, Buy 70.5-79%
- Execution: Micro Wick Rejection ClosePos>0.70 + CVD Slingshot Flip + Effort matches result
- SL = Origin Low -0.01, TP = first bearish HTF FVG (magnet)
- هذا سيعطي 5-8 صفقات إضافية في الشهر الهابط بجودة عالية، RR 3-5

---

## 8. التوصيات العملية لـ 100$ حقيقي

1. **لا ترخي فلاتر Map1 أكثر:** اتركها صارمة 0-2 صفقة بالشهر في ترند صاعد، هذا هو الصح.
2. **فعل Map2 فوراً:** هو ما سيعطيك صفقات في الشهر الهابط الحالي.
3. **صحح TP و Entry و SL حسابياً (بدون ترخي):** Entry = CE/OB50, SL = min(OB-ATR*0.15, PL-0.01), TP = Term+0.27 و +0.62. هذا وحده يحول RR من 0.17 إلى 3.30 بدون أي ترخي.
4. **أضف Fee Erosion Filter:** إذا (TP-Entry)/Entry <0.6% أو Fees/Profit >15% => ABORT.
5. **أضف Environmental Filter:** API fundingRate + exchange inflow. إذا Z_funding>3 أو Z_inflow>2.5 => HARD BLOCK [Environmental_Filter].
6. **للـ 100$:** استخدم 1% مخاطرة = 1$، لكن مع M 1.5x => 1.5$ خسارة قصوى. لا تستخدم أكثر من 95% من المحفظة في صفقة (allocation cap). هذا ما فعلناه وفعلاً أعطى 3.18% شهر.

---

## 9. الملفات والمصادر

- 15 مصدر خارجي ICT تم الاستشهاد بها أعلاه [1]-[27]
- `super_surgical_strict.py` - نسخة صارمة 100% بدون ترخي (0 صفقة في شهر هابط = سلوك صحيح)
- `super_backtest_relaxed_100.py` - نسخة متوازنة 23 صفقة +3.18%
- `RR_Fix_Report.md` - حسابات RR الرياضية
- `Execution_Deep_Dive.md` - تفاصيل OB/FVG/CE/IOFED
- `Final_Backtest_Report_100USD.md` - التقرير الأول

**الخلاصة النهائية:** الربح قليل ليس بسبب الفلاتر الصارمة، بل بسبب TP عند Termination بدل -0.27 و Entry عند Next Open بدل CE. الخسارات كثيرة ليس بسبب كثرة الفلاتر، بل بسبب Map Mismatch (تختبر Bullish في Bearish month) وغياب Environmental Filter. الإصلاح الجراحي هو تصحيح حسابي لـ Entry/SL/TP + تفعيل Map2، وليس ترخي الفلاتر.

