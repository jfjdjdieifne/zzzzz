# التشريح الممل جداً للمحطة الأولى: القاع المحمي الحقيقي - True Protected Low
## الخلية الإدراكية الأولى في الخريطة الصاعدة

> القاعدة الذهبية التي طلبتها: لا نتعامل مع OHLC كأرقام، بل كنقاط ضغط فيزيائي وموازين قوى. الحدث "ب" لا يحدث إلا إذا توفرت الطاقة في الحدث "أ".

---

### 1. التعريف الميكانيكي من المصادر الأصلية

**أ- Swing Low العادي (القاعدة):**
حسب ICT الرسمي: تشكيل 3 شموع، الشمعة الوسطى لديها أدنى low أقل من جيرانها [1](https://innercircletrader.net/tutorials/ict-swing-low-formation/)
- ليس كل وِك هو سوينغ
- السوينغ الحقيقي يسبب ردة فعل للسعر [6](https://thesimpleict.com/ict-swing-high-swing-low-explained/)

**ب- Protected Swing Low (القفزة النوعية):**
من LuxAlgo Protected Swings: 
- "A Protected Swing Low forms after a sweep of a low followed by a close above the opening price of the down-close candle series that created that low" [3](https://www.luxalgo.com/library/indicator/protected-swings/)[4](https://www.tradingview.com/script/7hDV5lWH-Protected-Swings-LuxAlgo/)
- المنطق متعدد الخطوات:
  1. **Liquidity Sweep**: وِك يكسر قاع سابق لكن الجسم يبقى داخل [4]
  2. **FVG Mitigation (اختياري)**: إذا تفاعل مع FVG موجود
  3. **CISD - Change in State of Delivery**: إغلاق جسم فوق مستوى التأكيد

**ج- Confirmation Level:**
"Opening price of the first candle in that series becomes the Confirmation Level. A candle body must close above this level to confirm the swing as protected" [3]

**د- الفرق بين المحمي وغير المحمي:**
- قاع عادي = مجرد 3 شموع
- قاع محمي = قاع عادي + كنس سيولة + إغلاق CISD = دفاع مؤسسي
- القاع المحمي يصبح نقطة إبطال (Invalidation) - إذا انكسر، فكرة الشراء فشلت

---

### 2. السببية السلوكية - لماذا يحدث هكذا؟ (مبدأ الطاقة)

**الحدث أ: تراكم السيولة**
- تحت كل قاع واضح، أوامر ستوب لونغ متجمعة [7](https://www.ictkillzone.com/ict-liquidity)
- الحوت يحتاج هذه السيولة ليملأ أمر شراء ضخم
- لذلك يخلق قيعان متساوية (Equal Lows) ضمن 0.05% tolerance [FibAlgo]

**الحدث ب: جرف السيولة (الطاقة)**
- وِك عنيف يكسر القاع بـ $20 مثلاً، يفجر ستوبات
- حجم تداول 200% فوق المتوسط = دخول حوت [Sweep Test]
- الإغلاق فوق القاع = فشل البائعين

**الحدث ج: سلسلة الإغلاقات الهابطة (الضغط الفيزيائي)**
- بعد الكنس، يتشكل ضغط بيعي مصطنع: 2-3 شموع إغلاق هابط متتالي
- كل شمعة: Close < Open = بيع
- أول شمعة في السلسلة فتحها = آخر دفاع للدببة

**الحدث د: CISD - تغير حالة التسليم (الانفجار)**
- شمعة صاعدة تغلق فوق فتح أول شمعة في السلسلة بجسم كامل
- هذا يعني: الدببة فشلت في حماية فتحها، الثيران سيطرت
- من هنا، القاع يصبح محمي - لا يجب أن ينكسر مرة أخرى في ترند صاعد

**العلاقة السببية:**
لا يمكن أن يحدث CISD بدون سلسلة هابطة، ولا يمكن أن تحدث سلسلة هابطة بدون كنس سيولة، ولا يمكن أن يحدث كنس بدون تجمع سيولة. هذا ما يجعل الانجن يفكر سببياً.

---

### 3. المعايير الرقمية الدقيقة للاختبار السلوكي

**اختبار Equal Lows:**
- $100.00 و $100.05 = فرق 0.05% = نفس البركة (Pass)
- $100 و $103 = فرق 3% = ليس نفس البركة (Fail)
- يجب أن تكون المسافة الزمنية >3 شموع، وإلا فهي Noise

**اختبار Sweep:**
- وِك تحت البركة + إغلاق فوق البركة = Sweep Confirmed
- حجم >2x المتوسط = تأكيد مؤسسي
- ممنوع تفعيل بيع ذعر عند الكسر

**اختبار Protected:**
- سلسلة 2-4 شموع إغلاق هابط متتالي
- Confirmation Level = Open أول شمعة في السلسلة
- الحماية تتأكد بإغلاق جسم فوق Confirmation
- مثالنا: Confirmation 108.0، إغلاق 108.2 فوقه بجسم صاعد = محمي

**اختبار Choch المرتبط:**
- بعد حماية القاع، يجب أن يكسر السعر آخر قمة هابطة تسببت في القاع مباشرة
- ليس أي قمة داخلية ثانوية
- الإغلاق يجب أن يكون بجسم كامل فوق القمة

---

### 4. لماذا القاع المحمي هو أساس الخريطة الصاعدة؟

1. **هو نقطة الصفر للفيبوناتشي:**
   بعد BOS، نرسم فيبوناتشي من القاع المحمي إلى القمة الجديدة، والمنطقة تحت 50% هي Discount المسموح الشراء فيها [4][5]

2. **هو الستوب المنطقي:**
   الستوب يوضع 10-20 pip تحت القاع المحمي، ليس تحت أي قاع عشوائي [Bullish OB guide]

3. **هو أساس هرمية ICT:**
   كل STL هو سوينغ لو، كل ITL هو سوينغ لو مع سوينغ أعلى على الجانبين، كل LTL هو ITL مع ITL أعلى [1]

4. **هو فلتر ضد الفخاخ:**
   قاع غير محمي = فخ، ينكسر بسهولة
   قاع محمي = دفاع حيتاني، يحترم

---

### 5. كيف طبقنا هذا في الانجن (كود سلوكي لا غبي)

```python
# ليس مجرد find_low()
# 1. كشف سوينغ ميكانيكي بفترة pivot
swings = detect_swings(df, pivot=1)  # fractal 3 candles

# 2. لكل سوينغ low، ابحث عن سلسلة هبوط
down_series = []
j = swing_index
while close[j] < open[j] and j > swing_index-10:
    down_series.append(j)
    j-=1

# 3. Confirmation = open أول شمعة في السلسلة (أقدم واحدة)
confirmation = open[down_series[-1]]

# 4. تحقق من الكنس: هل وِك كسر قاع سابق وأغلق فوقه؟
if low[swing] < prev_low and close[swing] > prev_low:
    sweep = True

# 5. تحقق من CISD: هل أغلق جسم فوق confirmation في 20 شمعة قادمة؟
for k in range(swing+1, swing+20):
    if close[k] > confirmation and close[k] > open[k]:
        protected = True
```

هذا ليس شرطاً ثابتاً، بل تتبع للسبب والنتيجة.

---

### 6. نتائج الاختبار السلوكي (إثبات عملي)

بنينا Sandbox يغذي الانجن بيانات مسمومة بمصايد:

- **Test Protected Low**: قاع 100.0 مع confirmation 108.0، إغلاق 108.2 فوقه، حجم 3000 = 200% spike
- النتيجة: ✅ PASS - Protected Low مع دفاع مؤسسي
- تقرير المحرك: "Protected Low at 100.00 index 5 - protected True conf 108.00 vol 3000 >1.5x avg"

هذا يثبت أن الخلية لا تنخدع كالبشر، بل تكتشف الفخ.

---

### 7. الخطوة التالية

القاع المحمي هو المحطة 1 فقط. المحطات القادمة:

- **المحطة 2: BOS الحقيقي** - يجب أن يكون مع Displacement و FVG، ليس مجرد كسر وِك [9]
- **المحطة 3: Discount Array** - كيف نقسم المسافة من القاع المحمي للقمة بفيبوناتشي ونحدد OTE 62-79% [6]
- **المحطة 4: التراجع لجمع الوقود** - السلوك الهادئ الذي يخدع البشر
- **المحطة 5: نقطة انطلاق الصاروخ** - FVG + OB غير ملموس

أنا جاهز لتفصيل المحطة الثانية بنفس العمق الممل عندما تعطيني إشارتك.

**المصادر المعتمدة:**
[1] ICT Swing Low Formation
[3][4] LuxAlgo Protected Swings (Sweep + CISD)
[6] ICT Swing High/Low Explained - reaction matters
[7] ICT Liquidity BSL/SSL definition
[FibAlgo] Equal H/L Tolerance 0.05%
