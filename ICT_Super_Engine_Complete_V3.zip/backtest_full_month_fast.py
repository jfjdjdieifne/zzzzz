import pandas as pd
import numpy as np
from engine.core.swing_detector import ProtectedSwingDetector
from engine.core.bos_detector import BOSDetector
from engine.core.orderblock_detector import OrderBlockDetector

df = pd.read_csv('/home/user/btcusdt_15m_last_month.csv')
df['timestamp'] = pd.to_datetime(df['timestamp'])
df = df.sort_values('timestamp').reset_index(drop=True)
print(f"Total 15M candles: {len(df)} from {df['timestamp'].iloc[0]} to {df['timestamp'].iloc[-1]}")

# Precompute swings once (fast)
swing_det = ProtectedSwingDetector(pivot_length=2)
swings_res = swing_det.analyze(df)
protected_lows_all = swings_res['protected_lows']
true_lows_all = swings_res['true_protected_lows']
print(f"Protected lows: {len(swings['protected_lows'])} True: {len(true_lows)} Ghost: {len(swings['ghost_lows'])}")

swing_sens = ProtectedSwingDetector(pivot_length=1)
swings_sens_res = swing_sens.analyze(df)
all_swings = swings_sens_res['all_swings']
print(f"Sensitive swings total: {len(all_swings)}")

# BOS balanced
class BalancedBOS(BOSDetector):
    def __init__(self):
        super().__init__()
        self.close_pos_thresh = 0.60
        self.disp_factor = 0.10
        self.upper_wick_thresh = 0.70
    def calculate_volume_bollinger(self, df, idx):
        start = max(0, idx-20)
        vol_mean = df['volume'].iloc[start:idx].mean() if idx>start else df['volume'].mean()
        curr = df['volume'].iloc[idx]
        is_outlier = curr > vol_mean*1.2
        return {'is_outlier': is_outlier, 'mean': vol_mean, 'upper_band': vol_mean*1.2, 'current': curr, 'ratio': curr/vol_mean if vol_mean>0 else 0}

bos_det = BalancedBOS()
bos_res = bos_det.analyze(df, all_swings)
print(f"BOS total signals: {bos_res['total']} valid: {len(bos_res['valid_bos'])} swept: {len(bos_res['liquidity_swept'])} suspended: {len(bos_res['suspended'])}")

# FVG and OB
ob_det = OrderBlockDetector()
fvgs = ob_det.detect_fvgs(df)
obs = ob_det.detect_bullish_obs(df, fvgs)
print(f"FVGs: {len(fvgs)} OBs: {len(obs)}")

# Now bar-by-bar simulation with precomputed signals filtered by index (no lookahead)
trades = []
logs = []
current_trade = None
state = "SEARCH_PROTECTED_LOW"
protected_low = None
bos_valid = None
buy_range = None

for i in range(50, len(df)-1):
    curr = df.iloc[i]
    nxt = df.iloc[i+1]
    
    # Manage live trade
    if current_trade:
        low = curr['low']
        high = curr['high']
        if low <= current_trade['stop_loss']:
            current_trade['exit_price'] = current_trade['stop_loss']
            current_trade['exit_time'] = curr['timestamp']
            current_trade['profit_usd'] = (current_trade['exit_price'] - current_trade['entry_price']) * current_trade['coins']
            current_trade['profit_pct'] = (current_trade['exit_price']/current_trade['entry_price']-1)*100
            current_trade['result'] = 'LOSS'
            current_trade['exit_reason'] = 'SL Hit - Protected Low broken'
            trades.append(current_trade)
            logs.append(f"[{curr['timestamp']}] EXIT SL Trade {current_trade['id']} Entry {current_trade['entry_price']:.2f} SL {current_trade['exit_price']:.2f} Loss {current_trade['profit_usd']:.2f}$")
            current_trade = None
            state = "SEARCH_PROTECTED_LOW"
            protected_low = None
            bos_valid = None
            continue
        if high >= current_trade['take_profit']:
            current_trade['exit_price'] = current_trade['take_profit']
            current_trade['exit_time'] = curr['timestamp']
            current_trade['profit_usd'] = (current_trade['exit_price'] - current_trade['entry_price']) * current_trade['coins']
            current_trade['profit_pct'] = (current_trade['exit_price']/current_trade['entry_price']-1)*100
            current_trade['result'] = 'WIN'
            current_trade['exit_reason'] = 'TP Hit - Termination Point'
            trades.append(current_trade)
            logs.append(f"[{curr['timestamp']}] EXIT TP Trade {current_trade['id']} Entry {current_trade['entry_price']:.2f} TP {current_trade['exit_price']:.2f} Profit {current_trade['profit_usd']:.2f}$")
            current_trade = None
            state = "SEARCH_PROTECTED_LOW"
            protected_low = None
            bos_valid = None
            continue
        continue
    
    # Not in trade
    # Station1: find most recent protected low with index <=i and within 150 bars and rejection>=1.0 and not ghost/trap
        recent_pl = [pl for pl in protected_lows if pl['index'] <= i and i - pl['index'] <= 150 and not pl['is_ghost'] and not pl['is_trap'] and pl['rejection_ratio'] and pl['rejection_ratio']>=1.0 and pl['protected']]
    if not recent_pl:
        # Try true protected
        recent_pl = [pl for pl in true_lows if pl['index'] <= i and i - pl['index'] <= 150]
    
    if not recent_pl:
        continue
    
    # Most recent
    pl = recent_pl[-1]
    
    if state == "SEARCH_PROTECTED_LOW":
        protected_low = pl
        state = "SEARCH_BOS"
        logs.append(f"[{curr['timestamp']}] Station1 Protected Low FOUND {pl['price']:.2f} idx {pl['index']} rej {pl['rejection_ratio']:.1f} -> SEARCH_BOS")
        continue
    
    if state == "SEARCH_BOS":
        # Find valid BOS after protected low and <=i and within 80 bars
        recent_bos = [b for b in bos_res['valid_bos'] if b['index'] <= i and b['index'] > protected_low['index'] and i - b['index'] <= 80]
        if not recent_bos:
            # If no valid BOS, check if protected low too old -> reset
            if i - protected_low['index'] > 150:
                state = "SEARCH_PROTECTED_LOW"
                protected_low = None
            continue
        
        bos_valid = recent_bos[-1]
        state = "SEARCH_DISCOUNT"
        logs.append(f"[{curr['timestamp']}] Station2 BOS Valid {bos_valid['price']:.2f} breaking {bos_valid['last_swing_price']:.2f} ClosePos {bos_valid['close_position']:.2f} -> SEARCH_DISCOUNT")
        continue
    
    if state == "SEARCH_DISCOUNT":
        # Calculate discount buy range 50-79% full OTE
        origin_idx = protected_low['index']
        origin_price = protected_low['price']
        term_price = df['high'].iloc[origin_idx:i+1].max()
        range_size = term_price - origin_price
        if range_size <=0:
            continue
        buy_low = term_price - range_size*0.79
        buy_high = term_price - range_size*0.50
        dynamic_eq = term_price - range_size*0.50  # simplified Eq = 50%
        
        # Check if current price in buy range
        if not (buy_low*0.995 <= curr['close'] <= buy_high*1.005 or buy_low <= curr['low'] <= buy_high):
            # If price went back to premium, reset?
            if curr['close'] > term_price - range_size*0.3:  # back to premium >70%
                # Still in discount? Actually if close > dynamic_eq + something, maybe wait
                pass
            # If price below origin (protected low broken), reset
            if curr['low'] < origin_price:
                logs.append(f"[{curr['timestamp']}] Station3 Discount: Price {curr['close']:.2f} broke Origin {origin_price:.2f} -> Reset to SEARCH_PROTECTED_LOW")
                state = "SEARCH_PROTECTED_LOW"
                protected_low = None
                bos_valid = None
            continue
        
        # Price in discount buy range
        state = "SEARCH_EXECUTION"
        buy_range = (buy_low, buy_high)
        logs.append(f"[{curr['timestamp']}] Station3 Discount: Price {curr['close']:.2f} in BuyRange {buy_low:.2f}-{buy_high:.2f} Eq {dynamic_eq:.2f} -> SEARCH_EXECUTION")
        continue
    
    if state == "SEARCH_EXECUTION":
        # Find OB and FVG near current price and in buy range, with index <=i and not mitigated and unmitigated and recent
        recent_fvgs = [f for f in fvgs if f.c1_idx <= i and not f.is_ghost and abs(f.low - curr['close']) < 200]  # near price
        recent_obs = [o for o in obs if o.index <= i and not o.is_mitigated]
        
        # Filter OBs in buy range
        valid_obs = []
        for ob in recent_obs:
            if buy_range[0] <= ob.low <= buy_range[1] or buy_range[0] <= ob.high <= buy_range[1] or (ob.low <= buy_range[1] and ob.high >= buy_range[0]):
                if i - ob.index <= 50:  # recent OB
                    valid_obs.append(ob)
        
        if not valid_obs or not recent_fvgs:
            continue
        
        # Find confluence
        found = None
        for ob in valid_obs[-2:]:  # last 2
            for fvg in recent_fvgs[-5:]:
                if abs(fvg.low - ob.high) < (ob.high-ob.low)*3:
                    # Check execution trigger at current candle
                    hl_range = curr['high']-curr['low']
                    if hl_range==0:
                        continue
                    lower_wick = min(curr['open'], curr['close']) - curr['low']
                    body = abs(curr['close']-curr['open'])
                    close_pos = (curr['close']-curr['low'])/hl_range
                    wick_rej = lower_wick > body*0.5 and close_pos>0.55
                    vol_mean = df['volume'].iloc[max(0,i-20):i].mean()
                    vol_spike = curr['volume'] > vol_mean*1.2
                    is_extreme_churn = body < hl_range*0.15 and curr['volume'] > vol_mean*2.5
                    
                    if (wick_rej or vol_spike) and not is_extreme_churn:
                        found = (ob,fvg)
                        break
            if found:
                break
        
        if not found:
            continue
        
        # Generate trade entry on next bar open
        ob, fvg = found
        entry_price = df.iloc[i+1]['open']
        stop_loss = protected_low['price'] - 0.01
        take_profit = term_price
        risk_pct = abs(entry_price-stop_loss)/entry_price*100
        
        total_balance=10000
        M=1.2
        allowed_loss= total_balance*0.01*M
        risk_dist= abs(entry_price-stop_loss)/entry_price
        spot_alloc= allowed_loss/risk_dist if risk_dist>0 else 0
        coins= spot_alloc/entry_price
        
        trade_id = len(trades)+1
        current_trade={
            'id': trade_id,
            'entry_index': i+1,
            'entry_time': df.iloc[i+1]['timestamp'],
            'entry_price': entry_price,
            'stop_loss': stop_loss,
            'take_profit': take_profit,
            'risk_pct': risk_pct,
            'coins': coins,
            'spot_allocation_usd': spot_alloc,
            'protected_low_price': protected_low['price'],
            'protected_low_idx': protected_low['index'],
            'protected_low_rejection': protected_low['rejection_ratio'],
            'bos_price': bos_valid['price'],
            'bos_breaking': bos_valid['last_swing_price'],
            'bos_close_pos': bos_valid['close_position'],
            'buy_range_low': buy_range[0],
            'buy_range_high': buy_range[1],
            'discount_eq': dynamic_eq if 'dynamic_eq' in locals() else buy_range[1],
            'ob_low': ob.low,
            'ob_high': ob.high,
            'fvg_low': fvg.low,
            'fvg_high': fvg.high,
            'fvg_ce': fvg.ce,
            'session': 'NY' if curr['timestamp'].hour in range(13,22) else 'London' if curr['timestamp'].hour in range(7,13) else 'Asian',
            'timeframe': '15M',
            'reason': f"Protected Low {protected_low['price']:.2f} rej {protected_low['rejection_ratio']:.1f} + BOS {bos_valid['price']:.2f} breaking {bos_valid['last_swing_price']:.2f} CP {bos_valid['close_position']:.2f} + Discount BuyRange 50-79% {buy_range[0]:.2f}-{buy_range[1]:.2f} Price {curr['close']:.2f} in range + OB {ob.low:.2f}-{ob.high:.2f} FVG {fvg.low:.2f}-{fvg.high:.2f} CE {fvg.ce:.2f} WickRej OR VolSpike"
        }
        logs.append(f"[{curr['timestamp']}] NEW TRADE {trade_id} Entry next {entry_price:.2f} SL {stop_loss:.2f} TP {take_profit:.2f} OB {ob.low:.2f}-{ob.high:.2f} FVG CE {fvg.ce:.2f} Session {current_trade['session']}")

# Final summary
print(f"\nTotal trades found (balanced, last 500? actually full month fast): {len(trades)} still in trade: {1 if current_trade else 0}")
total_pnl = sum([t.get('profit_usd',0) for t in trades])
wins = len([t for t in trades if t.get('result')=='WIN'])
losses = len([t for t in trades if t.get('result')=='LOSS'])
print(f"Closed trades: {len(trades)} Wins {wins} Losses {losses} PnL {total_pnl:.2f}$")

if trades:
    import pandas as pd
    df_trades = pd.DataFrame([{
        'id': t['id'],
        'entry_time': t['entry_time'],
        'entry_price': t['entry_price'],
        'exit_time': t.get('exit_time'),
        'exit_price': t.get('exit_price'),
        'stop_loss': t['stop_loss'],
        'take_profit': t['take_profit'],
        'profit_usd': t.get('profit_usd'),
        'profit_pct': t.get('profit_pct'),
        'result': t.get('result'),
        'risk_pct': t['risk_pct'],
        'coins': t['coins'],
        'allocation_usd': t['spot_allocation_usd'],
        'protected_low': t['protected_low_price'],
        'bos_price': t['bos_price'],
        'buy_range_low': t['buy_range_low'],
        'buy_range_high': t['buy_range_high'],
        'ob_low': t['ob_low'],
        'ob_high': t['ob_high'],
        'fvg_low': t['fvg_low'],
        'fvg_high': t['fvg_high'],
        'fvg_ce': t['fvg_ce'],
        'session': t['session'],
        'reason': t['reason']
    } for t in trades])
    df_trades.to_csv('/home/user/btcusdt_balanced_full_month_trades.csv', index=False)
    print("Saved to btcusdt_balanced_full_month_trades.csv")
    
    with open('/home/user/btcusdt_balanced_full_month_logs.txt','w') as f:
        for log in logs:
            f.write(log+'\n')
    print("Saved logs")

    for t in trades[:10]:
        print(f"\n--- Trade {t['id']} ---")
        print(f"Entry: {t['entry_time']} Price {t['entry_price']:.2f} Session {t['session']}")
        print(f"SL {t['stop_loss']:.2f} ({t['risk_pct']:.2f}%) TP {t['take_profit']:.2f}")
        if 'exit_time' in t:
            print(f"Exit: {t.get('exit_time')} Price {t.get('exit_price')} Result {t.get('result')} Profit {t.get('profit_usd'):.2f}$ ({t.get('profit_pct'):.2f}%)")
        print(f"PL {t['protected_low_price']:.2f} rej {t['protected_low_rejection']:.1f} BOS {t['bos_price']:.2f} breaking {t['bos_breaking']:.2f} CP {t['bos_close_pos']:.2f}")
        print(f"OB {t['ob_low']:.2f}-{t['ob_high']:.2f} FVG {t['fvg_low']:.2f}-{t['fvg_high']:.2f} CE {t['fvg_ce']:.2f}")
        print(f"Reason: {t['reason']}")
