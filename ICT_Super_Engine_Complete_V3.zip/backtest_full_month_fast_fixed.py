import pandas as pd
import numpy as np
from engine.core.swing_detector import ProtectedSwingDetector
from engine.core.bos_detector import BOSDetector
from engine.core.orderblock_detector import OrderBlockDetector

df = pd.read_csv('/home/user/btcusdt_15m_last_month.csv')
df['timestamp'] = pd.to_datetime(df['timestamp'])
df = df.sort_values('timestamp').reset_index(drop=True)
print(f"Total 15M candles: {len(df)}")

# Precompute once
swing_det = ProtectedSwingDetector(pivot_length=2)
swings_res = swing_det.analyze(df)
protected_lows_all = swings_res['protected_lows']
true_lows_all = swings_res['true_protected_lows']
print(f"Protected lows: {len(protected_lows_all)} True: {len(true_lows_all)}")

swing_sens = ProtectedSwingDetector(pivot_length=1)
swings_sens_res = swing_sens.analyze(df)
all_swings = swings_sens_res['all_swings']

class BalancedBOS(BOSDetector):
    def __init__(self):
        super().__init__()
        self.close_pos_thresh = 0.60
        self.disp_factor = 0.10
        self.upper_wick_thresh = 0.70
    def calculate_volume_bollinger(self, df, idx):
        start = max(0, idx-20)
        vol_mean = df['volume'].iloc[start:idx].mean() if idx>start else df['volume'].mean()
        curr = df['volume'].iloc[idx]
        is_outlier = curr > vol_mean*1.2
        return {'is_outlier': is_outlier, 'mean': vol_mean, 'upper_band': vol_mean*1.2, 'current': curr, 'ratio': curr/vol_mean if vol_mean>0 else 0}

bos_det = BalancedBOS()
bos_res = bos_det.analyze(df, all_swings)
print(f"BOS total: {bos_res['total']} valid: {len(bos_res['valid_bos'])}")

ob_det = OrderBlockDetector()
fvgs = ob_det.detect_fvgs(df)
obs = ob_det.detect_bullish_obs(df, fvgs)
print(f"FVGs: {len(fvgs)} OBs: {len(obs)}")

trades=[]
logs=[]
current_trade=None
state="SEARCH_PROTECTED_LOW"
protected_low=None
bos_valid=None
buy_range=None

for i in range(50, len(df)-1):
    curr = df.iloc[i]
    nxt = df.iloc[i+1]
    
    if current_trade:
        low = curr['low']
        high = curr['high']
        if low <= current_trade['stop_loss']:
            current_trade['exit_price'] = current_trade['stop_loss']
            current_trade['exit_time'] = curr['timestamp']
            current_trade['profit_usd'] = (current_trade['exit_price'] - current_trade['entry_price']) * current_trade['coins']
            current_trade['profit_pct'] = (current_trade['exit_price']/current_trade['entry_price']-1)*100
            current_trade['result'] = 'LOSS'
            trades.append(current_trade)
            logs.append(f"[{curr['timestamp']}] EXIT SL Trade {current_trade['id']}")
            current_trade=None
            state="SEARCH_PROTECTED_LOW"
            protected_low=None
            bos_valid=None
            continue
        if high >= current_trade['take_profit']:
            current_trade['exit_price'] = current_trade['take_profit']
            current_trade['exit_time'] = curr['timestamp']
            current_trade['profit_usd'] = (current_trade['exit_price'] - current_trade['entry_price']) * current_trade['coins']
            current_trade['profit_pct'] = (current_trade['exit_price']/current_trade['entry_price']-1)*100
            current_trade['result'] = 'WIN'
            trades.append(current_trade)
            logs.append(f"[{curr['timestamp']}] EXIT TP Trade {current_trade['id']}")
            current_trade=None
            state="SEARCH_PROTECTED_LOW"
            protected_low=None
            bos_valid=None
            continue
        continue
    
    # Find recent protected low
    recent_pl = [pl for pl in protected_lows_all if pl['index'] <= i and i - pl['index'] <= 150 and not pl['is_ghost'] and not pl['is_trap'] and pl['rejection_ratio'] and pl['rejection_ratio']>=1.0 and pl['protected']]
    if not recent_pl:
        recent_pl = [pl for pl in true_lows_all if pl['index'] <= i and i - pl['index'] <= 150]
    if not recent_pl:
        continue
    pl = recent_pl[-1]
    
    if state=="SEARCH_PROTECTED_LOW":
        protected_low=pl
        state="SEARCH_BOS"
        continue
    
    if state=="SEARCH_BOS":
        recent_bos = [b for b in bos_res['valid_bos'] if b['index'] <= i and b['index'] > protected_low['index'] and i - b['index'] <= 80]
        if not recent_bos:
            if i - protected_low['index'] > 150:
                state="SEARCH_PROTECTED_LOW"
                protected_low=None
            continue
        bos_valid=recent_bos[-1]
        state="SEARCH_DISCOUNT"
        continue
    
    if state=="SEARCH_DISCOUNT":
        origin_idx=protected_low['index']
        origin_price=protected_low['price']
        term_price=df['high'].iloc[origin_idx:i+1].max()
        range_size=term_price-origin_price
        if range_size<=0:
            continue
        buy_low=term_price - range_size*0.79
        buy_high=term_price - range_size*0.50
        if not (buy_low*0.995 <= curr['close'] <= buy_high*1.005 or buy_low <= curr['low'] <= buy_high):
            if curr['low'] < origin_price:
                state="SEARCH_PROTECTED_LOW"
                protected_low=None
                bos_valid=None
            continue
        state="SEARCH_EXECUTION"
        buy_range=(buy_low,buy_high)
        continue
    
    if state=="SEARCH_EXECUTION":
        recent_fvgs=[f for f in fvgs if f.c1_idx <= i and not f.is_ghost]
        recent_obs=[o for o in obs if o.index <= i and not o.is_mitigated]
        valid_obs=[ob for ob in recent_obs if buy_range[0] <= ob.low <= buy_range[1] or buy_range[0] <= ob.high <= buy_range[1] or (ob.low <= buy_range[1] and ob.high >= buy_range[0])]
        if not valid_obs or not recent_fvgs:
            continue
        found=None
        for ob in valid_obs[-2:]:
            for fvg in recent_fvgs[-5:]:
                if abs(fvg.low - ob.high) < (ob.high-ob.low)*3:
                    hl_range=curr['high']-curr['low']
                    if hl_range==0:
                        continue
                    lower_wick=min(curr['open'],curr['close'])-curr['low']
                    body=abs(curr['close']-curr['open'])
                    close_pos=(curr['close']-curr['low'])/hl_range
                    wick_rej=lower_wick>body*0.5 and close_pos>0.55
                    vol_mean=df['volume'].iloc[max(0,i-20):i].mean()
                    vol_spike=curr['volume']>vol_mean*1.2
                    is_extreme_churn=body < hl_range*0.15 and curr['volume']>vol_mean*2.5
                    if (wick_rej or vol_spike) and not is_extreme_churn:
                        found=(ob,fvg)
                        break
            if found:
                break
        if not found:
            continue
        ob,fvg=found
        entry_price=df.iloc[i+1]['open']
        stop_loss=protected_low['price']-0.01
        take_profit=term_price
        total_balance=10000
        M=1.2
        allowed_loss=total_balance*0.01*M
        risk_dist=abs(entry_price-stop_loss)/entry_price
        spot_alloc=allowed_loss/risk_dist if risk_dist>0 else 0
        coins=spot_alloc/entry_price
        trade_id=len(trades)+1
        current_trade={
            'id': trade_id,
            'entry_index': i+1,
            'entry_time': df.iloc[i+1]['timestamp'],
            'entry_price': entry_price,
            'stop_loss': stop_loss,
            'take_profit': take_profit,
            'coins': coins,
            'spot_allocation_usd': spot_alloc,
            'protected_low_price': protected_low['price'],
            'protected_low_idx': protected_low['index'],
            'protected_low_rejection': protected_low['rejection_ratio'],
            'bos_price': bos_valid['price'],
            'bos_breaking': bos_valid['last_swing_price'],
            'buy_range_low': buy_range[0],
            'buy_range_high': buy_range[1],
            'ob_low': ob.low,
            'ob_high': ob.high,
            'fvg_low': fvg.low,
            'fvg_high': fvg.high,
            'fvg_ce': fvg.ce,
        }
        logs.append(f"[{curr['timestamp']}] NEW TRADE {trade_id} Entry {entry_price:.2f} SL {stop_loss:.2f} TP {take_profit:.2f}")

print(f"\nTotal trades found: {len(trades)} still in trade: {1 if current_trade else 0}")
for t in trades[:10]:
    print(f"Trade {t['id']} Entry {t['entry_time']} Price {t['entry_price']:.2f} SL {t['stop_loss']:.2f} TP {t['take_profit']:.2f} PL {t['protected_low_price']:.2f} BOS {t['bos_price']:.2f}")

# Save
if trades:
    import pandas as pd
    pd.DataFrame(trades).to_csv('/home/user/btcusdt_balanced_full_month_trades.csv', index=False)
    print("Saved trades")
