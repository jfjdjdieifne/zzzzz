import pandas as pd
from engine.core.swing_detector import ProtectedSwingDetector
from engine.core.bos_detector import BOSDetector
from engine.core.discount_detector import DiscountDetector
from engine.core.orderblock_detector import OrderBlockDetector

df_1h = pd.read_csv('/home/user/btcusdt_1h_last_month.csv')
df_1h['timestamp'] = pd.to_datetime(df_1h['timestamp'])
df_1h = df_1h.sort_values('timestamp').reset_index(drop=True)

print(f"1H candles: {len(df_1h)} from {df_1h['timestamp'].iloc[0]} to {df_1h['timestamp'].iloc[-1]}")

trades_detailed = []
logs_all = []
current_trade = None
trade_id = 0

for i in range(30, len(df_1h)-1):
    past_1h = df_1h.iloc[:i+1].copy()
    current_candle = df_1h.iloc[i]
    next_candle = df_1h.iloc[i+1]
    current_time = current_candle['timestamp']
    
    # Manage live trade
    if current_trade is not None:
        low = current_candle['low']
        high = current_candle['high']
        if low <= current_trade['stop_loss']:
            exit_price = current_trade['stop_loss']
            profit_usd = (exit_price - current_trade['entry_price']) * current_trade['coins']
            profit_pct = (exit_price / current_trade['entry_price'] -1)*100
            current_trade['exit_price'] = exit_price
            current_trade['exit_time'] = current_time
            current_trade['exit_reason'] = 'STOP_LOSS_HIT - Protected Low broken'
            current_trade['profit_usd'] = profit_usd
            current_trade['profit_pct'] = profit_pct
            current_trade['result'] = 'LOSS'
            trades_detailed.append(current_trade)
            logs_all.append(f"[{current_time}] Trade {current_trade['id']} EXIT SL Hit: Entry {current_trade['entry_price']:.2f} SL {exit_price:.2f} Loss {profit_usd:.2f}$")
            current_trade = None
            continue
        if high >= current_trade['take_profit']:
            exit_price = current_trade['take_profit']
            profit_usd = (exit_price - current_trade['entry_price']) * current_trade['coins']
            profit_pct = (exit_price / current_trade['entry_price'] -1)*100
            current_trade['exit_price'] = exit_price
            current_trade['exit_time'] = current_time
            current_trade['exit_reason'] = 'TAKE_PROFIT_HIT - Termination Point'
            current_trade['profit_usd'] = profit_usd
            current_trade['profit_pct'] = profit_pct
            current_trade['result'] = 'WIN'
            trades_detailed.append(current_trade)
            logs_all.append(f"[{current_time}] Trade {current_trade['id']} EXIT TP Hit: Entry {current_trade['entry_price']:.2f} TP {exit_price:.2f} Profit {profit_usd:.2f}$")
            current_trade = None
            continue
        continue
    
    # Not in trade - look for entry
    # Station1
    swing_det = ProtectedSwingDetector(pivot_length=3)
    swings_res = swing_det.analyze(past_1h)
    true_lows = swings_res['true_protected_lows']
    if not true_lows:
        continue
    protected_low = true_lows[-1]
    if i - protected_low['index'] > 60:
        continue
    
    # Station2 BOS
    swing_sens = ProtectedSwingDetector(pivot_length=1)
    swings_sens = swing_sens.analyze(past_1h)
    bos_det = BOSDetector()
    bos_res = bos_det.analyze(past_1h, swings_sens['all_swings'])
    if not bos_res['valid_bos']:
        continue
    bos_valid = bos_res['valid_bos'][-1]
    if bos_valid['index'] <= protected_low['index']:
        continue
    if i - bos_valid['index'] > 30:
        continue
    
    # Station3 Discount
    origin_idx = protected_low['index']
    origin_price = protected_low['price']
    term_idx = bos_valid['index']
    term_price = past_1h['high'].iloc[origin_idx:term_idx+1].max()
    
    discount_det = DiscountDetector()
    try:
        disc_sig = discount_det.analyze(past_1h, origin_idx, origin_price, term_idx, term_price, current_idx=i, current_price=current_candle['close'])
    except:
        continue
    
    if 'Price_In_Premium' in disc_sig.cognitive_state['Current_State']:
        continue
    if disc_sig.is_bleeding_trap or disc_sig.is_induced_trap:
        continue
    
    buy_low, buy_high = disc_sig.recommended_buy_range
    if not (buy_low <= current_candle['close'] <= buy_high or buy_low <= current_candle['low'] <= buy_high):
        if abs(current_candle['close'] - buy_high)/buy_high > 0.005:
            continue
    
    # Station4 OB/FVG
    ob_det = OrderBlockDetector()
    fvgs = ob_det.detect_fvgs(past_1h)
    obs = ob_det.detect_bullish_obs(past_1h, fvgs)
    if not obs:
        continue
    
    valid_exec = None
    for ob in obs:
        if ob.is_mitigated:
            continue
        if not (buy_low <= ob.low <= buy_high or buy_low <= ob.high <= buy_high):
            if not (ob.low <= buy_high and ob.high >= buy_low):
                continue
        for fvg in fvgs:
            if fvg.is_ghost:
                continue
            if abs(fvg.low - ob.high) < (ob.high - ob.low)*2:
                hl_range = current_candle['high'] - current_candle['low']
                if hl_range==0:
                    continue
                lower_wick = min(current_candle['open'], current_candle['close']) - current_candle['low']
                body = abs(current_candle['close'] - current_candle['open'])
                close_pos = (current_candle['close'] - current_candle['low'])/hl_range
                wick_rejection = lower_wick > body*0.8 and close_pos>0.6
                vol_mean = past_1h['volume'].iloc[max(0,i-20):i].mean()
                is_vol_spike = current_candle['volume'] > vol_mean*1.5
                if wick_rejection and is_vol_spike:
                    valid_exec = (ob,fvg)
                    break
        if valid_exec:
            break
    
    if not valid_exec:
        continue
    
    # Generate trade - entry on next bar open (no lookahead)
    entry_price = next_candle['open']
    stop_loss = protected_low['price'] - 0.01
    take_profit = term_price
    risk_pct = abs(entry_price - stop_loss)/entry_price*100
    total_balance=10000
    base_risk=1.0
    M=1.5
    allowed_loss= total_balance*(base_risk/100*M)
    risk_distance= abs(entry_price-stop_loss)/entry_price
    spot_alloc = allowed_loss / risk_distance if risk_distance>0 else 0
    coins = spot_alloc / entry_price if entry_price>0 else 0
    
    trade_id+=1
    current_trade={
        'id': trade_id,
        'entry_index': i+1,
        'entry_time': next_candle['timestamp'],
        'entry_price': entry_price,
        'stop_loss': stop_loss,
        'take_profit': take_profit,
        'risk_pct': risk_pct,
        'coins': coins,
        'spot_allocation_usd': spot_alloc,
        'allowed_loss_usd': allowed_loss,
        'confluence_multiplier': M,
        'protected_low': protected_low,
        'bos': bos_valid,
        'discount_eq': disc_sig.dynamic_equilibrium,
        'buy_range': disc_sig.recommended_buy_range,
        'ob': valid_exec[0],
        'fvg': valid_exec[1],
        'reason': f"Protected Low {protected_low['price']:.2f} + BOS {bos_valid['price']:.2f} breaking {bos_valid['last_swing_price']:.2f} ClosePos {bos_valid['close_position']:.2f} + Discount Eq {disc_sig.dynamic_equilibrium:.2f} BuyRange {disc_sig.recommended_buy_range} + OB {valid_exec[0].low:.2f}-{valid_exec[0].high:.2f} FVG CE {valid_exec[1].ce:.2f} Wick Rejection + Vol Spike",
        'session': 'NY' if current_candle['timestamp'].hour in range(13,22) else 'London' if current_candle['timestamp'].hour in range(7,13) else 'Asian',
        'timeframe': '1H',
        'htf_context': f"4H SSL {disc_sig.discount_zone[0]:.2f} BSL {disc_sig.premium_zone[1]:.2f}"
    }
    logs_all.append(f"[{current_candle['timestamp']}] NEW TRADE {trade_id} SIGNAL: Entry next bar {entry_price:.2f} SL {stop_loss:.2f} ({risk_pct:.2f}%) TP {take_profit:.2f} OB {current_trade['ob']['low']:.2f}-{current_trade['ob']['high']:.2f} FVG CE {current_trade['fvg']['ce']:.2f}")

# Summary
print(f"\nTotal trades: {len(trades_detailed)}")
total_pnl = sum(t['profit_usd'] for t in trades_detailed)
wins = len([t for t in trades_detailed if t['result']=='WIN'])
losses = len([t for t in trades_detailed if t['result']=='LOSS'])
win_rate = wins/len(trades_detailed)*100 if trades_detailed else 0
print(f"Wins {wins} Losses {losses} WinRate {win_rate:.1f}% PnL {total_pnl:.2f}$")

if trades_detailed:
    import pandas as pd
    df_trades = pd.DataFrame([{
        'id': t['id'],
        'entry_time': t['entry_time'],
        'entry_price': t['entry_price'],
        'exit_time': t.get('exit_time'),
        'exit_price': t.get('exit_price'),
        'stop_loss': t['stop_loss'],
        'take_profit': t['take_profit'],
        'profit_usd': t.get('profit_usd'),
        'profit_pct': t.get('profit_pct'),
        'result': t.get('result'),
        'risk_pct': t['risk_pct'],
        'coins': t['coins'],
        'allocation_usd': t['spot_allocation_usd'],
        'protected_low': t['protected_low']['price'],
        'bos_price': t['bos']['price'],
        'discount_eq': t['discount_eq'],
        'buy_range_low': t['buy_range'][0],
        'buy_range_high': t['buy_range'][1],
        'ob_low': t['ob']['low'],
        'ob_high': t['ob']['high'],
        'fvg_low': t['fvg']['low'],
        'fvg_high': t['fvg']['high'],
        'fvg_ce': t['fvg']['ce'],
        'session': t['session'],
        'timeframe': t['timeframe'],
        'reason': t['reason']
    } for t in trades_detailed])
    df_trades.to_csv('/home/user/btcusdt_trades_1h_detailed.csv', index=False)
    print("Saved trades to btcusdt_trades_1h_detailed.csv")
    with open('/home/user/btcusdt_backtest_1h_logs.txt','w') as f:
        for log in logs_all:
            f.write(log+'\n')
    print("Saved logs")

    for t in trades_detailed:
        print(f"\n--- Trade {t['id']} ---")
        print(f"Entry: {t['entry_time']} Price {t['entry_price']:.2f} Session {t['session']} TF {t['timeframe']}")
        print(f"SL: {t['stop_loss']:.2f} ({t['risk_pct']:.2f}%) TP: {t['take_profit']:.2f}")
        print(f"Exit: {t.get('exit_time')} Price {t.get('exit_price')} Reason {t.get('exit_reason')} Result {t.get('result')} Profit {t.get('profit_usd'):.2f}$ ({t.get('profit_pct'):.2f}%)")
        print(f"Coins: {t['coins']:.4f} Alloc ${t['spot_allocation_usd']:.2f} M {t['confluence_multiplier']}")
        print(f"Protected Low {t['protected_low']['price']:.2f} idx {t['protected_low']['index']} BOS {t['bos']['price']:.2f} breaking {t['bos']['last_swing_price']:.2f} CE {t['fvg']['ce']:.2f}")
        print(f"Reason: {t['reason']}")
