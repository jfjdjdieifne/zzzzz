import pandas as pd
from engine.core.swing_detector import ProtectedSwingDetector
from engine.core.bos_detector import BOSDetector

df = pd.read_csv('/home/user/btcusdt_15m_last_month.csv')
df['timestamp'] = pd.to_datetime(df['timestamp'])

# Relaxed BOS detector: lower thresholds
class RelaxedBOSDetector(BOSDetector):
    def __init__(self):
        super().__init__(atr_period=14, volume_lookback=20)
        self.close_pos_thresh = 0.60  # was 0.75
        self.disp_factor = 0.10  # was 0.2
    
    def calculate_volume_bollinger(self, df, idx):
        # Lower threshold: mean*1.2 instead of mean+2std
        start = max(0, idx-20)
        vol_mean = df['volume'].iloc[start:idx].mean() if idx>start else df['volume'].mean()
        current_vol = df['volume'].iloc[idx]
        is_outlier = current_vol > vol_mean*1.2
        return {'is_outlier': is_outlier, 'mean': vol_mean, 'upper_band': vol_mean*1.2, 'current': current_vol, 'ratio': current_vol/vol_mean if vol_mean>0 else 0}

trades=[]
logs=[]

for i in range(30, len(df)-1):
    past = df.iloc[:i+1]
    curr = df.iloc[i]
    nxt = df.iloc[i+1]
    
    # Protected low with sensitive pivot 1
    swing_det = ProtectedSwingDetector(pivot_length=1)
    swings = swing_det.analyze(past)
    # Use protected_lows not true_protected_lows for relaxed
    protected_lows = swings['protected_lows']
    if not protected_lows:
        continue
    protected_low = protected_lows[-1]
    if i - protected_low['index'] > 80:
        continue
    
    # BOS relaxed
    swings_sens = swing_det.analyze(past)
    bos_det = RelaxedBOSDetector()
    bos_res = bos_det.analyze(past, swings_sens['all_swings'])
    if not bos_res['valid_bos']:
        continue
    bos_valid = bos_res['valid_bos'][-1]
    if bos_valid['index'] <= protected_low['index']:
        continue
    
    # Simple discount: price must be below median
    origin_price = protected_low['price']
    term_price = past['high'].iloc[protected_low['index']:].max()
    median = (origin_price + term_price)/2
    if curr['close'] > median:
        continue
    
    # Simple OB/FVG: look for bullish engulfing near discount
    # Find last bearish candle
    if i>=2:
        c1 = past.iloc[i-2]
        c2 = past.iloc[i-1]
        c3 = past.iloc[i]
        # FVG bullish? High C1 < Low C3
        if c1['high'] < c3['low']:
            # OB: last bearish before bullish displacement
            # Check if c2 bearish and c3 bullish engulf
            if c2['close'] < c2['open'] and c3['close'] > c3['open'] and c3['close'] > c2['high']:
                # Valid setup
                entry_price = nxt['open']
                stop_loss = protected_low['price'] - 0.01
                take_profit = term_price
                risk_pct = abs(entry_price-stop_loss)/entry_price*100
                
                trade = {
                    'id': len(trades)+1,
                    'entry_time': nxt['timestamp'],
                    'entry_price': entry_price,
                    'stop_loss': stop_loss,
                    'take_profit': take_profit,
                    'risk_pct': risk_pct,
                    'protected_low_price': protected_low['price'],
                    'protected_low_idx': protected_low['index'],
                    'bos_price': bos_valid['price'],
                    'bos_breaking': bos_valid['last_swing_price'],
                    'fvg_low': c1['high'],
                    'fvg_high': c3['low'],
                    'fvg_ce': (c1['high']+c3['low'])/2,
                    'ob_low': c2['low'],
                    'ob_high': c2['high'],
                    'close_pos': bos_valid['close_position'],
                    'volume_ratio': bos_valid['volume_outlier'],
                    'session': 'NY' if curr['timestamp'].hour in range(13,22) else 'London' if curr['timestamp'].hour in range(7,13) else 'Asian',
                    'reason': f"Relaxed: Protected Low {protected_low['price']:.2f} + BOS {bos_valid['price']:.2f} breaking {bos_valid['last_swing_price']:.2f} ClosePos {bos_valid['close_position']:.2f} + Discount price {curr['close']:.2f} < median {median:.2f} + OB {c2['low']:.2f}-{c2['high']:.2f} + FVG {c1['high']:.2f}-{c3['low']:.2f} CE {(c1['high']+c3['low'])/2:.2f}"
                }
                trades.append(trade)
                logs.append(f"[{curr['timestamp']}] Trade {trade['id']} Entry next {entry_price:.2f} SL {stop_loss:.2f} TP {take_profit:.2f} OB {c2['low']:.2f}-{c2['high']:.2f} FVG {c1['high']:.2f}-{c3['low']:.2f}")

print(f"Relaxed trades found: {len(trades)}")
for t in trades[:10]:
    print(f"\n--- Trade {t['id']} ---")
    print(f"Entry Time: {t['entry_time']} Price {t['entry_price']:.2f} Session {t['session']}")
    print(f"SL {t['stop_loss']:.2f} ({t['risk_pct']:.2f}%) TP {t['take_profit']:.2f}")
    print(f"Protected Low {t['protected_low_price']:.2f} idx {t['protected_low_idx']} BOS {t['bos_price']:.2f} breaking {t['bos_breaking']:.2f} ClosePos {t['close_pos']:.2f}")
    print(f"OB {t['ob_low']:.2f}-{t['ob_high']:.2f} FVG {t['fvg_low']:.2f}-{t['fvg_high']:.2f} CE {t['fvg_ce']:.2f}")
    print(f"Reason: {t['reason']}")

if trades:
    pd.DataFrame(trades).to_csv('/home/user/btcusdt_relaxed_trades.csv', index=False)
