import pandas as pd
import numpy as np
from engine.core.swing_detector import ProtectedSwingDetector
from engine.core.bos_detector import BOSDetector
from engine.core.orderblock_detector import OrderBlockDetector

df = pd.read_csv('/home/user/btcusdt_15m_last_month.csv')
df['timestamp'] = pd.to_datetime(df['timestamp'])
df = df.sort_values('timestamp').reset_index(drop=True)
print(f"Total 15M: {len(df)}")

# Precompute once
swing_det = ProtectedSwingDetector(pivot_length=2)
swings_res = swing_det.analyze(df)
protected_lows_all = swings_res['protected_lows']
true_lows_all = swings_res['true_protected_lows']
print(f"Protected: {len(protected_lows_all)} True: {len(true_lows_all)}")

swing_sens = ProtectedSwingDetector(pivot_length=1)
swings_sens_res = swing_sens.analyze(df)
all_swings = swings_sens_res['all_swings']
print(f"Sensitive swings: {len(all_swings)}")

class BalancedBOS(BOSDetector):
    def __init__(self):
        super().__init__()
        self.close_pos_thresh = 0.60
        self.disp_factor = 0.10
        self.upper_wick_thresh = 0.70
    def calculate_volume_bollinger(self, df, idx):
        start = max(0, idx-20)
        vol_mean = df['volume'].iloc[start:idx].mean() if idx>start else df['volume'].mean()
        curr = df['volume'].iloc[idx]
        is_outlier = curr > vol_mean*1.2
        return {'is_outlier': is_outlier, 'mean': vol_mean, 'upper_band': vol_mean*1.2, 'current': curr, 'ratio': curr/vol_mean if vol_mean>0 else 0}

bos_det = BalancedBOS()
bos_res = bos_det.analyze(df, all_swings)
print(f"BOS total: {bos_res['total']} valid: {len(bos_res['valid_bos'])}")

ob_det = OrderBlockDetector()
fvgs = ob_det.detect_fvgs(df)
obs = ob_det.detect_bullish_obs(df, fvgs)
print(f"FVGs: {len(fvgs)} OBs: {len(obs)}")

trades=[]
current_trade=None

for i in range(50, len(df)-1):
    curr = df.iloc[i]
    nxt = df.iloc[i+1]
    
    if current_trade:
        if curr['low'] <= current_trade['stop_loss']:
            current_trade['exit_price'] = current_trade['stop_loss']
            current_trade['exit_time'] = curr['timestamp']
            current_trade['profit_usd'] = (current_trade['exit_price'] - current_trade['entry_price']) * current_trade['coins']
            current_trade['profit_pct'] = (current_trade['exit_price']/current_trade['entry_price']-1)*100
            current_trade['result'] = 'LOSS'
            trades.append(current_trade)
            current_trade=None
            continue
        if curr['high'] >= current_trade['take_profit']:
            current_trade['exit_price'] = current_trade['take_profit']
            current_trade['exit_time'] = curr['timestamp']
            current_trade['profit_usd'] = (current_trade['exit_price'] - current_trade['entry_price']) * current_trade['coins']
            current_trade['profit_pct'] = (current_trade['exit_price']/current_trade['entry_price']-1)*100
            current_trade['result'] = 'WIN'
            trades.append(current_trade)
            current_trade=None
            continue
        continue
    
    # Find recent protected low within 150
    recent_pl = [pl for pl in protected_lows_all if pl['index'] <= i and i - pl['index'] <= 150 and not pl['is_ghost'] and not pl['is_trap'] and pl['rejection_ratio'] and pl['rejection_ratio']>=1.0 and pl['protected']]
    if not recent_pl:
        recent_pl = [pl for pl in true_lows_all if pl['index'] <= i and i - pl['index'] <= 150]
    if not recent_pl:
        continue
    pl = recent_pl[-1]
    
    # Find BOS after PL within 80
    recent_bos = [b for b in bos_res['valid_bos'] if b['index'] <= i and b['index'] > pl['index'] and i - b['index'] <= 80]
    if not recent_bos:
        continue
    bos_valid = recent_bos[-1]
    
    # Discount: deep OTE 70.5-79% only for RR>2
    origin_idx = pl['index']
    origin_price = pl['price']
    term_price = df['high'].iloc[origin_idx:i+1].max()
    range_size = term_price - origin_price
    if range_size <=0:
        continue
    buy_low = term_price - range_size*0.79
    buy_high = term_price - range_size*0.705
    
    # Strictly inside buy range (no buffer)
    if not (buy_low <= curr['close'] <= buy_high):
        continue
    
    # OB/FVG confluence near current price
    recent_fvgs = [f for f in fvgs if f.c1_idx <= i and not f.is_ghost]
    recent_obs = [o for o in obs if o.index <= i and not o.is_mitigated]
    
    valid_obs = [ob for ob in recent_obs if buy_low <= ob.low <= buy_high or buy_low <= ob.high <= buy_high or (ob.low <= buy_high and ob.high >= buy_low)]
    if not valid_obs:
        continue
    
    found=None
    for ob in valid_obs[-2:]:
        for fvg in recent_fvgs[-5:]:
            if abs(fvg.low - ob.high) < (ob.high-ob.low)*3:
                hl_range = curr['high']-curr['low']
                if hl_range==0:
                    continue
                lower_wick = min(curr['open'], curr['close']) - curr['low']
                body = abs(curr['close']-curr['open'])
                close_pos = (curr['close']-curr['low'])/hl_range
                wick_rej = lower_wick > body*0.5 and close_pos>0.55
                vol_mean = df['volume'].iloc[max(0,i-20):i].mean()
                vol_spike = curr['volume'] > vol_mean*1.2
                is_extreme_churn = body < hl_range*0.15 and curr['volume'] > vol_mean*2.5
                if (wick_rej or vol_spike) and not is_extreme_churn:
                    found=(ob,fvg)
                    break
        if found:
            break
    
    if not found:
        continue
    
    ob,fvg = found
    entry_price = df.iloc[i+1]['open']
    stop_loss = pl['price'] - 0.01
    
    # FIXED TP: beyond term using extension 0.27 and 0.62 per ICT
    tp_standard = term_price + range_size*0.27
    tp_deep = term_price + range_size*0.62
    take_profit = tp_standard  # use standard for RR>1.5 minimum
    
    risk = abs(entry_price - stop_loss)
    reward = abs(take_profit - entry_price)
    rr = reward / risk if risk>0 else 0
    
    # Enforce RR >=1.5
    if rr < 1.5:
        take_profit = tp_deep
        reward = abs(take_profit - entry_price)
        rr = reward / risk if risk>0 else 0
        if rr < 1.5:
            continue
    
    # Position sizing
    total_balance=10000
    M=1.5
    allowed_loss=total_balance*0.01*M
    risk_dist=abs(entry_price-stop_loss)/entry_price
    spot_alloc=allowed_loss/risk_dist if risk_dist>0 else 0
    coins=spot_alloc/entry_price
    
    current_trade={
        'id': len(trades)+1,
        'entry_index': i+1,
        'entry_time': df.iloc[i+1]['timestamp'],
        'entry_price': entry_price,
        'stop_loss': stop_loss,
        'take_profit': take_profit,
        'take_profit_deep': tp_deep,
        'risk': risk,
        'reward': reward,
        'rr': rr,
        'coins': coins,
        'spot_allocation_usd': spot_alloc,
        'protected_low_price': pl['price'],
        'protected_low_idx': pl['index'],
        'bos_price': bos_valid['price'],
        'buy_range_low': buy_low,
        'buy_range_high': buy_high,
        'ob_low': ob.low,
        'ob_high': ob.high,
        'fvg_low': fvg.low,
        'fvg_high': fvg.high,
        'fvg_ce': fvg.ce,
        'range_size': range_size,
        'term_price': term_price,
    }

print(f"\nTotal trades found with RR>=1.5: {len(trades)}")
for t in trades[:10]:
    print(f"\nTrade {t['id']} Entry {t['entry_time']} Price {t['entry_price']:.2f} SL {t['stop_loss']:.2f} TP {t['take_profit']:.2f} Deep {t['take_profit_deep']:.2f} RR {t['rr']:.2f}")
    print(f"  PL {t['protected_low_price']:.2f} BOS {t['bos_price']:.2f} Range {t['range_size']:.2f} Buy {t['buy_range_low']:.2f}-{t['buy_range_high']:.2f} OB {t['ob_low']:.2f}-{t['ob_high']:.2f} FVG CE {t['fvg_ce']:.2f}")
    # Simulate exit quickly
    future = df[df['timestamp'] > t['entry_time']].head(100)
    for _, row in future.iterrows():
        if row['low'] <= t['stop_loss']:
            print(f"  -> SL Hit at {row['timestamp']} WIN? LOSS RR {t['rr']:.2f}")
            break
        if row['high'] >= t['take_profit']:
            print(f"  -> TP Hit at {row['timestamp']} WIN RR {t['rr']:.2f}")
            break

# Save
if trades:
    pd.DataFrame(trades).to_csv('/home/user/btcusdt_rr_fixed_trades.csv', index=False)
    print("\nSaved to btcusdt_rr_fixed_trades.csv")
