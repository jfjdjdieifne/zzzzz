import pandas as pd
from engine.core.swing_detector import ProtectedSwingDetector
from engine.core.bos_detector import BOSDetector

df = pd.read_csv('/home/user/btcusdt_15m_last_month.csv')
df['timestamp'] = pd.to_datetime(df['timestamp'])

print(f"Total 15M candles: {len(df)}")

# Stage counts
stage_counts = {
    'protected_lows': 0,
    'protected_lows_true': 0,
    'bos_valid_strict': 0,
    'bos_valid_relaxed': 0,
    'discount_entered': 0,
    'fvg_found': 0,
    'ob_found': 0,
    'execution_trigger': 0
}

# For each bar, track
for i in range(50, len(df)):
    past = df.iloc[:i+1]
    
    # Station1
    swing_det = ProtectedSwingDetector(pivot_length=2)
    swings = swing_det.analyze(past)
    if swings['protected_lows']:
        stage_counts['protected_lows'] += 1
    if swings['true_protected_lows']:
        stage_counts['protected_lows_true'] += 1
    
    # Station2 strict BOS
    swing_sens = ProtectedSwingDetector(pivot_length=1)
    swings_sens = swing_sens.analyze(past)
    bos_det_strict = BOSDetector()
    bos_res_strict = bos_det_strict.analyze(past, swings_sens['all_swings'])
    if bos_res_strict['valid_bos']:
        stage_counts['bos_valid_strict'] += 1
    
    # Relaxed BOS
    class RelaxedBOS(BOSDetector):
        def __init__(self):
            super().__init__()
            self.close_pos_thresh = 0.60
            self.disp_factor = 0.10
        def calculate_volume_bollinger(self, df, idx):
            start = max(0, idx-20)
            vol_mean = df['volume'].iloc[start:idx].mean() if idx>start else df['volume'].mean()
            curr = df['volume'].iloc[idx]
            is_outlier = curr > vol_mean*1.5
            return {'is_outlier': is_outlier, 'mean': vol_mean, 'upper_band': vol_mean*1.5, 'current': curr, 'ratio': curr/vol_mean if vol_mean>0 else 0}
    
    bos_relaxed = RelaxedBOS()
    bos_res_relaxed = bos_relaxed.analyze(past, swings_sens['all_swings'])
    if bos_res_relaxed['valid_bos']:
        stage_counts['bos_valid_relaxed'] += 1

print("Stage counts (how many bars had at least one signal):")
for k,v in stage_counts.items():
    print(f"  {k}: {v} bars ({v/len(df)*100:.1f}%)")

# Detailed analysis of why BOS strict fails vs relaxed
# Let's check last 100 bars for BOS details
print("\n--- BOS Strict vs Relaxed comparison last 100 bars ---")
for i in range(len(df)-100, len(df)):
    past = df.iloc[:i+1]
    swing_sens = ProtectedSwingDetector(pivot_length=1)
    swings_sens = swing_sens.analyze(past)
    
    bos_strict = BOSDetector()
    bos_relaxed = RelaxedBOS()
    
    res_strict = bos_strict.analyze(past, swings_sens['all_swings'])
    res_relaxed = bos_relaxed.analyze(past, swings_sens['all_swings'])
    
    if res_relaxed['all_signals'] and not res_strict['valid_bos']:
        # Found case where relaxed passes but strict fails - diagnose why
        # Get first relaxed valid and first strict signal (if any)
        if res_relaxed['valid_bos']:
            r = res_relaxed['valid_bos'][0]
            # Find corresponding strict signal at same index
            strict_at_same_idx = [s for s in res_strict['all_signals'] if s['index']==r['index']]
            if strict_at_same_idx:
                s = strict_at_same_idx[0]
                print(f"\nBar {i} idx {r['index']}: Relaxed VALID but Strict {s['type']} - Reason: {s['reason'][:150]}")
                print(f"  Relaxed: ClosePos {r['close_position']:.2f} VolOutlier {r['volume_outlier']} Disp {r['displacement_atr_ratio']:.2f} UpperWick {r['upper_wick_ratio']:.2f}")
                if len([x for x in [r] if True])>3:
                    break

# Check Protected Low true vs protected
print("\n--- Protected Low true vs protected ---")
for i in range(len(df)-100, len(df)):
    past = df.iloc[:i+1]
    swing_det = ProtectedSwingDetector(pivot_length=2)
    swings = swing_det.analyze(past)
    if swings['protected_lows'] and not swings['true_protected_lows']:
        pl = swings['protected_lows'][-1]
        print(f"Bar {i}: protected low exists price {pl['price']:.2f} but true_protected empty - Check: protected={pl['protected']} verification={pl['verification']} is_ghost={pl['is_ghost']} is_trap={pl['is_trap']} rejection_ratio={pl['rejection_ratio']}")
        if i> len(df)-20:
            break

print("\n--- FVG and OB counts last 100 ---")
from engine.core.orderblock_detector import OrderBlockDetector
for i in range(len(df)-100, len(df)):
    past = df.iloc[:i+1]
    det = OrderBlockDetector()
    fvgs = det.detect_fvgs(past)
    obs = det.detect_bullish_obs(past, fvgs)
    if fvgs or obs:
        print(f"Bar {i}: FVGs {len(fvgs)} OBs {len(obs)}")
