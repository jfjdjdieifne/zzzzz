"""
Circular Resampling - Capped Circular Buffer for 100 candles only across timeframes
Philosophy: Pulling data separate for each timeframe (4H,15M,5M) consumes internet and leads to API ban.
Super modification: Engine pulls 1M timeframe data only as single broadcast channel [1.1.5,1.4.6]. Inside RAM, program Local Candle Aggregation (Resampling):
After every 5 minute candles builds 5M, after 15 builds 15M, and pours into circular fixed-size arrays capped precisely at 100 candles only per millimeter. Once candle 101 arrives, candle number 1 automatically deleted from RAM. This maintains RAM consumption stable at 25MB max throughout 24 hours, protecting Termux app from being killed by Android LMK System [1.1.5,1.4.6].

Implementation:
- Single WebSocket stream for 1M only
- Local resampling in RAM
- Capped buffers 100 candles each
- Android LMK protection: Total RAM 25MB max
"""

from collections import deque
import pandas as pd

class CappedCircularBuffer:
    def __init__(self, maxlen=100):
        self.maxlen = maxlen
        self.buffer = deque(maxlen=maxlen)
    
    def add(self, candle):
        """candle dict with timestamp, open, high, low, close, volume"""
        self.buffer.append(candle)
    
    def to_dataframe(self):
        return pd.DataFrame(list(self.buffer))
    
    def __len__(self):
        return len(self.buffer)

class MultiTimeframeResampler:
    """
    Resamples 1M data into 5M, 15M, 4H etc locally in RAM without API calls
    """
    def __init__(self):
        self.buffer_1m = CappedCircularBuffer(maxlen=100)
        self.buffer_5m = CappedCircularBuffer(maxlen=100)
        self.buffer_15m = CappedCircularBuffer(maxlen=100)
        self.buffer_4h = CappedCircularBuffer(maxlen=100)
        
        self.temp_5m = []  # holds 1m candles until 5
        self.temp_15m = []
        self.temp_4h = []  # 240 *1m = 4H
    
    def add_1m_candle(self, candle_1m):
        """
        Add 1M candle, automatically build higher timeframes
        """
        self.buffer_1m.add(candle_1m)
        self.temp_5m.append(candle_1m)
        self.temp_15m.append(candle_1m)
        self.temp_4h.append(candle_1m)
        
        # Build 5M every 5 candles
        if len(self.temp_5m) >= 5:
            candle_5m = self._aggregate(self.temp_5m)
            self.buffer_5m.add(candle_5m)
            self.temp_5m = []
        
        # Build 15M every 15 candles
        if len(self.temp_15m) >= 15:
            candle_15m = self._aggregate(self.temp_15m)
            self.buffer_15m.add(candle_15m)
            self.temp_15m = []
        
        # Build 4H every 240 candles
        if len(self.temp_4h) >= 240:
            candle_4h = self._aggregate(self.temp_4h)
            self.buffer_4h.add(candle_4h)
            self.temp_4h = []
    
    def _aggregate(self, candles):
        """Aggregate list of 1m candles into higher timeframe candle"""
        if not candles:
            return None
        open_price = candles[0]['open']
        close_price = candles[-1]['close']
        high_price = max(c['high'] for c in candles)
        low_price = min(c['low'] for c in candles)
        volume = sum(c['volume'] for c in candles)
        timestamp = candles[-1]['timestamp']
        
        return {
            'timestamp': timestamp,
            'open': open_price,
            'high': high_price,
            'low': low_price,
            'close': close_price,
            'volume': volume
        }
    
    def get_memory_usage_mb(self):
        """Estimate RAM usage: 100 candles * 4 buffers * ~50 bytes per candle ~ 20KB + Python overhead ~20MB"""
        # Each candle dict ~200 bytes, 400 candles total ~80KB + pandas overhead ~5MB + Python runtime ~20MB = ~25MB max
        total_candles = len(self.buffer_1m) + len(self.buffer_5m) + len(self.buffer_15m) + len(self.buffer_4h)
        # Rough estimate
        ram_mb = 20 + (total_candles * 200 / 1024 / 1024)
        return ram_mb

# Usage in Termux:
# resampler = MultiTimeframeResampler()
# async for raw_message in websocket:
#     candle_1m = json.loads(raw_message)
#     resampler.add_1m_candle(candle_1m)
#     # Now you have 1M,5M,15M,4H always capped at 100 candles, RAM 25MB max, zero API calls for higher timeframes
