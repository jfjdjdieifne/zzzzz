"""
Continuous 24/7 Whale Hunting Radar - No Sleep

Philosophy: Crypto market works 24/7 throughout week, super opportunities can literally happen any second night or day when sudden whale decides to pump terrifying liquidity market [1.4.1, 1.4.6]
Idea that crypto closes outside forex hours is wrong; whales, Asian hedge funds, automated platforms, Middle East investors pump big liquidity at times dead completely in traditional markets.

If we make bot sleep or stop searching outside specific hours, we will miss explosive super opportunities and irreplaceable chances occurring in middle of night.

But to program engine with continuous 24/7 hunting mechanism without falling into dead random oscillation trap:

1. Concept Aggressive vs Scheduled Liquidity
Smart engine divides whale movement across 24h into two physical forces:
- Scheduled Flow: Expected flows linked to market openings (US or Japanese ETFs). Here market expected geometrically easy.
- Emergency Sudden Liquidity (Whale Aggression): Moment when whale or huge institutional portfolio suddenly (1am for example) decides to buy or sell terrifying amounts market for own reasons (hidden accumulation, account liquidation, emergency arbitrage).

How does bot hunt 24h non-stop?
Engine never closes scanning gates. Stays awake second by second via WebSockets Stream silent. Instead of closing code by time, program Continuous Volatility Pulse sensor.
If whale appears suddenly in any dead hour of night and pumps anomalous volume and achieves BOS and Displacement super conditions, engine cells ignite immediately and switches to attack mode to snipe opportunity millimeter because honest whale fingerprint and explosive size cancel any time rule in crypto.

2. Dynamic equation for Dead Zone Filter (24/7 Dead Zone Filter)
Only problem staying searching 24h is late night human trading drops, price movement becomes zigzag boring (noise). If leave bot programmed with same filters, may see very small low on 5m and consider it protected low and buy and hang account.
Therefore to make code flexible, engine calculates Rolling 3-Hour Volume Mean and takes decision automatically:
- In crazy high liquidity hours: order book expands, volume conditions required to approve BOS become huge heavy to match market power.
- In quiet night hours (total dormancy): filters shrink and become very sensitive; bot calculates any sudden anomalous rise in volume (even if small compared to day volume) is evidence of emergency whale entry trying to move stagnant water.

3. Emergency trap catalog in 24h trades:
Trap "Low-Volume Midnight Raid" - Silent Dawn Liquidity Theft:
- Behavioral trap: 3am, violent candle drops and breaks previous day low down, looks like full collapse. Traditional bots rush either sell panic or early buy. Suddenly price flips and flies up.
- Engine intelligence: Engine works 24h and awake criminally; looks at Spot CVD delta.
  If break happened with relatively weak volume but Spot CVD recorded hidden buying leap (limit orders absorbed selling), engine infers: "This is artificial break in dormancy hour exploiting absence of human traders to steal stops (Stop Run) and pull bottom liquidity with minimal financial cost"
  Tactical: Engine classifies signal as super fleeting rebound opportunity, places buy order immediately from generated FVG, achieving huge profits before small traders wake up morning to find price flown.

Sources:
- Crypto market never closes, no opening bell, no 4pm cutoff, no holiday breaks [usethebitcoin]
- Crypto markets run continuously with no closing bells [usethebitcoin]
- Weekend trading brings lower volume, institutional stepping back, retail dominating, thinner liquidity price swings hit harder [usethebitcoin, smartinvestor]
- Trading activity continues throughout night [nordfx]
- Global sessions: Asian midnight-8am UTC, European 7am-4pm UTC, US 1pm-10pm UTC, late-night US volume drops significantly [usethebitcoin, stoic.ai]
- Overlap Europe-US 1pm-5pm UTC highest liquidity [usethebitcoin, stoic.ai]
- CME now trades crypto 24/7 as of May 29 2026, gap extinct [crypto.news]
- Crypto market truly 24/7/365 [walletfinder, switchere]
- Follow-the-sun pattern distinct periods high/low activity [walletfinder]
- Volatility and liquidity shift depending on time of day [usethebitcoin]
- Large price movements led by Asian exchanges during Asian session [stoic.ai]
- Weekend volatility higher because lower liquidity [smartinvestor]
- Seller Exhaustion Detector: Liquidity Sweep + Reclaim, CVD Bullish Divergence, RSI Bullish Divergence, Sell-Volume Dry-Up, Absorption [tradingview volumeprofile exhaustion]
- Absorption: elevated volume compressed range close in upper half supply being eaten [support.spotgamma]
- Stop Hunting 101: During Low Volume Windows thin liquidity sessions exaggerate stop runs, mark obvious swings Asian High/Low, London High/Low, Previous Day High/Low, Previous Week High/Low [acy Stop Hunting 101]
"""

import pandas as pd
import numpy as np
from typing import Dict

class ContinuousHuntingEngine:
    def __init__(self, rolling_window_hours=3):
        self.rolling_window = rolling_window_hours
    
    def calculate_rolling_3h_volume_mean(self, df: pd.DataFrame, current_idx: int) -> float:
        # Rolling 3-Hour Volume Mean - last 3 hours
        # Assuming 5m timeframe: 3 hours = 36 candles
        # 1m timeframe: 180 candles
        # For simplicity, use 36 candles for 5m, 12 candles for 15m? We'll use 36 as generic for 5m
        # Better: calculate based on timestamp difference 3 hours
        if current_idx < 5:
            return df['volume'].mean()
        
        # Last 36 candles ~3 hours on 5m
        lookback = 36
        start = max(0, current_idx - lookback)
        return df['volume'].iloc[start:current_idx].mean()
    
    def calculate_volume_z_score(self, current_volume: float, rolling_mean: float, df: pd.DataFrame, current_idx: int) -> float:
        lookback = 36
        start = max(0, current_idx - lookback)
        vols = df['volume'].iloc[start:current_idx]
        std = vols.std() if len(vols)>1 else 1
        if std < 1e-9:
            return 0
        return (current_volume - rolling_mean) / std
    
    def is_market_hollow(self, current_hour_utc: int, rolling_mean: float, overall_avg: float) -> bool:
        """
        Late-night US hours: Volume drops off significantly, order book depth shrinks [usethebitcoin]
        Asian session midnight-8am UTC, European 7-4pm, US 1pm-10pm, late-night US hours volume drops [stoic.ai]
        """
        # Late-night US hours: 0-5 UTC and 22-23 UTC are low liquidity
        low_liquidity_hours = [0,1,2,3,4,5,22,23]
        is_low_hour = current_hour_utc in low_liquidity_hours
        
        # Also check if rolling mean is significantly below overall avg (e.g., <60%)
        is_low_volume_period = rolling_mean < overall_avg * 0.6
        
        return is_low_hour or is_low_volume_period
    
    def calculate_cvd(self, df):
        cvd=[]
        running=0
        for _,row in df.iterrows():
            hl=row['high']-row['low']
            if hl>0:
                buy_factor=(row['close']-row['low'])/hl
                delta_factor=(buy_factor-0.5)*2
                delta=delta_factor*row['volume']
            else:
                delta=0
            running+=delta
            cvd.append(running)
        return pd.Series(cvd, index=df.index)
    
    def detect_midnight_raid(self, df: pd.DataFrame, current_idx: int, major_low: float) -> Dict:
        """
        Low-Volume Midnight Raid: 3am, violent candle drops and breaks previous day low down, looks like full collapse
        Traditional bots rush sell panic or early buy, suddenly flips and flies up
        Engine looks at Spot CVD: if break happened with relatively weak volume but Spot CVD recorded hidden buying leap (limit orders absorbed selling)
        => artificial break in dormancy hour exploiting absence of human traders to steal stops
        """
        if current_idx < 5:
            return {'is_raid': False}
        
        candle = df.iloc[current_idx]
        # Check if breaks previous day low
        if candle['low'] >= major_low:
            return {'is_raid': False}
        
        # Volume relatively weak?
        rolling_mean = self.calculate_rolling_3h_volume_mean(df, current_idx)
        vol_weak = candle['volume'] < rolling_mean*1.2  # relatively weak, not huge
        
        # CVD hidden buying leap?
        cvd_series = self.calculate_cvd(df)
        # CVD should show bullish divergence: price new low but CVD higher low / rising
        # Check last 5 CVD vs price lows
        lookback = 5
        start = max(0, current_idx-lookback)
        price_lows = df['low'].iloc[start:current_idx+1]
        cvd_vals = cvd_series.iloc[start:current_idx+1]
        
        # Price makes new low at current
        is_new_low = candle['low'] == price_lows.min()
        # CVD not making new low, maybe rising
        cvd_at_low = cvd_vals.iloc[-1]
        cvd_min = cvd_vals.min()
        cvd_hidden_buy = cvd_at_low > cvd_min + (cvd_vals.max()-cvd_vals.min())*0.2  # CVD not at bottom, rising
        
        is_raid = is_new_low and vol_weak and cvd_hidden_buy
        
        return {
            'is_raid': is_raid,
            'vol_weak': vol_weak,
            'cvd_hidden_buy': cvd_hidden_buy,
            'price_low': candle['low'],
            'major_low': major_low,
            'cvd_at_low': cvd_at_low,
            'cvd_min': cvd_min,
            'rolling_mean': rolling_mean,
            'current_vol': candle['volume']
        }
    
    def analyze(self, df: pd.DataFrame, current_idx: int, current_hour_utc: int, major_low: float, atr: float) -> Dict:
        candle = df.iloc[current_idx]
        rolling_3h_mean = self.calculate_rolling_3h_volume_mean(df, current_idx)
        overall_avg = df['volume'].mean()
        z_score = self.calculate_volume_z_score(candle['volume'], rolling_3h_mean, df, current_idx)
        
        is_hollow = self.is_market_hollow(current_hour_utc, rolling_3h_mean, overall_avg)
        
        # Adaptive Velocity Gate
        if is_hollow:
            # In hollow hours, filters shrink and become very sensitive
            # Lowered threshold: any anomalous rise even small compared to day volume is evidence of emergency whale
            dynamic_threshold = rolling_3h_mean * 1.5  # lowered from 2.5x to 1.5x for midnight
            threshold_status = "Lowered_For_Midnight_Context"
        else:
            # In crazy high liquidity hours, order book expands, volume conditions huge heavy
            dynamic_threshold = rolling_3h_mean * 2.5
            threshold_status = "Raised_For_High_Liquidity_Context"
        
        is_whale_influx = candle['volume'] > dynamic_threshold
        anomaly_status = "CRITICAL_WHALE_INFLUX_DETECTED" if is_whale_influx else "NORMAL"
        
        # Midnight raid check
        midnight_raid = self.detect_midnight_raid(df, current_idx, major_low)
        
        # Decision
        if is_whale_influx:
            decision = "Whale entry is mathematically validated despite the late hour."
            action = "TRIGGER_HYPER_ATTACK_MODE_IMMEDIATELY"
            ignore_clock = True
            conclusion = "An aggressive whale has entered the thin midnight market, creating a high displacement breakout. Time rules are bypassed by sheer kinetic energy. Catch the shallow FVG now."
        elif midnight_raid['is_raid']:
            decision = "Midnight raid detected - artificial break in dormancy hour exploiting absence of human traders to steal stops"
            action = "TRIGGER_HYPER_ATTACK_MODE_IMMEDIATELY - Rebound opportunity fleeting"
            ignore_clock = True
            conclusion = "This is artificial break in hour of dormancy exploiting absence of human traders to steal stops (Stop Run) and pull bottom liquidity with minimal cost - classify as super fleeting rebound opportunity, place buy immediately from generated FVG achieving huge profits before small traders wake up"
            anomaly_status = "MIDNIGHT_RAID_DETECTED"
        else:
            if is_hollow:
                decision = "Market hollow and no whale - protective sleep, no trade"
                action = "SLEEP_SILENTLY_PROTECT_MONEY"
            else:
                decision = "Normal market conditions"
                action = "CONTINUE_NORMAL_SCANNING"
            ignore_clock = False
            conclusion = "Market dead, sleep silently protecting money without wasting big opportunities" if is_hollow else "Normal scanning"
        
        return {
            'Core_Scanner_Status': '24/7_CONTINUOUS_WHALE_HUNTING',
            'Live_Market_Pulse': {
                'Current_Asset': 'SOL/USDT',
                'Current_Hour_UTC': current_hour_utc,
                'Is_Market_Hollow_Now': is_hollow,
                'Rolling_3H_Volume_Mean': rolling_3h_mean,
                'Overall_Avg_Volume': overall_avg,
                'Current_Candle_Volume': candle['volume'],
                'Z_Score_Anomaly_Status': anomaly_status,
                'Z_Score_Value': z_score
            },
            'Adaptive_Velocity_Gate': {
                'Is_Market_Hollow_Now': is_hollow,
                'Dynamic_Volume_Threshold': dynamic_threshold,
                'Dynamic_Volume_Threshold_Adjusted': threshold_status,
                'Decision': decision
            },
            'Execution_Permission': {
                'Ignore_Standard_Clock_Restriction': ignore_clock,
                'Action_Command': action,
                'Cognitive_Conclusion': conclusion
            },
            'Midnight_Raid_Check': midnight_raid,
            'Volume_Telemetry': {
                'Rolling_3H_Mean': rolling_3h_mean,
                'Current_Volume': candle['volume'],
                'Threshold': dynamic_threshold,
                'Is_Whale_Influx': is_whale_influx
            }
        }
