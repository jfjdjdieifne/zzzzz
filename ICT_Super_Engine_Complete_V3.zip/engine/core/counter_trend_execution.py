"""
Counter-Trend Spot Buy Execution - Second Map Station 4
Philosophy: Trading against general trend is temporary liquidity hunting.
Whale swept historical low and flipped LTF structure, needs to activate remaining pending contracts in LTF OB.
Once block touched, violent sudden bullish thrust rebound.
Doctrine: Goal not to stay weeks or wait new highs; goal is ride fast rebound 5-15% immediate spot, then exit entirely to cash USDT.

Micro-Trigger Matrix - 3 simultaneous live behavioral conditions:
1. CVD Slingshot: Spot CVD stops falling immediately and flips to sharp upward while price still stable/sideways at bottom.
   Digital: Panic sellers continue selling market, but whale limit orders inside OB swallow all sells with aggressive absorption paving for explosion.
2. Micro Wick Rejection: 1m/5m candle touching OB must achieve strict positional relation: Micro_Close_Position = (Close-Low)/(High-Low) >0.70
   Candle went below OB line, stole local liquidity, bounced quickly to close in upper 30% of its total range. Material confirmation of fast price rejection (micro SFP).
3. Effort Matches Result: Instantaneous rebound candle volume must be proportional directly with its price range, proving price freed from selling gates and moving with whale current easily, not Churning hidden correction.

Escape Plan:
1. SL = LTF_Origin_Low -0.01$ - Main low built by whale is only protection wall. If price drops again and body closes below this low, whale surrendered or crushed by bigger sellers, trade spoiled. Exit small loss 1-1.5% only lifeline to prevent freezing spot liquidity for years in deep abyss bottoms.
2. TP1 75%: First unfilled Bearish HTF FVG on 4H - works as rebound magnet, once price reaches it will collide with big sell orders of bearish whales and drop again; must exit immediately securing profits.
   TP2 25%: Latest nearest Bearish HTF OB formed on 4H before last collapse. At this price exit 100% and return immediately to silent cash USDT.

Sources:
- CVD Slingshot Flip: price holds support but CVD slowly bleeding downwards as sellers try to push down and fail, then suddenly CVD reverses sharply upwards [oboe: Failed Absorption + Flip]
- CVD rising while price flat = stealth accumulation watch for breakout [HS CVD]
- Absorption: large bid order placed just as price dipping indicates potential reversal, aggressive buying wave signals strong breakout [UrbanMatter]
- Micro Close Position >0.70 = rejection, close in upper 30% [VenturaSecurities wick percentage, steady-turtle VWAP rejection]
- Effort Matches Result: volume proportional to range, not churning hidden correction [oboe: Effort vs Result]
- Bearish HTF FVG as take profit magnet [innercircletrader FVG 6-step: take profit at next draw on liquidity old high/low or HTF FVG]
"""

import pandas as pd
import numpy as np
from typing import List, Dict

class CounterTrendSignal:
    def __init__(self):
        self.entry_price = None
        self.entry_type = None
        self.ob = None
        self.cvd_slingshot = False
        self.wick_rejection = False
        self.effort_match = False
        self.is_valid = False
        self.stop_loss = None
        self.tp1 = None  # Bearish HTF FVG 75%
        self.tp2 = None  # Bearish HTF OB 25%
        self.tp1_percent = 75
        self.tp2_percent = 25
        self.risk_reward = None
        self.reason = ""

class CounterTrendExecutionEngine:
    def __init__(self, atr_period=14):
        self.atr_period = atr_period
    
    def calculate_atr(self, df):
        tr1 = df['high']-df['low']
        tr2 = (df['high']-df['close'].shift()).abs()
        tr3 = (df['low']-df['close'].shift()).abs()
        tr = pd.concat([tr1,tr2,tr3], axis=1).max(axis=1)
        return tr.rolling(self.atr_period).mean().fillna(tr.mean())
    
    def calculate_cvd(self, df):
        cvd=[]
        running=0
        for _,row in df.iterrows():
            hl=row['high']-row['low']
            if hl>0:
                buy_factor=(row['close']-row['low'])/hl
                delta_factor=(buy_factor-0.5)*2
                delta=delta_factor*row['volume']
            else:
                delta=0
            running+=delta
            cvd.append(running)
        return pd.Series(cvd, index=df.index)
    
    def check_cvd_slingshot(self, df: pd.DataFrame, cvd_series: pd.Series, touch_idx: int) -> Dict:
        """
        CVD Slingshot: Spot CVD stops falling immediately and flips to sharp upward while price still stable/sideways at bottom
        """
        if touch_idx < 5:
            return {'is_slingshot': False}
        
        # Look at last 5 CVD values before touch
        lookback = 5
        start = max(0, touch_idx-lookback)
        cvd_segment = cvd_series.iloc[start:touch_idx]
        price_segment = df['close'].iloc[start:touch_idx]
        
        # CVD falling before?
        if len(cvd_segment) >=2:
            # Linear regression slope of CVD before touch
            x = np.arange(len(cvd_segment)).reshape(-1,1)
            y = cvd_segment.values
            from sklearn.linear_model import LinearRegression
            model = LinearRegression().fit(x,y)
            slope_before = model.coef_[0]
        else:
            slope_before = 0
        
        # At touch and next 2 candles, CVD rising sharply?
        end = min(len(df), touch_idx+3)
        cvd_after = cvd_series.iloc[touch_idx:end]
        price_after = df['close'].iloc[touch_idx:end]
        
        if len(cvd_after) >=2:
            x = np.arange(len(cvd_after)).reshape(-1,1)
            y = cvd_after.values
            model = LinearRegression().fit(x,y)
            slope_after = model.coef_[0]
        else:
            slope_after = 0
        
        # Price stable/sideways at bottom? Check price range small vs ATR?
        price_range_before = df['high'].iloc[start:touch_idx].max() - df['low'].iloc[start:touch_idx].min() if touch_idx>start else 0
        atr = self.calculate_atr(df).iloc[touch_idx]
        price_stable = price_range_before < atr*1.0 if atr>0 else False
        
        # Slingshot: before falling (slope_before<0) and after rising sharply (slope_after>0 and slope_after > |slope_before|*1.5)
        is_slingshot = (slope_before < 0) and (slope_after > 0) and (slope_after > abs(slope_before)*1.2) and price_stable
        
        return {
            'is_slingshot': is_slingshot,
            'slope_before': slope_before,
            'slope_after': slope_after,
            'price_stable': price_stable,
            'cvd_before': cvd_segment.iloc[-1] if len(cvd_segment)>0 else 0,
            'cvd_after': cvd_after.iloc[-1] if len(cvd_after)>0 else 0
        }
    
    def check_micro_wick_rejection(self, df: pd.DataFrame, touch_idx: int) -> Dict:
        """
        Micro Close Position = (Close[1M]-Low[1M])/(High[1M]-Low[1M]) >0.70
        """
        candle = df.iloc[touch_idx]
        hl_range = candle['high'] - candle['low']
        if hl_range>0:
            close_pos = (candle['close'] - candle['low']) / hl_range
            lower_wick = min(candle['open'], candle['close']) - candle['low']
            upper_wick = candle['high'] - max(candle['open'], candle['close'])
            body = abs(candle['close'] - candle['open'])
            # Wick rejection: lower wick > body and close in upper 30%
            wick_rejection = lower_wick > body*0.8 and close_pos > 0.70
        else:
            close_pos = 0
            lower_wick = 0
            upper_wick = 0
            body = 0
            wick_rejection = False
        
        return {
            'is_rejection': wick_rejection,
            'close_pos': close_pos,
            'lower_wick': lower_wick,
            'upper_wick': upper_wick,
            'body': body
        }
    
    def check_effort_matches_result(self, df: pd.DataFrame, touch_idx: int) -> Dict:
        """
        Effort Matches Result: rebound candle volume proportional directly with its price range, proving price freed from selling gates
        Avoid Churning hidden correction: huge volume but tiny body
        """
        candle = df.iloc[touch_idx]
        hl_range = candle['high'] - candle['low']
        body = abs(candle['close'] - candle['open'])
        volume = candle['volume']
        
        # Effort = Volume, Result = Range or Body
        # If volume huge but range tiny => Churning
        # If volume proportional to range => effort matches result
        
        # Calculate average range and avg volume last 20
        start = max(0, touch_idx-20)
        avg_range = (df['high'].iloc[start:touch_idx] - df['low'].iloc[start:touch_idx]).mean() if touch_idx>start else hl_range
        avg_vol = df['volume'].iloc[start:touch_idx].mean() if touch_idx>start else volume
        avg_body = abs(df['close'].iloc[start:touch_idx] - df['open'].iloc[start:touch_idx]).mean() if touch_idx>start else body
        
        # Proportional check: (volume / avg_vol) should be roughly similar to (range / avg_range)
        vol_ratio = volume / avg_vol if avg_vol>0 else 1
        range_ratio = hl_range / avg_range if avg_range>0 else 1
        body_ratio = body / avg_body if avg_body>0 else 1
        
        # If vol_ratio >> range_ratio *2 => churning (volume huge but range tiny)
        is_churning = vol_ratio > range_ratio*2.5 and body < avg_body*0.5
        
        effort_matches = not is_churning and vol_ratio > 0.8 and range_ratio > 0.5
        
        return {
            'effort_matches': effort_matches,
            'is_churning': is_churning,
            'vol_ratio': vol_ratio,
            'range_ratio': range_ratio,
            'body_ratio': body_ratio
        }
    
    def find_bearish_htf_fvg_and_ob(self, df_htf: pd.DataFrame) -> Dict:
        """
        Find first unfilled Bearish HTF FVG on 4H and latest Bearish HTF OB
        For this engine, we simulate HTF as 4H: use same df but look for bearish FVGs (Low C1 > High C3)
        """
        # Find bearish FVGs: Low C1 > High C3 and middle bearish
        bearish_fvgs = []
        for i in range(1, len(df_htf)-1):
            c1 = df_htf.iloc[i-1]
            c2 = df_htf.iloc[i]
            c3 = df_htf.iloc[i+1]
            if c1['low'] > c3['high'] and c2['close'] < c2['open']:
                # Bearish FVG: low C1 is top, high C3 is bottom
                gap_low = c3['high']
                gap_high = c1['low']
                # Check if unfilled (price hasn't returned to fill)
                # For simplicity, check if close after gap never entered
                bearish_fvgs.append({
                    'low': gap_low,
                    'high': gap_high,
                    'ce': (gap_low+gap_high)/2,
                    'index': i
                })
        
        # Bearish OB: last bullish candle before bearish displacement
        bearish_obs = []
        for i in range(1, len(df_htf)-1):
            prev = df_htf.iloc[i-1]
            curr = df_htf.iloc[i]
            if prev['close'] > prev['open'] and curr['close'] < curr['open']:
                # Bullish then bearish engulfing?
                if curr['low'] < prev['low'] and curr['close'] < prev['low']:
                    bearish_obs.append({
                        'low': prev['low'],
                        'high': prev['high'],
                        'index': i-1
                    })
        
        # TP1 = first unfilled bearish FVG (closest above current price)
        # TP2 = latest bearish OB (closest above)
        return {
            'bearish_fvgs': bearish_fvgs,
            'bearish_obs': bearish_obs
        }
    
    def generate_trade(self, df_ltf: pd.DataFrame, df_htf: pd.DataFrame, touch_idx: int, ob_high: float, ob_low: float, origin_low: float) -> CounterTrendSignal:
        sig = CounterTrendSignal()
        sig.ob = {'high': ob_high, 'low': ob_low}
        
        # Check 3 micro triggers
        cvd_series = self.calculate_cvd(df_ltf)
        cvd_check = self.check_cvd_slingshot(df_ltf, cvd_series, touch_idx)
        wick_check = self.check_micro_wick_rejection(df_ltf, touch_idx)
        effort_check = self.check_effort_matches_result(df_ltf, touch_idx)
        
        sig.cvd_slingshot = cvd_check['is_slingshot']
        sig.wick_rejection = wick_check['is_rejection']
        sig.effort_match = effort_check['effort_matches']
        
        # Entry price = close of touch candle or confluence level
        candle = df_ltf.iloc[touch_idx]
        sig.entry_price = candle['close']
        sig.entry_type = 'LTF_OB_CONFLUENCE'
        
        # Check if all 3 conditions met
        if cvd_check['is_slingshot'] and wick_check['is_rejection'] and effort_check['effort_matches']:
            sig.is_valid = True
            sig.reason = f"CVD Slingshot Flip slope {cvd_check['slope_before']:.2f}->{cvd_check['slope_after']:.2f} price stable {cvd_check['price_stable']} + Micro Wick Rejection ClosePos {wick_check['close_pos']:.2f}>0.70 LowerWick {wick_check['lower_wick']:.2f}>Body {wick_check['body']:.2f} + Effort Matches VolRatio {effort_check['vol_ratio']:.1f} RangeRatio {effort_check['range_ratio']:.1f} Not Churning {not effort_check['is_churning']}"
        else:
            sig.is_valid = False
            sig.reason = f"Missing triggers: CVD Slingshot {cvd_check['is_slingshot']} WickRej {wick_check['is_rejection']} EffortMatch {effort_check['effort_matches']} (Churning {effort_check['is_churning']})"
            return sig
        
        # Stop Loss: LTF_Origin_Low -0.01$
        sig.stop_loss = origin_low - 0.01
        
        # Take Profit: Bearish HTF FVG 75% and Bearish HTF OB 25%
        htf_levels = self.find_bearish_htf_fvg_and_ob(df_htf)
        
        # Find first bearish FVG above entry
        bearish_fvgs_above = [f for f in htf_levels['bearish_fvgs'] if f['low'] > sig.entry_price]
        if bearish_fvgs_above:
            # Closest
            tp1_fvg = min(bearish_fvgs_above, key=lambda x: x['low'])
            sig.tp1 = tp1_fvg['low']  # first FVG low as magnet
        else:
            # Fallback: 5-15% above entry
            sig.tp1 = sig.entry_price * 1.08  # 8% as example for counter-trend 5-15%
        
        bearish_obs_above = [o for o in htf_levels['bearish_obs'] if o['low'] > sig.entry_price]
        if bearish_obs_above:
            tp2_ob = max(bearish_obs_above, key=lambda x: x['low'])  # nearest above? Actually latest nearest
            # Take the closest above entry
            tp2_ob = min(bearish_obs_above, key=lambda x: x['low'])
            sig.tp2 = tp2_ob['low']
        else:
            sig.tp2 = sig.entry_price * 1.12  # 12%
        
        # Risk Reward
        if sig.stop_loss and sig.tp1:
            risk = sig.entry_price - sig.stop_loss
            reward1 = sig.tp1 - sig.entry_price
            reward2 = sig.tp2 - sig.entry_price if sig.tp2 else reward1
            avg_reward = reward1*0.75 + reward2*0.25
            sig.risk_reward = f"1:{avg_reward/risk:.1f}" if risk>0 else "N/A"
        
        return sig
