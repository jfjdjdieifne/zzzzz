"""
FVG Detection - Precision millimeter detection
Source: ICT FVG is 3-candle formation gap between high of 1st and low of 3rd [innercircletrader.net]
Behavioral: imbalance due to aggressive institutional buying/selling
"""
import pandas as pd
import numpy as np
from typing import List, Dict

class FVG:
    def __init__(self, index_start, index_end, high, low, type, atr, displacement_ratio):
        self.index_start = index_start  # candle 1
        self.index_mid = index_start + 1  # candle 2 (displacement)
        self.index_end = index_end  # candle 3
        self.high = high
        self.low = low
        self.type = type  # 'bullish' or 'bearish'
        self.atr = atr
        self.displacement_ratio = displacement_ratio
        self.mitigated = False
        self.mitigation_index = None
        # Consequent Encroachment = 50% of FVG = institutional partial fill level
        self.ce = (high + low) / 2
    
    def to_dict(self):
        return {
            'type': self.type,
            'high': self.high,
            'low': self.low,
            'ce': self.ce,
            'index_start': self.index_start,
            'index_mid': self.index_mid,
            'index_end': self.index_end,
            'displacement_ratio': self.displacement_ratio,
            'mitigated': self.mitigated,
            'gap_size': abs(self.high - self.low)
        }

class FVGDetector:
    """
    Behavioral principle: FVG = price moved too fast, skipped levels, no two-way trading
    Market seeks efficiency, returns to rebalance
    Validity filters:
    - Middle candle body must be > 1.0 ATR (displacement filter) [ict orderblock pro]
    - Wicks of 1st and 3rd must not overlap (gap)
    """
    def __init__(self, min_displacement_atr=1.0, min_gap_pct=0.05):
        self.min_displacement_atr = min_displacement_atr
        self.min_gap_pct = min_gap_pct
    
    def calculate_atr(self, df: pd.DataFrame, period=14):
        # Use smaller period for small datasets, fallback to simple TR
        if len(df) < period:
            period = max(2, len(df)//2)
        high = df['high']
        low = df['low']
        close = df['close']
        tr1 = high - low
        tr2 = (high - close.shift()).abs()
        tr3 = (low - close.shift()).abs()
        tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
        atr = tr.rolling(period).mean()
        # Fill NaN with expanding mean or simple average
        atr = atr.fillna(tr.expanding().mean())
        atr = atr.fillna(0.5)  # final fallback
        return atr
    
    def detect(self, df: pd.DataFrame) -> List[FVG]:
        df = df.copy()
        df['atr'] = self.calculate_atr(df)
        
        fvgs = []
        
        for i in range(1, len(df) - 1):
            # Three-candle window: i-1, i, i+1
            c1 = df.iloc[i-1]
            c2 = df.iloc[i]
            c3 = df.iloc[i+1]
            
            # Displacement filter: middle candle body must be impulsive
            body_size = abs(c2['close'] - c2['open'])
            atr = df['atr'].iloc[i]
            
            if pd.isna(atr) or atr == 0:
                continue
            
            displacement_ratio = body_size / atr
            
            if displacement_ratio < self.min_displacement_atr:
                continue  # weak move, not institutional
            
            # Bullish FVG: high of C1 < low of C3, middle bullish
            if c1['high'] < c3['low']:
                # Additional: middle candle bullish
                if c2['close'] > c2['open']:
                    gap_size = c3['low'] - c1['high']
                    gap_pct = gap_size / c2['close'] * 100
                    
                    if gap_pct >= self.min_gap_pct:
                        fvg = FVG(
                            index_start=i-1,
                            index_end=i+1,
                            high=c3['low'],  # top of gap is low of C3? Wait ICT def: gap between high C1 and low C3
                            low=c1['high'],   # bottom is high C1 for bullish? Actually reversed, let's correct
                            type='bullish',
                            atr=atr,
                            displacement_ratio=displacement_ratio
                        )
                        # Correct: for bullish, gap is between high C1 (bottom) and low C3 (top)
                        # So low = high C1, high = low C3
                        fvg.low = c1['high']
                        fvg.high = c3['low']
                        fvg.ce = (fvg.low + fvg.high) / 2
                        fvgs.append(fvg)
            
            # Bearish FVG: low of C1 > high of C3, middle bearish
            if c1['low'] > c3['high']:
                if c2['close'] < c2['open']:
                    gap_size = c1['low'] - c3['high']
                    gap_pct = gap_size / c2['close'] * 100
                    
                    if gap_pct >= self.min_gap_pct:
                        fvg = FVG(
                            index_start=i-1,
                            index_end=i+1,
                            high=c1['low'],
                            low=c3['high'],
                            type='bearish',
                            atr=atr,
                            displacement_ratio=displacement_ratio
                        )
                        fvgs.append(fvg)
        
        # Filter overlapping FVGs - keep strongest (highest displacement)
        return self.filter_overlapping(fvgs)
    
    def filter_overlapping(self, fvgs: List[FVG]) -> List[FVG]:
        """Keep strongest FVG in overlapping zone"""
        if not fvgs:
            return []
        
        # Sort by displacement ratio descending
        fvgs_sorted = sorted(fvgs, key=lambda x: x.displacement_ratio, reverse=True)
        
        filtered = []
        for fvg in fvgs_sorted:
            overlap = False
            for existing in filtered:
                # Check if indices overlap
                if not (fvg.index_end < existing.index_start or fvg.index_start > existing.index_end):
                    # Overlap exists, check price overlap too
                    if not (fvg.high < existing.low or fvg.low > existing.high):
                        overlap = True
                        break
            if not overlap:
                filtered.append(fvg)
        
        return sorted(filtered, key=lambda x: x.index_start)
    
    def check_mitigation(self, df: pd.DataFrame, fvgs: List[FVG]) -> List[FVG]:
        """Check if FVG has been mitigated (price returned and traded through)"""
        for fvg in fvgs:
            for idx in range(fvg.index_end + 1, len(df)):
                candle = df.iloc[idx]
                
                if fvg.type == 'bullish':
                    # Mitigated when price trades through CE or full FVG
                    # Body close below low = full mitigation (IFVG)
                    if candle['low'] <= fvg.low:
                        fvg.mitigated = True
                        fvg.mitigation_index = idx
                        break
                else:
                    if candle['high'] >= fvg.high:
                        fvg.mitigated = True
                        fvg.mitigation_index = idx
                        break
        
        return fvgs
    
    def analyze(self, df: pd.DataFrame) -> Dict:
        fvgs = self.detect(df)
        fvgs = self.check_mitigation(df, fvgs)
        
        return {
            'all_fvgs': [f.to_dict() for f in fvgs],
            'bullish_fvgs': [f.to_dict() for f in fvgs if f.type == 'bullish'],
            'bearish_fvgs': [f.to_dict() for f in fvgs if f.type == 'bearish'],
            'unmitigated_bullish': [f.to_dict() for f in fvgs if f.type == 'bullish' and not f.mitigated],
            'unmitigated_bearish': [f.to_dict() for f in fvgs if f.type == 'bearish' and not f.mitigated],
            'total': len(fvgs)
        }
