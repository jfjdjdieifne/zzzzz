"""
Live Trade Management - Battle Commander
Philosophy: Once buying center entered and state becomes IN_TRADE, engine stops being hunter waiting and becomes tactical risk manager and live liquidity protector.
Function: Eliminate two biggest flaws in classic bots: Dumb Fear (flees early leaving millions on table) and Blind Greed (watches profits evaporate turning into loss)

1. Dynamic Break-Even Shift Protocol - Structural Immunity ICT
Dumb bots move stop to entry as soon as price rises by fixed % 1% or 2% fear, price returns with quick wick hits stop at entry and exits before great launch. Engine follows ICT Mechanical Immunity:

Mechanism: Waits silently until price rises and achieves Internal Minor BOS on 5m timeframe in trade direction. This break leaves behind new protected sub low. Only in these seconds, stop order moves automatically from deep low to exact entry price + fees. Trade becomes officially free and safe 100%, and leaves price to breathe in wide upper spaces without fear of early exit.

Digital definition Internal BOS:
Price rises and records Minor_High, retraces slightly (cleaning greedy) and records soft Minor_Low, launches again and breaks Minor_High. Requires: Close[5M] > Minor_High
Tactical: Once body close above line, infers: Whale built new fortified sub base to protect its rise, internal structure break confirmed. Moves stop to Entry_Price + Fees. Trade now safe free 100%, impossible to lose dollar, without tightening choke on price.

2. Sequential Liquidation and Trailing Stop Behind Whale - Multi-Target OB Trailing
To prevent losing big profits and leaving money on table, forbid total exit at first target, and also forbid waiting blindly for final target.

- At price reaching TP1 - previous confirmed swing high that started correction (Last_Confirmed_Swing_High): Engine launches immediate market sell for 50% of spot amount instantly securing real cash in portfolio.
- Reason: Previous high line teems with sell and distribution orders for other whales and scared beginners; securing half profits is survival doctrine.

- Management of remaining 50% (Trailing Engine): Stop moves dynamically not based on dumb % (like raise 2% below price) but based on Whale Kinetic Structure (Market Structure Trailing):
Engine watches formation of new bullish order blocks (Bullish LTF OBs) born during rise on 15m timeframe. Once each candle confirms birth of new bullish OB supported by FVG, engine moves stop for remaining position automatically and places it below lowest tail of new order block by one cent. Price flies up, stop crawls behind leaning on financial concrete walls built by whale step by step during rise. If rally ends suddenly and market reverses violently, you are automatically exited with highest possible honest profits without leaving money on market makers table.

[Price flies up] -> [New Bullish OB forms on 15M] -> [Stop crawls automatically below new OB low]

3. Emergency Escape and Surgical Mechanism at Geological Force Reversal - Force Liquidation Trigger
This is most brilliant and flexible filter in engine. If price heading toward final biggest target TP2, and suddenly fingerprint of whale betrayal distribution appears, engine does not wait for trailing stop hit; flees with money immediately if this dual behavioral mathematical condition occurs in any live minute candle:

If minute candle records anomalous explosive volume outside upper channel of StdDev for 50 minute candles (Volume Outlier, Z-Score of Volume >3.5) (terrifying sudden money pumping), but its close collapses in bottom abyss of candle itself (Close_Position 1M = (Close-Low)/(High-Low) <0.15) and coincides with vertical terrifying scary drop in Spot CVD indicator proving exit and liquidation of hundreds of millions dollars market in these seconds.

Immediate Inferential Decision: Engine infers thinking without emotions: "Power balance flipped geologically suddenly and unexpectedly; there is giant whale flooding market with distribution market now Institutional Distribution. Staying here is not courage but dumb greed and leaving money on table to evaporate". Issues immediate order (EMERGENCY MARKET SELL - 100%); sells all remaining spot amount immediately at current market price, and closes trade with current available profits, exiting entirely to safe haven USDT watching market collapse that will happen in coming minutes.
"""

import pandas as pd
import numpy as np
from typing import Dict, List
from sklearn.linear_model import LinearRegression

class LiveTradeManager:
    def __init__(self):
        pass
    
    def detect_internal_bos(self, df_5m: pd.DataFrame, entry_idx: int) -> Dict:
        """
        Internal Minor BOS on 5m: price rises, records Minor_High, retraces to Minor_Low, then breaks Minor_High with Close[5M] > Minor_High
        """
        # Look for Minor_High after entry
        # Find first swing high after entry
        start = entry_idx
        # Simple: find local high then low then break
        # For demo, find any high after entry that gets broken
        
        for i in range(start+1, len(df_5m)-2):
            # Potential Minor High: high higher than neighbors
            if df_5m['high'].iloc[i] > df_5m['high'].iloc[i-1] and df_5m['high'].iloc[i] >= df_5m['high'].iloc[i+1]:
                minor_high = df_5m['high'].iloc[i]
                # Find minor low after it
                for j in range(i+1, len(df_5m)-1):
                    if df_5m['low'].iloc[j] < df_5m['low'].iloc[j-1] and df_5m['low'].iloc[j] <= df_5m['low'].iloc[j+1]:
                        minor_low = df_5m['low'].iloc[j]
                        # Now look for break: close above minor_high
                        for k in range(j+1, len(df_5m)):
                            if df_5m['close'].iloc[k] > minor_high:
                                return {
                                    'found': True,
                                    'minor_high': minor_high,
                                    'minor_high_idx': i,
                                    'minor_low': minor_low,
                                    'minor_low_idx': j,
                                    'bos_idx': k,
                                    'bos_price': df_5m['close'].iloc[k]
                                }
        return {'found': False}
    
    def manage_break_even(self, df_5m: pd.DataFrame, entry_idx: int, entry_price: float, current_idx: int) -> Dict:
        """
        Break-Even Shift: Wait silently until Internal Minor BOS verified, then move stop to Entry + Fees
        """
        detection = self.detect_internal_bos(df_5m, entry_idx)
        
        if detection['found'] and detection['bos_idx'] <= current_idx:
            # Move stop to entry + fees (e.g., 0.1%)
            new_stop = entry_price * 1.001  # entry + fees
            return {
                'should_shift': True,
                'new_stop': new_stop,
                'reason': f"Internal Minor BOS verified at {detection['bos_price']:.2f} breaking Minor High {detection['minor_high']:.2f} - Whale built new fortified sub base, internal structure break confirmed, move stop to Entry+Fees {new_stop:.2f} trade now safe free 100%",
                'detection': detection
            }
        else:
            return {
                'should_shift': False,
                'new_stop': None,
                'reason': "Waiting silently for Internal Minor BOS - give price full space to breathe, don't move original stop at all unless physical inevitable effect on 5M"
            }
    
    def detect_new_bullish_obs_trailing(self, df_15m: pd.DataFrame, last_trailing_stop: float) -> Dict:
        """
        Multi-Target OB Trailing: Watch formation of new bullish OBs during rise on 15m, each new OB supported by FVG, move stop below lowest tail of new OB by 1 cent
        """
        # Simplified: detect bullish OBs as last bearish before bullish displacement after entry
        # For each new OB after last trailing stop update, move stop
        
        # Find bullish OBs after last stop
        # Use simple detection: bearish candle followed by bullish engulfing with large body
        
        new_obs = []
        for i in range(1, len(df_15m)-1):
            prev = df_15m.iloc[i-1]
            curr = df_15m.iloc[i]
            nxt = df_15m.iloc[i+1] if i+1 < len(df_15m) else None
            
            if prev['close'] < prev['open']:  # bearish
                if curr['close'] > curr['open'] and curr['close'] > prev['high']:  # bullish engulf
                    # Check if leaves FVG: prev high < next low?
                    if nxt is not None and prev['high'] < nxt['low']:
                        # This is bullish OB with FVG
                        new_obs.append({
                            'index': i-1,
                            'low': prev['low'],
                            'high': prev['high']
                        })
        
        # For each new OB, trailing stop = New Bullish OB Low -0.01
        if new_obs:
            latest_ob = new_obs[-1]
            trailing_stop = latest_ob['low'] - 0.01
            # Only move up, never down
            if trailing_stop > last_trailing_stop:
                return {
                    'should_trail': True,
                    'new_stop': trailing_stop,
                    'ob': latest_ob,
                    'reason': f"New Bullish OB formed at {latest_ob['low']:.2f}-{latest_ob['high']:.2f} supported by FVG - Price flies up, stop crawls behind leaning on financial concrete walls built by whale step by step"
                }
        
        return {'should_trail': False}
    
    def detect_force_liquidation_trigger(self, df_1m: pd.DataFrame, current_idx: int) -> Dict:
        """
        Force Liquidation Trigger: Emergency escape when:
        1. Volume Outlier Anomaly: Volume of current live minute candle outside upper channel of StdDev for 50 minute candles (Z-Score Volume >3.5) terrifying sudden money pumping
        2. Close Position Collapse: Close_Position 1M = (Close-Low)/(High-Low) <0.15 - price closed collapsed in bottom abyss
        3. Vertical CVD Drop: Spot CVD records vertical sharp drop proving exit and liquidation of hundreds of millions market in these seconds
        """
        if current_idx < 50:
            return {'should_escape': False}
        
        candle = df_1m.iloc[current_idx]
        
        # 1. Volume Outlier: Z-Score >3.5
        vol_lookback = df_1m['volume'].iloc[current_idx-50:current_idx]
        vol_mean = vol_lookback.mean()
        vol_std = vol_lookback.std()
        if vol_std >0:
            z_vol = (candle['volume'] - vol_mean) / vol_std
        else:
            z_vol = 0
        is_vol_outlier = z_vol > 3.5
        
        # 2. Close Position Collapse <0.15
        hl_range = candle['high'] - candle['low']
        close_pos = (candle['close'] - candle['low']) / hl_range if hl_range>0 else 0.5
        is_close_collapse = close_pos < 0.15
        
        # 3. Vertical CVD Drop: calculate CVD
        # Simplified CVD: cumulative delta last 10 candles
        # Delta per candle = (close-low)/range -0.5 *2 * volume
        cvd_vals=[]
        running=0
        for j in range(max(0,current_idx-10), current_idx+1):
            row = df_1m.iloc[j]
            rng = row['high'] - row['low']
            if rng>0:
                buy_factor = (row['close']-row['low'])/rng
                delta = (buy_factor-0.5)*2*row['volume']
            else:
                delta=0
            running+=delta
            cvd_vals.append(running)
        
        # Vertical drop: last CVD vs previous CVD sharp down
        if len(cvd_vals)>=2:
            cvd_drop = cvd_vals[-1] - cvd_vals[-2]
            # Sharp drop if drop < -2*std of CVD changes
            cvd_changes = np.diff(cvd_vals)
            if len(cvd_changes)>=2:
                mean_change = np.mean(cvd_changes[:-1])
                std_change = np.std(cvd_changes[:-1])
                is_cvd_vertical_drop = cvd_drop < (mean_change - 2*std_change) and cvd_drop < 0
            else:
                is_cvd_vertical_drop = False
        else:
            is_cvd_vertical_drop = False
            cvd_drop = 0
        
        should_escape = is_vol_outlier and is_close_collapse and is_cvd_vertical_drop
        
        reason = ""
        if should_escape:
            reason = f"Force Liquidation Trigger: Volume Z-Score {z_vol:.2f}>3.5 terrifying sudden money pumping {candle['volume']} vs avg {vol_mean:.0f} + ClosePos {close_pos:.2f}<0.15 collapsed in bottom abyss + Vertical CVD Drop {cvd_drop:.0f} proving exit liquidation of hundreds of millions market in seconds - Power balance flipped geologically, giant whale flooding market with distribution, staying is dumb greed leaving money on table"
        
        return {
            'should_escape': should_escape,
            'z_vol': z_vol,
            'close_pos': close_pos,
            'cvd_drop': cvd_drop,
            'is_vol_outlier': is_vol_outlier,
            'is_close_collapse': is_close_collapse,
            'is_cvd_vertical_drop': is_cvd_vertical_drop,
            'reason': reason
        }
    
    def manage(self, df_5m: pd.DataFrame, df_15m: pd.DataFrame, df_1m: pd.DataFrame,
               entry_idx: int, entry_price: float, current_idx_5m: int, current_idx_15m: int, current_idx_1m: int,
               current_stop: float, tp1: float, tp2: float, remaining_pct: float) -> Dict:
        
        result = {
            'break_even_shift': None,
            'trailing_stop': None,
            'emergency_escape': None,
            'partial_tp1': None,
            'state': 'HOLD'
        }
        
        # 1. Break-even shift check
        be_res = self.manage_break_even(df_5m, entry_idx, entry_price, current_idx_5m)
        result['break_even_shift'] = be_res
        
        # 2. Check TP1 reached (previous confirmed swing high)
        current_price_5m = df_5m['close'].iloc[current_idx_5m] if current_idx_5m < len(df_5m) else entry_price
        if current_price_5m >= tp1 and remaining_pct == 100:
            # Sell 50% at TP1
            result['partial_tp1'] = {
                'should_sell': True,
                'percent': 50,
                'price': tp1,
                'reason': f"Price reached TP1 {tp1} = Last_Confirmed_Swing_High previous high that started correction teems with sell distribution orders for other whales and scared beginners; securing half profits is survival doctrine"
            }
            result['state'] = 'PARTIAL_TP1_EXECUTED'
        
        # 3. Trailing stop behind new bullish OBs
        if remaining_pct <= 50:  # After TP1, trailing remaining 50%
            trail_res = self.detect_new_bullish_obs_trailing(df_15m, current_stop)
            result['trailing_stop'] = trail_res
            if trail_res['should_trail']:
                result['state'] = 'TRAILING_STOP_UPDATED'
        
        # 4. Emergency escape check
        escape_res = self.detect_force_liquidation_trigger(df_1m, current_idx_1m)
        result['emergency_escape'] = escape_res
        if escape_res['should_escape']:
            result['state'] = 'EMERGENCY_SELL_100_PERCENT'
        
        return result
