"""
LTF CHoCH Detector - Second Map Station 2
Philosophy: In depth of low, general psychology still bearish fearful. Small traders keep selling every small bounce.
Bearish Order Blocks left behind successive lower highs during collapse.
True CHoCH is bullish breakout of latest and last lower high that directly caused last price low before HTF Sweep.
Mechanical: breaking this specific high means consuming all pending sell orders of bearish institutions and starting aggressive buying.

Protocol:
1. Invalidation High: Scan descending from sweep moment, find exact price of highest point in bearish candle that preceded last collapse wave directly. Store as LTF_Recent_Lower_High.
2. CHoCH Validation:
   - Body Displacement Rule: Close[Y] > LTF_Recent_Lower_High - strict ICT: if only wick High breaks and closes below, CHoCH canceled immediately. Body must fully settle above sub-ceiling.
   - Momentum Slope: calculate angle of bullish breaking candles vs bearish collapsing candles. Green bullish rate must be at least 2x faster than red bearish.
Traps:
- Minor Internal Structure Trap: Price bounces and breaks very small high formed between two bearish candles inside collapse wave. Classic dumb bots think CHoCH and buy, then collapse continues. Filter: Structural Significance Filter: distance between sub low and target high must be > ATR(14)*1.5, else Internal Noise.
- Illiquid Character Change: 15m candle closes above invalidation high with full body but Volume dead small and no Spot CVD rise. Analyze Effort vs Result: Price rose only because sellers withdrew temporarily, not because whale pumped new buying liquidity. Reject as Exhaustion Break.

State Update:
HTF_State: Liquidity_Swept_At_4H_Low
LTF_State: CHoCH_Confirmed_Bullish
Verified_LTF_Origin_Low: e.g., 82.05
CHoCH_Breakout_Price: e.g., 88.50
Adaptive_Engine_Status: PREPARE_FOR_DISCOUNT_ARRAY_AND_OB_HUNTING

Sources:
- CHOCH = break of most recent higher low (bullish trend) or lower high (bearish trend) confirming long-term reversal [ICT abbreviations]
- CHoCH vs MSS: CHoCH slower softer warning without displacement, MSS harder confirmation with displacement [innercircletrader MSS]
- Require body close not wick, wick increases false break [tradingfinder, 3commas: Require full candle body to close beyond protected swing point, not just wick][innercircletrader BOS vs CHOCH: body close confirmation]
- Confirm CHoCH with 3 checks: body close, displacement fast strong ideally volume spike leaving FVG, prefer sweep preceded [3commas]
- Structural significance: distance > ATR*1.5 else internal noise [in.tradingview choch scripts: ATR multiple filter][fxnx: Misinterpreting Internal Structure - break of minor internal is NOT CHoCH, only major swing points count]
- CHoCH early warning not confirmation, always wait for displacement [trenddaytrader]
- LTF CHoCH is entry trigger only when inside HTF-aligned zone [quantum-algo: LTF CHoCH is your entry trigger only when it occurs inside HTF-aligned zone]
"""
import pandas as pd
import numpy as np
from typing import Dict, List
from sklearn.linear_model import LinearRegression

class LTF_CHoCH_Signal:
    def __init__(self, index, price, type):
        self.index = index
        self.price = price
        self.type = type  # VALID_CHOCH, INTERNAL_NOISE, EXHAUSTION_BREAK, WICK_ONLY
        self.target_high = None
        self.target_high_index = None
        self.close_position = None
        self.momentum_ratio = None
        self.distance_atr_ratio = None
        self.volume = None
        self.volume_spike = False
        self.cvd_divergence = False
        self.is_valid = False
        self.reason = ""
    
    def to_dict(self):
        return {
            'index': self.index,
            'price': self.price,
            'type': self.type,
            'target_high': self.target_high,
            'target_high_index': self.target_high_index,
            'close_position': self.close_position,
            'momentum_ratio': self.momentum_ratio,
            'distance_atr_ratio': self.distance_atr_ratio,
            'volume': self.volume,
            'volume_spike': self.volume_spike,
            'cvd_divergence': self.cvd_divergence,
            'is_valid': self.is_valid,
            'reason': self.reason
        }

class LTFChoCHDetector:
    def __init__(self, atr_period=14, significance_atr_factor=1.5, momentum_factor=2.0):
        self.atr_period = atr_period
        self.sig_factor = significance_atr_factor
        self.mom_factor = momentum_factor
    
    def calculate_atr(self, df):
        tr1 = df['high'] - df['low']
        tr2 = (df['high'] - df['close'].shift()).abs()
        tr3 = (df['low'] - df['close'].shift()).abs()
        tr = pd.concat([tr1,tr2,tr3], axis=1).max(axis=1)
        atr = tr.rolling(self.atr_period).mean().fillna(tr.mean())
        return atr
    
    def calculate_cvd(self, df):
        cvd=[]
        running=0
        for _,row in df.iterrows():
            hl=row['high']-row['low']
            if hl>0:
                buy_factor=(row['close']-row['low'])/hl
                delta_factor=(buy_factor-0.5)*2
                delta=delta_factor*row['volume']
            else:
                delta=0
            running+=delta
            cvd.append(running)
        return pd.Series(cvd, index=df.index)
    
    def find_recent_lower_high(self, df: pd.DataFrame, sweep_idx: int) -> Dict:
        """
        Scan descending from sweep moment, find exact price of highest point in bearish candle that preceded last collapse wave directly.
        This is LTF_Recent_Lower_High - the inevitable invalidation high.
        """
        # Look back 30 candles from sweep
        start = max(0, sweep_idx-30)
        # Find last bearish impulse before sweep that caused last low
        # We want the last swing high that is higher than surrounding and whose following low is the lowest low
        # Simplified: find local highs before sweep
        local_highs=[]
        for j in range(start, sweep_idx):
            if j>0 and j < len(df)-1:
                # Local high: high higher than neighbors
                if df['high'].iloc[j] > df['high'].iloc[j-1] and df['high'].iloc[j] >= df['high'].iloc[j+1]:
                    # And following candles are bearish down to sweep low
                    # Check if this high's next low is close to sweep low?
                    local_highs.append((j, df['high'].iloc[j], df['low'].iloc[j]))
        
        if not local_highs:
            # Fallback: take max high in last 20 before sweep
            segment = df.iloc[start:sweep_idx]
            if len(segment)>0:
                max_idx = segment['high'].idxmax()
                # Convert idxmax which returns label index to positional
                if isinstance(max_idx, int):
                    pos = max_idx
                else:
                    # If timestamp index, find positional
                    pos = df.index.get_loc(max_idx) if max_idx in df.index else start
                return {'index': pos, 'price': df['high'].iloc[pos], 'low_before': df['low'].iloc[pos]}
            return None
        
        # The recent lower high is the last one before sweep (most recent)
        last_high_idx, last_high_price, _ = local_highs[-1]
        
        # Find the low that this high caused (lowest low after this high and before sweep)
        after_high = df.iloc[last_high_idx:sweep_idx]
        if len(after_high)>0:
            lowest_low = after_high['low'].min()
        else:
            lowest_low = df['low'].iloc[sweep_idx]
        
        return {'index': last_high_idx, 'price': last_high_price, 'low_caused': lowest_low}
    
    def calculate_momentum_slope(self, df: pd.DataFrame, target_idx: int, choch_idx: int) -> Dict:
        """
        Momentum Slope: angle of bullish breaking candles vs bearish collapsing candles
        Green bullish rate must be at least 2x faster than red bearish rate = Displacement
        """
        # Bearish collapsing: candles from target_high index to choch_idx-1 that are bearish down
        # Actually bearish collapsing before sweep? We want bearish slope before target high?
        # Simplified: last 5 bearish candles before target high vs first 3 bullish after target high break
        
        # Bearish segment: 5 candles before target
        bear_start = max(0, target_idx-5)
        bear_segment = df.iloc[bear_start:target_idx]
        bear_closes = bear_segment['close'].values
        if len(bear_closes) >=2:
            x = np.arange(len(bear_closes)).reshape(-1,1)
            y = bear_closes
            model = LinearRegression().fit(x,y)
            bear_slope = model.coef_[0]  # should be negative
        else:
            bear_slope = -0.1
        
        # Bullish breaking: candles from target to choch
        bull_segment = df.iloc[target_idx:choch_idx+1]
        bull_closes = bull_segment['close'].values
        if len(bull_closes) >=2:
            x = np.arange(len(bull_closes)).reshape(-1,1)
            y = bull_closes
            model = LinearRegression().fit(x,y)
            bull_slope = model.coef_[0]  # should be positive
        else:
            bull_slope = 0.1
        
        # Ratio: bullish speed vs bearish speed absolute
        bull_abs = abs(bull_slope)
        bear_abs = abs(bear_slope)
        ratio = bull_abs / bear_abs if bear_abs>0 else 0
        
        return {
            'bear_slope': bear_slope,
            'bull_slope': bull_slope,
            'ratio': ratio,
            'is_displacement': ratio >= self.mom_factor
        }
    
    def analyze_candle(self, df: pd.DataFrame, idx: int, target_high_info: Dict, atr_series: pd.Series, cvd_series: pd.Series) -> LTF_CHoCH_Signal:
        candle = df.iloc[idx]
        target_price = target_high_info['price']
        target_idx = target_high_info['index']
        
        signal = LTF_CHoCH_Signal(idx, candle['close'], 'UNKNOWN')
        signal.target_high = target_price
        signal.target_high_index = target_idx
        signal.volume = candle['volume']
        
        # Distance between sub low and target high must be > ATR*1.5 else Internal Noise
        # Sub low = lowest low between target high and choch candle? Actually low that target high caused
        sub_low = target_high_info.get('low_caused', df['low'].iloc[target_idx:idx].min() if idx>target_idx else candle['low'])
        distance = target_price - sub_low
        atr = atr_series.iloc[idx]
        distance_atr_ratio = distance / atr if atr>0 else 0
        signal.distance_atr_ratio = distance_atr_ratio
        
        # Structural Significance Filter
        if distance_atr_ratio < self.sig_factor:
            signal.type = 'INTERNAL_NOISE'
            signal.is_valid = False
            signal.reason = f"Internal Noise: Distance target high {target_price:.2f} - sub low {sub_low:.2f} = {distance:.2f} = {distance_atr_ratio:.2f} ATR < {self.sig_factor} ATR => قمة صغيرة جداً تشكلت بين شمعتين هابطتين داخل الموجة الانهيارية، تجاهلها تماماً"
            return signal
        
        # Body Displacement Rule: Close > Target
        close = candle['close']
        high = candle['high']
        
        if high > target_price and close <= target_price:
            # Wick only
            signal.type = 'WICK_ONLY'
            signal.is_valid = False
            signal.reason = f"Wick Only: High {high:.2f} اخترق القمة {target_price:.2f} لكن Close {close:.2f} عاد أسفلها، يلغى CHoCH فوراً - يجب أن يستقر جسم الشمعة بالكامل فوق السقف الفرعي"
            return signal
        
        if close <= target_price:
            # No break at all
            return None
        
        # At this point Close > Target => potential CHoCH
        
        # Momentum Slope
        mom_info = self.calculate_momentum_slope(df, target_idx, idx)
        signal.momentum_ratio = mom_info['ratio']
        
        if not mom_info['is_displacement']:
            # Not fast enough, but still could be valid if volume spike?
            # For strict, require displacement
            pass  # we will check volume next
        
        # Volume and CVD check
        # Volume spike?
        lookback = 20
        start = max(0, idx-lookback)
        vol_mean = df['volume'].iloc[start:idx].mean() if idx>start else candle['volume']
        vol_std = df['volume'].iloc[start:idx].std() if idx>start else 0
        vol_upper = vol_mean + 2*vol_std if vol_std>0 else vol_mean*2
        is_vol_spike = candle['volume'] > vol_upper
        
        signal.volume_spike = is_vol_spike
        
        # CVD check: is CVD rising during bullish break?
        if idx >= 1:
            cvd_now = cvd_series.iloc[idx]
            cvd_prev = cvd_series.iloc[idx-1]
            cvd_rising = cvd_now > cvd_prev
        else:
            cvd_rising = False
        
        signal.cvd_divergence = cvd_rising
        
        # Illiquid Character Change Trap
        if not is_vol_spike and not cvd_rising:
            signal.type = 'EXHAUSTION_BREAK'
            signal.is_valid = False
            signal.reason = f"Exhaustion Break: Close {close:.2f}>{target_price:.2f} بجسم ممتلئ لكن Volume {candle['volume']} ميت وصغير (mean {vol_mean:.0f}) ولا يوجد ارتفاع في Spot CVD - السعر ارتفع فقط لأن البائعين انسحبوا مؤقتاً لتعبئة أوامر أعلى، وليس لأن الحوت ضخ سيولة شرائية جديدة"
            return signal
        
        # Valid CHoCH
        if mom_info['is_displacement'] and (is_vol_spike or cvd_rising):
            signal.type = 'VALID_CHOCH'
            signal.is_valid = True
            signal.reason = f"VALID CHoCH: Close {close:.2f}>{target_price:.2f} body displacement + Momentum Ratio {mom_info['ratio']:.2f}x >=2x (bull {mom_info['bull_slope']:.4f} vs bear {mom_info['bear_slope']:.4f}) + Distance {distance_atr_ratio:.2f} ATR >{self.sig_factor} + Volume Spike {is_vol_spike} + CVD Rising {cvd_rising} - اختراق القمة الفاصلة الحتمية التي تسببت مباشرة في القاع الأخير قبل الجرف، استهلاك أوامر البيع المعلقة للمؤسسات الهابطة وبدء ضخ سيولة شرائية عدوانية"
            return signal
        else:
            # Weak but still valid if body close true?
            signal.type = 'VALID_CHOCH_WEAK'
            signal.is_valid = True
            signal.reason = f"VALID CHoCH Weak: Close above target but momentum ratio {mom_info['ratio']:.2f} <2x or volume not spike, still valid as per adaptive"
            return signal
    
    def detect(self, df: pd.DataFrame, sweep_idx: int) -> List[LTF_CHoCH_Signal]:
        # Find recent lower high
        target_info = self.find_recent_lower_high(df, sweep_idx)
        if not target_info:
            return []
        
        atr_series = self.calculate_atr(df)
        cvd_series = self.calculate_cvd(df)
        
        signals = []
        
        # Look for CHoCH after sweep
        for idx in range(sweep_idx+1, len(df)):
            sig = self.analyze_candle(df, idx, target_info, atr_series, cvd_series)
            if sig:
                signals.append(sig)
                if sig.is_valid and sig.type.startswith('VALID'):
                    break  # First valid CHoCH is the revolution
        
        return signals
    
    def analyze(self, df: pd.DataFrame, sweep_idx: int) -> Dict:
        signals = self.detect(df, sweep_idx)
        
        valid = [s for s in signals if s.is_valid]
        internal_noise = [s for s in signals if s.type=='INTERNAL_NOISE']
        wick_only = [s for s in signals if s.type=='WICK_ONLY']
        exhaustion = [s for s in signals if s.type=='EXHAUSTION_BREAK']
        
        state = "WAITING_CHOCH"
        cognitive = {}
        if valid:
            last_valid = valid[-1]
            state = "CHoCH_Confirmed_Bullish"
            cognitive = {
                "HTF_State": "Liquidity_Swept_At_4H_Low",
                "LTF_State": "CHoCH_Confirmed_Bullish",
                "Verified_LTF_Origin_Low": df['low'].iloc[sweep_idx],
                "CHoCH_Breakout_Price": last_valid.price,
                "Target_High": last_valid.target_high,
                "CHoCH_Index": last_valid.index,
                "Adaptive_Engine_Status": "PREPARE_FOR_DISCOUNT_ARRAY_AND_OB_HUNTING"
            }
        
        return {
            'all_signals': [s.to_dict() for s in signals],
            'valid_choch': [s.to_dict() for s in valid],
            'internal_noise': [s.to_dict() for s in internal_noise],
            'wick_only': [s.to_dict() for s in wick_only],
            'exhaustion': [s.to_dict() for s in exhaustion],
            'state': state,
            'cognitive': cognitive,
            'total': len(signals)
        }
