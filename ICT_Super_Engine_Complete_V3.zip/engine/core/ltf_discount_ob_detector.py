"""
LTF Discount Matrix + LTF Order Blocks - Second Map Station 3
Philosophy: In bearish HTF but LTF counter-rally, move is fleeting and hasty.
Whale swept HTF low and pumped CHoCH, wants to raise price quickly to fill gaps above and distribute there.
He will return down only for mitigation of pending contracts, won't wait long.

Mechanism:
1. Micro Bounds:
- LTF_Origin_Low = deepest sub low formed during liquidity sweep =0%
- LTF_Validation_High = highest peak reached by CHoCH rocket rebound =100%

2. Dynamic Equilibrium via Micro-POC:
Micro-POC = price levels that saw highest volume injection in CHoCH candle itself
LTF_Dynamic_Equilibrium = (Micro-POC + Median 50%)/2
Strict: Forbid Spot Buy entirely above this level

3. LTF Bullish OB Double Institutional Immunity Filter:
- Internal Liquidity Grab: bearish candle's lower wick must have broken/swept liquidity of immediately preceding sub candle
- Engulfing & Displacement: following candle directly (or within 2) must engulf opening price entirely, close full body, leave untouched LTF FVG

Traps:
- Premium Churning Trap: after CHoCH, price moves sideways with tiny candles dead volume above DynamicEq. Dumb bots think accumulation and buy, then collapse breaks bottom.
  Detection: Volume-to-Range Decay: price sideways in premium zone with volume < avg by 60% => no new whale buys, deadly dormancy due to absence of buyers => block buying

- OB Breaker Trap: price drops to LTF OB but drop is single huge Marubozu bearish, pierces OB smoothly closes below
  Detection: Attack Energy via ratio of bodies last 3 corrective candles increasing sharply + selling volume rising outside std dev => not soft retracement, big timeframe sellers regained control, wall-breaking attack => cancel pending buy immediately

State Update: Market_Context Bearish_HTF_But_LTF_Counter_Rally, Target LTF OB Zone High/Low, DynamicEq, Action ALLOW_MONITORING_FOR_EXECUTION_TRIGGERS
"""

import pandas as pd
import numpy as np
from typing import List, Dict
from sklearn.linear_model import LinearRegression

class LTF_OB:
    def __init__(self, index, high, low):
        self.index = index
        self.high = high
        self.low = low
        self.mid = (high+low)/2
        self.is_valid = False
        self.is_mitigated = False
        self.internal_liquidity_grab = False
        self.engulfing_displacement = False
        self.parent_fvg = None
        self.reason = ""
    
    def to_dict(self):
        return {
            'index': self.index,
            'high': self.high,
            'low': self.low,
            'mid': self.mid,
            'is_valid': self.is_valid,
            'is_mitigated': self.is_mitigated,
            'internal_grab': self.internal_liquidity_grab,
            'engulf_disp': self.engulfing_displacement,
            'reason': self.reason
        }

class LTF_Discount_Signal:
    def __init__(self):
        self.origin_low = None
        self.validation_high = None
        self.micro_poc = None
        self.median_50 = None
        self.dynamic_eq = None
        self.premium_zone = None
        self.discount_zone = None
        self.is_premium_churning_trap = False
        self.is_ob_breaker_trap = False
        self.target_ob_zone = None
        self.cognitive = {}
    
    def to_dict(self):
        return {
            'origin': self.origin_low,
            'validation_high': self.validation_high,
            'micro_poc': self.micro_poc,
            'median_50': self.median_50,
            'dynamic_eq': self.dynamic_eq,
            'premium_zone': self.premium_zone,
            'discount_zone': self.discount_zone,
            'is_premium_churning': self.is_premium_churning_trap,
            'is_breaker': self.is_ob_breaker_trap,
            'target_ob': self.target_ob_zone,
            'cognitive': self.cognitive
        }

class LTFDiscountOBDetector:
    def __init__(self, atr_period=14):
        self.atr_period = atr_period
    
    def calculate_atr(self, df):
        tr1 = df['high']-df['low']
        tr2 = (df['high']-df['close'].shift()).abs()
        tr3 = (df['low']-df['close'].shift()).abs()
        tr = pd.concat([tr1,tr2,tr3], axis=1).max(axis=1)
        return tr.rolling(self.atr_period).mean().fillna(tr.mean())
    
    def find_micro_bounds(self, df: pd.DataFrame, choch_idx: int):
        """
        LTF_Origin_Low = deepest sub low formed during liquidity sweep (lowest low in last 20 before CHoCH)
        LTF_Validation_High = highest peak reached by CHoCH rocket rebound and started retracing from (max high after CHoCH until pullback)
        """
        # Origin: lowest low in 20 candles before and including CHoCH sweep low?
        # For simplicity, lowest low in last 20 before choch_idx
        start = max(0, choch_idx-20)
        origin_low = df['low'].iloc[start:choch_idx+1].min()
        origin_idx = df['low'].iloc[start:choch_idx+1].idxmin()
        if isinstance(origin_idx, str):
            origin_idx = df.index.get_loc(origin_idx) if origin_idx in df.index else start
        
        # Validation High: highest high after CHoCH until first pullback (next 10 candles after choch)
        end = min(len(df), choch_idx+10)
        validation_high = df['high'].iloc[choch_idx:end].max()
        validation_idx = df['high'].iloc[choch_idx:end].idxmax()
        
        return {
            'origin_low': origin_low,
            'origin_idx': origin_idx if isinstance(origin_idx,int) else df.index.get_loc(origin_idx) if origin_idx in df.index else start,
            'validation_high': validation_high,
            'validation_idx': validation_idx if isinstance(validation_idx,int) else df.index.get_loc(validation_idx) if validation_idx in df.index else choch_idx,
        }
    
    def calculate_micro_poc(self, df: pd.DataFrame, choch_idx: int):
        """
        Micro-POC = price levels that saw highest volume injection in CHoCH candle itself
        For CHoCH candle, typical price = (high+low+close)/3, but micro-POC we can approximate as high volume node inside CHoCH candle's range
        Simpler: POC = typical price of CHoCH candle with highest volume, or VWAP of CHoCH candle's range?
        We'll take CHoCH candle's typical price as micro-POC, or if CHoCH consists of multiple candles (displacement leg), take volume-weighted average price of those candles
        """
        choch_candle = df.iloc[choch_idx]
        # Typical price
        typical = (choch_candle['high'] + choch_candle['low'] + choch_candle['close'])/3
        
        # If displacement leg is 2-3 candles, take VWAP of leg
        # Find displacement leg: consecutive bullish candles with large bodies before choch_idx
        # For simplicity, take average of last 3 bullish candles volume-weighted
        start = max(0, choch_idx-3)
        leg = df.iloc[start:choch_idx+1]
        bullish_leg = leg[leg['close'] > leg['open']]
        if len(bullish_leg) >0:
            # VWAP
            vwap = (bullish_leg['close'] * bullish_leg['volume']).sum() / bullish_leg['volume'].sum() if bullish_leg['volume'].sum()>0 else typical
            micro_poc = vwap
        else:
            micro_poc = typical
        
        return micro_poc
    
    def detect_ltf_bullish_obs(self, df: pd.DataFrame, discount_low: float, discount_high: float, choch_idx: int) -> List[LTF_OB]:
        """
        Double Institutional Immunity Filter:
        1. Internal Liquidity Grab: bearish candle's lower wick must have broken/swept liquidity of immediately preceding sub candle
        2. Engulfing & Displacement: following candle directly (or within 2) must engulf opening price entirely, close full body, leave untouched LTF FVG
        Only inside targeted discount zone
        """
        obs=[]
        for i in range(1, len(df)-1):
            # Only inside discount zone (price of OB inside discount)
            # OB price should be within discount zone (below dynamic eq)
            # We'll filter later after dynamic eq known, for now check if low within [origin, validation_high] and below high
            # But we need discount range, we will pass later
            prev = df.iloc[i-1]
            curr = df.iloc[i]  # candidate bearish OB
            next_c = df.iloc[i+1] if i+1 < len(df) else None
            next2 = df.iloc[i+2] if i+2 < len(df) else None
            
            # Must be bearish candle
            if not (curr['close'] < curr['open']):
                continue
            
            # Filter 1: Internal Liquidity Grab
            # Lower wick of curr must have broken/swept low of prev sub candle
            curr_lower_wick = min(curr['open'], curr['close']) - curr['low']
            prev_low = prev['low']
            # Sweep if curr low < prev low
            internal_grab = curr['low'] < prev_low
            
            # Also check if curr low broke recent sub low (lowest low of last 5)
            recent_lows = df['low'].iloc[max(0,i-5):i]
            if len(recent_lows)>0:
                recent_min = recent_lows.min()
                internal_grab = internal_grab or (curr['low'] < recent_min)
            
            if not internal_grab:
                continue
            
            # Filter 2: Engulfing & Displacement
            # Next candle must engulf opening price entirely, close full body, leave FVG
            # Check next 1 or 2 candles
            engulf_found = False
            fvg_found = False
            for nxt in [next_c, next2]:
                if nxt is None:
                    continue
                # Engulf: nxt close > curr open entirely (bullish engulf)
                if nxt['close'] > curr['open'] and nxt['open'] < curr['close']:
                    # Full body close: close in upper part of range?
                    hl_range = nxt['high'] - nxt['low']
                    close_pos = (nxt['close'] - nxt['low']) / hl_range if hl_range>0 else 0
                    if close_pos > 0.6:  # bullish full body
                        # Displacement: body > ATR*0.5 and leaves FVG
                        # FVG check: High prev < Low next?
                        # For bullish FVG after OB: High of curr < Low of next2?
                        # Simplified: check if nxt high leaves gap with next candle low?
                        # We'll check if there is FVG between curr and nxt+1
                        # For this detection, we check if nxt's low > curr's high? No that would be bearish gap
                        # For bullish after bearish OB: we want bullish FVG where High of curr (OB) < Low of next bullish's next candle?
                        # Actually bullish FVG forms when High C1 < Low C3
                        # Let C1 = curr (OB bearish), C2 = nxt (bullish displacement), C3 = next after nxt
                        # So we need to check if curr high < low of candle after nxt
                        if next2 is not None:
                            if curr['high'] < next2['low']:
                                fvg_found = True
                        else:
                            # If only next candle, check if it leaves small gap with prev? Simplified
                            pass
                        
                        # If engulf and (displacement large), consider valid even if FVG not yet formed? But spec says must leave FVG
                        # For now, require body large
                        body = abs(nxt['close'] - nxt['open'])
                        atr = (df['high'].iloc[max(0,i-14):i+1] - df['low'].iloc[max(0,i-14):i+1]).mean()
                        if body > atr*0.5:
                            engulf_found = True
                            break
            
            if not engulf_found:
                continue
            
            # Valid OB
            ob = LTF_OB(i, curr['high'], curr['low'])
            ob.internal_liquidity_grab = internal_grab
            ob.engulfing_displacement = engulf_found
            ob.is_valid = True
            ob.reason = f"Internal Grab {curr['low']:.2f}<{prev_low:.2f} + Engulf Close {next_c['close']:.2f}>{curr['open']:.2f} + Displacement body"
            obs.append(ob)
        
        return obs
    
    def detect_premium_churning_trap(self, df: pd.DataFrame, dynamic_eq: float, current_idx: int) -> Dict:
        """
        Premium Churning Trap: after CHoCH, price moves sideways with tiny candles dead volume above DynamicEq
        Volume-to-Range Decay: price sideways in premium zone with volume < avg by 60%
        """
        # Look at last 10 candles before current
        lookback = 10
        start = max(0, current_idx-lookback)
        segment = df.iloc[start:current_idx+1]
        
        # Filter candles in premium zone (close > dynamic_eq)
        premium_candles = segment[segment['close'] > dynamic_eq]
        
        if len(premium_candles) < 5:
            return {'is_trap': False}
        
        # Check if sideways: high-low range small vs ATR, and volume < avg by 60%
        avg_range = (premium_candles['high'] - premium_candles['low']).mean()
        atr = (df['high'].iloc[max(0,current_idx-14):current_idx+1] - df['low'].iloc[max(0,current_idx-14):current_idx+1]).mean()
        
        is_sideways = avg_range < atr*0.5 if atr>0 else False
        
        avg_vol = df['volume'].mean()
        premium_vol_avg = premium_candles['volume'].mean()
        vol_decay = premium_vol_avg < avg_vol*0.4  # less than avg by 60%
        
        is_trap = is_sideways and vol_decay
        
        return {
            'is_trap': is_trap,
            'avg_range': avg_range,
            'atr': atr,
            'premium_vol_avg': premium_vol_avg,
            'avg_vol': avg_vol,
            'vol_decay_ratio': premium_vol_avg/avg_vol if avg_vol>0 else 1
        }
    
    def detect_ob_breaker_trap(self, df: pd.DataFrame, ob: LTF_OB, current_idx: int) -> Dict:
        """
        OB Breaker Trap: price drops to LTF OB but drop is single huge Marubozu bearish, pierces OB smoothly closes below
        Attack Energy: ratio of bodies last 3 corrective candles increasing sharply + selling volume rising outside std dev
        """
        # Find candles from recent high to OB touch
        # For simplicity, last 3 candles before current that are bearish corrective
        lookback = 5
        start = max(0, current_idx-lookback)
        segment = df.iloc[start:current_idx+1]
        bearish = segment[segment['close'] < segment['open']]
        
        if len(bearish) < 3:
            return {'is_trap': False}
        
        bodies = abs(bearish['close'] - bearish['open']).values
        volumes = bearish['volume'].values
        
        # Check if bodies increasing sharply
        # Linear regression slope positive and last body huge > ATR
        if len(bodies) >= 3:
            x = np.arange(len(bodies)).reshape(-1,1)
            model = LinearRegression().fit(x, bodies)
            slope_body = model.coef_[0]
            body_increasing = slope_body > 0 and bodies[-1] > np.mean(bodies[:-1])*1.5 if len(bodies)>1 else False
        else:
            body_increasing = False
            slope_body = 0
        
        # Volume rising outside std dev?
        if len(volumes) >=3:
            x = np.arange(len(volumes)).reshape(-1,1)
            model_v = LinearRegression().fit(x, volumes)
            slope_vol = model_v.coef_[0]
            vol_mean = df['volume'].iloc[max(0,current_idx-20):current_idx].mean()
            vol_std = df['volume'].iloc[max(0,current_idx-20):current_idx].std()
            vol_upper = vol_mean + 2*vol_std if vol_std>0 else vol_mean*2
            last_vol = volumes[-1]
            vol_rising = slope_vol>0 and last_vol > vol_upper
        else:
            vol_rising = False
            slope_vol = 0
        
        # Check if last bearish is Marubozu: body close to full range, small wicks
        if len(bearish)>0:
            last = bearish.iloc[-1]
            hl_range = last['high'] - last['low']
            body = abs(last['close'] - last['open'])
            body_ratio = body / hl_range if hl_range>0 else 0
            is_marubozu = body_ratio > 0.8
        else:
            is_marubozu = False
        
        is_trap = body_increasing and vol_rising and is_marubozu
        
        return {
            'is_trap': is_trap,
            'body_increasing': body_increasing,
            'vol_rising': vol_rising,
            'is_marubozu': is_marubozu,
            'slope_body': slope_body,
            'slope_vol': slope_vol if 'slope_vol' in locals() else 0
        }
    
    def analyze(self, df: pd.DataFrame, choch_idx: int, current_idx: int=None) -> LTF_Discount_Signal:
        if current_idx is None:
            current_idx = len(df)-1
        
        bounds = self.find_micro_bounds(df, choch_idx)
        origin_low = bounds['origin_low']
        validation_high = bounds['validation_high']
        
        micro_poc = self.calculate_micro_poc(df, choch_idx)
        median_50 = (origin_low + validation_high)/2
        dynamic_eq = (micro_poc + median_50)/2
        
        signal = LTF_Discount_Signal()
        signal.origin_low = origin_low
        signal.validation_high = validation_high
        signal.micro_poc = micro_poc
        signal.median_50 = median_50
        signal.dynamic_eq = dynamic_eq
        signal.premium_zone = (dynamic_eq, validation_high)
        signal.discount_zone = (origin_low, dynamic_eq)
        
        # Premium Churning Trap check
        churn_check = self.detect_premium_churning_trap(df, dynamic_eq, current_idx)
        signal.is_premium_churning_trap = churn_check['is_trap']
        
        # Find LTF OBs inside discount
        all_obs = self.detect_ltf_bullish_obs(df, origin_low, dynamic_eq, choch_idx)
        # Filter OBs inside discount zone
        discount_obs = [ob for ob in all_obs if ob.low >= origin_low and ob.high <= dynamic_eq]
        
        # Check OB Breaker Trap for each OB
        breaker_traps = []
        for ob in discount_obs:
            breaker_check = self.detect_ob_breaker_trap(df, ob, current_idx)
            if breaker_check['is_trap']:
                ob.is_valid = False
                breaker_traps.append(ob)
        
        valid_obs = [ob for ob in discount_obs if ob.is_valid and ob not in breaker_traps]
        
        if valid_obs:
            # Target OB zone: most recent valid OB
            last_ob = valid_obs[-1]
            signal.target_ob_zone = {'High': last_ob.high, 'Low': last_ob.low}
        else:
            signal.target_ob_zone = None
        
        # Cognitive state
        current_price = df['close'].iloc[current_idx]
        if current_price > dynamic_eq:
            if churn_check['is_trap']:
                action = "Block BUY immediately and cancel trade idea temporarily - No new whale buys, deadly dormancy due to absence of buyers"
                state = "PREMIUM_CHURNING_TRAP"
            else:
                action = "Price in Premium - No Buy"
                state = "IN_PREMIUM"
        else:
            if breaker_traps:
                action = "Cancel pending buy immediately - Big timeframe sellers regained control, wall-breaking attack, step aside without hanging any dollar"
                state = "OB_BREAKER_TRAP"
            elif valid_obs:
                action = "ALLOW_MONITORING_FOR_EXECUTION_TRIGGERS"
                state = "IN_DISCOUNT_VALID_OB"
            else:
                action = "In Discount but no valid OB yet - waiting"
                state = "IN_DISCOUNT_NO_OB"
        
        signal.cognitive = {
            "Market_Context": "Bearish_HTF_But_LTF_Counter_Rally",
            "Target_LTF_OB_Zone": signal.target_ob_zone,
            "Dynamic_Equilibrium_Line": dynamic_eq,
            "Action_Status": action,
            "State": state,
            "Premium_Churning_Check": churn_check,
            "Num_Valid_OBs": len(valid_obs),
            "Num_Breaker_Traps": len(breaker_traps)
        }
        
        signal.is_ob_breaker_trap = len(breaker_traps) >0
        
        return signal
