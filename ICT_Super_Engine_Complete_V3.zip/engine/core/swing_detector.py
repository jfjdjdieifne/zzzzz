"""
True Protected Low - Thinking Engine not Fixed Numbers
Implements:
- Selling Momentum Velocity (dynamic relativity)
- Dynamic Rejection Filter (Avg Wick * 2.5)
- Ghost Support Trap (Spot CVD / Volume Delta)
- Trendline Liquidity Trap (Linear Regression R2 >0.95)
- Under Verification State (Causality BOS/CHoCH)
Based on ICT + LuxAlgo Protected Swings + Behavioral Unit Testing
"""
import pandas as pd
import numpy as np
from typing import List, Dict, Tuple
from sklearn.linear_model import LinearRegression

class SwingPoint:
    def __init__(self, index, timestamp, price, type, atr=None):
        self.index = index
        self.timestamp = timestamp
        self.price = price
        self.type = type
        self.protected = False
        self.protection_index = None
        self.confirmation_level = None
        self.sweep_detected = False
        self.atr_at_formation = atr
        # New thinking fields
        self.selling_velocity = None  # decreasing?
        self.rejection_ratio = None  # wick vs avg_wick
        self.is_ghost_support = False
        self.is_trendline_trap = False
        self.verification_state = "PENDING"  # PENDING, VERIFIED, FAILED
        self.target_high_for_bos = None
        
    def to_dict(self):
        return {
            'index': self.index,
            'price': self.price,
            'type': self.type,
            'protected': self.protected,
            'confirmation_level': self.confirmation_level,
            'sweep': self.sweep_detected,
            'selling_velocity': self.selling_velocity,
            'rejection_ratio': self.rejection_ratio,
            'is_ghost': self.is_ghost_support,
            'is_trap': self.is_trendline_trap,
            'verification': self.verification_state,
            'target_high': self.target_high_for_bos
        }

class ProtectedSwingDetector:
    """
    Behavioral Causality Engine:
    Event B can only happen if Event A had enough energy.
    No fixed dumb numbers except proven: 50% equilibrium, 0.05% tolerance, 95% R2
    All else is Contextual Relativity
    """
    def __init__(self, pivot_length=3, atr_period=14):
        self.pivot_length = pivot_length
        self.atr_period = atr_period
        
    def calculate_atr(self, df: pd.DataFrame) -> pd.Series:
        high = df['high']
        low = df['low']
        close = df['close']
        tr1 = high - low
        tr2 = (high - close.shift()).abs()
        tr3 = (low - close.shift()).abs()
        tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
        atr = tr.rolling(max(2, len(df)//2)).mean() if len(df) < self.atr_period else tr.rolling(self.atr_period).mean()
        atr = atr.fillna(tr.expanding().mean()).fillna(0.5)
        return atr
    
    def detect_swings(self, df: pd.DataFrame) -> List[SwingPoint]:
        """Mechanical 3-candle fractal but with pivot"""
        df = df.copy()
        df['atr'] = self.calculate_atr(df)
        swings = []
        n = len(df)
        
        for i in range(self.pivot_length, n - self.pivot_length):
            # Low
            window_lows = df['low'].iloc[i - self.pivot_length : i + self.pivot_length + 1]
            if df['low'].iloc[i] == window_lows.min():
                if df['low'].iloc[i] < df['low'].iloc[i-1] and df['low'].iloc[i] <= df['low'].iloc[i+1]:
                    # Allow equal on one side for equal lows pool but strict on other
                    sp = SwingPoint(i, df['timestamp'].iloc[i] if 'timestamp' in df.columns else i, df['low'].iloc[i], 'low', df['atr'].iloc[i])
                    swings.append(sp)
            # High
            window_highs = df['high'].iloc[i - self.pivot_length : i + self.pivot_length + 1]
            if df['high'].iloc[i] == window_highs.max():
                if df['high'].iloc[i] > df['high'].iloc[i-1] and df['high'].iloc[i] >= df['high'].iloc[i+1]:
                    sp = SwingPoint(i, df['timestamp'].iloc[i] if 'timestamp' in df.columns else i, df['high'].iloc[i], 'high', df['atr'].iloc[i])
                    swings.append(sp)
        
        return sorted(swings, key=lambda x: x.index)
    
    # === NEW THINKING FILTERS ===

    def calculate_selling_momentum_velocity(self, df: pd.DataFrame, candidate_index: int) -> Dict:
        """
        موجة التسييل والاستنزاف
        سرعة الزخم البيعي = متوسط Range و Body لآخر 5 شموع هابطة قبل القاع
        إذا كانت تتقلص تدريجياً => البائعون يستنزفون
        """
        # Look back 10 candles before candidate
        start = max(0, candidate_index - 10)
        bearish_candles = []
        for j in range(start, candidate_index):
            if df['close'].iloc[j] < df['open'].iloc[j]:
                rng = df['high'].iloc[j] - df['low'].iloc[j]
                body = abs(df['close'].iloc[j] - df['open'].iloc[j])
                bearish_candles.append({'range': rng, 'body': body, 'index': j})
        
        if len(bearish_candles) < 3:
            return {'velocity_decreasing': False, 'avg_range': 0, 'trend': 'unknown'}
        
        # Check if ranges are decreasing
        ranges = [c['range'] for c in bearish_candles[-3:]]  # last 3 bearish
        bodies = [c['body'] for c in bearish_candles[-3:]]
        
        # Decreasing means each next is smaller than previous
        range_decreasing = ranges[0] > ranges[1] > ranges[2] if len(ranges)>=3 else False
        body_decreasing = bodies[0] > bodies[1] > bodies[2] if len(bodies)>=3 else False
        
        # More robust: linear regression slope negative
        x = np.arange(len(ranges)).reshape(-1,1)
        if len(ranges) >= 2:
            reg_range = LinearRegression().fit(x, ranges)
            slope_range = reg_range.coef_[0]
            reg_body = LinearRegression().fit(x, bodies)
            slope_body = reg_body.coef_[0]
            decreasing = slope_range < 0 and slope_body < 0
        else:
            decreasing = False
            slope_range = 0
        
        return {
            'velocity_decreasing': decreasing or (range_decreasing and body_decreasing),
            'avg_range': np.mean(ranges),
            'slope_range': slope_range,
            'ranges': ranges,
            'bodies': bodies
        }
    
    def dynamic_rejection_filter(self, df: pd.DataFrame, candidate_index: int) -> Dict:
        """
        معادلة الرفض النسبي
        متوسط الذيول لآخر 30 شمعة vs ذيل الشمعة المرشحة
        ذيل سفلي = min(open,close) - low
        يجب أن يكون 2.5x أكبر من المعتاد
        """
        # Calculate lower wicks for last 30 candles
        lookback = 30
        start = max(0, candidate_index - lookback)
        wicks = []
        for j in range(start, candidate_index):
            lower_wick = min(df['open'].iloc[j], df['close'].iloc[j]) - df['low'].iloc[j]
            wicks.append(max(0, lower_wick))
        
        if not wicks:
            return {'is_extreme': False, 'ratio': 0}
        
        avg_wick = np.mean(wicks) if np.mean(wicks) > 0 else 0.1
        candidate_wick = min(df['open'].iloc[candidate_index], df['close'].iloc[candidate_index]) - df['low'].iloc[candidate_index]
        candidate_wick = max(0, candidate_wick)
        
        ratio = candidate_wick / avg_wick if avg_wick > 0 else 0
        
        # Dynamic threshold: 2.5x per user spec, but adaptive to volatility
        # If avg_wick is tiny, require even larger ratio
        is_extreme = ratio >= 2.5
        
        return {
            'is_extreme': is_extreme,
            'ratio': ratio,
            'candidate_wick': candidate_wick,
            'avg_wick': avg_wick
        }
    
    def ghost_support_filter(self, df: pd.DataFrame, candidate_index: int) -> Dict:
        """
        فخ الدعم الزائف الخالي من الأوامر
        يفحص حجم التداول والـ CVD
        إذا حجم الارتداد < متوسط الحجم => لا يوجد حوت، فقط توقف بائعين
        """
        if 'volume' not in df.columns:
            return {'is_ghost': False, 'volume_ratio': 1.0}
        
        # Average volume last 20 candles
        start = max(0, candidate_index - 20)
        avg_vol = df['volume'].iloc[start:candidate_index].mean() if candidate_index > start else df['volume'].mean()
        
        candidate_vol = df['volume'].iloc[candidate_index]
        # Also check next candle (recovery candle) volume
        next_vol = df['volume'].iloc[candidate_index+1] if candidate_index+1 < len(df) else candidate_vol
        
        # Ghost if recovery volume < 80% of avg
        volume_ratio = next_vol / avg_vol if avg_vol > 0 else 1.0
        
        # Also check CVD: if close not strongly bullish despite long wick
        # CVD proxy: (close - low) / (high - low) should be >0.6 for strong buying
        candle = df.iloc[candidate_index]
        high_low_range = candle['high'] - candle['low']
        if high_low_range > 0:
            buying_pressure = (candle['close'] - candle['low']) / high_low_range
        else:
            buying_pressure = 0
        
        is_ghost = volume_ratio < 0.8 and buying_pressure < 0.6
        
        return {
            'is_ghost': is_ghost,
            'volume_ratio': volume_ratio,
            'buying_pressure': buying_pressure,
            'candidate_vol': candidate_vol,
            'next_vol': next_vol,
            'avg_vol': avg_vol
        }
    
    def trendline_liquidity_trap_detection(self, swings: List[SwingPoint], df: pd.DataFrame) -> List[SwingPoint]:
        """
        فخ خط الاتجاه التجميعي المفخخ
        يحسب Linear Regression لآخر 4-5 قيعان
        إذا R2 >95% وميل صاعد => فخ هندسي متعمد = مسبح سيولة
        يتوقف عن الشراء، ينتظر كسر الخط والمجزرة
        """
        lows = [s for s in swings if s.type == 'low']
        if len(lows) < 4:
            return swings
        
        # Take last 5 lows
        recent_lows = lows[-5:]
        x = np.array([s.index for s in recent_lows]).reshape(-1,1)
        y = np.array([s.price for s in recent_lows])
        
        model = LinearRegression().fit(x, y)
        r2 = model.score(x, y)
        slope = model.coef_[0]
        
        # If R2 >0.95 and slope >0 (ascending trendline) => trap
        if r2 > 0.95 and slope > 0:
            # Mark all recent lows as trap
            for s in recent_lows:
                s.is_trendline_trap = True
                # Log: "هذا فخ هندسي متعمد!"
        
        return swings
    
    def detect_protected_status_with_thinking(self, df: pd.DataFrame, swings: List[SwingPoint]) -> List[SwingPoint]:
        """
        الحجر الصحي والتحقق الشامل - Under Verification State
        لا يمنح Protected إلا بعد:
        1. Selling Velocity decreasing
        2. Dynamic Rejection extreme
        3. Not Ghost Support
        4. Not Trendline Trap
        5. Sweep + CISD + BOS/CHoCH causality
        """
        # First, mark trendline traps
        swings = self.trendline_liquidity_trap_detection(swings, df)
        
        for swing in swings:
            if swing.type != 'low':
                continue
            idx = swing.index
            if idx < 5 or idx >= len(df)-1:
                continue
            
            # Filter 1: Selling Momentum Velocity
            velocity_info = self.calculate_selling_momentum_velocity(df, idx)
            swing.selling_velocity = velocity_info
            
            # If velocity not decreasing and not extreme rejection, skip? But keep for logging
            # We don't hard fail, we use as confluence score
            
            # Filter 2: Dynamic Rejection
            rejection_info = self.dynamic_rejection_filter(df, idx)
            swing.rejection_ratio = rejection_info['ratio']
            
            if not rejection_info['is_extreme']:
                # Not extreme enough, might be weak low
                # But don't discard, mark for verification
                pass
            
            # Filter 3: Ghost Support
            ghost_info = self.ghost_support_filter(df, idx)
            swing.is_ghost_support = ghost_info['is_ghost']
            
            if ghost_info['is_ghost']:
                # Ghost support -> weak low, will be broken soon
                swing.verification_state = "FAILED_GHOST"
                continue
            
            # Filter 4: Trendline Trap
            if swing.is_trendline_trap:
                swing.verification_state = "LIQUIDITY_POOL"  # Not a buy zone, it's a target for sweep
                continue
            
            # Filter 5: Original protected logic - down series + CISD
            down_series = []
            j = idx
            while j >= 0 and j > idx - 10:
                if df['close'].iloc[j] < df['open'].iloc[j]:
                    down_series.append(j)
                    j -= 1
                else:
                    break
            
            if len(down_series) >= 2:
                first_in_series = down_series[-1]
                confirmation_level = df['open'].iloc[first_in_series]
                swing.confirmation_level = confirmation_level
                
                # Sweep check
                prev_lows = [s for s in swings if s.type == 'low' and s.index < idx]
                if prev_lows:
                    prev_low = prev_lows[-1]
                    if df['low'].iloc[idx] < prev_low.price and df['close'].iloc[idx] > prev_low.price:
                        swing.sweep_detected = True
                
                # CISD check: close above confirmation within 20 candles
                # This is flexible time: 5 to 50 candles per spec
                for k in range(idx+1, min(idx+50, len(df))):
                    if df['close'].iloc[k] > confirmation_level and df['close'].iloc[k] > df['open'].iloc[k]:
                        swing.protected = True
                        swing.protection_index = k
                        
                        # Now enter verification state: need BOS/CHoCH
                        # Find target high: last lower high that caused this low
                        # For simplicity, target is last swing high before this low
                        prev_highs = [s for s in swings if s.type == 'high' and s.index < idx]
                        if prev_highs:
                            target_high = prev_highs[-1]
                            swing.target_high_for_bos = target_high.price
                            
                            # Check if BOS/CHoCH happens after protection
                            for m in range(k+1, min(k+50, len(df))):
                                if df['close'].iloc[m] > target_high.price:
                                    swing.verification_state = "VERIFIED"
                                    break
                            else:
                                swing.verification_state = "PENDING_BOS"
                        else:
                            swing.verification_state = "PENDING_BOS"
                        break
                
                # If still not protected, mark as pending
                if not swing.protected:
                    swing.verification_state = "PENDING_CISD"
        
        return swings
    
    def get_true_protected_lows(self, df: pd.DataFrame) -> List[SwingPoint]:
        swings = self.detect_swings(df)
        swings = self.detect_protected_status_with_thinking(df, swings)
        # True protected = protected + verified + not ghost + not trap + extreme rejection + decreasing velocity
        true_lows = [
            s for s in swings 
            if s.type == 'low' 
            and s.protected 
            and s.verification_state in ["VERIFIED", "PENDING_BOS"]
            and not s.is_ghost_support 
            and not s.is_trendline_trap
            and s.rejection_ratio is not None and s.rejection_ratio >= 2.0  # slightly relaxed from 2.5 for real market
        ]
        return true_lows
    
    def analyze(self, df: pd.DataFrame) -> Dict:
        swings = self.detect_swings(df)
        swings = self.detect_protected_status_with_thinking(df, swings)
        
        return {
            'all_swings': [s.to_dict() for s in swings],
            'protected_lows': [s.to_dict() for s in swings if s.type == 'low' and s.protected],
            'protected_highs': [s.to_dict() for s in swings if s.type == 'high' and s.protected],
            'true_protected_lows': [s.to_dict() for s in swings if s.type == 'low' and s.protected and s.verification_state in ["VERIFIED","PENDING_BOS"] and not s.is_ghost_support and not s.is_trendline_trap],
            'ghost_lows': [s.to_dict() for s in swings if s.type == 'low' and s.is_ghost_support],
            'trap_lows': [s.to_dict() for s in swings if s.type == 'low' and s.is_trendline_trap],
            'pending_verification': [s.to_dict() for s in swings if s.type == 'low' and s.verification_state.startswith("PENDING")],
            'total_swings': len(swings)
        }
