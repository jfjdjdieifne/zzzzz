"""
Final Integrated Engine - All 12 Cells Connected - No Lookahead - Spot Only
Combines:
Map1: Protected Low + BOS + Discount Array + Execution OB+FVG (4)
Map2: HTF Sweep SFP + LTF CHoCH + LTF Discount OB + Counter-Trend Execution (4)
Tactical: Pure Displacement + Position Sizing + Environmental Filter + Live Trade Management + Execution Friction (5)
Total: 13 cells (including Pure Displacement as part of both maps)

This file is the main entry point that connects all cells bar-by-bar without cheating.
"""

import pandas as pd
import numpy as np
from engine.core.swing_detector import ProtectedSwingDetector
from engine.core.bos_detector import BOSDetector
from engine.core.discount_detector import DiscountDetector
from engine.core.orderblock_detector import OrderBlockDetector, ExecutionEngine
from engine.core.htf_sweep_detector import HTFSweepDetector
from engine.core.ltf_choch_detector import LTFChoCHDetector
from engine.core.ltf_discount_ob_detector import LTFDiscountOBDetector
from engine.core.counter_trend_execution import CounterTrendExecutionEngine
from engine.core.pure_displacement_engine import PureDisplacementEngine, DynamicProfileSwitcher
from engine.core.position_sizing import AdaptivePositionSizer
from engine.core.environmental_filter import EnvironmentalFilter
from engine.core.live_trade_management import LiveTradeManager
from engine.core.execution_friction_engine import ExecutionFrictionEngine
from engine.core.fvg_detector import FVGDetector
from engine.core.liquidity import LiquidityEngine

class FinalIntegratedEngine:
    def __init__(self, base_risk_pct=1.0):
        # Map1 cells
        self.swing_det = ProtectedSwingDetector(pivot_length=3)
        self.swing_sensitive = ProtectedSwingDetector(pivot_length=1)
        self.bos_det = BOSDetector()
        self.discount_det = DiscountDetector()
        self.ob_det = OrderBlockDetector()
        self.exec_eng = ExecutionEngine()
        self.fvg_det = FVGDetector()
        self.liq_eng = LiquidityEngine()
        
        # Map2 cells
        self.htf_sweep_det = HTFSweepDetector()
        self.ltf_choch_det = LTFChoCHDetector()
        self.ltf_discount_ob_det = LTFDiscountOBDetector()
        self.counter_exec_eng = CounterTrendExecutionEngine()
        
        # Tactical cells
        self.displacement_eng = PureDisplacementEngine()
        self.profile_switcher = DynamicProfileSwitcher()
        self.position_sizer = AdaptivePositionSizer(base_risk_pct=base_risk_pct)
        self.env_filter = EnvironmentalFilter()
        self.live_manager = LiveTradeManager()
        self.friction_eng = ExecutionFrictionEngine()
        
        # State
        self.state = {
            'map': 'Map1',  # Map1 or Map2
            'map1_stage': 'SEARCH_PROTECTED_LOW',
            'map2_stage': 'MONITORING_HTF_COLLAPSE',
            'protected_low': None,
            'bos_valid': None,
            'htf_sweep_valid': None,
            'ltf_choch_valid': None,
            'discount_state': None,
            'ltf_discount_state': None,
            'trade': None,
            'trades': []
        }
    
    def run_bar_by_bar(self, df: pd.DataFrame, df_htf: pd.DataFrame = None, funding_history=None, inflow_history=None, order_book_asks=None):
        """
        Main loop - No Lookahead Protocol
        df = LTF data (15m/5m) for execution
        df_htf = HTF data (4H/Daily) for bias and sweep detection (if None, use df)
        funding_history, inflow_history for environmental filter (list of floats)
        order_book_asks for slippage check (list of dicts price, quantity)
        """
        logs = []
        
        # Use df as HTF if not provided
        if df_htf is None:
            df_htf = df
        
        for i in range(10, len(df)):
            past_ltf = df.iloc[:i+1]
            past_htf = df_htf.iloc[:min(i+1, len(df_htf))]
            
            # === MAP1 LOGIC ===
            if self.state['map'] == 'Map1':
                if self.state['map1_stage'] == 'SEARCH_PROTECTED_LOW':
                    swings = self.swing_det.analyze(past_ltf)
                    true_lows = swings['true_protected_lows']
                    if true_lows:
                        self.state['protected_low'] = true_lows[-1]
                        self.state['map1_stage'] = 'SEARCH_BOS'
                        logs.append(f"[{i}] Map1 Station1: True Protected Low {true_lows[-1]['price']:.2f} VERIFIED")
                
                elif self.state['map1_stage'] == 'SEARCH_BOS':
                    swings = self.swing_sensitive.analyze(past_ltf)
                    bos_res = self.bos_det.analyze(past_ltf, swings['all_swings'])
                    if bos_res['valid_bos']:
                        self.state['bos_valid'] = bos_res['valid_bos'][-1]
                        self.state['map1_stage'] = 'SEARCH_DISCOUNT'
                        logs.append(f"[{i}] Map1 Station2: Valid BOS {bos_res['valid_bos'][-1]['price']:.2f} breaking {bos_res['valid_bos'][-1]['last_swing_price']:.2f}")
                
                elif self.state['map1_stage'] == 'SEARCH_DISCOUNT':
                    protected = self.state['protected_low']
                    bos = self.state['bos_valid']
                    if protected and bos:
                        origin_idx = protected['index']
                        origin_price = protected['price']
                        term_idx = bos['index']
                        term_price = past_ltf['high'].iloc[origin_idx:].max()
                        disc_sig = self.discount_det.analyze(past_ltf, origin_idx, origin_price, term_idx, term_price, current_idx=i, current_price=past_ltf['close'].iloc[-1])
                        self.state['discount_state'] = disc_sig
                        
                        if 'Price_In_Discount' in disc_sig.cognitive_state['Current_State'] and not disc_sig.is_bleeding_trap and not disc_sig.is_induced_trap:
                            self.state['map1_stage'] = 'SEARCH_EXECUTION'
                            logs.append(f"[{i}] Map1 Station3: Discount Eq {disc_sig.dynamic_equilibrium:.2f} BuyRange {disc_sig.recommended_buy_range}")
                
                elif self.state['map1_stage'] == 'SEARCH_EXECUTION':
                    protected = self.state['protected_low']
                    if protected:
                        # Check environmental filter before execution
                        if funding_history and inflow_history:
                            env_res = self.env_filter.analyze(
                                current_funding=funding_history[-1] if funding_history else 0.01,
                                funding_history_168h=funding_history[-168:] if len(funding_history)>=168 else funding_history,
                                recent_inflow_usd=inflow_history[-1] if inflow_history else 10000000,
                                inflow_history_48h=inflow_history[-48:] if len(inflow_history)>=48 else inflow_history
                            )
                            if 'HARD_BLOCK' in env_res['Environmental_Gatekeeper_Decision']:
                                logs.append(f"[{i}] Map1 Station4: Environmental HARD_BLOCK {env_res['Reason']} - Trade Aborted")
                                continue
                        
                        # Execution
                        exec_res = self.exec_eng.analyze(past_ltf, protected_low_price=protected['price'], termination_high_price=past_ltf['high'].max(), origin_idx=protected['index'], term_idx=i)
                        
                        if exec_res['valid_trades']:
                            trade = exec_res['valid_trades'][0]
                            
                            # Check friction: slippage and fees
                            if order_book_asks:
                                friction_res = self.friction_eng.analyze_order_book_and_fees(
                                    asks=order_book_asks,
                                    required_usd=trade['sl']*10,  # placeholder
                                    theoretical_price=trade['entry'],
                                    atr=3.0,
                                    entry_price=trade['entry'],
                                    theoretical_tp=trade['tp'],
                                    theoretical_profit_range_pct=5.0
                                )
                                if 'HARD_ABORT' in friction_res['Cognitive_Execution_Conclusion']['Action_Command'] or 'ABORT' in friction_res['Gatekeeper_Audit_Report']['Status']:
                                    logs.append(f"[{i}] Map1 Station4: Friction ABORT {friction_res['Cognitive_Execution_Conclusion']['Log_Report']}")
                                    continue
                            
                            # Position sizing with confluence multiplier
                            # Example: Map1 ProTrend + Real BOS + Volume Z>3 + CVD divergence + Funding cool
                            sizing_res = self.position_sizer.calculate(
                                total_balance=10000,
                                entry_price=trade['entry'],
                                stop_loss_price=trade['sl'],
                                map_type='Map1_Bullish_ProTrend',
                                bos_real=True,
                                has_safe_distance=True,
                                is_noise=False,
                                volume_z_score=3.5,
                                is_aggressive_absorption=True,
                                close_pos=0.90,
                                is_silent=False,
                                is_churning=False,
                                funding_z_score=0.5,
                                inflow_z_score=0.3
                            )
                            
                            # Enter on next bar open (no lookahead)
                            if i+1 < len(df):
                                entry_price_next = df['open'].iloc[i+1]
                                self.state['trade'] = {
                                    'entry_idx': i+1,
                                    'entry_price': entry_price_next,
                                    'stop_loss': trade['sl'],
                                    'take_profit': trade['tp'],
                                    'rr': trade['rr'],
                                    'sizing': sizing_res,
                                    'ob': trade['ob'],
                                    'fvg': trade['fvg']
                                }
                                self.state['trades'].append(self.state['trade'])
                                self.state['map1_stage'] = 'IN_TRADE'
                                logs.append(f"[{i}] Map1 Station4: EXECUTED SPOT BUY Entry {entry_price_next:.2f} SL {trade['sl']:.2f} TP {trade['tp']:.2f} RR {trade['rr']} M {sizing_res['Final_Multiplier_M']} Alloc ${sizing_res['Spot_Allocation_USD']:.2f}")
            
            # === MAP2 LOGIC ===
            # If Map1 fails or bearish HTF, switch to Map2? For demo, we run Map2 in parallel if bearish HTF detected
            # Simplified: if no protected low found and price collapsing, start Map2
            
            # Map2 Station1: HTF Sweep
            if self.state['map2_stage'] == 'MONITORING_HTF_COLLAPSE':
                # Assume major low is recent swing low
                # For demo, use 90 as major low if price below
                major_low = past_htf['low'].min() + 2  # example
                htf_sweep_res = self.htf_sweep_det.analyze(past_htf, major_low)
                if htf_sweep_res['valid_sfps']:
                    self.state['htf_sweep_valid'] = htf_sweep_res['valid_sfps'][-1]
                    self.state['map2_stage'] = 'WAITING_LTF_CHOCH'
                    logs.append(f"[{i}] Map2 Station1: Valid HTF SFP Low {htf_sweep_res['valid_sfps'][-1]['low']:.2f}<Major {major_low:.2f} Close {htf_sweep_res['valid_sfps'][-1]['close']:.2f}>{major_low:.2f} Vol Spike + CVD Divergence")
            
            elif self.state['map2_stage'] == 'WAITING_LTF_CHOCH':
                sweep = self.state['htf_sweep_valid']
                if sweep:
                    sweep_idx = sweep['index']
                    ltf_choch_res = self.ltf_choch_det.analyze(past_ltf, sweep_idx)
                    if ltf_choch_res['valid_choch']:
                        self.state['ltf_choch_valid'] = ltf_choch_res['valid_choch'][-1]
                        self.state['map2_stage'] = 'SEARCH_LTF_DISCOUNT_OB'
                        logs.append(f"[{i}] Map2 Station2: Valid LTF CHoCH {ltf_choch_res['valid_choch'][-1]['price']:.2f} breaking {ltf_choch_res['valid_choch'][-1]['target_high']:.2f}")
            
            elif self.state['map2_stage'] == 'SEARCH_LTF_DISCOUNT_OB':
                choch = self.state['ltf_choch_valid']
                if choch:
                    choch_idx = choch['index']
                    ltf_disc_res = self.ltf_discount_ob_det.analyze(past_ltf, choch_idx, current_idx=i)
                    if ltf_disc_res.target_ob_zone:
                        self.state['ltf_discount_state'] = ltf_disc_res
                        if 'ALLOW_MONITORING' in ltf_disc_res.cognitive['Action_Status']:
                            self.state['map2_stage'] = 'SEARCH_COUNTER_TREND_EXECUTION'
                            logs.append(f"[{i}] Map2 Station3: LTF Discount Eq {ltf_disc_res.dynamic_eq:.2f} OB Zone {ltf_disc_res.target_ob_zone}")
        
        return {
            'logs': logs,
            'trades': self.state['trades'],
            'final_state': self.state
        }

# Example usage:
# df_15m = pd.read_csv('btc_15m.csv')
# df_4h = pd.read_csv('btc_4h.csv')
# engine = FinalIntegratedEngine(base_risk_pct=1.0)
# result = engine.run_bar_by_bar(df_15m, df_4h, funding_history=[...], inflow_history=[...], order_book_asks=[...])
# result['trades'] -> spot buys only, no lookahead
