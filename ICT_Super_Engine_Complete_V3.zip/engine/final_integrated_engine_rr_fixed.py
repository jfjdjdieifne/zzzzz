"""
Fixed RR - Ensures winning trades >1R, ideally 1.5-3R, without losing microscopic accuracy
Problem diagnosed:
- Trade 1: Entry 63391.80 SL 62664.79 Risk 727.01 TP 63513 Reward 121.2 RR 0.17 <1
- Why? TP = term_price (max high from origin) = 63513, Entry 63391 is only 121$ below term, but SL 727$ below entry => RR 0.17

Root cause: TP = termination (previous high) gives tiny reward if entry is near termination (shallow discount 50-61.8%)
- Entry at 60% retracement: Origin 0%, Term 100%, Entry at 60% from bottom (i.e., 40% below Term), Risk = Entry - Origin = 40% range, Reward = Term - Entry = 60%? Wait earlier calc wrong
- Let's recalc correctly:
  Origin = 0%, Term =100%, Range = Term-Origin
  Entry at X% retracement from Term: Entry = Term - Range*X%
  Actually retracement % is from Term down: 0% at Term, 100% at Origin
  So Entry at 50% retracement = Term - Range*0.5, Risk = Entry - Origin = Term - Range*0.5 - Origin = Range*0.5, Reward = Term - Entry = Range*0.5, RR=1
  Entry at 61.8% retracement = Term - Range*0.618, Risk = Range*0.382, Reward = Range*0.618, RR=1.618
  Entry at 70.5% retracement = Term - Range*0.705, Risk = Range*0.295, Reward = Range*0.705, RR=2.39
  Entry at 79% retracement = Term - Range*0.79, Risk = Range*0.21, Reward = Range*0.79, RR=3.76

So RR should be >1 if entry in 50-79% range and TP = Term (previous high)
- Entry at 50% => RR 1
- Entry at 61.8% => RR 1.618
- Entry at 70.5% => RR 2.39
- Entry at 79% => RR 3.76

Why our trades RR <1? Because entry is ABOVE buy range (near Term) not inside 50-79%
- Trade3 Entry 64483.60 Term 64488 Range 529.11 BuyRange 50-79% = 64070-64223
- Entry 64483 is ABOVE 64223, outside buy range, but allowed due to 0.5% buffer
- Entry at 64483 is only 4.4$ below Term, which is 0.8% retracement, not 50-79%!
- Risk = Entry - Origin = 64483-63958=524, Reward = Term-Entry=4.4, RR=0.008

So flaw is: we allowed entry outside buy range with buffer, and term_price is max high from origin to current, which may be recent high very close to entry if market made new high just before entry

Fix 1: Strictly enforce entry must be inside buy range 50-79% (or 70.5-79% deep for better RR), no buffer, no allowing entry above buy_high
Fix 2: TP should be beyond Term, not at Term, using extension -0.27 and -0.62 per ICT:
  TP1 = Term + Range*0.27 (standard institutional expansion target)
  TP2 = Term + Range*0.62 (deep)
  Then even if entry at 50% retracement, Reward = (Term-Entry) + Range*0.27 = Range*0.5 + Range*0.27 = Range*0.77, Risk = Range*0.5, RR=1.54
  Entry at 61.8%: Reward = 0.618+0.27=0.888, Risk=0.382, RR=2.32
  Entry at 70.5%: Reward=0.705+0.27=0.975, Risk=0.295, RR=3.30
  Entry at 79%: Reward=0.79+0.27=1.06, Risk=0.21, RR=5.04
  With TP2 extension 0.62: RR even higher

Fix 3: Enforce deep discount only 70.5-79% for RR>2, not shallow 50-61.8% which gives RR 1-1.6
Fix 4: Add RR filter: reject trade if RR <1.5 after calculating extended TP

This keeps microscopic accuracy (still requires Protected Low VERIFIED, BOS Body Close, Discount OTE, OB Double Immunity, FVG, Wick OR Vol) but ensures winning trades >1R
"""

import pandas as pd
import numpy as np
from engine.core.swing_detector import ProtectedSwingDetector
from engine.core.bos_detector import BOSDetector
from engine.core.orderblock_detector import OrderBlockDetector

class BalancedRRBOSDetector(BOSDetector):
    def __init__(self):
        super().__init__(atr_period=14, volume_lookback=20)
        self.close_pos_thresh = 0.65
        self.disp_factor = 0.10
        self.upper_wick_thresh = 0.70
    def calculate_volume_bollinger(self, df, idx):
        start = max(0, idx-20)
        vol_mean = df['volume'].iloc[start:idx].mean() if idx>start else df['volume'].mean()
        curr = df['volume'].iloc[idx]
        is_outlier = curr > vol_mean*1.5
        return {'is_outlier': is_outlier, 'mean': vol_mean, 'upper_band': vol_mean*1.5, 'current': curr, 'ratio': curr/vol_mean if vol_mean>0 else 0}

class BalancedRREngine:
    def __init__(self):
        self.swing_det = ProtectedSwingDetector(pivot_length=2)
        self.swing_sens = ProtectedSwingDetector(pivot_length=1)
        self.bos_det = BalancedRRBOSDetector()
        self.ob_det = OrderBlockDetector()
    
    def run(self, df):
        trades=[]
        logs=[]
        current_trade=None
        
        for i in range(50, len(df)-1):
            past = df.iloc[:i+1]
            curr = df.iloc[i]
            nxt = df.iloc[i+1]
            
            if current_trade:
                low = curr['low']
                high = curr['high']
                if low <= current_trade['stop_loss']:
                    current_trade['exit_price'] = current_trade['stop_loss']
                    current_trade['exit_time'] = curr['timestamp']
                    current_trade['profit_usd'] = (current_trade['exit_price'] - current_trade['entry_price']) * current_trade['coins']
                    current_trade['profit_pct'] = (current_trade['exit_price']/current_trade['entry_price']-1)*100
                    current_trade['result'] = 'LOSS'
                    trades.append(current_trade)
                    logs.append(f"[{curr['timestamp']}] EXIT SL Trade {current_trade['id']} Loss {current_trade['profit_usd']:.2f}$")
                    current_trade=None
                    continue
                if high >= current_trade['take_profit']:
                    current_trade['exit_price'] = current_trade['take_profit']
                    current_trade['exit_time'] = curr['timestamp']
                    current_trade['profit_usd'] = (current_trade['exit_price'] - current_trade['entry_price']) * current_trade['coins']
                    current_trade['profit_pct'] = (current_trade['exit_price']/current_trade['entry_price']-1)*100
                    current_trade['result'] = 'WIN'
                    trades.append(current_trade)
                    logs.append(f"[{curr['timestamp']}] EXIT TP Trade {current_trade['id']} Profit {current_trade['profit_usd']:.2f}$ RR {current_trade['rr']:.2f}")
                    current_trade=None
                    continue
                continue
            
            # Station1
            swings = self.swing_det.analyze(past)
            protected_ok = [s for s in swings['all_swings'] if s['type']=='low' and s['protected'] and not s['is_ghost'] and not s['is_trap'] and s['rejection_ratio'] and s['rejection_ratio']>=1.0]
            if not protected_ok:
                # Fallback to true protected
                protected_ok = swings['true_protected_lows']
            if not protected_ok:
                continue
            protected_low = protected_ok[-1]
            if i - protected_low['index'] > 150:
                continue
            
            # Station2
            swings_sens = self.swing_sens.analyze(past)
            bos_res = self.bos_det.analyze(past, swings_sens['all_swings'])
            if not bos_res['valid_bos']:
                continue
            bos_valid = bos_res['valid_bos'][-1]
            if bos_valid['index'] <= protected_low['index']:
                continue
            if i - bos_valid['index'] > 80:
                continue
            
            # Station3 Discount - FIXED: Use deep OTE 70.5-79% only for RR>2, and enforce strictly inside buy range (no buffer)
            origin_idx = protected_low['index']
            origin_price = protected_low['price']
            term_price = past['high'].iloc[origin_idx:].max()
            range_size = term_price - origin_price
            if range_size <=0:
                continue
            
            # FIXED: Deep discount only 70.5-79% for better RR
            buy_low = term_price - range_size*0.79
            buy_high = term_price - range_size*0.705
            
            # FIXED: Strictly enforce entry inside buy range, no buffer, no allowing low touches outside
            if not (buy_low <= curr['close'] <= buy_high):
                continue
            
            # Station4 OB/FVG
            fvgs = self.ob_det.detect_fvgs(past)
            obs = self.ob_det.detect_bullish_obs(past, fvgs)
            
            valid_exec = None
            for ob in obs[-3:]:  # last 3
                if ob.is_mitigated:
                    continue
                # OB must be within buy range strictly
                if not (buy_low <= ob.low <= buy_high or buy_low <= ob.high <= buy_high or (ob.low <= buy_high and ob.high >= buy_low)):
                    continue
                for fvg in fvgs[-5:]:
                    if fvg.is_ghost:
                        continue
                    if abs(fvg.low - ob.high) < (ob.high-ob.low)*2:
                        hl_range = curr['high']-curr['low']
                        if hl_range==0:
                            continue
                        lower_wick = min(curr['open'], curr['close']) - curr['low']
                        body = abs(curr['close']-curr['open'])
                        close_pos = (curr['close']-curr['low'])/hl_range
                        wick_rej = lower_wick > body*0.5 and close_pos>0.55
                        vol_mean = past['volume'].iloc[max(0,i-20):i].mean()
                        vol_spike = curr['volume'] > vol_mean*1.2
                        is_extreme_churn = body < hl_range*0.15 and curr['volume'] > vol_mean*2.5
                        if (wick_rej or vol_spike) and not is_extreme_churn:
                            valid_exec = (ob,fvg)
                            break
                if valid_exec:
                    break
            
            if not valid_exec:
                continue
            
            # Generate trade with FIXED RR: TP beyond term using extension -0.27 and -0.62 per ICT
            ob,fvg = valid_exec
            entry_price = df.iloc[i+1]['open']
            
            # FIXED: SL still protected low -0.01
            stop_loss = protected_low['price'] - 0.01
            
            # FIXED: TP beyond term using extension
            # TP1 = term + range*0.27 (standard institutional expansion)
            # TP2 = term + range*0.62 (deep) - we will use TP1 as main TP for RR calc, but final TP could be TP2 for 1:3+
            # For this engine, use TP = term + range*0.27 for RR>1.5 minimum, or term + range*0.62 for RR>2.5
            tp_standard = term_price + range_size*0.27
            tp_deep = term_price + range_size*0.62
            
            # Choose TP based on desired RR: use standard 0.27 for RR>1.5, deep 0.62 for RR>2.5
            # For balanced, use standard for 75% and deep for 25%? But for RR calc, use standard
            take_profit = tp_standard
            
            risk = abs(entry_price - stop_loss)
            reward = abs(take_profit - entry_price)
            rr = reward / risk if risk>0 else 0
            
            # FIXED: Enforce RR filter >=1.5, reject if RR<1.5
            if rr < 1.5:
                # Try deep TP
                take_profit = tp_deep
                reward = abs(take_profit - entry_price)
                rr = reward / risk if risk>0 else 0
                if rr < 1.5:
                    logs.append(f"[{curr['timestamp']}] REJECTED Trade RR {rr:.2f}<1.5 - Entry {entry_price:.2f} SL {stop_loss:.2f} TP {take_profit:.2f} Range {range_size:.2f}")
                    continue
            
            # Position sizing
            total_balance=10000
            M=1.5
            allowed_loss= total_balance*0.01*M
            risk_dist= abs(entry_price-stop_loss)/entry_price
            spot_alloc= allowed_loss/risk_dist if risk_dist>0 else 0
            coins= spot_alloc/entry_price
            
            trade_id = len(trades)+1
            current_trade={
                'id': trade_id,
                'entry_index': i+1,
                'entry_time': df.iloc[i+1]['timestamp'],
                'entry_price': entry_price,
                'stop_loss': stop_loss,
                'take_profit': take_profit,
                'take_profit_deep': tp_deep,
                'risk_pct': risk/ entry_price*100 if entry_price>0 else 0,
                'rr': rr,
                'coins': coins,
                'spot_allocation_usd': spot_alloc,
                'protected_low': protected_low,
                'bos': bos_valid,
                'buy_range': (buy_low, buy_high),
                'ob': ob,
                'fvg': fvg,
                'range_size': range_size,
                'term_price': term_price,
                'origin_price': origin_price,
            }
            logs.append(f"[{curr['timestamp']}] NEW TRADE {trade_id} Entry {entry_price:.2f} SL {stop_loss:.2f} TP {take_profit:.2f} (Deep {tp_deep:.2f}) RR {rr:.2f} BuyRange Deep 70.5-79% {buy_low:.2f}-{buy_high:.2f} Price {curr['close']:.2f} OB {ob.low:.2f}-{ob.high:.2f} FVG CE {fvg.ce:.2f}")
        
        return trades, logs

# Test on last 500 candles
import pandas as pd
df = pd.read_csv('/home/user/btcusdt_15m_last_month.csv')
df['timestamp'] = pd.to_datetime(df['timestamp'])
df = df.iloc[-500:].reset_index(drop=True)

engine = BalancedRREngine()
trades, logs = engine.run(df)

print(f"Fixed RR trades found: {len(trades)}")
for t in trades:
    print(f"\nTrade {t['id']} Entry {t['entry_time']} Price {t['entry_price']:.2f} SL {t['stop_loss']:.2f} TP {t['take_profit']:.2f} Deep TP {t['take_profit_deep']:.2f} RR {t['rr']:.2f}")
    print(f"  PL {t['protected_low']['price']:.2f} BOS {t['bos']['price']:.2f} Range {t['range_size']:.2f} BuyRange {t['buy_range'][0]:.2f}-{t['buy_range'][1]:.2f}")
    print(f"  OB {t['ob'].low:.2f}-{t['ob'].high:.2f} FVG {t['fvg'].low:.2f}-{t['fvg'].high:.2f} CE {t['fvg'].ce:.2f}")

# Simulate exits quickly
test_df = df
for t in trades[:5]:
    future = test_df[test_df['timestamp'] > t['entry_time']]
    for _, row in future.iterrows():
        if row['low'] <= t['stop_loss']:
            print(f"  -> SL Hit at {row['timestamp']} Price {row['low']:.2f} LOSS")
            break
        if row['high'] >= t['take_profit']:
            print(f"  -> TP Hit at {row['timestamp']} Price {row['high']:.2f} WIN RR {t['rr']:.2f}")
            break
