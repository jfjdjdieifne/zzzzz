"""
Super Intelligence Engine - Integration of 4 Stations of Bullish Pro-Trend Map
No Lookahead, No Cheating, Bar-by-Bar, Spot Only, Behavioral Thinking
"""
import pandas as pd
import numpy as np
from engine.core.swing_detector import ProtectedSwingDetector
from engine.core.bos_detector import BOSDetector
from engine.core.discount_detector import DiscountDetector
from engine.core.orderblock_detector import ExecutionEngine
from engine.core.fvg_detector import FVGDetector
from engine.core.liquidity import LiquidityEngine

class SuperEngine:
    def __init__(self):
        self.swing_det = ProtectedSwingDetector(pivot_length=3)  # for protected low - needs stronger structure
        self.swing_det_sensitive = ProtectedSwingDetector(pivot_length=1)  # for BOS - more sensitive
        self.bos_det = BOSDetector()
        self.discount_det = DiscountDetector()
        self.exec_eng = ExecutionEngine()
        self.fvg_det = FVGDetector()
        self.liq_eng = LiquidityEngine()
        
        self.cognitive_memory = {
            'protected_low': None,
            'last_swing_high': None,
            'bos_valid': None,
            'discount_state': None,
            'trade': None,
            'state': 'SEARCH_PROTECTED_LOW'
        }
    
    def run_bar_by_bar(self, df: pd.DataFrame):
        """
        No Lookahead Protocol: for each bar i, only use df[:i+1]
        Entry on next bar open after signal
        """
        trades = []
        logs = []
        
        for i in range(10, len(df)):  # start after enough history (10 for testing, 20 for live)
            past_df = df.iloc[:i+1].copy()
            
            # Station 1: True Protected Low
            if self.cognitive_memory['state'] == 'SEARCH_PROTECTED_LOW':
                swings = self.swing_det.analyze(past_df)
                true_lows = swings['true_protected_lows']
                if true_lows:
                    # Take most recent verified
                    last_true = true_lows[-1]
                    self.cognitive_memory['protected_low'] = last_true
                    self.cognitive_memory['state'] = 'SEARCH_BOS'
                    logs.append(f"Bar {i}: Found True Protected Low {last_true['price']:.2f} VERIFIED - switching to SEARCH_BOS")
            
            # Station 2: BOS
            elif self.cognitive_memory['state'] == 'SEARCH_BOS':
                swings = self.swing_det_sensitive.analyze(past_df)
                all_swings = swings['all_swings']
                bos_res = self.bos_det.analyze(past_df, all_swings)
                if bos_res['valid_bos']:
                    last_bos = bos_res['valid_bos'][-1]
                    self.cognitive_memory['bos_valid'] = last_bos
                    self.cognitive_memory['last_swing_high'] = last_bos['last_swing_price']
                    self.cognitive_memory['state'] = 'SEARCH_DISCOUNT'
                    logs.append(f"Bar {i}: Valid BOS {last_bos['price']:.2f} breaking {last_bos['last_swing_price']:.2f} - switching to SEARCH_DISCOUNT")
            
            # Station 3: Discount Array
            elif self.cognitive_memory['state'] == 'SEARCH_DISCOUNT':
                protected = self.cognitive_memory['protected_low']
                bos = self.cognitive_memory['bos_valid']
                if not protected or not bos:
                    continue
                
                origin_idx = protected['index']
                origin_price = protected['price']
                term_idx = bos['index']
                term_price = bos['last_swing_price']  # actually high broken, but use BOS price as termination?
                # For simplicity, termination = max high after BOS in past_df
                term_price = past_df['high'].iloc[origin_idx:].max()
                term_idx_actual = past_df['high'].iloc[origin_idx:].idxmax()
                if isinstance(term_idx_actual, str):
                    term_idx_actual = len(past_df)-1
                
                discount_sig = self.discount_det.analyze(
                    past_df, 
                    origin_idx, origin_price, 
                    term_idx_actual if isinstance(term_idx_actual,int) else i, 
                    term_price,
                    current_idx=i,
                    current_price=past_df['close'].iloc[-1]
                )
                
                self.cognitive_memory['discount_state'] = discount_sig.to_dict()
                
                # Check if price in discount and not bleeding/induced trap
                if 'Price_In_Discount' in discount_sig.cognitive_state['Current_State'] and not discount_sig.is_bleeding_trap and not discount_sig.is_induced_trap:
                    self.cognitive_memory['state'] = 'SEARCH_EXECUTION'
                    logs.append(f"Bar {i}: Price in Discount {past_df['close'].iloc[-1]:.2f} < Eq {discount_sig.dynamic_equilibrium:.2f}, Buy Range {discount_sig.recommended_buy_range} - switching to SEARCH_EXECUTION")
                elif discount_sig.is_bleeding_trap:
                    logs.append(f"Bar {i}: Bleeding Trap detected - freezing uptrend map")
                    # Optionally reset to search protected low again
                    # self.cognitive_memory['state'] = 'SEARCH_PROTECTED_LOW'
            
            # Station 4: Execution
            elif self.cognitive_memory['state'] == 'SEARCH_EXECUTION':
                protected = self.cognitive_memory['protected_low']
                discount = self.cognitive_memory['discount_state']
                if not protected or not discount:
                    continue
                
                origin_price = protected['price']
                term_price = discount['termination'] if isinstance(discount, dict) else self.cognitive_memory['last_swing_high']
                if isinstance(term_price, dict):
                    term_price = term_price if isinstance(term_price, (int,float)) else discount['termination']
                
                # Execution engine analysis
                exec_res = self.exec_eng.analyze(past_df, protected_low_price=origin_price, termination_high_price=term_price, origin_idx=protected['index'], term_idx=i)
                
                if exec_res['valid_trades']:
                    trade = exec_res['valid_trades'][0]
                    # No lookahead entry: enter on next bar open
                    if i+1 < len(df):
                        entry_price = df['open'].iloc[i+1]
                        stop_loss = trade['sl']
                        take_profit = trade['tp']
                        
                        self.cognitive_memory['trade'] = {
                            'entry_idx': i+1,
                            'entry_price': entry_price,
                            'stop_loss': stop_loss,
                            'take_profit': take_profit,
                            'rr': trade['rr'],
                            'ob': trade['ob'],
                            'fvg': trade['fvg']
                        }
                        self.cognitive_memory['state'] = 'IN_TRADE'
                        logs.append(f"Bar {i}: EXECUTED SPOT BUY Entry {entry_price:.2f} SL {stop_loss:.2f} TP {take_profit:.2f} RR {trade['rr']} Type {trade['ob']}")
                        trades.append(self.cognitive_memory['trade'])
                    else:
                        logs.append(f"Bar {i}: Valid setup found but no next bar for entry")
        
        return {
            'trades': trades,
            'logs': logs,
            'final_state': self.cognitive_memory['state'],
            'cognitive_memory': self.cognitive_memory
        }

# Example usage (for live / backtest without cheating)
# df = pd.read_csv('btc_1m.csv') with columns timestamp,open,high,low,close,volume
# engine = SuperEngine()
# result = engine.run_bar_by_bar(df)
# result['trades'] contains spot buys only, no future leak
