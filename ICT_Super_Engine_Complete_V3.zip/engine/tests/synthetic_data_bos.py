"""
BOS Test Scenarios - Real vs Traps
"""
import pandas as pd
from datetime import datetime, timedelta

def generate_bos_real_scenario():
    """Real BOS: Close > High + Close_Position >0.75 + Volume Outlier + Displacement > ATR*0.2 + No long upper wick"""
    data = []
    base = datetime(2024,1,1)
    
    # Build up to last confirmed swing high at 100
    prices = [
        (95, 96, 94, 95.5),  # 0
        (95.5, 100, 95.5, 99.8),  # 1 high 100 = last confirmed high
        (99.8, 99.9, 97, 97.5),  # 2 pullback low
        (97.5, 98, 97.2, 97.8),  # 3
        (97.8, 98.5, 97.5, 98.2),  # 4
        # BOS candle real: high 101.5, low 98, close 101.2 (close in upper quarter, body large)
        # Close_Position = (101.2-98)/(101.5-98)=3.2/3.5=0.91 >0.75
        # Displacement = 101.2-100=1.2, ATR ~1.0, ratio 1.2 >0.2 true
        # Upper wick = 101.5-101.2=0.3 small, body= 101.2-98? Wait open 98.5 close 101.2 body 2.7 large
        # Volume outlier: 5000 vs avg 1000
        (98.2, 101.5, 98.0, 101.2),  # 5 REAL BOS
        (101.2, 102, 100.8, 101.8),  # 6 continuation
    ]
    
    for idx, (o,h,l,c) in enumerate(prices):
        vol = 5000 if idx==5 else 1000
        data.append({
            'timestamp': base + timedelta(minutes=idx*5),
            'open': o, 'high': h, 'low': l, 'close': c, 'volume': vol
        })
    return pd.DataFrame(data)

def generate_bos_fake_close_trap():
    """Fake Close Trap: breaks high but close barely above by cents, < ATR*0.2, then next candle collapses"""
    data = []
    base = datetime(2024,1,1)
    prices = [
        (95, 96, 94, 95.5),
        (95.5, 100, 95.5, 99.8),  # high 100
        (99.8, 99.9, 97, 97.5),
        (97.5, 98, 97.2, 97.8),
        # Fake close: high 100.3, close 100.05 (only 0.05 above high, ATR ~1, 0.05 <0.2*ATR)
        # Close_Position might be high but displacement small
        (97.8, 100.3, 97.5, 100.05),  # 4 FAKE CLOSE
        (100.05, 100.1, 96, 96.5),  # 5 collapse
    ]
    for idx, (o,h,l,c) in enumerate(prices):
        vol = 1500 if idx==4 else 1000
        data.append({
            'timestamp': base + timedelta(minutes=idx*5),
            'open': o, 'high': h, 'low': l, 'close': c, 'volume': vol
        })
    return pd.DataFrame(data)

def generate_bos_liquidity_sweep_trap():
    """High Liquidity Sweep Trap: long upper wick, small body, wick is biggest part"""
    data = []
    base = datetime(2024,1,1)
    prices = [
        (95, 96, 94, 95.5),
        (95.5, 100, 95.5, 99.8),  # high 100
        (99.8, 99.9, 97, 97.5),
        # Sweep: high 102, low 97.5, open 98, close 98.5 (body 0.5 small, upper wick 102-98.5=3.5 huge 87% of range)
        # Upper wick ratio 3.5/4.5=0.77 >0.6 => trap
        (97.5, 102, 97.5, 98.5),  # 3 SWEEP TRAP
        (98.5, 99, 96, 96.2),  # 4 drop
    ]
    for idx, (o,h,l,c) in enumerate(prices):
        vol = 2000 if idx==3 else 1000
        data.append({
            'timestamp': base + timedelta(minutes=idx*5),
            'open': o, 'high': h, 'low': l, 'close': c, 'volume': vol
        })
    return pd.DataFrame(data)

def generate_bos_churning_trap():
    """Churning: huge volume but tiny body, absorption"""
    data = []
    base = datetime(2024,1,1)
    prices = [
        (95, 96, 94, 95.5),
        (95.5, 100, 95.5, 99.8),
        (99.8, 99.9, 97, 97.5),
        # Churning: open 97.5 high 101 low 97.5 close 97.8 (body 0.3 tiny) volume 6000 huge
        # Effort = 0.3/6000=0.00005 vs avg effort 0.002 => churning
        (97.5, 101, 97.5, 97.8),  # 3 CHURNING
        (97.8, 98, 96, 96.5),
    ]
    for idx, (o,h,l,c) in enumerate(prices):
        vol = 6000 if idx==3 else 1000
        data.append({
            'timestamp': base + timedelta(minutes=idx*5),
            'open': o, 'high': h, 'low': l, 'close': c, 'volume': vol
        })
    return pd.DataFrame(data)
