"""Discount Array Tests"""
import pandas as pd
from datetime import datetime, timedelta

def generate_hyper_impulsive_move():
    """Hyper-Impulsive: few candles, huge volume, large bodies, no overlap"""
    data = []
    base = datetime(2024,1,1)
    # Origin low at 100
    data.append({'timestamp': base, 'open': 100, 'high': 100.5, 'low': 100, 'close': 100.2, 'volume': 1000})
    # 5 candles to 120 hyper
    for i in range(1,6):
        o = 100 + (i-1)*4
        c = o + 3.8  # large body
        h = c + 0.2
        l = o - 0.1
        vol = 3000  # huge
        data.append({
            'timestamp': base + timedelta(minutes=i*5),
            'open': o, 'high': h, 'low': l, 'close': c, 'volume': vol
        })
    # Pullback
    for i in range(6,15):
        o = 120 - (i-6)*0.5
        h = o + 0.2
        l = o - 0.6
        c = o - 0.4
        data.append({
            'timestamp': base + timedelta(minutes=i*5),
            'open': o, 'high': h, 'low': l, 'close': c, 'volume': 800
        })
    return pd.DataFrame(data)

def generate_weak_gradual_move():
    """Weak/Gradual: many candles, overlapping, small bodies"""
    data = []
    base = datetime(2024,1,1)
    data.append({'timestamp': base, 'open': 100, 'high': 100.5, 'low': 100, 'close': 100.2, 'volume': 1000})
    price = 100
    for i in range(1,20):
        # Overlapping, small bodies, mix bullish bearish
        o = price
        if i % 3 == 0:
            c = o - 0.3  # bearish overlap
        else:
            c = o + 0.5
        h = max(o,c) + 0.3
        l = min(o,c) - 0.3
        vol = 1000
        price = c
        data.append({
            'timestamp': base + timedelta(minutes=i*5),
            'open': o, 'high': h, 'low': l, 'close': c, 'volume': vol
        })
    # Ensure high around 115
    # Pullback deep
    for i in range(20,30):
        o = price
        c = o - 0.6
        h = o + 0.2
        l = c - 0.3
        price = c
        data.append({
            'timestamp': base + timedelta(minutes=i*5),
            'open': o, 'high': h, 'low': l, 'close': c, 'volume': 900
        })
    return pd.DataFrame(data)

def generate_discount_with_fvg_deep():
    """For Induced Trap: shallow bounce at 52% but deep FVGs at 75% unfilled"""
    data = []
    base = datetime(2024,1,1)
    # Up move 100 to 120
    data.append({'timestamp': base, 'open': 100, 'high': 100.5, 'low': 100, 'close': 100.3, 'volume': 1000})
    for i in range(1,5):
        o = 100 + i*5
        data.append({
            'timestamp': base + timedelta(minutes=i*5),
            'open': o, 'high': o+5, 'low': o-0.2, 'close': o+4.5, 'volume': 2000
        })
    # Down to 109.6 (52% retracement: 120 - range20*0.52=109.6)
    # This bounce will be inducement if deep FVG exists at 105 (75%)
    for i in range(5,10):
        o = 120 - (i-5)*2
        c = o - 1.5
        data.append({
            'timestamp': base + timedelta(minutes=i*5),
            'open': o, 'high': o+0.3, 'low': c-0.2, 'close': c, 'volume': 800
        })
    # Bounce at 109.6
    data.append({
        'timestamp': base + timedelta(minutes=10*5),
        'open': 109.6, 'high': 110.5, 'low': 109.5, 'close': 110.2, 'volume': 900
    })
    return pd.DataFrame(data)

def generate_liquidity_bleeding():
    """Bleeding: price dropping into discount with increasing bearish volume + CVD collapsing"""
    data = []
    base = datetime(2024,1,1)
    # Up 100 to 120
    for i in range(5):
        o = 100 + i*4
        data.append({
            'timestamp': base + timedelta(minutes=i*5),
            'open': o, 'high': o+4.5, 'low': o-0.2, 'close': o+4, 'volume': 2000
        })
    # Down with increasing bearish volume
    price = 120
    vol = 1000
    for i in range(5,15):
        o = price
        c = o - 1.0 - i*0.1  # increasing bearish size
        h = o + 0.2
        l = c - 0.5
        vol += 300  # increasing
        price = c
        data.append({
            'timestamp': base + timedelta(minutes=i*5),
            'open': o, 'high': h, 'low': l, 'close': c, 'volume': vol
        })
    return pd.DataFrame(data)
