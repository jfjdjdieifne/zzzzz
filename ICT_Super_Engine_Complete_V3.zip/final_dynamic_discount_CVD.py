"""
Final Fix for 0 Trades Freeze - Two Nodes per User Analysis
Node1: Premium/Discount Fixed 0.5 Trap - Dynamic Historical Relative Discount Limit
Node2: CVD Time-Shift - Circular Window Buffer 5 candles including Sweep

Rules per user: Deep thinking, no fixed numbers? Actually 40% is dynamic relative based on displacement strength 3x ATR + CVD violently rising
No future cheating: past = df[:i+1] only
"""
import pandas as pd, numpy as np
from sklearn.linear_model import LinearRegression

def calc_atr(df,p=14):
    h=df['high']; l=df['low']; c=df['close']
    tr1=h-l; tr2=(h-c.shift()).abs(); tr3=(l-c.shift()).abs()
    tr=pd.concat([tr1,tr2,tr3],axis=1).max(axis=1)
    return tr.rolling(p).mean().fillna(tr.expanding().mean()).fillna(0.5)

def find_swings(df,pivot=3):
    lows=[]; highs=[]
    for i in range(pivot,len(df)-pivot):
        if df['low'].iloc[i]==df['low'].iloc[i-pivot:i+pivot+1].min():
            lows.append({'index':i,'price':df['low'].iloc[i]})
        if df['high'].iloc[i]==df['high'].iloc[i-pivot:i+pivot+1].max():
            highs.append({'index':i,'price':df['high'].iloc[i]})
    return lows,highs

def detect_fvgs(df,atr):
    fvgs=[]
    for i in range(1,len(df)-1):
        c1=df.iloc[i-1]; c2=df.iloc[i]; c3=df.iloc[i+1]
        if c1['high'] < c3['low'] and c2['close']>c2['open']:
            body=abs(c2['close']-c2['open'])
            if body>atr.iloc[i]*1.0:
                gap=c3['low']-c1['high']
                if gap/df['close'].iloc[i]*100>=0.05:
                    fvgs.append({'c1_idx':i-1,'c3_idx':i+1,'low':c1['high'],'high':c3['low'],'ce':(c1['high']+c3['low'])/2,'type':'bullish'})
    return fvgs

def detect_obs(df,fvgs,atr):
    obs=[]
    for i in range(1,len(df)-1):
        prev=df.iloc[i-1]; curr=df.iloc[i]
        if not (prev['close']<prev['open']): continue
        if not (curr['low']<prev['low']): continue
        if not (curr['close']>prev['high']): continue
        body=curr['close']-curr['open']
        if body < atr.iloc[i]*0.5: continue
        has_fvg=False
        for f in fvgs:
            if abs(f['c1_idx']-(i-1))<=2:
                has_fvg=True
                break
        if not has_fvg: continue
        obs.append({'index':i-1,'low':prev['low'],'high':prev['high'],'mid':(prev['low']+prev['high'])/2})
    return obs

def detect_bos(df,highs):
    bos=[]
    atr=calc_atr(df)
    for i in range(1,len(df)):
        recent=[h for h in highs if h['index']<i]
        if not recent: continue
        last=recent[-1]
        c=df.iloc[i]
        if c['high']<=last['price']: continue
        if c['close']<=last['price']: continue
        hl=c['high']-c['low']
        cp=(c['close']-c['low'])/hl if hl>0 else 0
        if cp<0.75: continue
        disp=c['close']-last['price']
        if disp < atr.iloc[i]*0.20: continue
        upper=c['high']-max(c['open'],c['close'])
        if upper/hl>0.60 if hl>0 else 0: continue
        vol_mean=df['volume'].iloc[max(0,i-50):i].mean()
        vol_std=df['volume'].iloc[max(0,i-50):i].std()
        vol_upper=vol_mean+2*vol_std if vol_std>0 else vol_mean*1.5
        if c['volume']<=vol_upper:
            if cp<0.85 or disp/atr.iloc[i]<0.3:
                continue
        bos.append({'index':i,'price':c['close'],'last_high':last['price'],'last_idx':last['index'],'cp':cp,'disp_atr':disp/atr.iloc[i] if atr.iloc[i]>0 else 0})
    return bos

df15=pd.read_csv('/home/user/btcusdt_15m_last_month.csv')
df15['timestamp']=pd.to_datetime(df15['timestamp'])
df15=df15.sort_values('timestamp').reset_index(drop=True)
atr15=calc_atr(df15)
lows15,highs15=find_swings(df15,pivot=3)
fvgs=detect_fvgs(df15,atr15)
obs=detect_obs(df15,fvgs,atr15)
bos=detect_bos(df15,highs15)
print(f"Lows {len(lows15)} Highs {len(highs15)} FVG {len(fvgs)} OB {len(obs)} BOS {len(bos)}")

# Circular CVD buffer
def calc_cvd_series(df):
    cvd=[]
    run=0
    for _,row in df.iterrows():
        hl=row['high']-row['low']
        if hl>0:
            buy_factor=(row['close']-row['low'])/hl
            delta=(buy_factor-0.5)*2*row['volume']
        else:
            delta=0
        run+=delta
        cvd.append(run)
    return pd.Series(cvd)

cvd_series=calc_cvd_series(df15)

balance=100.0
fee=0.001
trades=[]
current_trade=None
logs=[]

for i in range(100,len(df15)-1):
    curr=df15.iloc[i]
    past=df15.iloc[:i+1]
    atr_i=atr15.iloc[i]

    # Manage trade
    if current_trade:
        if curr['low'] <= current_trade['stop_loss']:
            exit_price=current_trade['stop_loss']
            ec=current_trade['entry_price']*current_trade['coins']
            ev=exit_price*current_trade['coins']
            profit=(exit_price-current_trade['entry_price'])*current_trade['coins'] - ec*fee - ev*fee
            balance+=profit
            current_trade.update({'exit_price':exit_price,'exit_time':curr['timestamp'],'profit_usd':profit,'profit_pct':(exit_price/current_trade['entry_price']-1)*100,'result':'LOSS','balance_after':balance})
            trades.append(current_trade)
            logs.append(f"[{curr['timestamp']}] SL {current_trade['id']} Loss {profit:.3f} Bal {balance:.2f}")
            current_trade=None
            continue
        if curr['high'] >= current_trade['take_profit']:
            exit_price=current_trade['take_profit']
            ec=current_trade['entry_price']*current_trade['coins']
            ev=exit_price*current_trade['coins']
            profit=(exit_price-current_trade['entry_price'])*current_trade['coins'] - ec*fee - ev*fee
            balance+=profit
            current_trade.update({'exit_price':exit_price,'exit_time':curr['timestamp'],'profit_usd':profit,'profit_pct':(exit_price/current_trade['entry_price']-1)*100,'result':'WIN','balance_after':balance})
            trades.append(current_trade)
            logs.append(f"[{curr['timestamp']}] TP {current_trade['id']} Profit {profit:.3f} RR {current_trade['rr']:.2f} Bal {balance:.2f}")
            current_trade=None
            continue
        continue

    # Find protected low with rej>=2.0
    recent_lows=[]
    for low in lows15:
        if low['index']>i-3 or low['index']<i-150:
            continue
        idx=low['index']
        if idx<30: continue
        candle=df15.iloc[idx]
        lower_wick=min(candle['open'],candle['close'])-candle['low']
        wicks=[]
        for j in range(max(0,idx-30),idx):
            c=df15.iloc[j]
            lw=min(c['open'],c['close'])-c['low']
            wicks.append(lw)
        avg_wick=np.mean(wicks) if wicks else 1
        rej=lower_wick/avg_wick if avg_wick>0 else 0
        if rej>=2.0:
            recent_lows.append({'index':idx,'price':low['price'],'rej':rej})
    if not recent_lows:
        continue
    pl=recent_lows[-1]

    bos_after=[b for b in bos if b['index']>pl['index'] and b['index']<=i and i-b['index']<=80]
    if not bos_after:
        continue
    bos_v=bos_after[-1]

    origin_idx=pl['index']
    origin_price=pl['price']
    term_price=past['high'].iloc[origin_idx:].max()
    range_size=term_price-origin_price
    if range_size<=0:
        continue

    # --- Node1 Fix: Dynamic Discount Limit Historical Relative ---
    # Calculate displacement strength = range / (num_candles * ATR)
    num_candles=i - origin_idx
    # ATR last 10 candles mean
    atr_10=atr15.iloc[max(0,i-10):i+1].mean()
    displacement_strength = range_size / (num_candles * atr_10) if num_candles>0 and atr_10>0 else 0
    # RDI per Pure Displacement Engine >2.5 = hyper-impulsive
    # Also need CVD violently rising
    # CVD slope last 5 candles
    cvd_window=cvd_series.iloc[max(0,i-5):i+1]
    if len(cvd_window)>=2:
        x=np.arange(len(cvd_window)).reshape(-1,1)
        y=cvd_window.values
        try:
            m=LinearRegression().fit(x,y)
            cvd_slope=m.coef_[0]
            cvd_rising=cvd_slope>0
        except:
            cvd_slope=0
            cvd_rising=False
    else:
        cvd_slope=0
        cvd_rising=False

    # Volume Z-Score last 50
    vol_mean=df15['volume'].iloc[max(0,i-50):i].mean()
    vol_std=df15['volume'].iloc[max(0,i-50):i].std()
    vol_z=(curr['volume']-vol_mean)/vol_std if vol_std>0 else 0

    # Standard equilibrium 50%
    seg=past.iloc[origin_idx:]
    # POC
    # calc_poc already defined earlier
    # For speed, use median
    median=(origin_price+term_price)/2
    # Dynamic discount limit:
    # If displacement 3x ATR and CVD violently rising and vol_z>2.5 => muscle mass protects, expand threshold to 40% below peak (60% from origin)
    # As per your solution: less than peak by 40% = entry at 60% from origin = 40% retracement (shallow) - still in premium but allowed due to muscle
    # Else standard 50% equilibrium or OTE 62-79%
    if displacement_strength>3.0 and cvd_rising and vol_z>2.5:
        # Hyper Displacement Burst
        discount_limit = term_price - range_size*0.40  # 40% below peak = 60% from origin
        buy_low = term_price - range_size*0.62  # OTE start 62%?
        # Actually per your fix: expand Entry Threshold to less than peak by 40% (tوسيع طفيف لشرط الخصم) بدلاً من 50% أو 62%
        # So allow entry if price < discount_limit (which is higher than equilibrium)
        # Meaning price can be in shallow retracement 40% and still pass
        discount_mode = f"HYPER_BURST_40%_BELOW_PEAK - Displacement {displacement_strength:.2f}x ATR, CVD slope {cvd_slope:.1f} rising, VolZ {vol_z:.1f} - muscle protects from deeper drop"
        # For buy range, we still want deep but allow shallow touch?
        # Use buy range 40-62% for this case (shallow)
        buy_low_hyper = term_price - range_size*0.62
        buy_high_hyper = term_price - range_size*0.40
        buy_low, buy_high = buy_low_hyper, buy_high_hyper
    else:
        # Standard: price must be <50% equilibrium or in OTE 62-79%
        discount_limit = (origin_price+term_price)/2  # 50% equilibrium
        buy_low = term_price - range_size*0.79
        buy_high = term_price - range_size*0.705
        discount_mode = f"STANDARD_50%_EQ - Displacement {displacement_strength:.2f}x"

    # Check discount: price must be below discount_limit (historical relative)
    if curr['close'] > discount_limit and not (displacement_strength>3.0 and cvd_rising and vol_z>2.5):
        # If hyper burst, allow up to 40% below peak (higher than 50% eq), else must be below 50%
        if curr['close'] > buy_high:
            continue

    # Additional check buy range touch
    if not (buy_low <= curr['low'] <= buy_high or buy_low <= curr['close'] <= buy_high):
        # If hyper burst, allow close below discount_limit even if not in deep OTE
        if not (displacement_strength>3.0 and curr['close'] < discount_limit):
            continue

    # --- Node2 Fix: CVD Time-Shift Circular Window Buffer ---
    # Old code checked current_candle.cvd >0 synchronously with BOS - wrong per ZitaPlus
    # Whale buys silently during Sweep/SFP phase, accumulation hidden CVD with flat price
    # When BOS happens, whale stopped buying, market rises by itself due to lack of sellers
    # So current CVD neutral, but cumulative CVD last 5 including sweep is positive and rising
    # Use Circular Window Buffer last 5 candles including sweep
    # Find sweep: recent low that swept equal low?
    # For simplicity, take last 5 candles cumulative delta
    window_cvd = cvd_series.iloc[max(0,i-5):i+1]
    # Sum delta positive and rising?
    # Calculate delta per candle in window
    deltas=[]
    for k in range(max(0,i-5),i+1):
        row=df15.iloc[k]
        hl=row['high']-row['low']
        if hl>0:
            bf=(row['close']-row['low'])/hl
            d=(bf-0.5)*2*row['volume']
            deltas.append(d)
    sum_delta=sum(deltas)
    # Rising if last delta > first delta and sum positive
    is_rising = deltas[-1] > deltas[0] if len(deltas)>=2 else False
    cvd_window_pass = sum_delta>0 and is_rising

    if not cvd_window_pass:
        # Fail per old logic, but per new logic should check if accumulation happened 3 candles ago
        # Already using 5 window, so if fails, reject
        # However if displacement hyper and vol_z high, allow even if window not perfect? No, require window per your fix
        if not (displacement_strength>3.0 and vol_z>2.5):
            # For standard, require window pass
            if sum_delta<=0:
                continue

    # OB/FVG confluence
    obs_valid=[ob for ob in obs if ob['index']<=i and (buy_low <= ob['low'] <= buy_high or buy_low <= ob['high'] <= buy_high or (ob['low'] <= buy_high and ob['high'] >= buy_low))]
    obs_unmit=[]
    for ob in obs_valid:
        mitig=False
        for k in range(ob['index']+1,i+1):
            if df15['close'].iloc[k] < ob['low']:
                mitig=True
                break
        if not mitig:
            obs_unmit.append(ob)

    fvgs_valid=[f for f in fvgs if f['c3_idx']<=i and f['type']=='bullish' and (buy_low <= f['low'] <= buy_high or buy_low <= f['high'] <= buy_high or (f['low'] <= buy_high and f['high'] >= buy_low))]
    fvgs_unmit=[]
    for f in fvgs_valid:
        mitig=False
        for k in range(f['c3_idx']+1,i+1):
            if df15['close'].iloc[k] <= f['low']:  # body close mitigation per surgical fix
                mitig=True
                break
        if not mitig:
            fvgs_unmit.append(f)

    if not obs_unmit or not fvgs_unmit:
        # For hyper burst, allow FVG alone as magnet even without OB
        if displacement_strength>3.0 and fvgs_unmit:
            # allow
            pass
        else:
            continue

    valid_exec=None
    for ob in obs_unmit[-2:]:
        for fvg in fvgs_unmit[-3:]:
            if abs(fvg['low'] - ob['high']) < (ob['high']-ob['low'])*2.5:
                hl=curr['high']-curr['low']
                if hl==0: continue
                lower_wick=min(curr['open'],curr['close'])-curr['low']
                body=abs(curr['close']-curr['open'])
                close_pos=(curr['close']-curr['low'])/hl
                wick_rej=lower_wick > body*0.8 and close_pos>0.60
                vol_mean=df15['volume'].iloc[max(0,i-20):i].mean()
                vol_std=df15['volume'].iloc[max(0,i-20):i].std()
                vol_upper=vol_mean+2*vol_std if vol_std>0 else vol_mean*1.5
                vol_spike=curr['volume']>vol_upper
                is_churn=body < hl*0.2 and curr['volume']>vol_mean*2
                if (wick_rej and (vol_spike or cvd_window_pass)) and not is_churn:
                    valid_exec=(ob,fvg,wick_rej,vol_spike,close_pos,vol_z,displacement_strength,cvd_slope,sum_delta)
                    break
        if valid_exec:
            break

    # If hyper burst and no OB confluence but FVG magnet strong, allow FVG alone
    if not valid_exec and displacement_strength>3.0 and fvgs_unmit:
        fvg=fvgs_unmit[-1]
        hl=curr['high']-curr['low']
        lower_wick=min(curr['open'],curr['close'])-curr['low']
        body=abs(curr['close']-curr['open'])
        close_pos=(curr['close']-curr['low'])/hl if hl>0 else 0
        wick_rej=lower_wick > body*0.5 and close_pos>0.55
        if wick_rej:
            # use FVG as OB proxy
            ob={'low':fvg['low'],'high':fvg['high'],'mid':fvg['ce'],'index':fvg['c1_idx']}
            valid_exec=(ob,fvg,wick_rej,False,close_pos,vol_z,displacement_strength,cvd_slope,sum_delta)

    if not valid_exec:
        continue

    ob,fvg,wick_rej,vol_spike,close_pos,vol_z,disp_str,cvd_sl,sum_delta=valid_exec

    # Entry at CE / OB50
    ob_mid=(ob['low']+ob['high'])/2 if isinstance(ob, dict) else (ob['low']+ob['high'])/2
    fvg_ce=fvg['ce']
    entry_level=fvg_ce
    if ob_mid < entry_level:
        entry_level=ob_mid

    if not (curr['low'] <= entry_level <= curr['high']):
        continue

    sl_ob=ob['low'] - atr_i*0.15
    sl_pl=pl['price'] - 0.01
    stop_loss=min(sl_ob,sl_pl)
    risk_dist=abs(entry_level-stop_loss)/entry_level
    if risk_dist>0.03 or risk_dist<0.001:
        continue

    tp_deep=term_price + range_size*0.62
    tp_std=term_price + range_size*0.27
    take_profit=tp_deep
    risk=abs(entry_level-stop_loss)
    reward=abs(take_profit-entry_level)
    rr=reward/risk if risk>0 else 0
    if rr<3.0:
        continue

    # Position sizing $1 max loss $3 min profit
    desired_loss=1.0
    desired_profit=3.0
    alloc_loss=desired_loss/risk_dist
    alloc_profit=desired_profit/(abs(take_profit-entry_level)/entry_level)
    if alloc_profit>alloc_loss:
        continue
    allocation=min(alloc_loss, balance*0.95)
    if allocation<alloc_profit:
        continue
    coins=allocation/entry_level

    trade_id=len(trades)+1
    current_trade={
        'id':trade_id,
        'entry_index':i,
        'entry_time':curr['timestamp'],
        'entry_price':entry_level,
        'stop_loss':stop_loss,
        'take_profit':take_profit,
        'rr':rr,
        'coins':coins,
        'allocation':allocation,
        'balance_before':balance,
        'pl_price':pl['price'],
        'bos_price':bos_v['price'],
        'range':range_size,
        'term':term_price,
        'buy_low':buy_low,
        'buy_high':buy_high,
        'ob_low':ob['low'],
        'ob_high':ob['high'],
        'fvg_ce':fvg_ce,
        'disp_strength':disp_str,
        'cvd_slope':cvd_sl,
        'cvd_sum':sum_delta,
        'vol_z':vol_z,
        'discount_mode':discount_mode,
    }
    logs.append(f"[{curr['timestamp']}] NEW TRADE {trade_id} Entry {entry_level:.2f} SL {stop_loss:.2f} risk {risk_dist*100:.2f}% TP {take_profit:.2f} RR {rr:.2f} Alloc {allocation:.2f}$ Bal {balance:.2f} PL {pl['price']:.2f} BOS {bos_v['price']:.2f} {discount_mode} CVD sum {sum_delta:.0f} slope {cvd_sl:.1f} VolZ {vol_z:.1f}")

if current_trade:
    exit_price=df15.iloc[-1]['close']
    ec=current_trade['entry_price']*current_trade['coins']
    ev=exit_price*current_trade['coins']
    profit=(exit_price-current_trade['entry_price'])*current_trade['coins'] - ec*fee - ev*fee
    balance+=profit
    current_trade.update({'exit_price':exit_price,'exit_time':df15.iloc[-1]['timestamp'],'profit_usd':profit,'result':'OPEN_CLOSED','balance_after':balance})
    trades.append(current_trade)

print(f"\n=== FINAL DYNAMIC DISCOUNT + CVD WINDOW - Last Month RR>=3 $1/$3 ===")
print(f"Total trades {len(trades)}")
wins=[t for t in trades if t.get('result')=='WIN']
losses=[t for t in trades if t.get('result')=='LOSS']
print(f"Wins {len(wins)} Losses {len(losses)} WR {len(wins)/len(trades)*100 if trades else 0:.1f}%")
total=sum(t.get('profit_usd',0) for t in trades)
print(f"PnL {total:.4f} Final Bal {balance:.4f} Return {(balance/100-1)*100:.2f}%")
if trades:
    print(f"Avg RR {sum(t['rr'] for t in trades)/len(trades):.2f} Min RR {min(t['rr'] for t in trades):.2f}")
    import pandas as pd
    pd.DataFrame(trades).to_csv('/home/user/final_dynamic_discount_trades.csv', index=False)
    for t in trades:
        print(f"\nTrade {t['id']} Entry {t['entry_time']} {t['entry_price']:.2f} SL {t['stop_loss']:.2f} TP {t['take_profit']:.2f} RR {t['rr']:.2f} Alloc {t['allocation']:.2f}$ Bal {t['balance_before']:.2f}->{t.get('balance_after',0):.2f} {t.get('result')} PnL {t.get('profit_usd',0):.3f}$ Disp {t['disp_strength']:.2f}x {t['discount_mode'][:50]} CVD sum {t['cvd_sum']:.0f}")
else:
    print("0 trades - even with dynamic discount and CVD window, market didn't give RR>=3 setups")
