"""
FINAL HIGH-BETA ALT ENGINE - 15%+ 20%+ Halal Spot No Margin
Tactics per user:
1. High-Beta Alts Selection: Ignore BTC/ETH, go to SOL, NEAR, FET etc with Beta >1.2
   - When BTC moves 1%, alts move 4-5% same ICT models (Sweep+OB+FVG)
   - Entry $100 in 5% move RR 3:1 => $15 profit vs $1 on BTC

2. Multi-Timeframe Compound Frequency: 3M/5M for 5 alts simultaneously, 4-5 quick trades/day, 1.5-2 profit each, compounding

Filters (Intermarket Order Flow):
1. Rolling Pearson Correlation last 30 candles - Gate.io research Correlation ~0.85
2. Crypto Beta Factor - Bitget Beta Play, HFT algorithms pump high-beta alts after BTC breakout
3. Cross-Asset Order Flow Volume - ScienceDirect order flow predictive, check CVD alt + BTC

Traps:
- Bitcoin Liquidity Gravity - CoinDesk/Kaiko BTC ultimate liquidity pool, when BTC drops violently liquidation cascades, market makers withdraw bids from alts
- Synthetic Displacement Trap - Bookmap low-liquidity pumps, short squeezes not real whale

Exception: True CVD Divergence Regime Shift - BTC slowly down while alt CVD explodes vertically VolZ>3.0 + Spot Inflows = forced accumulation

All dynamic weight muscle thinking, no fixed dumb numbers, with sources
"""
import pandas as pd, numpy as np
from sklearn.linear_model import LinearRegression

def calc_atr(df,p=14):
    h=df['high']; l=df['low']; c=df['close']
    tr1=h-l; tr2=(h-c.shift()).abs(); tr3=(l-c.shift()).abs()
    tr=pd.concat([tr1,tr2,tr3],axis=1).max(axis=1)
    return tr.rolling(p).mean().fillna(tr.expanding().mean()).fillna(0.5)

def calc_cvd_series(df):
    cvd=[]
    run=0
    for _,row in df.iterrows():
        hl=row['high']-row['low']
        if hl>0:
            bf=(row['close']-row['low'])/hl
            d=(bf-0.5)*2*row['volume']
        else:
            d=0
        run+=d
        cvd.append(run)
    return pd.Series(cvd)

def rolling_correlation(x,y,window=30):
    # Pearson rolling
    corr=[]
    for i in range(len(x)):
        if i<window:
            corr.append(0)
        else:
            xv=x.iloc[i-window:i]
            yv=y.iloc[i-window:i]
            if xv.std()==0 or yv.std()==0:
                corr.append(0)
            else:
                c=np.corrcoef(xv,yv)[0,1]
                corr.append(c if not np.isnan(c) else 0)
    return pd.Series(corr)

def rolling_beta(alt_returns, btc_returns, window=60):
    betas=[]
    r2s=[]
    for i in range(len(alt_returns)):
        if i<window:
            betas.append(0); r2s.append(0)
        else:
            x=btc_returns.iloc[i-window:i].values.reshape(-1,1)
            y=alt_returns.iloc[i-window:i].values
            if np.std(x)==0:
                betas.append(0); r2s.append(0)
            else:
                try:
                    model=LinearRegression().fit(x,y)
                    beta=model.coef_[0]
                    r2=model.score(x,y)
                    betas.append(beta)
                    r2s.append(r2)
                except:
                    betas.append(0); r2s.append(0)
    return pd.Series(betas), pd.Series(r2s)

# Load BTC 15m
df_btc=pd.read_csv('/home/user/btcusdt_15m_last_month.csv')
df_btc['timestamp']=pd.to_datetime(df_btc['timestamp'])
df_btc=df_btc.sort_values('timestamp').reset_index(drop=True)

# Create synthetic alt data: SOL with Beta 1.444 R2 0.6975 per source Medium SOL vs BTC Beta
# y = 1.444*x + 0.00012
beta_true=1.444
np.random.seed(42)
# Generate alt returns = beta * btc_returns + noise
btc_returns=df_btc['close'].pct_change().fillna(0)
noise=np.random.normal(0,0.002, len(btc_returns))  # 0.2% noise
alt_returns=btc_returns*beta_true + noise

# Build synthetic SOL price
alt_close=[df_btc['close'].iloc[0]*0.01]  # start 1% of BTC price ~600
for i in range(1,len(df_btc)):
    prev=alt_close[-1]
    ret=alt_returns.iloc[i]
    alt_close.append(prev*(1+ret))

df_alt=pd.DataFrame({
    'timestamp':df_btc['timestamp'],
    'open':alt_close,
    'high':[c*1.005 for c in alt_close],
    'low':[c*0.995 for c in alt_close],
    'close':alt_close,
    'volume':df_btc['volume']*1.2  # alts have 20% more volume on moves
})
# Adjust high/low to have some wicks
for i in range(len(df_alt)):
    # Make high = max(open,close)* (1+ random 0.3%)
    o=df_alt['open'].iloc[i]
    c=df_alt['close'].iloc[i]
    h=max(o,c)*(1+abs(np.random.normal(0,0.002)))
    l=min(o,c)*(1-abs(np.random.normal(0,0.002)))
    df_alt.at[i,'high']=h
    df_alt.at[i,'low']=l

print(f"BTC {len(df_btc)} ALT synthetic {len(df_alt)} Beta true {beta_true}")

# Calculate rolling correlation and beta
corr_series=rolling_correlation(df_alt['close'].pct_change(), df_btc['close'].pct_change(), window=30)
beta_series, r2_series=rolling_beta(df_alt['close'].pct_change(), df_btc['close'].pct_change(), window=60)

# ATR and CVD
atr_alt=calc_atr(df_alt)
cvd_alt=calc_cvd_series(df_alt)
cvd_btc=calc_cvd_series(df_btc)

# Find swings alt
def find_swings(df,pivot=3):
    lows=[]; highs=[]
    for i in range(pivot,len(df)-pivot):
        if df['low'].iloc[i]==df['low'].iloc[i-pivot:i+pivot+1].min():
            lows.append({'index':i,'price':df['low'].iloc[i]})
        if df['high'].iloc[i]==df['high'].iloc[i-pivot:i+pivot+1].max():
            highs.append({'index':i,'price':df['high'].iloc[i]})
    return lows,highs

lows_alt,highs_alt=find_swings(df_alt,pivot=3)

balance=100.0
fee=0.001
trades=[]
current_trade=None
logs=[]

for i in range(100,len(df_alt)-1):
    curr=df_alt.iloc[i]
    curr_btc=df_btc.iloc[i]
    past=df_alt.iloc[:i+1]
    atr_i=atr_alt.iloc[i]
    corr=corr_series.iloc[i]
    beta=beta_series.iloc[i]
    r2=r2_series.iloc[i]

    # Manage trade
    if current_trade:
        if curr['low'] <= current_trade['stop_loss']:
            exit_price=current_trade['stop_loss']
            ec=current_trade['entry_price']*current_trade['coins']
            ev=exit_price*current_trade['coins']
            profit=(exit_price-current_trade['entry_price'])*current_trade['coins'] - ec*fee - ev*fee
            balance+=profit
            current_trade.update({'exit_price':exit_price,'exit_time':curr['timestamp'],'profit_usd':profit,'profit_pct':(exit_price/current_trade['entry_price']-1)*100,'result':'LOSS','balance_after':balance})
            trades.append(current_trade)
            current_trade=None
            continue
        if curr['high'] >= current_trade['take_profit']:
            exit_price=current_trade['take_profit']
            ec=current_trade['entry_price']*current_trade['coins']
            ev=exit_price*current_trade['coins']
            profit=(exit_price-current_trade['entry_price'])*current_trade['coins'] - ec*fee - ev*fee
            balance+=profit
            current_trade.update({'exit_price':exit_price,'exit_time':curr['timestamp'],'profit_usd':profit,'profit_pct':(exit_price/current_trade['entry_price']-1)*100,'result':'WIN','balance_after':balance})
            trades.append(current_trade)
            current_trade=None
            continue
        continue

    # --- Filter 1: Rolling Pearson Correlation ---
    # Gate.io Research: correlation ~0.85, must be positive and strong
    if corr < 0.70:
        # Correlation weak, skip unless true CVD divergence exception
        # Check exception later
        pass_condition_corr=False
    else:
        pass_condition_corr=True

    # --- Filter 2: Beta Factor ---
    # Bitget Beta Play: high-beta alts amplify BTC moves, Beta >1.2 and R2>0.6
    # Source: SOL vs BTC Beta 1.444 R2 0.6975, high beta with high R2 = genuinely amplifying
    if beta < 1.2 or r2 < 0.5:
        pass_beta=False
    else:
        pass_beta=True

    # --- Filter 3: Cross-Asset Order Flow Volume ---
    # ScienceDirect: order flow predictive, check CVD alt + BTC both rising
    cvd_alt_now=cvd_alt.iloc[i]
    cvd_alt_prev=cvd_alt.iloc[max(0,i-5)]
    cvd_btc_now=cvd_btc.iloc[i]
    cvd_btc_prev=cvd_btc.iloc[max(0,i-5)]
    cvd_alt_rising=cvd_alt_now>cvd_alt_prev
    cvd_btc_rising=cvd_btc_now>cvd_btc_prev

    # --- Traps ---
    # Bitcoin Liquidity Gravity: when BTC drops violently, liquidation cascades, market makers withdraw bids from alts
    btc_drop_violent = curr_btc['close'] < df_btc['close'].iloc[i-1] and (df_btc['low'].iloc[i] < df_btc['low'].iloc[i-1]*0.98) and curr_btc['volume']>df_btc['volume'].iloc[max(0,i-20):i].mean()*2
    if btc_drop_violent and not (cvd_alt_rising and vol_z>3 if 'vol_z' in locals() else False):
        # Skip alt longs when BTC gravity pulling
        continue

    # Synthetic Displacement Trap: alt displacement not driven by real whale, but short squeeze or low liquidity
    # Check volume Z <1 but price up 2% => low-liquidity pump
    vol_mean=df_alt['volume'].iloc[max(0,i-20):i].mean()
    vol_std=df_alt['volume'].iloc[max(0,i-20):i].std()
    vol_z=(curr['volume']-vol_mean)/vol_std if vol_std>0 else 0
    price_change_pct=(curr['close']-curr['open'])/curr['open']*100
    is_low_liq_pump = vol_z<1.0 and price_change_pct>2.0
    if is_low_liq_pump:
        continue

    # --- Exception: True CVD Divergence Regime Shift ---
    # BTC slowly down or ranging, while alt CVD explodes vertically VolZ>3.0 + Spot Inflows (volume spike)
    # Source: ZitaPlus, Bitget
    btc_slow_down = df_btc['close'].iloc[i] < df_btc['close'].iloc[i-1]*1.001 and df_btc['close'].iloc[i] > df_btc['close'].iloc[i-1]*0.99  # ranging/slow down
    alt_cvd_explode = (cvd_alt_now - cvd_alt_prev) > 0 and vol_z>3.0
    is_true_divergence = btc_slow_down and alt_cvd_explode

    # Allow trade if (corr strong AND beta high AND CVD rising) OR true divergence exception
    if not ( (pass_condition_corr and pass_beta and cvd_alt_rising and cvd_btc_rising) or is_true_divergence ):
        if not is_true_divergence:
            continue

    # Find protected low with rej>=2.0
    recent_lows=[l for l in lows_alt if l['index']<=i-3 and i-l['index']<=100]
    valid_pl=[]
    for low in recent_lows:
        idx=low['index']
        if idx<30: continue
        candle=df_alt.iloc[idx]
        lower_wick=min(candle['open'],candle['close'])-candle['low']
        wicks=[]
        for j in range(max(0,idx-20),idx):
            c=df_alt.iloc[j]
            lw=min(c['open'],c['close'])-c['low']
            wicks.append(lw)
        avg_wick=np.mean(wicks) if wicks else 1
        rej=lower_wick/avg_wick if avg_wick>0 else 0
        if rej>=2.0:
            valid_pl.append({'index':idx,'price':low['price'],'rej':rej})
    if not valid_pl:
        continue
    pl=valid_pl[-1]

    # BOS: find last swing high before i
    recent_highs=[h for h in highs_alt if h['index']<i and h['index']>pl['index']]
    if not recent_highs:
        continue
    last_high=recent_highs[-1]
    # BOS if close > last high
    if curr['close'] <= last_high['price']:
        continue
    hl=curr['high']-curr['low']
    cp=(curr['close']-curr['low'])/hl if hl>0 else 0
    if cp<0.60:
        continue
    disp=curr['close']-last_high['price']
    if disp < atr_i*0.15:
        continue

    # Discount: origin=pl, term=max high since origin
    origin_idx=pl['index']
    origin_price=pl['price']
    term_price=past['high'].iloc[origin_idx:].max()
    range_size=term_price-origin_price
    if range_size<=0:
        continue

    # Dynamic discount inversely proportional to muscle power
    num_candles=i-origin_idx
    atr_10=atr_alt.iloc[max(0,i-10):i+1].mean()
    disp_power=range_size/(num_candles*atr_10) if num_candles>0 and atr_10>0 else 0
    muscle_power=disp_power * (1+max(0,vol_z)/5)

    discount_pct=0.79 - muscle_power*0.10
    discount_pct=max(0.30, min(0.79, discount_pct))
    buy_low=term_price - range_size*discount_pct
    buy_high=term_price - range_size*max(0.10, discount_pct-0.10)

    if curr['close']>buy_high and muscle_power<1.0:
        continue
    if not (buy_low <= curr['low'] <= buy_high or buy_low <= curr['close'] <= buy_high):
        if not (muscle_power>2.5 and curr['close'] < term_price - range_size*0.40):
            continue

    # Find OB/FVG in buy zone
    # Simplified: use recent low as OB
    # Find OBs
    # For speed, use last 2 lows as OB proxy
    # Check wick rejection
    lower_wick=min(curr['open'],curr['close'])-curr['low']
    body=abs(curr['close']-curr['open'])
    close_pos=(curr['close']-curr['low'])/hl if hl>0 else 0
    wick_rej=lower_wick > body*0.8 and close_pos>0.60

    if not wick_rej:
        continue

    # Entry at CE 50% of buy range
    entry_level=(buy_low+buy_high)/2
    if not (curr['low'] <= entry_level <= curr['high']):
        continue

    sl_ob=buy_low - atr_i*0.15
    sl_pl=pl['price'] - 0.01
    stop_loss=min(sl_ob,sl_pl)
    risk_dist=abs(entry_level-stop_loss)/entry_level
    if risk_dist>0.05 or risk_dist<0.001:
        continue

    tp_deep=term_price + range_size*0.62
    take_profit=tp_deep
    risk=abs(entry_level-stop_loss)
    reward=abs(take_profit-entry_level)
    rr=reward/risk if risk>0 else 0
    if rr<2.5:
        continue

    # Full-chest allocation
    allocation=balance*0.995
    coins=allocation/entry_level
    net_loss=allocation*risk_dist
    net_profit=allocation*abs(take_profit-entry_level)/entry_level

    # Require high-beta profit: when BTC moves 1%, alt moves 4-5% => with 100$ RR 3:1 => $15 profit
    # Our alt beta 1.444, so BTC 1% => alt 1.444% => with RR 3 => profit 4.33% => $4.33
    # To get $15 profit, need BTC 3% move => alt 4.33% => profit 4.33$? Actually need 5% alt move
    # Let's check reward % : if reward 5% with 100$ => profit $5
    reward_pct=abs(take_profit-entry_level)/entry_level*100
    if reward_pct<3.0:
        # For high-beta, require at least 3% reward to get $3+ profit
        if not (is_true_divergence and reward_pct>=2.0):
            continue

    trade_id=len(trades)+1
    current_trade={
        'id':trade_id,
        'entry_time':curr['timestamp'],
        'entry_price':entry_level,
        'stop_loss':stop_loss,
        'take_profit':take_profit,
        'rr':rr,
        'coins':coins,
        'allocation':allocation,
        'balance_before':balance,
        'risk_dist':risk_dist*100,
        'reward_dist':reward_pct,
        'net_loss':net_loss,
        'net_profit':net_profit,
        'pl_price':pl['price'],
        'term':term_price,
        'range':range_size,
        'discount_pct':discount_pct,
        'muscle_power':muscle_power,
        'beta':beta,
        'corr':corr,
        'r2':r2,
        'vol_z':vol_z,
        'is_true_div':is_true_divergence,
    }

# Close at end
if current_trade:
    exit_price=df_alt.iloc[-1]['close']
    ec=current_trade['entry_price']*current_trade['coins']
    ev=exit_price*current_trade['coins']
    profit=(exit_price-current_trade['entry_price'])*current_trade['coins'] - ec*fee - ev*fee
    balance+=profit
    current_trade.update({'exit_price':exit_price,'exit_time':df_alt.iloc[-1]['timestamp'],'profit_usd':profit,'result':'OPEN_CLOSED','balance_after':balance})
    trades.append(current_trade)

print(f"\n=== HIGH-BETA ALT ENGINE - Last Month 15M Synthetic SOL Beta 1.444 ===")
print(f"Total trades {len(trades)}")
wins=[t for t in trades if t.get('result')=='WIN']
losses=[t for t in trades if t.get('result')=='LOSS']
print(f"Wins {len(wins)} Losses {len(losses)} WR {len(wins)/len(trades)*100 if trades else 0:.1f}%")
total=sum(t.get('profit_usd',0) for t in trades)
print(f"PnL {total:.4f} Final Bal {balance:.4f} Return {(balance/100-1)*100:.2f}%")
if trades:
    print(f"Avg RR {sum(t['rr'] for t in trades)/len(trades):.2f} Avg risk {sum(t['risk_dist'] for t in trades)/len(trades):.2f}% Avg reward {sum(t['reward_dist'] for t in trades)/len(trades):.2f}%")
    print(f"Avg beta {sum(t['beta'] for t in trades)/len(trades):.2f} Avg corr {sum(t['corr'] for t in trades)/len(trades):.2f}")
    import pandas as pd
    pd.DataFrame(trades).to_csv('/home/user/high_beta_alt_trades.csv', index=False)
    for t in trades:
        print(f"\nTrade {t['id']} Entry {t['entry_time']} {t['entry_price']:.2f} SL {t['stop_loss']:.2f} risk {t['risk_dist']:.2f}% TP {t['take_profit']:.2f} reward {t['reward_dist']:.2f}% RR {t['rr']:.2f} Alloc {t['allocation']:.2f}$ NetLoss {t['net_loss']:.2f}$ NetProfit {t['net_profit']:.2f}$ Bal {t['balance_before']:.2f}->{t.get('balance_after',0):.2f} {t.get('result')} Beta {t['beta']:.2f} Corr {t['corr']:.2f} R2 {t['r2']:.2f} Muscle {t['muscle_power']:.2f}x TrueDiv {t['is_true_div']}")
else:
    print("0 trades - high-beta filters too strict for synthetic data, need lower corr threshold")
