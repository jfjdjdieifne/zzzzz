"""
FINAL LIVE TEST - Last Month - RR 3:1+ Guaranteed per ICT
Map1 Pro-Trend + Map2 Counter-Trend Combined - Surgical Strict - No Fixed Numbers
Entry: LIMIT at CE / OB50
SL: min(OB-ATR*0.15, PL-0.01)
TP: Term + Range*0.62 (deep) => RR 4.49-6.71 for deep OTE 70.5-79%
Enforce RR >=3.0
"""
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression

def calc_atr(df,p=14):
    h=df['high']; l=df['low']; c=df['close']
    tr1=h-l; tr2=(h-c.shift()).abs(); tr3=(l-c.shift()).abs()
    tr=pd.concat([tr1,tr2,tr3],axis=1).max(axis=1)
    return tr.rolling(p).mean().fillna(tr.expanding().mean()).fillna(0.5)

def calc_poc(seg,low_p,high_p,bins=20):
    edges=np.linspace(low_p,high_p,bins)
    vol_bins=np.zeros(bins-1)
    for _,row in seg.iterrows():
        typical=(row['high']+row['low']+row['close'])/3
        if low_p <= typical <= high_p:
            idx=np.digitize(typical,edges)-1
            idx=max(0,min(idx,len(vol_bins)-1))
            vol_bins[idx]+=row['volume']
    if vol_bins.sum()==0:
        return (low_p+high_p)/2
    return (edges[np.argmax(vol_bins)]+edges[np.argmax(vol_bins)+1])/2

# Load 15m
df15=pd.read_csv('/home/user/btcusdt_15m_last_month.csv')
df15['timestamp']=pd.to_datetime(df15['timestamp'])
df15=df15.sort_values('timestamp').reset_index(drop=True)

# Resample 4H for HTF
df4h=df15.set_index('timestamp').resample('4h').agg({'open':'first','high':'max','low':'min','close':'last','volume':'sum'}).dropna().reset_index()
print(f"15m {len(df15)} 4h {len(df4h)} period {df15['timestamp'].iloc[0]}->{df15['timestamp'].iloc[-1]}")

# Swing detection simple pivot
def find_swings(df,pivot=2):
    lows=[]; highs=[]
    for i in range(pivot,len(df)-pivot):
        # low
        window=df['low'].iloc[i-pivot:i+pivot+1]
        if df['low'].iloc[i]==window.min():
            # rejection filter will be applied later
            lows.append({'index':i,'price':df['low'].iloc[i],'timestamp':df['timestamp'].iloc[i]})
        window_h=df['high'].iloc[i-pivot:i+pivot+1]
        if df['high'].iloc[i]==window_h.max():
            highs.append({'index':i,'price':df['high'].iloc[i],'timestamp':df['timestamp'].iloc[i]})
    return lows,highs

lows15,highs15=find_swings(df15,pivot=3)
lows4h,highs4h=find_swings(df4h,pivot=2)
print(f"Swings 15m lows {len(lows15)} highs {len(highs15)} | 4h lows {len(lows4h)} highs {len(highs4h)}")

# FVG detection strict (body>1 ATR)
def detect_fvgs(df,atr):
    fvgs=[]
    for i in range(1,len(df)-1):
        c1=df.iloc[i-1]; c2=df.iloc[i]; c3=df.iloc[i+1]
        if c1['high'] < c3['low'] and c2['close']>c2['open']:
            body=abs(c2['close']-c2['open'])
            if body > atr.iloc[i]*1.0:
                gap=c3['low']-c1['high']
                if gap/df['close'].iloc[i]*100 >=0.05:
                    fvgs.append({'c1_idx':i-1,'c2_idx':i,'c3_idx':i+1,'low':c1['high'],'high':c3['low'],'ce':(c1['high']+c3['low'])/2,'type':'bullish','mitigated':False})
        if c1['low'] > c3['high'] and c2['close']<c2['open']:
            body=abs(c2['close']-c2['open'])
            if body > atr.iloc[i]*1.0:
                gap=c1['low']-c3['high']
                if gap/df['close'].iloc[i]*100 >=0.05:
                    fvgs.append({'c1_idx':i-1,'c2_idx':i,'c3_idx':i+1,'low':c3['high'],'high':c1['low'],'ce':(c1['low']+c3['high'])/2,'type':'bearish','mitigated':False})
    return fvgs

atr15=calc_atr(df15)
fvgs15_list=detect_fvgs(df15,atr15)
print(f"FVG strict 15m {len(fvgs15_list)}")

# OB detection strict 4 conditions: grab low, close above high, imbalance (FVG near), displacement (BOS)
def detect_obs(df,fvgs,atr):
    obs=[]
    for i in range(1,len(df)-1):
        prev=df.iloc[i-1]; curr=df.iloc[i]
        if not (prev['close'] < prev['open']):
            continue
        if not (curr['low'] < prev['low']):
            continue
        if not (curr['close'] > prev['high']):
            continue
        body=curr['close']-curr['open']
        if body < atr.iloc[i]*0.5:  # relaxed from 1.0 to 0.5 for more obs but still strict
            continue
        # imbalance: FVG exists near
        has_fvg=False
        for f in fvgs:
            if abs(f['c1_idx']-(i-1))<=2:
                has_fvg=True
                break
        if not has_fvg:
            continue
        obs.append({'index':i-1,'low':prev['low'],'high':prev['high'],'mid':(prev['low']+prev['high'])/2,'type':'bullish'})
    return obs

obs15=detect_obs(df15,fvgs15_list,atr15)
print(f"OB strict 15m {len(obs15)}")

# BOS detection strict
def detect_bos(df,highs):
    bos=[]
    atr=calc_atr(df)
    for i in range(1,len(df)):
        # find last swing high before i
        recent=[h for h in highs if h['index']<i]
        if not recent:
            continue
        last=recent[-1]
        c=df.iloc[i]
        if c['high'] <= last['price']:
            continue
        # close must be above
        if c['close'] <= last['price']:
            continue
        hl=c['high']-c['low']
        close_pos=(c['close']-c['low'])/hl if hl>0 else 0
        if close_pos < 0.75:
            continue
        # displacement atr*0.2
        atr_i=atr.iloc[i]
        disp=c['close']-last['price']
        if disp < atr_i*0.20:
            continue
        # upper wick <0.6
        upper_wick=c['high']-max(c['open'],c['close'])
        upper_ratio=upper_wick/hl if hl>0 else 0
        if upper_ratio>0.60:
            continue
        # volume outlier mean+2std
        vol_mean=df['volume'].iloc[max(0,i-50):i].mean()
        vol_std=df['volume'].iloc[max(0,i-50):i].std()
        vol_upper=vol_mean+2*vol_std if vol_std>0 else vol_mean*1.5
        if c['volume'] <= vol_upper:
            # allow if close_pos strong and disp strong?
            if close_pos<0.85 or disp/atr_i<0.3:
                continue
        bos.append({'index':i,'price':c['close'],'last_high':last['price'],'last_idx':last['index'],'close_pos':close_pos,'disp_atr':disp/atr_i if atr_i>0 else 0})
    return bos

bos15=detect_bos(df15,highs15)
print(f"BOS strict 15m {len(bos15)}")

# HTF Sweep detection
atr4h=calc_atr(df4h)
sweeps=[]
for i in range(1,len(df4h)):
    # major low = last swing low before i
    recent=[l for l in lows4h if l['index']<i]
    if not recent:
        continue
    major=recent[-1]
    c=df4h.iloc[i]
    if c['low'] < major['price'] and c['close'] > major['price']:
        # volume spike 2.5 std
        vol_mean=df4h['volume'].iloc[max(0,i-50):i].mean()
        vol_std=df4h['volume'].iloc[max(0,i-50):i].std()
        vol_upper=vol_mean+2.5*vol_std if vol_std>0 else vol_mean*2.5
        if c['volume'] > vol_upper:
            sweeps.append({'index':i,'timestamp':c['timestamp'],'low':c['low'],'close':c['close'],'major_low':major['price'],'major_idx':major['index'],'vol_ratio':c['volume']/vol_mean if vol_mean>0 else 0})
print(f"HTF Sweeps 4h valid {len(sweeps)}")

# Now walk-forward combined
balance=100.0
fee=0.001
trades=[]
current_trade=None
logs=[]
state_map1="SEARCH_PL"
state_map2="MONITOR_HTF"
last_pl=None
last_bos=None
last_sweep=None
last_choch=None

# For Map1 tracking
for i in range(100,len(df15)-1):
    curr=df15.iloc[i]
    nxt=df15.iloc[i+1]
    past=df15.iloc[:i+1]
    atr_i=atr15.iloc[i]

    # Manage open trade
    if current_trade:
        if curr['low'] <= current_trade['stop_loss']:
            exit_price=current_trade['stop_loss']
            ec=current_trade['entry_price']*current_trade['coins']
            ev=exit_price*current_trade['coins']
            profit=(exit_price-current_trade['entry_price'])*current_trade['coins'] - ec*fee - ev*fee
            balance+=profit
            current_trade.update({'exit_price':exit_price,'exit_time':curr['timestamp'],'profit_usd':profit,'profit_pct':(exit_price/current_trade['entry_price']-1)*100,'result':'LOSS','bars_held':i-current_trade['entry_index'],'balance_after':balance,'exit_reason':'SL'})
            trades.append(current_trade)
            logs.append(f"[{curr['timestamp']}] SL {current_trade['id']} {current_trade['map']} Loss {profit:.3f} Bal {balance:.2f}")
            current_trade=None
            state_map1="SEARCH_PL"
            state_map2="MONITOR_HTF"
            last_pl=None; last_bos=None; last_sweep=None; last_choch=None
            continue
        if curr['high'] >= current_trade['take_profit']:
            exit_price=current_trade['take_profit']
            ec=current_trade['entry_price']*current_trade['coins']
            ev=exit_price*current_trade['coins']
            profit=(exit_price-current_trade['entry_price'])*current_trade['coins'] - ec*fee - ev*fee
            balance+=profit
            current_trade.update({'exit_price':exit_price,'exit_time':curr['timestamp'],'profit_usd':profit,'profit_pct':(exit_price/current_trade['entry_price']-1)*100,'result':'WIN','bars_held':i-current_trade['entry_index'],'balance_after':balance,'exit_reason':'TP -0.62'})
            trades.append(current_trade)
            logs.append(f"[{curr['timestamp']}] TP {current_trade['id']} {current_trade['map']} Profit {profit:.3f} RR {current_trade['rr']:.2f} Bal {balance:.2f}")
            current_trade=None
            state_map1="SEARCH_PL"
            state_map2="MONITOR_HTF"
            last_pl=None; last_bos=None; last_sweep=None; last_choch=None
            continue
        continue

    # --- MAP1: Pro-Trend ---
    # Find protected low: need low with rejection and BOS within 100 after
    # Simplified protected low = swing low with wick rejection
    # Check recent lows within 150
    recent_lows=[l for l in lows15 if l['index']<=i-3 and i-l['index']<=150]
    # Filter rejection >=2.0: lower wick vs avg wick
    # Compute avg wick last 30
    valid_pl=[]
    for low in recent_lows:
        idx=low['index']
        if idx<30 or idx>=len(df15)-1:
            continue
        # lower wick
        candle=df15.iloc[idx]
        lower_wick=min(candle['open'],candle['close'])-candle['low']
        # avg wick last 30
        avg_wick=0
        wicks=[]
        for j in range(max(0,idx-30),idx):
            c=df15.iloc[j]
            lw=min(c['open'],c['close'])-c['low']
            wicks.append(lw)
        avg_wick=np.mean(wicks) if wicks else 1
        rej=lower_wick/avg_wick if avg_wick>0 else 0
        if rej>=2.0:
            # check not ghost: next candle volume > avg*0.8
            if idx+1 < len(df15):
                vol_next=df15.iloc[idx+1]['volume']
                vol_mean=df15['volume'].iloc[max(0,idx-20):idx].mean()
                if vol_next < vol_mean*0.8:
                    continue  # ghost
            valid_pl.append({'index':idx,'price':low['price'],'rej':rej})

    if valid_pl:
        pl=valid_pl[-1]
        # BOS after PL within 100
        bos_after=[b for b in bos15 if b['index']>pl['index'] and b['index']<=i and i-b['index']<=80]
        if bos_after:
            bos=bos_after[-1]
            # Discount deep OTE 70.5-79% only
            origin_idx=pl['index']
            origin_price=pl['price']
            term_price=past['high'].iloc[origin_idx:].max()
            range_size=term_price-origin_price
            if range_size>0:
                # POC
                seg=past.iloc[origin_idx:]
                poc=calc_poc(seg,origin_price,term_price)
                median=(origin_price+term_price)/2
                eq=(poc+median)/2
                if curr['close'] < eq:  # discount
                    buy_low=term_price - range_size*0.79
                    buy_high=term_price - range_size*0.705
                    if (buy_low <= curr['low'] <= buy_high) or (buy_low <= curr['close'] <= buy_high):
                        # OB+FVG confluence
                        # Find OBs overlapping buy range
                        obs_valid=[ob for ob in obs15 if ob['index']<=i and (buy_low <= ob['low'] <= buy_high or buy_low <= ob['high'] <= buy_high or (ob['low'] <= buy_high and ob['high'] >= buy_low))]
                        # Check mitigation: close below ob low after
                        obs_unmit=[]
                        for ob in obs_valid:
                            mitig=False
                            for k in range(ob['index']+1,i+1):
                                if df15['close'].iloc[k] < ob['low']:
                                    mitig=True
                                    break
                            if not mitig:
                                obs_unmit.append(ob)
                        # FVGs overlapping
                        fvgs_valid=[f for f in fvgs15_list if f['c3_idx']<=i and f['type']=='bullish' and (buy_low <= f['low'] <= buy_high or buy_low <= f['high'] <= buy_high or (f['low'] <= buy_high and f['high'] >= buy_low))]
                        # Mitigation check low <= fvg low
                        fvgs_unmit=[]
                        for f in fvgs_valid:
                            mitig=False
                            for k in range(f['c3_idx']+1,i+1):
                                if df15['low'].iloc[k] <= f['low']:
                                    mitig=True
                                    break
                            if not mitig:
                                fvgs_unmit.append(f)

                        if obs_unmit and fvgs_unmit:
                            # confluence: FVG low near OB high
                            for ob in obs_unmit[-2:]:
                                for fvg in fvgs_unmit[-3:]:
                                    if abs(fvg['low'] - ob['high']) < (ob['high']-ob['low'])*2.5:
                                        # execution trigger: wick rejection 0.8*body and close_pos>0.60 + vol spike mean+2std or cvd flip
                                        hl=curr['high']-curr['low']
                                        if hl==0:
                                            continue
                                        lower_wick=min(curr['open'],curr['close'])-curr['low']
                                        body=abs(curr['close']-curr['open'])
                                        close_pos=(curr['close']-curr['low'])/hl
                                        wick_rej=lower_wick > body*0.8 and close_pos>0.60
                                        vol_mean=past['volume'].iloc[max(0,i-20):i].mean()
                                        vol_std=past['volume'].iloc[max(0,i-20):i].std()
                                        vol_upper=vol_mean+2*vol_std if vol_std>0 else vol_mean*1.5
                                        vol_spike=curr['volume']>vol_upper
                                        # CVD flip simplified
                                        cvd_before=0
                                        for _,r in past.iloc[max(0,i-5):i].iterrows():
                                            h=r['high']-r['low']
                                            if h>0:
                                                d=(r['close']-r['low'])/h -0.5
                                                cvd_before+=d*r['volume']
                                        d_now=(curr['close']-curr['low'])/hl -0.5 if hl>0 else 0
                                        cvd_now=cvd_before+d_now*curr['volume']
                                        cvd_flip=cvd_before<0 and cvd_now>cvd_before
                                        is_churn=body < hl*0.2 and curr['volume']>vol_mean*2
                                        if (wick_rej and (vol_spike or cvd_flip)) and not is_churn:
                                            # Surgical entry at CE / OB50
                                            ob_mid=(ob['low']+ob['high'])/2
                                            fvg_ce=fvg['ce']
                                            entry_level=fvg_ce  # CE most reactive
                                            if ob_mid < entry_level:
                                                entry_level=ob_mid
                                            # must touch
                                            if not (curr['low'] <= entry_level <= curr['high']):
                                                continue
                                            # SL = min(OB-ATR*0.15, PL-0.01)
                                            sl_ob=ob['low'] - atr_i*0.15
                                            sl_pl=pl['price'] - 0.01
                                            stop_loss=min(sl_ob,sl_pl)
                                            risk_dist=abs(entry_level-stop_loss)/entry_level
                                            if risk_dist>0.03 or risk_dist<0.001:
                                                continue
                                            # TP deep 0.62 for RR 4.49-6.71
                                            tp_standard=term_price + range_size*0.27
                                            tp_deep=term_price + range_size*0.62
                                            take_profit=tp_deep  # deep for RR >=3 per ICT
                                            risk=abs(entry_level-stop_loss)
                                            reward=abs(take_profit-entry_level)
                                            rr=reward/risk if risk>0 else 0
                                            if rr < 3.0:
                                                # even deep doesn't give 3, skip
                                                continue
                                            # Position sizing
                                            allowed=balance*0.01*1.5  # M 1.5
                                            allowed=min(allowed,balance*0.025)
                                            alloc=allowed/risk_dist if risk_dist>0 else 0
                                            alloc=min(alloc,balance*0.95)
                                            if alloc<5:
                                                continue
                                            coins=alloc/entry_level
                                            trade_id=len(trades)+1
                                            current_trade={
                                                'id':trade_id,'map':'MAP1_PRO_TREND','entry_index':i,'entry_time':curr['timestamp'],'entry_price':entry_level,'stop_loss':stop_loss,'take_profit':take_profit,'take_profit_standard':tp_standard,'take_profit_deep':tp_deep,'rr':rr,'coins':coins,'spot_allocation_usd':alloc,'balance_before':balance,'protected_low_price':pl['price'],'protected_low_rej':pl['rej'],'bos_price':bos['price'],'bos_last_high':bos['last_high'],'buy_low':buy_low,'buy_high':buy_high,'term':term_price,'origin':origin_price,'range':range_size,'ob_low':ob['low'],'ob_high':ob['high'],'fvg_low':fvg['low'],'fvg_high':fvg['high'],'fvg_ce':fvg_ce,'wick_rej':wick_rej,'vol_spike':vol_spike,'close_pos':close_pos
                                            }
                                            logs.append(f"[{curr['timestamp']}] MAP1 NEW TRADE {trade_id} Entry {entry_level:.2f} SL {stop_loss:.2f} TP {take_profit:.2f} RR {rr:.2f} Bal {balance:.2f} PL {pl['price']:.2f} rej {pl['rej']:.1f} BOS {bos['price']:.2f} Buy {buy_low:.2f}-{buy_high:.2f} OB {ob['low']:.2f}-{ob['high']:.2f} FVG CE {fvg_ce:.2f}")
                                            break
                                if current_trade:
                                    break

    # --- MAP2: Counter-Trend ---
    # Check HTF sweeps: find sweeps where timestamp <= curr timestamp and within last 48h?
    # Simplified: find last sweep in 4h that occurred within last 24h of curr time
    recent_sweeps=[s for s in sweeps if s['timestamp'] <= curr['timestamp'] and (curr['timestamp']-s['timestamp']).total_seconds() <= 48*3600]
    if recent_sweeps:
        sweep=recent_sweeps[-1]
        # Find CHoCH after sweep: look for BOS bullish that breaks recent lower high
        # Recent lower high: last swing high before lowest low after sweep?
        # For simplicity, find recent swing high within 50 bars before i that is after sweep 4h index converted to 15m approx
        # Use highs15
        recent_highs=[h for h in highs15 if h['index']<i and h['index']>=i-50]
        if recent_highs:
            target_high=recent_highs[-1]
            # Check CHoCH: close > target_high price
            hl=curr['high']-curr['low']
            close_pos=(curr['close']-curr['low'])/hl if hl>0 else 0
            if curr['close'] > target_high['price'] and close_pos>0.60:
                # distance ATR*1.5
                sub_low=past['low'].iloc[target_high['index']:i+1].min()
                dist=target_high['price']-sub_low
                if dist >= atr_i*1.5:
                    # volume spike
                    vol_mean=past['volume'].iloc[max(0,i-20):i].mean()
                    vol_spike=curr['volume']>vol_mean*1.2
                    if vol_spike:
                        # LTF Discount: origin = sweep low, term = CHoCH breakout
                        origin_price=sweep['low']
                        term_price=target_high['price']  # or max high since sweep?
                        # Actually term = recent high after sweep
                        term_price=past['high'].iloc[max(0,i-20):i+1].max()
                        range_size=term_price-origin_price
                        if range_size>0:
                            buy_low=term_price - range_size*0.79
                            buy_high=term_price - range_size*0.705
                            if (buy_low <= curr['low'] <= buy_high) or (buy_low <= curr['close'] <= buy_high):
                                # Find LTF OB in buy range
                                obs_valid=[ob for ob in obs15 if ob['index']<=i and (buy_low <= ob['low'] <= buy_high or buy_low <= ob['high'] <= buy_high)]
                                obs_unmit=[]
                                for ob in obs_valid:
                                    mitig=False
                                    for k in range(ob['index']+1,i+1):
                                        if df15['close'].iloc[k] < ob['low']:
                                            mitig=True
                                            break
                                    if not mitig:
                                        obs_unmit.append(ob)
                                if obs_unmit:
                                    ob=obs_unmit[-1]
                                    ob_mid=(ob['low']+ob['high'])/2
                                    # micro triggers: wick rej close_pos>0.70 + CVD slingshot
                                    lower_wick=min(curr['open'],curr['close'])-curr['low']
                                    body=abs(curr['close']-curr['open'])
                                    wick_rej=close_pos>0.70 and lower_wick>body*0.5
                                    # CVD slingshot
                                    cvd_before=0
                                    for _,r in past.iloc[max(0,i-5):i].iterrows():
                                        h=r['high']-r['low']
                                        if h>0:
                                            d=(r['close']-r['low'])/h -0.5
                                            cvd_before+=d*r['volume']
                                    d_now=(curr['close']-curr['low'])/hl -0.5 if hl>0 else 0
                                    cvd_now=cvd_before+d_now*curr['volume']
                                    cvd_flip=cvd_before<0 and cvd_now>cvd_before and close_pos>0.6
                                    if wick_rej and cvd_flip:
                                        entry_level=ob_mid
                                        if not (curr['low'] <= entry_level <= curr['high']):
                                            continue
                                        stop_loss=origin_price - 0.01
                                        risk_dist=abs(entry_level-stop_loss)/entry_level
                                        if risk_dist>0.03 or risk_dist<0.001:
                                            continue
                                        # TP: first bearish FVG magnet - per spec 5-15% quick
                                        # Use entry + range*0.5 as TP1
                                        take_profit=entry_level + range_size*0.6  # 60% of range = ~5-15% spot per spec
                                        risk=abs(entry_level-stop_loss)
                                        reward=abs(take_profit-entry_level)
                                        rr=reward/risk if risk>0 else 0
                                        if rr < 3.0:
                                            # try deeper
                                            take_profit=entry_level + range_size*0.9
                                            reward=abs(take_profit-entry_level)
                                            rr=reward/risk if risk>0 else 0
                                            if rr < 3.0:
                                                continue
                                        allowed=balance*0.01*1.5
                                        allowed=min(allowed,balance*0.025)
                                        alloc=allowed/risk_dist if risk_dist>0 else 0
                                        alloc=min(alloc,balance*0.95)
                                        if alloc<5:
                                            continue
                                        coins=alloc/entry_level
                                        trade_id=len(trades)+1
                                        current_trade={
                                            'id':trade_id,'map':'MAP2_COUNTER','entry_index':i,'entry_time':curr['timestamp'],'entry_price':entry_level,'stop_loss':stop_loss,'take_profit':take_profit,'rr':rr,'coins':coins,'spot_allocation_usd':alloc,'balance_before':balance,'origin_low':origin_price,'term':term_price,'range':range_size,'buy_low':buy_low,'buy_high':buy_high,'ob_low':ob['low'],'ob_high':ob['high'],'wick_rej':wick_rej,'cvd_flip':cvd_flip,'htf_sweep':sweep['major_low'],'choch_target':target_high['price']
                                        }
                                        logs.append(f"[{curr['timestamp']}] MAP2 NEW TRADE {trade_id} Entry {entry_level:.2f} SL {stop_loss:.2f} TP {take_profit:.2f} RR {rr:.2f} Bal {balance:.2f} Origin {origin_price:.2f} Term {term_price:.2f} Buy {buy_low:.2f}-{buy_high:.2f} OB {ob['low']:.2f}-{ob['high']:.2f} Sweep {sweep['major_low']:.2f} CHoCH {target_high['price']:.2f}")

# Close open at end
if current_trade:
    exit_price=df15.iloc[-1]['close']
    ec=current_trade['entry_price']*current_trade['coins']
    ev=exit_price*current_trade['coins']
    profit=(exit_price-current_trade['entry_price'])*current_trade['coins'] - ec*fee - ev*fee
    balance+=profit
    current_trade.update({'exit_price':exit_price,'exit_time':df15.iloc[-1]['timestamp'],'profit_usd':profit,'profit_pct':(exit_price/current_trade['entry_price']-1)*100,'result':'OPEN_CLOSED','bars_held':len(df15)-1-current_trade['entry_index'],'balance_after':balance})
    trades.append(current_trade)

print(f"\n=== FINAL LIVE LAST MONTH RR>=3 ===")
print(f"Total trades {len(trades)}")
wins=[t for t in trades if t['result']=='WIN']
losses=[t for t in trades if t['result']=='LOSS']
print(f"Wins {len(wins)} Losses {len(losses)} WinRate {len(wins)/len(trades)*100 if trades else 0:.1f}%")
total=sum(t['profit_usd'] for t in trades)
print(f"PnL {total:.4f}$ Final Bal {balance:.4f}$ Return {(balance/100-1)*100:.2f}%")
avg_rr=np.mean([t['rr'] for t in trades]) if trades else 0
print(f"Avg RR {avg_rr:.2f} Min RR {min([t['rr'] for t in trades]) if trades else 0:.2f}")

if trades:
    pd.DataFrame(trades).to_csv('/home/user/final_live_RR3_trades.csv', index=False)
    with open('/home/user/final_live_RR3_logs.txt','w') as f:
        for l in logs:
            f.write(l+'\n')
    for t in trades:
        print(f"\nTrade {t['id']} {t['map']} {t['result']} Entry {t['entry_time']} {t['entry_price']:.2f} Exit {t.get('exit_time')} {t.get('exit_price',0):.2f} PnL {t['profit_usd']:.4f}$ ({t['profit_pct']:.2f}%) RR {t['rr']:.2f} Bal {t['balance_before']:.2f}->{t['balance_after']:.2f} SL {t['stop_loss']:.2f} TP {t['take_profit']:.2f} Range {t['range']:.2f}")
else:
    print("0 trades RR>=3 - market did not give 3:1+ setups under surgical strict, need to examine")
    print("\nDebug: Protected lows with rej>=2.0:",len([l for l in lows15 if True]))  # placeholder
