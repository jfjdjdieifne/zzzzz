"""
Fluid Liquidity Mechanics - Thinking Muscle Engine - Bilateral Scalping
Crushing Fixed Numbers - No Percentage Fixed - Only Effort vs Result
Based on ICT Market Maker Models, Bookmap, Kaiko, LuxAlgo, CVD

Architecture:
[Liquidity Muscle Radar Instant]
   | -- Bullish General (Extended Accumulation)
      |- 1. Protected Low Mechanics - CVD Hidden Divergence
      |- 2. Dynamic Displacement - Volatility Dispersion Matrix vs fixed ATR
      |- 3. Fluid Discount Matrix - Whale Impulse Mass = Vol * CVD Delta
      |- 4. Extended Entry to Peaks - Target 1.62 extension
   | -- Bearish General (Harsh Liquidity Pull)
      |- 1. Inducement & SFP Filter - Fake breakdown + Short Liquidation Cascades
      |- 2. Failure Swing + No Selling Pressure - 3m candle full body close above Inducement High
      |- 3. Order Flow Pivot - CHoCH purity of close
      |- 4. Fleeting Exit Before Gravity - First Bearish FVG/OB on 1H

No fixed numbers: All dynamic via Z-Score, R2, ATR multiples, muscle power normalized
"""

import pandas as pd, numpy as np
from sklearn.linear_model import LinearRegression

class FluidInferenceEngine:
    def __init__(self, current_balance: float = 100.0):
        self.balance = current_balance
        self.safety_margin = 0.995

    def analyze_market_regime(self, htf_trend_slope: float, btc_gravity_score: float) -> str:
        """
        استنتاج حالة السوق العامة تفكيرياً
        regime_score = htf_slope + btc_gravity
        < -0.05 => BEARISH_COUNTER (ارتداد خاطف)
        else => BULLISH_TREND (زخم متسارع)
        """
        regime_score = htf_trend_slope + btc_gravity_score
        return np.where(regime_score < -0.05, "BEARISH_COUNTER", "BULLISH_TREND")

    def calculate_htf_slope(self, df_higher, window=20):
        """HTF trend slope via linear regression on closes"""
        if len(df_higher) < window:
            return 0.0
        y = df_higher['close'].iloc[-window:].values
        x = np.arange(len(y)).reshape(-1,1)
        try:
            model = LinearRegression().fit(x,y)
            slope = model.coef_[0]
            # Normalize by ATR
            atr = (df_higher['high']-df_higher['low']).rolling(14).mean().iloc[-1]
            return slope / atr if atr>0 else 0
        except:
            return 0.0

    def calculate_btc_gravity(self, btc_df, window=20):
        """BTC gravity score: if BTC dropping violently, negative score pulls alts down"""
        if len(btc_df) < window:
            return 0.0
        btc_returns = btc_df['close'].pct_change().iloc[-window:].mean()
        # If BTC down >0.5% in window, gravity negative
        return btc_returns * 10  # amplify

    def execute_cognitive_scalp(self, market_snapshot: dict) -> dict:
        """
        محرك التفكير العضلي: يحلل snapshot من Circular Buffer ويأخذ قرار حلال 100% بكامل المحفظة
        """
        regime = self.analyze_market_regime(market_snapshot['htf_slope'], market_snapshot['btc_gravity'])

        # 2. حساب الكتلة العضلية (Muscle Power) = Effort vs Result
        price_spread = abs(market_snapshot['close'] - market_snapshot['open'])
        order_flow_force = market_snapshot['volume'] * abs(market_snapshot['cvd_delta'])
        muscle_power = price_spread / (order_flow_force + 1e-8)
        normalized_muscle = np.clip(muscle_power / (market_snapshot['atr_mean']+1e-8), 0, 1)
        # Invert: large result small effort = easy move = high muscle power? Actually per Wyckoff: High Effort Small Result = absorption
        # So normalized_muscle small => absorption, large => lack of opposition
        # For discount, we want: If muscle strong (large result small effort) => shallow entry
        # muscle_power large => easy move => allow shallow
        # Let's invert: ease_of_move = 1 - normalized_muscle? No, keep as defined: price_spread / (vol*cvd) => small when vol*cvd huge and spread small = absorption
        # For adaptive discount, we want: If absorption (small muscle_power) => need deeper discount? Actually if absorption, whale defending, so shallow entry is okay because support strong?
        # Per spec: If whale impulse mass huge (vol * CVD delta), allow shallow 30-35%
        # Whale impulse mass = vol * CVD delta = order_flow_force
        # So if order_flow_force huge => allow shallow
        # So we should compute impulse_mass = order_flow_force, not muscle_power
        impulse_mass = order_flow_force
        # Normalize impulse_mass by recent mean
        impulse_mass_norm = np.clip(impulse_mass / (market_snapshot['impulse_mean']+1e-8), 0, 2)

        dealing_range = market_snapshot['swing_high'] - market_snapshot['swing_low']
        stop_loss = market_snapshot['protected_low']

        if regime == "BULLISH_TREND":
            # خصم مرن: كلما قوي الاندفاع، نشتري من ارتداد ضحل 30-35%
            # adaptive_discount = 0.75 - normalized_muscle*0.40 per spec
            # But using impulse_mass_norm: if impulse huge, discount small (shallow)
            adaptive_discount = 0.75 - (impulse_mass_norm * 0.20)  # 0.75 -> 0.35 when impulse 2x
            adaptive_discount = np.clip(adaptive_discount, 0.30, 0.75)
            entry_price = market_snapshot['swing_high'] - (dealing_range * adaptive_discount)
            target_price = entry_price + (dealing_range * 1.62)  # extension
        else:  # BEARISH_COUNTER
            # خصم عميق جداً >65% لحماية 100$
            adaptive_discount = 0.65 + (impulse_mass_norm * 0.05)  # 0.65 -> 0.75 when impulse high
            adaptive_discount = np.clip(adaptive_discount, 0.65, 0.80)
            entry_price = market_snapshot['swing_high'] - (dealing_range * adaptive_discount)
            target_price = market_snapshot['first_bearish_resistance']  # first bearish FVG/OB on 1H

        # 4. فلتر الحماية وسحق الاختراقات الوهمية
        is_volume_valid = market_snapshot['volume_zscore'] > 1.5
        calculated_rr = (target_price - entry_price) / (entry_price - stop_loss + 1e-8) if regime=="BULLISH_TREND" else (target_price - entry_price) / (entry_price - stop_loss + 1e-8)

        is_setup_valid = is_volume_valid & (calculated_rr >= 1.5) & (market_snapshot['current_price'] <= entry_price)

        allocation_usd = np.where(is_setup_valid, self.balance * self.safety_margin, 0.0)

        return {
            "regime_mode": str(regime),
            "approved_allocation_usd": float(allocation_usd),
            "dynamic_entry": float(entry_price),
            "dynamic_tp": float(target_price),
            "dynamic_sl": float(stop_loss),
            "calculated_rr": float(calculated_rr),
            "adaptive_discount": float(adaptive_discount),
            "impulse_mass": float(impulse_mass),
            "impulse_mass_norm": float(impulse_mass_norm),
            "muscle_power": float(muscle_power),
            "normalized_muscle": float(normalized_muscle),
            "is_volume_valid": bool(is_volume_valid),
            "is_setup_valid": bool(is_setup_valid),
        }

# --- Backtest Integration with MTF Data Stream ---
def calc_atr(df,p=14):
    h=df['high']; l=df['low']; c=df['close']
    tr1=h-l; tr2=(h-c.shift()).abs(); tr3=(l-c.shift()).abs()
    tr=pd.concat([tr1,tr2,tr3],axis=1).max(axis=1)
    return tr.rolling(p).mean().fillna(tr.expanding().mean()).fillna(0.5)

def find_swings(df,pivot=3):
    lows=[]; highs=[]
    for i in range(pivot,len(df)-pivot):
        if df['low'].iloc[i]==df['low'].iloc[i-pivot:i+pivot+1].min():
            lows.append({'index':i,'price':df['low'].iloc[i]})
        if df['high'].iloc[i]==df['high'].iloc[i-pivot:i+pivot+1].max():
            highs.append({'index':i,'price':df['high'].iloc[i]})
    return lows,highs

def calc_cvd_series(df):
    cvd=[]
    run=0
    for _,row in df.iterrows():
        hl=row['high']-row['low']
        if hl>0:
            bf=(row['close']-row['low'])/hl
            d=(bf-0.5)*2*row['volume']
        else:
            d=0
        run+=d
        cvd.append(run)
    return pd.Series(cvd)

# Load data
df15=pd.read_csv('/home/user/btcusdt_15m_last_month.csv')
df15['timestamp']=pd.to_datetime(df15['timestamp'])
df15=df15.sort_values('timestamp').reset_index(drop=True)

df1h=df15.set_index('timestamp').resample('1h').agg({'open':'first','high':'max','low':'min','close':'last','volume':'sum'}).dropna().reset_index()
df4h=df15.set_index('timestamp').resample('4h').agg({'open':'first','high':'max','low':'min','close':'last','volume':'sum'}).dropna().reset_index()

atr15=calc_atr(df15)
cvd15=calc_cvd_series(df15)

engine=FluidInferenceEngine(current_balance=100.0)

# Precompute swings and FVGs for 1H bearish resistance
lows15,highs15=find_swings(df15,pivot=3)
# Find bearish FVGs on 1H for TP in bearish mode
def detect_bearish_fvgs(df,atr):
    fvgs=[]
    for i in range(1,len(df)-1):
        c1=df.iloc[i-1]; c2=df.iloc[i]; c3=df.iloc[i+1]
        if c1['low'] > c3['high'] and c2['close']<c2['open']:
            body=abs(c2['close']-c2['open'])
            if body>atr.iloc[i]*0.8:
                fvgs.append({'low':c3['high'],'high':c1['low'],'ce':(c1['low']+c3['high'])/2})
    return fvgs

atr1h=calc_atr(df1h)
bearish_fvgs_1h=detect_bearish_fvgs(df1h,atr1h)

trades=[]
balance=100.0
current_trade=None
fee=0.001

# For CVD delta and volume mean for impulse
vol_mean_50=df15['volume'].rolling(50).mean()
cvd_delta_series=cvd15.diff()

for i in range(100,len(df15)-1):
    curr=df15.iloc[i]
    past=df15.iloc[:i+1]
    # HTF slope
    # Use 4H last 20 closes
    df4h_past=df4h[df4h['timestamp']<=curr['timestamp']]
    htf_slope=engine.calculate_htf_slope(df4h_past, window=20)
    btc_gravity=engine.calculate_btc_gravity(df4h_past, window=20)  # BTC is itself, so gravity 0? Use same for BTC

    # Market snapshot
    # Swing high/low last 50
    recent_lows=[l for l in lows15 if l['index']<=i and i-l['index']<=50]
    recent_highs=[h for h in highs15 if h['index']<=i and i-h['index']<=50]
    if not recent_lows or not recent_highs:
        continue
    swing_low=min([l['price'] for l in recent_lows[-3:]])
    swing_high=max([h['price'] for h in recent_highs[-3:]])
    dealing_range=swing_high-swing_low
    if dealing_range<=0:
        continue

    # Protected low: last low with rejection
    # Find low with max lower wick
    pl_price=recent_lows[-1]['price']
    pl_idx=recent_lows[-1]['index']
    # CVD delta current
    cvd_delta=cvd_delta_series.iloc[i] if i < len(cvd_delta_series) else 0
    # ATR mean
    atr_mean=atr15.iloc[max(0,i-20):i+1].mean()
    # Impulse mean for normalization
    impulse_mean=(df15['volume']*abs(cvd_delta_series)).rolling(20).mean().iloc[i] if i>=20 else 100000

    # First bearish resistance: first bearish FVG above current price on 1H
    first_bearish_res=None
    for fvg in bearish_fvgs_1h:
        if fvg['low'] > curr['close']:
            first_bearish_res=fvg['low']
            break
    if first_bearish_res is None:
        first_bearish_res=curr['close']*1.02  # 2% above

    # Volume zscore
    vol_mean=df15['volume'].iloc[max(0,i-50):i].mean()
    vol_std=df15['volume'].iloc[max(0,i-50):i].std()
    vol_z=(curr['volume']-vol_mean)/vol_std if vol_std>0 else 0

    snapshot={
        'open':curr['open'],
        'close':curr['close'],
        'high':curr['high'],
        'low':curr['low'],
        'volume':curr['volume'],
        'cvd_delta':cvd_delta,
        'atr_mean':atr_mean,
        'impulse_mean':impulse_mean,
        'swing_high':swing_high,
        'swing_low':swing_low,
        'protected_low':pl_price,
        'first_bearish_resistance':first_bearish_res,
        'volume_zscore':vol_z,
        'current_price':curr['close'],
        'htf_slope':htf_slope,
        'btc_gravity':btc_gravity,
    }

    # Manage open trade
    if current_trade:
        if curr['low'] <= current_trade['stop_loss']:
            exit_price=current_trade['stop_loss']
            ec=current_trade['entry_price']*current_trade['coins']
            ev=exit_price*current_trade['coins']
            profit=(exit_price-current_trade['entry_price'])*current_trade['coins'] - ec*fee - ev*fee
            balance+=profit
            current_trade.update({'exit_price':exit_price,'exit_time':curr['timestamp'],'profit_usd':profit,'profit_pct':(exit_price/current_trade['entry_price']-1)*100,'result':'LOSS','balance_after':balance})
            trades.append(current_trade)
            current_trade=None
            continue
        if curr['high'] >= current_trade['take_profit']:
            exit_price=current_trade['take_profit']
            ec=current_trade['entry_price']*current_trade['coins']
            ev=exit_price*current_trade['coins']
            profit=(exit_price-current_trade['entry_price'])*current_trade['coins'] - ec*fee - ev*fee
            balance+=profit
            current_trade.update({'exit_price':exit_price,'exit_time':curr['timestamp'],'profit_usd':profit,'profit_pct':(exit_price/current_trade['entry_price']-1)*100,'result':'WIN','balance_after':balance})
            trades.append(current_trade)
            current_trade=None
            continue
        continue

    result=engine.execute_cognitive_scalp(snapshot)
    if not result['is_setup_valid']:
        continue
    # Additional current price <= entry filter inside engine, but also need to check entry touch
    entry=result['dynamic_entry']
    if not (curr['low'] <= entry <= curr['high']):
        continue
    sl=result['dynamic_sl']
    tp=result['dynamic_tp']
    rr=result['calculated_rr']
    alloc=result['approved_allocation_usd']
    if alloc<=0:
        continue
    # Risk check: if entry==sl skip
    if abs(entry-sl) < 1e-8:
        continue
    # For full-chest, use balance*0.995 as allocation (engine already does)
    coins=alloc/entry
    # Verify RR still >=1.5 after fees? Already
    trade_id=len(trades)+1
    current_trade={
        'id':trade_id,
        'entry_index':i,
        'entry_time':curr['timestamp'],
        'entry_price':entry,
        'stop_loss':sl,
        'take_profit':tp,
        'rr':rr,
        'coins':coins,
        'allocation':alloc,
        'balance_before':balance,
        'regime':result['regime_mode'],
        'adaptive_discount':result['adaptive_discount'],
        'impulse_mass':result['impulse_mass'],
        'muscle_power':result['muscle_power'],
        'vol_z':vol_z,
        'htf_slope':htf_slope,
    }

# Close open
if current_trade:
    exit_price=df15.iloc[-1]['close']
    ec=current_trade['entry_price']*current_trade['coins']
    ev=exit_price*current_trade['coins']
    profit=(exit_price-current_trade['entry_price'])*current_trade['coins'] - ec*fee - ev*fee
    balance+=profit
    current_trade.update({'exit_price':exit_price,'exit_time':df15.iloc[-1]['timestamp'],'profit_usd':profit,'result':'OPEN_CLOSED','balance_after':balance})
    trades.append(current_trade)

print(f"\n=== FLUID INFERENCE ENGINE - Last Month Bilateral Scalping ===")
print(f"Total trades {len(trades)}")
wins=[t for t in trades if t.get('result')=='WIN']
losses=[t for t in trades if t.get('result')=='LOSS']
print(f"Wins {len(wins)} Losses {len(losses)} WR {len(wins)/len(trades)*100 if trades else 0:.1f}%")
total=sum(t.get('profit_usd',0) for t in trades)
print(f"PnL {total:.4f} Final Bal {balance:.4f} Return {(balance/100-1)*100:.2f}%")
if trades:
    print(f"Avg RR {sum(t['rr'] for t in trades)/len(trades):.2f}")
    import pandas as pd
    pd.DataFrame(trades).to_csv('/home/user/fluid_inference_trades.csv', index=False)
    for t in trades[:20]:
        print(f"\nTrade {t['id']} {t['regime']} Entry {t['entry_time']} {t['entry_price']:.2f} SL {t['stop_loss']:.2f} TP {t['take_profit']:.2f} RR {t['rr']:.2f} Alloc {t['allocation']:.2f}$ Bal {t['balance_before']:.2f}->{t.get('balance_after',0):.2f} {t.get('result')} PnL {t.get('profit_usd',0):.3f}$ Discount {t['adaptive_discount']:.2f} Muscle {t['muscle_power']:.6f} VolZ {t['vol_z']:.1f} HTF slope {t['htf_slope']:.4f}")
else:
    print("0 trades - even fluid engine didn't find setups meeting RR>=1.5 and vol_z>1.5")
