"""
Real 5 Alts Backtest - No Synthetic Data - Tactic 2: Multi-Timeframe Compound Frequency
- Uses real 5m data from Binance Vision API for SOL, AVAX, DOGE, PEPE, WIF
- 8857 candles each (5m last month)
- Engine: Balanced with all microscopic fixes, Full-Chest 99.5%, Dynamic Discount, CVD Window, Rolling 3H Vol, Fee Filter
- Goal: 4-5 trades per day per alt, 1.5-2$ profit each, compounding
"""
import pandas as pd, numpy as np
from sklearn.linear_model import LinearRegression

def calc_atr(df,p=14):
    h=df['high']; l=df['low']; c=df['close']
    tr1=h-l; tr2=(h-c.shift()).abs(); tr3=(l-c.shift()).abs()
    tr=pd.concat([tr1,tr2,tr3],axis=1).max(axis=1)
    return tr.rolling(p).mean().fillna(tr.expanding().mean()).fillna(0.5)

def find_swings(df,pivot=3):
    lows=[]; highs=[]
    for i in range(pivot,len(df)-pivot):
        if df['low'].iloc[i]==df['low'].iloc[i-pivot:i+pivot+1].min():
            lows.append({'index':i,'price':df['low'].iloc[i]})
        if df['high'].iloc[i]==df['high'].iloc[i-pivot:i+pivot+1].max():
            highs.append({'index':i,'price':df['high'].iloc[i]})
    return lows,highs

def detect_fvgs(df,atr):
    fvgs=[]
    for i in range(1,len(df)-1):
        c1=df.iloc[i-1]; c2=df.iloc[i]; c3=df.iloc[i+1]
        if c1['high'] < c3['low'] and c2['close']>c2['open']:
            body=abs(c2['close']-c2['open'])
            if body>atr.iloc[i]*0.8:
                gap=c3['low']-c1['high']
                if gap/df['close'].iloc[i]*100>=0.03:
                    fvgs.append({'c1_idx':i-1,'c3_idx':i+1,'low':c1['high'],'high':c3['low'],'ce':(c1['high']+c3['low'])/2,'type':'bullish'})
    return fvgs

def detect_obs(df,fvgs,atr):
    obs=[]
    for i in range(1,len(df)-1):
        prev=df.iloc[i-1]; curr=df.iloc[i]
        if not (prev['close']<prev['open']): continue
        if not (curr['low']<prev['low']): continue
        if not (curr['close']>prev['high']): continue
        body=curr['close']-curr['open']
        if body < atr.iloc[i]*0.4: continue
        has_fvg=False
        for f in fvgs:
            if abs(f['c1_idx']-(i-1))<=3:
                has_fvg=True
                break
        if not has_fvg: continue
        obs.append({'index':i-1,'low':prev['low'],'high':prev['high'],'mid':(prev['low']+prev['high'])/2})
    return obs

def detect_bos(df,highs):
    bos=[]
    atr=calc_atr(df)
    for i in range(1,len(df)):
        recent=[h for h in highs if h['index']<i]
        if not recent: continue
        last=recent[-1]
        c=df.iloc[i]
        if c['high']<=last['price']: continue
        if c['close']<=last['price']: continue
        hl=c['high']-c['low']
        cp=(c['close']-c['low'])/hl if hl>0 else 0
        if cp<0.60: continue
        disp=c['close']-last['price']
        if disp < atr.iloc[i]*0.15: continue
        upper=c['high']-max(c['open'],c['close'])
        if upper/hl>0.70 if hl>0 else 0: continue
        bos.append({'index':i,'price':c['close'],'last_high':last['price']})
    return bos

def calc_cvd_series(df):
    cvd=[]
    run=0
    for _,row in df.iterrows():
        hl=row['high']-row['low']
        if hl>0:
            bf=(row['close']-row['low'])/hl
            d=(bf-0.5)*2*row['volume']
        else:
            d=0
        run+=d
        cvd.append(run)
    return pd.Series(cvd)

def backtest_single(df, name, initial_balance=100.0):
    atr=calc_atr(df)
    lows,highs=find_swings(df,pivot=3)
    fvgs=detect_fvgs(df,atr)
    obs=detect_obs(df,fvgs,atr)
    bos=detect_bos(df,highs)
    cvd_series=calc_cvd_series(df)
    rolling_3h=df['volume'].rolling(36).mean()  # 3h = 36*5m

    balance=initial_balance
    fee=0.001
    trades=[]
    current_trade=None

    for i in range(100,len(df)-1):
        curr=df.iloc[i]
        past=df.iloc[:i+1]
        atr_i=atr.iloc[i]

        if current_trade:
            if curr['low'] <= current_trade['stop_loss']:
                exit_price=current_trade['stop_loss']
                ec=current_trade['entry_price']*current_trade['coins']
                ev=exit_price*current_trade['coins']
                profit=(exit_price-current_trade['entry_price'])*current_trade['coins'] - ec*fee - ev*fee
                balance+=profit
                current_trade.update({'exit_price':exit_price,'exit_time':curr['timestamp'],'profit_usd':profit,'profit_pct':(exit_price/current_trade['entry_price']-1)*100,'result':'LOSS','balance_after':balance})
                trades.append(current_trade)
                current_trade=None
                continue
            if curr['high'] >= current_trade['take_profit']:
                exit_price=current_trade['take_profit']
                ec=current_trade['entry_price']*current_trade['coins']
                ev=exit_price*current_trade['coins']
                profit=(exit_price-current_trade['entry_price'])*current_trade['coins'] - ec*fee - ev*fee
                balance+=profit
                current_trade.update({'exit_price':exit_price,'exit_time':curr['timestamp'],'profit_usd':profit,'profit_pct':(exit_price/current_trade['entry_price']-1)*100,'result':'WIN','balance_after':balance})
                trades.append(current_trade)
                current_trade=None
                continue
            continue

        recent_lows=[]
        for low in lows:
            if low['index']>i-3 or low['index']<i-150:
                continue
            idx=low['index']
            if idx<30: continue
            candle=df.iloc[idx]
            lower_wick=min(candle['open'],candle['close'])-candle['low']
            wicks=[]
            for j in range(max(0,idx-30),idx):
                c=df.iloc[j]
                lw=min(c['open'],c['close'])-c['low']
                wicks.append(lw)
            avg_wick=np.mean(wicks) if wicks else 1
            rej=lower_wick/avg_wick if avg_wick>0 else 0
            if rej>=2.0:
                recent_lows.append({'index':idx,'price':low['price'],'rej':rej})
        if not recent_lows:
            continue
        pl=recent_lows[-1]

        bos_after=[b for b in bos if b['index']>pl['index'] and b['index']<=i and i-b['index']<=80]
        if not bos_after:
            continue
        bos_v=bos_after[-1]

        origin_idx=pl['index']
        origin_price=pl['price']
        term_price=past['high'].iloc[origin_idx:].max()
        range_size=term_price-origin_price
        if range_size<=0:
            continue

        num_candles=i-origin_idx
        atr_10=atr.iloc[max(0,i-10):i+1].mean()
        disp_power=range_size/(num_candles*atr_10) if num_candles>0 and atr_10>0 else 0

        cvd_win=cvd_series.iloc[max(0,i-5):i+1]
        cvd_slope=0
        if len(cvd_win)>=2:
            x=np.arange(len(cvd_win)).reshape(-1,1)
            y=cvd_win.values
            try:
                m=LinearRegression().fit(x,y)
                cvd_slope=m.coef_[0]
            except:
                cvd_slope=0

        vol_mean=df['volume'].iloc[max(0,i-50):i].mean()
        vol_std=df['volume'].iloc[max(0,i-50):i].std()
        vol_z=(curr['volume']-vol_mean)/vol_std if vol_std>0 else 0

        muscle_power=disp_power * (1+max(0,cvd_slope)/1000) * (1+max(0,vol_z)/5)
        discount_pct=0.79 - muscle_power*0.10
        discount_pct=max(0.30, min(0.79, discount_pct))
        buy_low=term_price - range_size*discount_pct
        buy_high=term_price - range_size*max(0.10, discount_pct-0.10)

        if curr['close']>buy_high and muscle_power<1.0:
            continue
        if not (buy_low <= curr['low'] <= buy_high or buy_low <= curr['close'] <= buy_high):
            if not (muscle_power>2.5 and curr['close'] < term_price - range_size*0.40):
                continue

        deltas=[]
        for k in range(max(0,i-5),i+1):
            row=df.iloc[k]
            hl_r=row['high']-row['low']
            if hl_r>0:
                bf=(row['close']-row['low'])/hl_r
                d=(bf-0.5)*2*row['volume']
                deltas.append(d)
        sum_delta=sum(deltas)
        is_rising=deltas[-1]>deltas[0] if len(deltas)>=2 else False
        cvd_window=sum_delta>0 and is_rising

        if not cvd_window and muscle_power<1.0:
            continue

        obs_valid=[ob for ob in obs if ob['index']<=i and (buy_low <= ob['low'] <= buy_high or buy_low <= ob['high'] <= buy_high or (ob['low'] <= buy_high and ob['high'] >= buy_low))]
        obs_unmit=[]
        for ob in obs_valid:
            mitig=False
            for k in range(ob['index']+1,i+1):
                if df['close'].iloc[k] < ob['low']:
                    mitig=True
                    break
            if not mitig:
                obs_unmit.append(ob)

        fvgs_valid=[f for f in fvgs if f['c3_idx']<=i and f['type']=='bullish' and (buy_low <= f['low'] <= buy_high or buy_low <= f['high'] <= buy_high or (f['low'] <= buy_high and f['high'] >= buy_low))]
        fvgs_unmit=[]
        for f in fvgs_valid:
            mitig=False
            for k in range(f['c3_idx']+1,i+1):
                if df['close'].iloc[k] <= f['low']:
                    mitig=True
                    break
            if not mitig:
                fvgs_unmit.append(f)

        if not obs_unmit and not fvgs_unmit:
            continue

        valid_exec=None
        for ob in obs_unmit[-2:]:
            for fvg in fvgs_unmit[-3:]:
                if abs(fvg['low'] - ob['high']) < (ob['high']-ob['low'])*3:
                    hl=curr['high']-curr['low']
                    if hl==0: continue
                    lower_wick=min(curr['open'],curr['close'])-curr['low']
                    body=abs(curr['close']-curr['open'])
                    close_pos=(curr['close']-curr['low'])/hl
                    wick_rej=lower_wick > body*0.8 and close_pos>0.60
                    roll=rolling_3h.iloc[i] if not pd.isna(rolling_3h.iloc[i]) else vol_mean
                    is_hollow=curr['timestamp'].hour in [0,1,2,3,4,5,22,23]
                    thresh=roll*1.5 if is_hollow else roll*2.5
                    vol_spike=curr['volume']>thresh
                    is_churn=body < hl*0.2 and curr['volume']>vol_mean*2
                    if (wick_rej and (vol_spike or cvd_window)) and not is_churn:
                        valid_exec=(ob,fvg,wick_rej,vol_spike,close_pos,vol_z,muscle_power)
                        break
            if valid_exec:
                break
        if not valid_exec and muscle_power>2.5 and fvgs_unmit:
            fvg=fvgs_unmit[-1]
            hl=curr['high']-curr['low']
            lower_wick=min(curr['open'],curr['close'])-curr['low']
            body=abs(curr['close']-curr['open'])
            close_pos=(curr['close']-curr['low'])/hl if hl>0 else 0
            wick_rej=lower_wick > body*0.5 and close_pos>0.55
            if wick_rej:
                ob={'low':fvg['low'],'high':fvg['high'],'mid':fvg['ce'],'index':fvg['c1_idx']}
                valid_exec=(ob,fvg,wick_rej,False,close_pos,vol_z,muscle_power)
        if not valid_exec:
            continue

        ob,fvg,wick_rej,vol_spike,close_pos,vol_z,muscle_power=valid_exec

        ob_mid=(ob['low']+ob['high'])/2
        fvg_ce=fvg['ce']
        entry_level=fvg_ce
        if ob_mid < entry_level:
            entry_level=ob_mid

        if not (curr['low'] <= entry_level <= curr['high']):
            continue

        sl_ob=ob['low'] - atr_i*0.15
        sl_pl=pl['price'] - 0.01
        stop_loss=min(sl_ob,sl_pl)
        risk_dist=abs(entry_level-stop_loss)/entry_level
        if risk_dist>0.03 or risk_dist<0.001:
            continue

        tp_deep=term_price + range_size*0.62
        take_profit=tp_deep
        risk=abs(entry_level-stop_loss)
        reward=abs(take_profit-entry_level)
        rr=reward/risk if risk>0 else 0
        if rr<1.5:
            continue

        reward_pct=abs(take_profit-entry_level)/entry_level
        if reward_pct<0.006:
            continue
        if 0.002/reward_pct>0.15:
            continue
        if muscle_power<0.8:
            continue

        allocation=balance*0.995
        coins=allocation/entry_level

        trade_id=len(trades)+1
        current_trade={
            'id':trade_id,
            'entry_time':curr['timestamp'],
            'entry_price':entry_level,
            'stop_loss':stop_loss,
            'take_profit':take_profit,
            'rr':rr,
            'coins':coins,
            'allocation':allocation,
            'balance_before':balance,
            'risk_dist':risk_dist*100,
            'reward_dist':reward_pct*100,
        }

    if current_trade:
        exit_price=df.iloc[-1]['close']
        ec=current_trade['entry_price']*current_trade['coins']
        ev=exit_price*current_trade['coins']
        profit=(exit_price-current_trade['entry_price'])*current_trade['coins'] - ec*fee - ev*fee
        balance+=profit
        current_trade.update({'exit_price':exit_price,'exit_time':df.iloc[-1]['timestamp'],'profit_usd':profit,'result':'OPEN_CLOSED','balance_after':balance})
        trades.append(current_trade)

    return trades, balance

# Run for 5 alts
import os
alts=['SOLUSDT','AVAXUSDT','DOGEUSDT','PEPEUSDT','WIFUSDT']
results={}
for symbol in alts:
    path=f'/home/user/{symbol}_5m_last_month_real.csv'
    if not os.path.exists(path):
        print(f"Missing {path}")
        continue
    df=pd.read_csv(path)
    df['timestamp']=pd.to_datetime(df['timestamp'])
    print(f"\n=== Backtesting {symbol} 5m Real Data {len(df)} candles ===")
    trades,final_bal=backtest_single(df, symbol, 100.0)
    print(f"{symbol} Trades {len(trades)} Final Bal {final_bal:.2f} Return {(final_bal/100-1)*100:.2f}%")
    if trades:
        wins=len([t for t in trades if t['result']=='WIN'])
        print(f"  Wins {wins} Losses {len(trades)-wins} WR {wins/len(trades)*100:.1f}% Avg RR {sum(t['rr'] for t in trades)/len(trades):.2f}")
    results[symbol]={'trades':trades,'final_bal':final_bal}

# Portfolio sequential rotation
all_trades=[]
for sym,res in results.items():
    for t in res['trades']:
        all_trades.append({**t,'symbol':sym})

all_sorted=sorted(all_trades, key=lambda x: x['entry_time'])

balance=100.0
for t in all_sorted:
    entry=t['entry_price']
    exitp=t.get('exit_price', entry*1.01)
    # recalc with current balance full-chest
    alloc=balance*0.995
    coins=alloc/entry
    # use stored profit_pct if available
    # profit = alloc * profit_pct/100
    profit_pct=t.get('profit_pct',0)
    # Actually profit_pct from trade is based on old balance, need to recompute with new balance?
    # For simplicity, use profit_usd scaled by balance ratio
    # profit_full = t['profit_usd'] * (balance / t['balance_before']) if t['balance_before']>0 else t['profit_usd']
    # Let's recompute using exit_price
    if 'exit_price' in t:
        ec=entry*coins
        ev=t['exit_price']*coins
        profit=(t['exit_price']-entry)*coins - ec*0.001 - ev*0.001
    else:
        profit=t['profit_usd']* (balance/100)
    balance+=profit

print(f"\n=== COMBINED 5 ALTS PORTFOLIO - Sequential Full-Chest Rotation ===")
print(f"Total trades combined {len(all_sorted)}")
total_pnl=sum(t['profit_usd'] for t in all_sorted)
print(f"Sum PnL if each $100 separate: {total_pnl:.2f}$")
print(f"Final balance sequential compounding: {balance:.2f}$ Return {(balance/100-1)*100:.2f}%")

# Summary table
import pandas as pd
rows=[]
for sym,res in results.items():
    trades=res['trades']
    if not trades:
        rows.append({'Symbol':sym,'Trades':0,'PnL$':0,'Return%':0,'WR%':0,'AvgRR':0})
        continue
    total=sum(t['profit_usd'] for t in trades)
    wins=len([t for t in trades if t['result']=='WIN'])
    avg_rr=sum(t['rr'] for t in trades)/len(trades)
    rows.append({'Symbol':sym,'Trades':len(trades),'Wins':wins,'Losses':len(trades)-wins,'WR%':round(wins/len(trades)*100,1),'PnL$':round(total,2),'FinalBal$':round(res['final_bal'],2),'Return%':round((res['final_bal']/100-1)*100,2),'AvgRR':round(avg_rr,2)})

df_summary=pd.DataFrame(rows)
print("\n=== Summary Table 5 Alts Real Data ===")
print(df_summary.to_string(index=False))
df_summary.to_csv('/home/user/real_5_alts_summary.csv', index=False)

if all_sorted:
    pd.DataFrame(all_sorted).to_csv('/home/user/real_5_alts_combined_trades.csv', index=False)
