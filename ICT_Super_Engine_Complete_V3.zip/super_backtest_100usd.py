"""
Super Engine - Deep Thinking Backtest - Last Month - $100 Balance 1% Risk
No Lookahead, Walk-Forward, Spot Only Long
Incorporates:
- True Protected Low (Velocity, Rejection 2.5x, Ghost, Trendline R2>0.95, Verification BOS)
- BOS triple filter (ClosePos>0.65, Vol Outlier 1.5x, Displacement ATR*0.1, No Sweep)
- Discount Dynamic (POC VPVR + Median)/2, OTE 70.5-79% deep for RR>2
- OB/FVG confluence with execution trigger (Wick OR Vol, no extreme churn)
- RR Fix: TP = term + range*0.27 (ICT) and 0.62 deep, enforce RR>=1.5
- Position Sizing Adaptive M = W_structure + W_volume + W_delta + W_context 0.25-2.5x
- Fees 0.1% taker, slippage guard
- Continuous equity compounding
"""
import pandas as pd
import numpy as np
from datetime import datetime
import json

from engine.core.swing_detector import ProtectedSwingDetector
from engine.core.bos_detector import BOSDetector
from engine.core.orderblock_detector import OrderBlockDetector
from engine.core.position_sizing import ConfluenceWeighter

# --- Balanced BOS with relaxed thresholds for real market ---
class BalancedBOS(BOSDetector):
    def __init__(self):
        super().__init__(atr_period=14, volume_lookback=20)
        self.close_pos_thresh = 0.60
        self.disp_factor = 0.10
        self.upper_wick_thresh = 0.70
    def calculate_volume_bollinger(self, df, idx):
        start = max(0, idx-20)
        vol_mean = df['volume'].iloc[start:idx].mean() if idx>start else df['volume'].mean()
        curr = df['volume'].iloc[idx]
        is_outlier = curr > vol_mean*1.2
        return {'is_outlier': is_outlier, 'mean': vol_mean, 'upper_band': vol_mean*1.2, 'current': curr, 'ratio': curr/vol_mean if vol_mean>0 else 0, 'std': df['volume'].iloc[start:idx].std() if idx>start else 0}

def calculate_z_score(curr, mean, std):
    if std==0 or pd.isna(std):
        return 0
    return (curr-mean)/std

def calculate_atr(df, period=14):
    high = df['high']
    low = df['low']
    close = df['close']
    tr1 = high - low
    tr2 = (high - close.shift()).abs()
    tr3 = (low - close.shift()).abs()
    tr = pd.concat([tr1,tr2,tr3], axis=1).max(axis=1)
    atr = tr.rolling(period).mean().fillna(tr.expanding().mean()).fillna(0.5)
    return atr

def calculate_poc(df_segment, low_price, high_price, bins=20):
    bins_edges = np.linspace(low_price, high_price, bins)
    vol_per_bin = np.zeros(bins-1)
    for _, row in df_segment.iterrows():
        typical = (row['high']+row['low']+row['close'])/3
        if low_price <= typical <= high_price:
            idx = np.digitize(typical, bins_edges)-1
            idx = max(0, min(idx, len(vol_per_bin)-1))
            vol_per_bin[idx] += row['volume']
    if vol_per_bin.sum()==0:
        return (low_price+high_price)/2
    max_idx = np.argmax(vol_per_bin)
    return (bins_edges[max_idx]+bins_edges[max_idx+1])/2

# Load data
df = pd.read_csv('/home/user/btcusdt_15m_last_month.csv')
df['timestamp'] = pd.to_datetime(df['timestamp'])
df = df.sort_values('timestamp').reset_index(drop=True)
print(f"Loaded {len(df)} candles from {df['timestamp'].iloc[0]} to {df['timestamp'].iloc[-1]}")

# Detectors
swing_det = ProtectedSwingDetector(pivot_length=2)
swing_sens = ProtectedSwingDetector(pivot_length=1)
bos_det = BalancedBOS()
ob_det = OrderBlockDetector()
weighter = ConfluenceWeighter()

# Trading params
initial_balance = 100.0
balance = initial_balance
base_risk_pct = 1.0
fee_pct = 0.001  # 0.1% taker

trades = []
equity_curve = []
current_trade = None
logs = []

# Precompute ATR for whole df for speed (but walk-forward will still use past only for decision, ATR here for display)
atr_full = calculate_atr(df)

for i in range(50, len(df)-1):
    past = df.iloc[:i+1].copy()
    curr = df.iloc[i]
    nxt = df.iloc[i+1]
    atr_series = calculate_atr(past)

    # Equity update tracking
    equity_curve.append({'timestamp': curr['timestamp'], 'balance': balance, 'price': curr['close']})

    # Manage open trade
    if current_trade:
        low = curr['low']
        high = curr['high']
        # SL first
        if low <= current_trade['stop_loss']:
            exit_price = current_trade['stop_loss']
            # fees
            entry_cost = current_trade['entry_price'] * current_trade['coins']
            exit_value = exit_price * current_trade['coins']
            fee_entry = entry_cost * fee_pct
            fee_exit = exit_value * fee_pct
            profit_usd = (exit_price - current_trade['entry_price']) * current_trade['coins'] - fee_entry - fee_exit
            # Balance update
            balance += profit_usd
            current_trade['exit_price'] = exit_price
            current_trade['exit_time'] = curr['timestamp']
            current_trade['profit_usd'] = profit_usd
            current_trade['profit_pct'] = (exit_price/current_trade['entry_price']-1)*100
            current_trade['result'] = 'LOSS'
            current_trade['bars_held'] = i - current_trade['entry_index']
            current_trade['exit_reason'] = 'STOP_LOSS_HIT - Protected Low broken, whale surrendered, lifeline 1%'
            current_trade['balance_after'] = balance
            current_trade['fee_total'] = fee_entry + fee_exit
            trades.append(current_trade)
            logs.append(f"[{curr['timestamp']}] EXIT SL Trade {current_trade['id']} Entry {current_trade['entry_price']:.2f} SL {current_trade['stop_loss']:.2f} Exit {exit_price:.2f} Loss {profit_usd:.2f}$ Balance {balance:.2f}$")
            current_trade = None
            continue
        if high >= current_trade['take_profit']:
            exit_price = current_trade['take_profit']
            entry_cost = current_trade['entry_price'] * current_trade['coins']
            exit_value = exit_price * current_trade['coins']
            fee_entry = entry_cost * fee_pct
            fee_exit = exit_value * fee_pct
            profit_usd = (exit_price - current_trade['entry_price']) * current_trade['coins'] - fee_entry - fee_exit
            balance += profit_usd
            current_trade['exit_price'] = exit_price
            current_trade['exit_time'] = curr['timestamp']
            current_trade['profit_usd'] = profit_usd
            current_trade['profit_pct'] = (exit_price/current_trade['entry_price']-1)*100
            current_trade['result'] = 'WIN'
            current_trade['bars_held'] = i - current_trade['entry_index']
            current_trade['exit_reason'] = 'TAKE_PROFIT_HIT - Termination +0.27 extension magnet reached'
            current_trade['balance_after'] = balance
            current_trade['fee_total'] = fee_entry + fee_exit
            trades.append(current_trade)
            logs.append(f"[{curr['timestamp']}] EXIT TP Trade {current_trade['id']} Entry {current_trade['entry_price']:.2f} TP {current_trade['take_profit']:.2f} Exit {exit_price:.2f} Profit {profit_usd:.2f}$ RR {current_trade['rr']:.2f} Balance {balance:.2f}$")
            current_trade = None
            continue
        continue

    # --- Station 1: Protected Low ---
    try:
        swings_res = swing_det.analyze(past)
    except Exception as e:
        continue
    # Filter protected lows: protected True, not ghost, not trap, rejection >=1.0, within 150 bars
    protected_ok = [s for s in swings_res['all_swings'] if s['type']=='low' and s['protected'] and not s['is_ghost'] and not s['is_trap'] and s['rejection_ratio'] and s['rejection_ratio']>=1.0]
    if not protected_ok:
        # fallback to true_protected_lows
        protected_ok = swings_res['true_protected_lows']
    if not protected_ok:
        continue
    protected_low = protected_ok[-1]
    if i - protected_low['index'] > 150:
        continue

    # --- Station 2: BOS ---
    try:
        swings_sens_res = swing_sens.analyze(past)
        bos_res = bos_det.analyze(past, swings_sens_res['all_swings'])
    except:
        continue
    if not bos_res['valid_bos']:
        continue
    bos_valid = bos_res['valid_bos'][-1]
    if bos_valid['index'] <= protected_low['index']:
        continue
    if i - bos_valid['index'] > 80:
        continue

    # --- Station 3: Discount ---
    origin_idx = protected_low['index']
    origin_price = protected_low['price']
    term_price = past['high'].iloc[origin_idx:].max()
    range_size = term_price - origin_price
    if range_size <=0:
        continue

    # POC and Dynamic Equilibrium
    segment = past.iloc[origin_idx:]
    poc = calculate_poc(segment, origin_price, term_price)
    median_50 = (origin_price + term_price)/2
    dyn_eq = (poc + median_50)/2

    # Check price in Discount (must be below Eq)
    if curr['close'] > dyn_eq:
        continue

    # Deep OTE 70.5-79% only for RR>2
    buy_low = term_price - range_size*0.79
    buy_high = term_price - range_size*0.705

    # Strictly inside buy range
    if not (buy_low <= curr['close'] <= buy_high):
        # also allow low touches
        if not (buy_low <= curr['low'] <= buy_high):
            continue

    # Trap checks: Liquidity Bleeding (bear vol increasing + CVD collapsing)
    # Simplified bleeding detection: last 10 candles bear vol increasing and CVD slope negative
    lookback = 10
    seg_bleed = past.iloc[max(0,i-lookback):i+1]
    bear_vols = [r['volume'] for _, r in seg_bleed.iterrows() if r['close'] < r['open']]
    if len(bear_vols)>=3:
        x = np.arange(len(bear_vols)).reshape(-1,1)
        from sklearn.linear_model import LinearRegression
        try:
            model = LinearRegression().fit(x, np.array(bear_vols))
            bear_slope = model.coef_[0]
            bear_increasing = bear_slope > 0
        except:
            bear_increasing = False
            bear_slope = 0
    else:
        bear_increasing = False
        bear_slope = 0

    # CVD proxy
    cvd = 0
    cvd_vals = []
    for _, r in seg_bleed.iterrows():
        hl = r['high']-r['low']
        if hl>0:
            delta = (r['close']-r['low'])/hl - 0.5
            cvd += delta * r['volume']
            cvd_vals.append(cvd)
    if len(cvd_vals)>=3:
        x = np.arange(len(cvd_vals)).reshape(-1,1)
        try:
            model = LinearRegression().fit(x, np.array(cvd_vals))
            cvd_slope = model.coef_[0]
            cvd_collapsing = cvd_slope <0 and cvd <0
        except:
            cvd_collapsing = False
            cvd_slope = 0
    else:
        cvd_collapsing = False
        cvd_slope = 0

    is_bleeding = bear_increasing and cvd_collapsing
    if is_bleeding:
        logs.append(f"[{curr['timestamp']}] BLEEDING TRAP skip - bear vol inc {bear_slope:.1f} cvd slope {cvd_slope:.1f}")
        continue

    # --- Station 4: OB/FVG ---
    try:
        fvgs = ob_det.detect_fvgs(past)
        obs = ob_det.detect_bullish_obs(past, fvgs)
    except:
        continue
    if not obs:
        continue

    # Find valid OB/FVG confluence in buy range
    valid_exec = None
    recent_fvgs = [f for f in fvgs if not f.is_ghost]
    recent_obs = [o for o in obs if not o.is_mitigated]

    # Filter OBs overlapping buy range
    valid_obs = []
    for ob in recent_obs:
        if buy_low <= ob.low <= buy_high or buy_low <= ob.high <= buy_high or (ob.low <= buy_high and ob.high >= buy_low):
            valid_obs.append(ob)

    if not valid_obs:
        continue

    for ob in valid_obs[-3:]:  # last 3
        for fvg in recent_fvgs[-5:]:
            if abs(fvg.low - ob.high) < (ob.high-ob.low)*3:
                hl_range = curr['high']-curr['low']
                if hl_range==0:
                    continue
                lower_wick = min(curr['open'], curr['close']) - curr['low']
                body = abs(curr['close']-curr['open'])
                close_pos = (curr['close']-curr['low'])/hl_range if hl_range>0 else 0
                wick_rej = lower_wick > body*0.5 and close_pos>0.55
                vol_mean = past['volume'].iloc[max(0,i-20):i].mean()
                vol_std = past['volume'].iloc[max(0,i-20):i].std()
                vol_spike = curr['volume'] > vol_mean*1.2
                z_vol = calculate_z_score(curr['volume'], vol_mean, vol_std)
                is_extreme_churn = body < hl_range*0.15 and curr['volume'] > vol_mean*2.5
                if (wick_rej or vol_spike) and not is_extreme_churn:
                    valid_exec = (ob,fvg,wick_rej,vol_spike,close_pos,z_vol)
                    break
        if valid_exec:
            break

    if not valid_exec:
        continue

    ob,fvg,wick_rej,vol_spike,close_pos,z_vol = valid_exec

    # --- Position Sizing & Confluence Multiplier ---
    # W_structure: BOS valid with safe distance
    # Safe distance: close - last swing > ATR*0.1
    atr_curr = atr_series.iloc[-1]
    disp = bos_valid['price'] - bos_valid['last_swing_price']
    has_safe = disp > atr_curr*0.1
    is_noise = False  # simplified
    map_type = "Map1_Bullish_ProTrend"
    bos_real = True

    w_struct = weighter.weight_structure(map_type, bos_real, has_safe, is_noise)
    w_vol = weighter.weight_volume(z_vol)
    # Delta
    is_aggressive = wick_rej and close_pos>0.85 and vol_spike and z_vol>2.0
    is_silent = close_pos>0.6 and not is_aggressive
    is_churning = body < hl_range*0.2 and curr['volume'] > vol_mean*2
    w_delta = weighter.weight_delta(is_aggressive, close_pos, is_silent, is_churning)
    # Context ideal for backtest neutral 0.5
    funding_z = 0.0
    inflow_z = 0.0
    w_context = weighter.weight_context(funding_z, inflow_z)

    M = w_struct + w_vol + w_delta + w_context
    M = max(0.25, min(2.50, M))

    # --- Generate Trade with RR Fix ---
    entry_price = nxt['open']
    stop_loss = protected_low['price'] - 0.01

    tp_standard = term_price + range_size*0.27
    tp_deep = term_price + range_size*0.62
    take_profit = tp_standard

    risk = abs(entry_price - stop_loss)
    reward = abs(take_profit - entry_price)
    rr = reward / risk if risk>0 else 0

    if rr < 1.5:
        take_profit = tp_deep
        reward = abs(take_profit - entry_price)
        rr = reward / risk if risk>0 else 0
        if rr < 1.5:
            logs.append(f"[{curr['timestamp']}] REJECT RR {rr:.2f}<1.5 Entry {entry_price:.2f} SL {stop_loss:.2f} TP {take_profit:.2f}")
            continue

    risk_dist = abs(entry_price - stop_loss)/entry_price
    if risk_dist==0:
        continue
    allowed_loss = balance * (base_risk_pct/100) * M
    # Cap allowed loss to balance*0.02 to avoid overleverage
    allowed_loss = min(allowed_loss, balance*0.025)
    spot_allocation = allowed_loss / risk_dist
    # Ensure not using more than balance
    spot_allocation = min(spot_allocation, balance*0.95)  # max 95% of balance in one spot trade
    coins = spot_allocation / entry_price

    trade_id = len(trades)+1
    current_trade = {
        'id': trade_id,
        'entry_index': i+1,
        'entry_time': nxt['timestamp'],
        'entry_price': entry_price,
        'stop_loss': stop_loss,
        'take_profit': take_profit,
        'take_profit_deep': tp_deep,
        'take_profit_standard': tp_standard,
        'risk_pct': risk_dist*100,
        'rr': rr,
        'coins': coins,
        'spot_allocation_usd': spot_allocation,
        'allowed_loss_usd': allowed_loss,
        'balance_before': balance,
        'M': M,
        'w_struct': w_struct,
        'w_vol': w_vol,
        'w_delta': w_delta,
        'w_context': w_context,
        'z_vol': z_vol,
        'protected_low_price': protected_low['price'],
        'protected_low_idx': protected_low['index'],
        'protected_low_rej': protected_low['rejection_ratio'],
        'bos_price': bos_valid['price'],
        'bos_last_high': bos_valid['last_swing_price'],
        'bos_close_pos': bos_valid['close_position'],
        'buy_range_low': buy_low,
        'buy_range_high': buy_high,
        'dyn_eq': dyn_eq,
        'poc': poc,
        'term_price': term_price,
        'origin_price': origin_price,
        'range_size': range_size,
        'ob_low': ob.low,
        'ob_high': ob.high,
        'fvg_low': fvg.low,
        'fvg_high': fvg.high,
        'fvg_ce': fvg.ce,
        'wick_rej': wick_rej,
        'vol_spike': vol_spike,
        'close_pos': close_pos,
        'reason': f"PL {protected_low['price']:.2f} rej {protected_low['rejection_ratio']:.1f} VERIFIED + BOS {bos_valid['price']:.2f} brk {bos_valid['last_swing_price']:.2f} CP {bos_valid['close_position']:.2f} VolZ {z_vol:.1f} + Discount Eq {dyn_eq:.2f} POC {poc:.2f} Deep OTE 70.5-79% {buy_low:.2f}-{buy_high:.2f} Price {curr['close']:.2f} <Eq + OB {ob.low:.2f}-{ob.high:.2f} FVG {fvg.low:.2f}-{fvg.high:.2f} CE {fvg.ce:.2f} Trigger Wick {wick_rej} VolSpike {vol_spike} ClosePos {close_pos:.2f} No Bleed + M {M:.2f} (Struct {w_struct:.2f} Vol {w_vol:.2f} Delta {w_delta:.2f} Ctx {w_context:.2f}) RR {rr:.2f} TP ext 0.27",
    }
    logs.append(f"[{curr['timestamp']}] NEW TRADE {trade_id} Entry next {entry_price:.2f} SL {stop_loss:.2f} TP {take_profit:.2f} (std {tp_standard:.2f} deep {tp_deep:.2f}) RR {rr:.2f} BuyRange Deep {buy_low:.2f}-{buy_high:.2f} Price {curr['close']:.2f} OB {ob.low:.2f}-{ob.high:.2f} FVG CE {fvg.ce:.2f} M {M:.2f} Balance {balance:.2f}$ Allocation {spot_allocation:.2f}$ Coins {coins:.6f}")

# Final if still open, close at last price
if current_trade:
    exit_price = df.iloc[-1]['close']
    entry_cost = current_trade['entry_price'] * current_trade['coins']
    exit_value = exit_price * current_trade['coins']
    fee_entry = entry_cost * fee_pct
    fee_exit = exit_value * fee_pct
    profit_usd = (exit_price - current_trade['entry_price']) * current_trade['coins'] - fee_entry - fee_exit
    balance += profit_usd
    current_trade['exit_price'] = exit_price
    current_trade['exit_time'] = df.iloc[-1]['timestamp']
    current_trade['profit_usd'] = profit_usd
    current_trade['profit_pct'] = (exit_price/current_trade['entry_price']-1)*100
    current_trade['result'] = 'OPEN_CLOSED_AT_END'
    current_trade['bars_held'] = len(df)-1 - current_trade['entry_index']
    current_trade['exit_reason'] = 'CLOSED_AT_END_OF_DATA'
    current_trade['balance_after'] = balance
    current_trade['fee_total'] = fee_entry + fee_exit
    trades.append(current_trade)

# Stats
print(f"\n=== FINAL REPORT $100 1% Risk Last Month ===")
print(f"Total trades: {len(trades)}")
wins = [t for t in trades if t['result']=='WIN']
losses = [t for t in trades if t['result']=='LOSS']
win_rate = len(wins)/len(trades)*100 if trades else 0
total_pnl = sum(t['profit_usd'] for t in trades)
total_fees = sum(t.get('fee_total',0) for t in trades)
avg_win = np.mean([t['profit_usd'] for t in wins]) if wins else 0
avg_loss = np.mean([t['profit_usd'] for t in losses]) if losses else 0
avg_rr = np.mean([t['rr'] for t in trades]) if trades else 0
avg_bars = np.mean([t['bars_held'] for t in trades]) if trades else 0

print(f"Wins: {len(wins)} Losses: {len(losses)} WinRate: {win_rate:.1f}%")
print(f"Total PnL: {total_pnl:.4f}$ Fees: {total_fees:.4f}$ Net PnL: {total_pnl:.4f}$")
print(f"Final Balance: {balance:.4f}$ from 100$ => Return { (balance/100-1)*100:.2f}%")
print(f"Avg Win: {avg_win:.4f}$ Avg Loss: {avg_loss:.4f}$ Avg RR: {avg_rr:.2f} Avg Bars Held: {avg_bars:.1f}")

# Equity max drawdown
equity_df = pd.DataFrame(equity_curve)
# Add trades equity progression
# Compute drawdown from peak balance
balances = [initial_balance] + [t['balance_after'] for t in trades]
peak = initial_balance
max_dd = 0
for b in balances:
    if b>peak:
        peak=b
    dd = (peak-b)/peak*100
    if dd>max_dd:
        max_dd=dd
print(f"Max Drawdown: {max_dd:.2f}%")

# Expectancy
if wins and losses:
    expectancy = (len(wins)/len(trades))*avg_win + (len(losses)/len(trades))*avg_loss
    print(f"Expectancy per trade: {expectancy:.4f}$")

# Save trades
if trades:
    trades_df = pd.DataFrame(trades)
    trades_df.to_csv('/home/user/super_backtest_100usd_trades_detailed.csv', index=False)
    print("Saved trades to super_backtest_100usd_trades_detailed.csv")

    with open('/home/user/super_backtest_100usd_logs.txt','w') as f:
        for log in logs:
            f.write(log+'\n')
    print("Saved logs to super_backtest_100usd_logs.txt")

    # Print detailed trades
    for t in trades:
        print(f"\n--- Trade {t['id']} {t['result']} ---")
        print(f"Entry Time: {t['entry_time']} Price: {t['entry_price']:.2f} | Exit Time: {t.get('exit_time')} Price: {t.get('exit_price',0):.2f}")
        print(f"SL: {t['stop_loss']:.2f} ({t['risk_pct']:.2f}%) TP: {t['take_profit']:.2f} (std {t['take_profit_standard']:.2f} deep {t['take_profit_deep']:.2f}) RR: {t['rr']:.2f}")
        print(f"Profit: {t['profit_usd']:.4f}$ ({t['profit_pct']:.2f}%) | Allocation: {t['spot_allocation_usd']:.2f}$ Coins: {t['coins']:.6f} | Balance: {t['balance_before']:.2f} -> {t['balance_after']:.2f}$ | M {t['M']:.2f} Fees {t.get('fee_total',0):.4f}$")
        print(f"PL {t['protected_low_price']:.2f} rej {t['protected_low_rej']:.1f} | BOS {t['bos_price']:.2f} brk {t['bos_last_high']:.2f} CP {t['bos_close_pos']:.2f}")
        print(f"Discount Eq {t['dyn_eq']:.2f} POC {t['poc']:.2f} Range {t['range_size']:.2f} BuyRange Deep {t['buy_range_low']:.2f}-{t['buy_range_high']:.2f}")
        print(f"OB {t['ob_low']:.2f}-{t['ob_high']:.2f} FVG {t['fvg_low']:.2f}-{t['fvg_high']:.2f} CE {t['fvg_ce']:.2f} | Wick {t['wick_rej']} VolSpike {t['vol_spike']} ClosePos {t['close_pos']:.2f} ZVol {t['z_vol']:.2f}")
        print(f"Reason: {t['reason']}")
