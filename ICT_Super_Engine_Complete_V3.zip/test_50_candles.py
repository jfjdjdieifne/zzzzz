import pandas as pd
from datetime import datetime, timedelta

Avg_Volume = 60000
ATR_fixed = 5.00
Last_High = 150.00

candles = [
    {"Index": 1, "Open": 145.00, "High": 146.00, "Low": 142.00, "Close": 143.50, "Volume": 45000},
    {"Index": 2, "Open": 143.50, "High": 144.00, "Low": 139.00, "Close": 140.20, "Volume": 52000},
    {"Index": 3, "Open": 140.20, "High": 141.50, "Low": 132.00, "Close": 139.80, "Volume": 185000},
    {"Index": 4, "Open": 139.80, "High": 142.00, "Low": 138.50, "Close": 141.50, "Volume": 75000},
    {"Index": 5, "Open": 141.50, "High": 143.00, "Low": 139.00, "Close": 140.00, "Volume": 42000},
    {"Index": 6, "Open": 140.00, "High": 141.20, "Low": 139.10, "Close": 139.80, "Volume": 38000},
    {"Index": 7, "Open": 139.80, "High": 140.50, "Low": 139.20, "Close": 140.10, "Volume": 29000},
    {"Index": 8, "Open": 140.10, "High": 143.80, "Low": 139.90, "Close": 143.20, "Volume": 61000},
    {"Index": 9, "Open": 143.20, "High": 144.50, "Low": 141.00, "Close": 142.00, "Volume": 54000},
    {"Index": 10, "Open": 142.00, "High": 142.80, "Low": 135.00, "Close": 141.90, "Volume": 59000},
    {"Index": 11, "Open": 141.90, "High": 143.50, "Low": 141.20, "Close": 143.00, "Volume": 48000},
    {"Index": 12, "Open": 143.00, "High": 145.20, "Low": 142.80, "Close": 144.90, "Volume": 57000},
    {"Index": 13, "Open": 144.90, "High": 152.50, "Low": 144.00, "Close": 148.90, "Volume": 140000},
    {"Index": 14, "Open": 148.90, "High": 151.00, "Low": 146.50, "Close": 147.20, "Volume": 68000},
    {"Index": 15, "Open": 147.20, "High": 149.50, "Low": 146.00, "Close": 149.10, "Volume": 51000},
    {"Index": 16, "Open": 149.10, "High": 158.50, "Low": 148.20, "Close": 157.90, "Volume": 230000},
    {"Index": 17, "Open": 157.90, "High": 159.00, "Low": 156.00, "Close": 158.20, "Volume": 110000},
    {"Index": 18, "Open": 158.20, "High": 161.00, "Low": 157.50, "Close": 160.10, "Volume": 98000},
    {"Index": 19, "Open": 160.10, "High": 162.50, "Low": 159.00, "Close": 161.80, "Volume": 85000},
    {"Index": 20, "Open": 161.80, "High": 163.00, "Low": 160.20, "Close": 161.00, "Volume": 69000},
    {"Index": 21, "Open": 161.00, "High": 161.80, "Low": 157.50, "Close": 158.00, "Volume": 52000},
    {"Index": 22, "Open": 158.00, "High": 159.20, "Low": 156.00, "Close": 156.50, "Volume": 47000},
    {"Index": 23, "Open": 156.50, "High": 158.00, "Low": 155.20, "Close": 157.40, "Volume": 43000},
    {"Index": 24, "Open": 157.40, "High": 157.90, "Low": 151.00, "Close": 151.80, "Volume": 58000},
    {"Index": 25, "Open": 151.80, "High": 153.00, "Low": 149.50, "Close": 150.10, "Volume": 49000},
    {"Index": 26, "Open": 150.10, "High": 151.50, "Low": 147.20, "Close": 148.00, "Volume": 44000},
    {"Index": 27, "Open": 148.00, "High": 149.20, "Low": 145.00, "Close": 145.80, "Volume": 41000},
    {"Index": 28, "Open": 145.80, "High": 146.50, "Low": 143.80, "Close": 144.10, "Volume": 38000},
    {"Index": 29, "Open": 144.10, "High": 145.00, "Low": 142.10, "Close": 142.50, "Volume": 35000},
    {"Index": 30, "Open": 142.50, "High": 143.80, "Low": 142.00, "Close": 143.10, "Volume": 31000},
    {"Index": 31, "Open": 143.10, "High": 145.00, "Low": 142.90, "Close": 144.80, "Volume": 46000},
    {"Index": 32, "Open": 144.80, "High": 146.20, "Low": 144.00, "Close": 144.30, "Volume": 39000},
    {"Index": 33, "Open": 144.30, "High": 145.50, "Low": 143.10, "Close": 143.50, "Volume": 33000},
    {"Index": 34, "Open": 143.50, "High": 144.20, "Low": 141.80, "Close": 142.00, "Volume": 37000},
    {"Index": 35, "Open": 142.00, "High": 143.00, "Low": 140.50, "Close": 141.20, "Volume": 42000},
    {"Index": 36, "Open": 141.20, "High": 142.50, "Low": 139.80, "Close": 140.00, "Volume": 45000},
    {"Index": 37, "Open": 140.00, "High": 141.00, "Low": 138.90, "Close": 139.20, "Volume": 49000},
    {"Index": 38, "Open": 139.20, "High": 140.50, "Low": 135.20, "Close": 135.50, "Volume": 54000},
    {"Index": 39, "Open": 135.50, "High": 136.80, "Low": 134.90, "Close": 135.10, "Volume": 59000},
    {"Index": 40, "Open": 135.10, "High": 135.50, "Low": 134.40, "Close": 134.80, "Volume": 51000},
    {"Index": 41, "Open": 134.80, "High": 141.00, "Low": 134.50, "Close": 140.50, "Volume": 195000},
    {"Index": 42, "Open": 140.50, "High": 142.80, "Low": 139.90, "Close": 142.20, "Volume": 110000},
    {"Index": 43, "Open": 142.20, "High": 143.00, "Low": 141.10, "Close": 141.80, "Volume": 85000},
    {"Index": 44, "Open": 141.80, "High": 142.10, "Low": 137.50, "Close": 137.90, "Volume": 63000},
    {"Index": 45, "Open": 137.90, "High": 138.50, "Low": 136.20, "Close": 136.80, "Volume": 52000},
    {"Index": 46, "Open": 136.80, "High": 137.20, "Low": 135.80, "Close": 136.10, "Volume": 44000},
    {"Index": 47, "Open": 136.10, "High": 136.50, "Low": 135.20, "Close": 135.40, "Volume": 41000},
    {"Index": 48, "Open": 135.40, "High": 135.90, "Low": 134.90, "Close": 135.20, "Volume": 49000},
    {"Index": 49, "Open": 135.20, "High": 136.00, "Low": 134.70, "Close": 135.60, "Volume": 125000},
    {"Index": 50, "Open": 135.60, "High": 136.50, "Low": 135.30, "Close": 136.20, "Volume": 115000},
]

df = pd.DataFrame([{
    'timestamp': datetime(2024,1,1) + timedelta(minutes=c['Index']*5),
    'open': c['Open'],
    'high': c['High'],
    'low': c['Low'],
    'close': c['Close'],
    'volume': c['Volume']
} for c in candles])

print("="*90)
print(f"اختبار 2 - 50 شمعة - Setup: Avg_Vol={Avg_Volume} ATR={ATR_fixed} Last_High={Last_High}")
print("="*90)

logs=[]

for i in range(len(df)):
    c = df.iloc[i]
    idx = i+1
    hl = c['high']-c['low']
    close_pos = (c['close']-c['low'])/hl if hl>0 else 0
    vol = c['volume']
    # Volume Bollinger proxy
    vol_mean = df['volume'].iloc[max(0,i-20):i].mean() if i>=5 else Avg_Volume
    is_outlier = vol > Avg_Volume*2 or vol > vol_mean*2
    
    if idx==3:
        lower_wick = min(c['open'],c['close'])-c['low']
        # avg wick last 2
        avg_wick = 1.5
        ratio = lower_wick/avg_wick
        logs.append(f"[{idx}] Station1 Candidate Low {c['low']:.2f} Vol {vol} (3.08x avg) LowerWick {lower_wick:.2f} Ratio {ratio:.1f}x>2.5 => Protected Low 132.00 candidate - Selling Velocity decreasing? Body 1.4 vs prev bodies 2-2.8 decreasing")
    
    if idx==13:
        disp = c['close'] - Last_High
        upper_wick = c['high'] - max(c['open'],c['close'])
        upper_ratio = upper_wick / hl if hl>0 else 0
        logs.append(f"[{idx}] Station2 BOS CHECK: High {c['high']:.2f}>150 Close {c['close']:.2f}<150 ClosePos {close_pos:.2f}<0.75 Disp {disp:.2f} (neg) UpperWickRatio {upper_ratio:.2f} Vol {vol} -> WICK ONLY / LIQUIDITY SWEEP TRAP (Fake Close)")
    
    if idx==16:
        disp = c['close'] - Last_High
        upper_wick = c['high'] - max(c['open'],c['close'])
        upper_ratio = upper_wick / hl if hl>0 else 0
        logs.append(f"[{idx}] Station2 BOS CHECK: High {c['high']:.2f}>150 Close {c['close']:.2f}>150 ClosePos {close_pos:.2f}>0.75 Vol {vol} Outlier={is_outlier} Disp {disp:.2f}> {ATR_fixed*0.2} UpperWickRatio {upper_ratio:.2f} -> VALID BOS - State -> SEARCH_DISCOUNT (Termination 158.5)")
    
    if idx==20:
        logs.append(f"[{idx}] Station2 Continuation: High 163.00 new high - Range Origin 132 -> Termination 163 = 31$")

    if idx in [21,25,30,38,40]:
        # Discount calculations
        origin = 132.0
        term = 163.0
        median = (origin+term)/2
        # POC approx: volume profile between 132-163 max at 145-150 area?
        poc = 148.0
        dyn_eq = (poc + median)/2
        # median =147.5, dyn_eq=(148+147.5)/2=147.75
        logs.append(f"[{idx}] Station3 Discount: Price {c['close']:.2f} DynamicEq {(poc+((origin+term)/2))/2:.2f} (POC~{poc}+Median~{(origin+term)/2:.2f})/2 Premium {(poc+((origin+term)/2))/2:.2f}-163 NO BUY Discount 132-{(poc+((origin+term)/2))/2:.2f} Watch")

    if idx==41:
        # Candle 41: Open 134.8 High 141 Low 134.5 Close 140.5 Vol 195k
        # This is after deep pullback to 134.4 low at 40
        # Check if bullish OB: prev bearish? Candle40 bearish (135.1->134.8 bearish) Candle41 bullish engulfing? Open 134.8 High 141 Low134.5 Close140.5
        # Low 134.5 > Low prev 134.4? Actually 134.5 >134.4 not grab, but close above high prev 135.5? Close 140.5 >135.5 yes
        # Volume 195k = 3.25x avg 60k outlier, displacement body 140.5-134.8=5.7 large
        # This could be bullish OB formation + displacement + BOS of last lower high?
        # Also FVG: need High C1 < Low C3 - let's see C39 High136.8, C41 Low134.5 => 136.8>134.5 no gap
        # But C40 High135.5, C42 Low139.9? 135.5<139.9 => gap 135.5-139.9 = bullish FVG 4.4$
        logs.append(f"[{idx}] Station4 Potential Reversal: Open {c['open']} Low {c['low']} High {c['high']} Close {c['close']} Vol {vol} 3.25x avg - Bullish Displacement large body {c['close']-c['open']:.2f} - Could be bullish OB formation after sweep of 134.40 low")

    if idx==44:
        # Candle44: Open141.8 High142.1 Low137.5 Close137.9 Vol63000 bearish large red
        logs.append(f"[{idx}] Station4 Retracement Efficiency CHECK: Bearish candle Open141.8 Close137.9 Body {c['open']-c['close']:.2f} Vol63000 - If dropping to OB via huge reds increasing vol => Failed OB Attack - Cancel buy")

    if idx in [49,50]:
        # Candle49 Vol125k close135.6 open135.2 body 0.4 small but volume huge? Could be churning?
        # Candle49 lower wick = min(135.2,135.6)-134.7=0.5, upper wick=136-135.6=0.4, range=1.3, close_pos=(135.6-134.7)/1.3=0.69>0.6 wick rejection?
        lower_wick = min(c['open'],c['close'])-c['low']
        body = abs(c['close']-c['open'])
        close_pos_wick = (c['close']-c['low'])/(c['high']-c['low']) if (c['high']-c['low'])>0 else 0
        wick_rej = lower_wick > body and close_pos_wick>0.6
        logs.append(f"[{idx}] Station4 Execution Trigger: Price {c['close']:.2f} Low {c['low']:.2f} LowerWick {lower_wick:.2f} Body {body:.2f} ClosePos {close_pos_wick:.2f} WickRej={wick_rej} Vol{vol} - Check CVD flip")

for l in logs:
    print(l)

print("\n" + "="*90)
print("الخلاصة:")
print("- Protected Low: Candle3 Low 132.00 Vol185k Ratio huge => candidate VERIFIED")
print("- BOS Fake at 13: High152.5 Close148.9<150 WICK ONLY -> LIQUIDITY_SWEPT TRAP")
print("- BOS Valid at 16: High158.5 Close157.9>150 ClosePos 0.89>0.75 Vol230k Outlier Disp 7.9>1.0 UpperWick 0.10 small -> VALID BOS")
print("- Discount: Origin132 Term163 Median147.5 POC~148 Eq~147.75 Premium 147.75-163 NO BUY Discount 132-147.75 Watch BuyRange Shallow 50-61.8% 147.5-152.95? Actually high - range*0.5 etc or Deep OTE 70.5-79% 139.7-142.9")
print("- Execution: Candle41 displacement bullish 195k could be reversal after sweep of 134.4 low, but need FVG/OB confluence + CVD flip. Candles49-50 volume spike 125k with wick rejection lower wick 0.5 body 0.4 closePos0.69 => potential micro wick rejection but volume huge with small body could be churning")
print("="*90)
