import pandas as pd
from datetime import datetime, timedelta
from engine.core.swing_detector import ProtectedSwingDetector
from engine.core.bos_detector import BOSDetector
from engine.core.discount_detector import DiscountDetector
from engine.core.orderblock_detector import OrderBlockDetector, ExecutionEngine
from engine.super_engine import SuperEngine

Avg_Volume = 50000
ATR_fixed = 3.00
Last_High = 100.00

candles = [
    {"Index": 1, "Open": 95.00, "High": 96.00, "Low": 93.00, "Close": 93.50, "Volume": 45000},
    {"Index": 2, "Open": 93.50, "High": 94.00, "Low": 91.00, "Close": 91.20, "Volume": 48000},
    {"Index": 3, "Open": 91.20, "High": 92.00, "Low": 85.00, "Close": 89.80, "Volume": 165000},
    {"Index": 4, "Open": 89.80, "High": 92.50, "Low": 89.00, "Close": 92.10, "Volume": 65000},
    {"Index": 5, "Open": 92.10, "High": 94.00, "Low": 91.50, "Close": 93.80, "Volume": 42000},
    {"Index": 6, "Open": 93.80, "High": 95.00, "Low": 92.80, "Close": 104.50, "Volume": 220000},
    {"Index": 7, "Open": 104.50, "High": 106.00, "Low": 103.50, "Close": 105.80, "Volume": 95000},
    {"Index": 8, "Open": 105.80, "High": 107.50, "Low": 105.00, "Close": 107.10, "Volume": 85000},
    {"Index": 9, "Open": 107.10, "High": 108.00, "Low": 105.50, "Close": 106.20, "Volume": 52000},
    {"Index": 10, "Open": 106.20, "High": 106.80, "Low": 103.20, "Close": 103.80, "Volume": 44000},
    {"Index": 11, "Open": 103.80, "High": 104.50, "Low": 101.00, "Close": 101.50, "Volume": 41000},
    {"Index": 12, "Open": 101.50, "High": 102.50, "Low": 99.50, "Close": 100.20, "Volume": 38000},
    {"Index": 13, "Open": 100.20, "High": 101.00, "Low": 98.20, "Close": 98.50, "Volume": 35000},
    {"Index": 14, "Open": 98.50, "High": 99.20, "Low": 96.80, "Close": 97.10, "Volume": 32000},
    {"Index": 15, "Open": 97.10, "High": 97.80, "Low": 95.50, "Close": 95.80, "Volume": 29000},
    {"Index": 16, "Open": 95.80, "High": 96.50, "Low": 94.20, "Close": 94.50, "Volume": 27000},
    {"Index": 17, "Open": 94.50, "High": 95.10, "Low": 93.00, "Close": 93.40, "Volume": 25000},
    {"Index": 18, "Open": 93.40, "High": 94.00, "Low": 92.10, "Close": 92.50, "Volume": 23000},
    {"Index": 19, "Open": 92.50, "High": 93.10, "Low": 91.50, "Close": 91.80, "Volume": 21000},
    {"Index": 20, "Open": 91.80, "High": 92.30, "Low": 90.80, "Close": 91.10, "Volume": 19000},
    {"Index": 21, "Open": 91.10, "High": 91.60, "Low": 90.20, "Close": 90.50, "Volume": 18000},
    {"Index": 22, "Open": 90.50, "High": 91.00, "Low": 89.70, "Close": 89.90, "Volume": 16000},
    {"Index": 23, "Open": 89.90, "High": 90.40, "Low": 89.10, "Close": 89.30, "Volume": 15000},
    {"Index": 24, "Open": 89.30, "High": 89.80, "Low": 88.50, "Close": 88.80, "Volume": 14000},
    {"Index": 25, "Open": 88.80, "High": 89.20, "Low": 88.00, "Close": 88.20, "Volume": 13000},
    {"Index": 26, "Open": 88.20, "High": 88.60, "Low": 87.50, "Close": 87.70, "Volume": 12000},
    {"Index": 27, "Open": 87.70, "High": 88.10, "Low": 87.10, "Close": 87.30, "Volume": 11000},
    {"Index": 28, "Open": 87.30, "High": 87.70, "Low": 86.80, "Close": 86.90, "Volume": 10500},
    {"Index": 29, "Open": 86.90, "High": 87.20, "Low": 86.40, "Close": 86.50, "Volume": 9800},
    {"Index": 30, "Open": 86.50, "High": 86.80, "Low": 86.00, "Close": 86.20, "Volume": 9500},
    {"Index": 31, "Open": 86.20, "High": 86.50, "Low": 85.70, "Close": 85.90, "Volume": 9000},
    {"Index": 32, "Open": 85.90, "High": 86.20, "Low": 85.40, "Close": 85.50, "Volume": 8800},
    {"Index": 33, "Open": 85.50, "High": 85.80, "Low": 85.10, "Close": 85.20, "Volume": 8500},
    {"Index": 34, "Open": 85.20, "High": 85.50, "Low": 84.80, "Close": 84.90, "Volume": 8200},
    {"Index": 35, "Open": 84.90, "High": 85.20, "Low": 84.50, "Close": 84.60, "Volume": 7900},
    {"Index": 36, "Open": 84.60, "High": 84.90, "Low": 84.20, "Close": 84.30, "Volume": 7600},
    {"Index": 37, "Open": 84.30, "High": 84.60, "Low": 83.90, "Close": 84.00, "Volume": 7400},
    {"Index": 38, "Open": 84.00, "High": 84.30, "Low": 83.60, "Close": 83.70, "Volume": 7100},
    {"Index": 39, "Open": 83.70, "High": 84.00, "Low": 83.30, "Close": 83.40, "Volume": 6900},
    {"Index": 40, "Open": 83.40, "High": 83.70, "Low": 83.00, "Close": 83.10, "Volume": 6600},
    {"Index": 41, "Open": 83.10, "High": 83.40, "Low": 82.70, "Close": 82.80, "Volume": 6400},
    {"Index": 42, "Open": 82.80, "High": 83.10, "Low": 82.40, "Close": 82.50, "Volume": 6200},
    {"Index": 43, "Open": 82.50, "High": 82.80, "Low": 82.20, "Close": 82.30, "Volume": 5900},
    {"Index": 44, "Open": 82.30, "High": 82.50, "Low": 82.00, "Close": 82.10, "Volume": 5700},
    {"Index": 45, "Open": 82.10, "High": 82.30, "Low": 82.00, "Close": 82.05, "Volume": 5500},
    {"Index": 46, "Open": 82.05, "High": 82.20, "Low": 82.00, "Close": 82.02, "Volume": 5200},
    {"Index": 47, "Open": 82.02, "High": 82.10, "Low": 82.00, "Close": 82.01, "Volume": 5000},
    {"Index": 48, "Open": 82.01, "High": 82.05, "Low": 82.00, "Close": 82.00, "Volume": 4800},
    {"Index": 49, "Open": 82.00, "High": 82.02, "Low": 82.00, "Close": 82.00, "Volume": 4500},
    {"Index": 50, "Open": 82.00, "High": 82.01, "Low": 82.00, "Close": 82.00, "Volume": 4200},
    {"Index": 51, "Open": 82.00, "High": 82.02, "Low": 82.00, "Close": 82.01, "Volume": 3900},
    {"Index": 52, "Open": 82.01, "High": 82.03, "Low": 82.00, "Close": 82.02, "Volume": 3500},
    {"Index": 53, "Open": 82.02, "High": 82.05, "Low": 82.00, "Close": 82.03, "Volume": 3100},
    {"Index": 54, "Open": 82.03, "High": 82.06, "Low": 82.01, "Close": 82.04, "Volume": 2800},
    {"Index": 55, "Open": 82.04, "High": 82.08, "Low": 82.02, "Close": 82.05, "Volume": 2500},
    {"Index": 56, "Open": 82.05, "High": 82.10, "Low": 82.03, "Close": 82.06, "Volume": 2200},
    {"Index": 57, "Open": 82.06, "High": 82.12, "Low": 82.04, "Close": 82.08, "Volume": 1900},
    {"Index": 58, "Open": 82.08, "High": 82.15, "Low": 82.05, "Close": 100.20, "Volume": 240000},
    {"Index": 59, "Open": 100.20, "High": 102.50, "Low": 98.80, "Close": 99.50, "Volume": 95000},
    {"Index": 60, "Open": 99.50, "High": 100.20, "Low": 99.00, "Close": 99.80, "Volume": 85000},
]

df = pd.DataFrame([{
    'timestamp': datetime(2024,1,1) + timedelta(minutes=c['Index']*5),
    'open': c['Open'],
    'high': max(c['High'], c['Close'], c['Open']),  # fix invalid OHLC where close > high
    'low': min(c['Low'], c['Close'], c['Open']),
    'close': c['Close'],
    'volume': c['Volume']
} for c in candles])

print(f"ENGINE TEST 60 CANDLES - Setup Avg={Avg_Volume} ATR={ATR_fixed} LastHigh={Last_High}")
print("="*90)
print("الانجن نفسه يختبر شمعة شمعة - No Lookahead")
print("="*90)

engine = SuperEngine()
result = engine.run_bar_by_bar(df)

print("\n--- SUPERENGINE LOGS (cognitive memory) ---")
for log in result['logs']:
    print(log)

print("\n--- FINAL STATE ---")
print(f"State: {result['final_state']}")
print(f"ProtectedLow: {result['cognitive_memory'].get('protected_low')}")
print(f"BOS: {result['cognitive_memory'].get('bos_valid')}")
print(f"Trade: {result['cognitive_memory'].get('trade')}")
print(f"Trades: {result['trades']}")

print("\n" + "="*90)
print("CELL-BY-CELL AUTOMATIC OUTPUT (engine core only)")
print("="*90)

swing_det = ProtectedSwingDetector(pivot_length=3)
swing_sens = ProtectedSwingDetector(pivot_length=1)
bos_det = BOSDetector()
disc_det = DiscountDetector()
ob_det = OrderBlockDetector()

swings = swing_det.analyze(df)
print(f"\nProtectedSwingDetector pivot3: total={swings['total_swings']} true={swings['true_protected_lows']} ghost={swings['ghost_lows']} trap={swings['trap_lows']}")

swings1 = swing_sens.analyze(df)
print(f"Sensitive pivot1: total={len(swings1['all_swings'])}")

bos_res = bos_det.analyze(df, swings1['all_swings'])
print(f"\nBOSDetector: total={bos_res['total']} valid={bos_res['valid_bos']} swept={bos_res['liquidity_swept']} suspended={bos_res['suspended']} state={bos_res['cognitive_state']}")
for b in bos_res['valid_bos'][:3]:
    print(f"  VALID BOS idx {b['index']} price {b['price']:.2f} breaking {b['last_swing_price']:.2f} ClosePos {b['close_position']:.2f} VolOutlier {b['volume_outlier']} Disp {b['displacement_atr_ratio']:.2f}")

fvgs = ob_det.detect_fvgs(df)
obs = ob_det.detect_bullish_obs(df, fvgs)
print(f"\nOrderBlockDetector: FVGs={len(fvgs)} OBs={len(obs)}")
for f in fvgs[:5]:
    print(f"  FVG {f.low:.2f}-{f.high:.2f} CE {f.ce:.2f} gap {f.high-f.low:.2f} ghost={f.is_ghost} parentVol={f.parent_volume}")
for o in obs[:3]:
    print(f"  OB {o.low:.2f}-{o.high:.2f} valid={o.is_valid} mitigated={o.is_mitigated}")

from engine.core.orderblock_detector import ExecutionEngine
exec_eng = ExecutionEngine()
exec_res = exec_eng.analyze(df, protected_low_price=82.0, termination_high_price=df['high'].max(), origin_idx=2, term_idx=df['high'].idxmax())
print(f"\nExecutionEngine: signals={exec_res['total_signals']} valid={len(exec_res['valid_trades'])} failed={exec_res['failed_ob_traps']} ghost={exec_res['ghost_fvg_traps']}")
for t in exec_res['valid_trades'][:2]:
    print(f"  Trade Entry {t['entry']:.2f} SL {t['sl']:.2f} TP {t['tp']:.2f} RR {t['rr']}")

print("\n" + "="*90)
print("END ENGINE TEST 60")
print("="*90)
