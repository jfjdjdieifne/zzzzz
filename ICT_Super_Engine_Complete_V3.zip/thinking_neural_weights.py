"""
Thinking Neural Engine - وزن وكتلة وجهد
بدون أرقام ثابتة جامدة - تفكير تحليلي استنتاجي

1. الوزن (Weights & Biases): كل إشارة لها وزن ديناميكي يتعلم بالخطأ والصواب (Reinforcement Learning)
2. الكتلة العضلية (Momentum & Volume): Effort vs Result - Wyckoff - إذا حجم ضخم وحركة صغيرة => امتصاص
3. الجهد والطاقة (Activation): Sigmoid جمع الأوزان، إذا تجاوز عتبة تنقبض العضلة = دخول صفقة

No fixed thresholds like volume>100000 - only Contextual Z-Score normalization per your spec:
Z = (V_current - μ_V)/σ_V, Threshold True if Z>2.5 [Dynamic Volume Z-Score]
ADI = (Termination-Origin)/(N*ATR) >3.0 [Pure Displacement]
"""

import pandas as pd
import numpy as np
from collections import deque
import math

# --- 1. Contextual Normalization (No Fixed Numbers) ---
class ContextualNormalizer:
    """
    Welford's Online Algorithm - numerically stable recurrence for mean/variance
    Prevents floating point drift over long run + periodic full recalc every 1000 candles
    Per your Termux Pipeline spec: Running/Online Algorithms + binary merge tree O(log N)
    """
    def __init__(self, window=50):
        self.window = window
        self.count = 0
        self.mean = 0.0
        self.M2 = 0.0  # sum of squares of differences
        self.history = deque(maxlen=window)

    def update(self, value):
        self.history.append(value)
        self.count += 1
        delta = value - self.mean
        self.mean += delta / self.count
        delta2 = value - self.mean
        self.M2 += delta * delta2

        # Periodic full recalc every 1000 to prevent drift
        if self.count % 1000 == 0:
            arr = np.array(self.history)
            self.mean = arr.mean()
            self.M2 = ((arr - self.mean)**2).sum()
            self.count = len(arr)

    def get_stats(self):
        if self.count < 2:
            return self.mean, 1.0
        variance = self.M2 / (self.count - 1) if self.count>1 else 1.0
        std = math.sqrt(variance) if variance>0 else 1.0
        return self.mean, std

    def z_score(self, current):
        mean, std = self.get_stats()
        if std == 0:
            return 0.0
        return (current - mean) / std

    def is_outlier(self, current, threshold=2.5):
        # No fixed volume number, only Z>2.5 per your Dynamic Volume Z-Score spec
        return self.z_score(current) > threshold

# --- 2. Muscle Mass Sensor - Effort vs Result (Wyckoff) ---
class MuscleMassSensor:
    """
    الكتلة العضلية = السيولة الحقيقية وحجم التداول
    Effort = Volume, Result = Price Range * Body
    Source: VSA - effort vs result: high volume should produce big move, mismatch = absorption [eliteforextrading, algostorm, wyckoffanalytics]
    """
    def __init__(self):
        self.volume_norm = ContextualNormalizer(window=50)
        self.range_norm = ContextualNormalizer(window=50)

    def analyze(self, candle):
        volume = candle['volume']
        high = candle['high']
        low = candle['low']
        open_ = candle['open']
        close = candle['close']
        body = abs(close - open_)
        hl_range = high - low

        # Update normalizers
        self.volume_norm.update(volume)
        self.range_norm.update(hl_range)

        # Effort vs Result
        # Effort = volume normalized Z
        # Result = body / range (close position) * range Z
        effort_z = self.volume_norm.z_score(volume)
        result_z = self.range_norm.z_score(hl_range)

        # Effort vs Result Ratio
        # High effort (Z>2.5) + small result (range small, body tiny) = absorption = trap
        # Low effort + large result = lack of opposition = continuation
        if hl_range>0:
            body_to_range = body / hl_range
            close_pos = (close - low) / hl_range
        else:
            body_to_range=0
            close_pos=0.5

        # Absorption detection
        is_absorption = (effort_z > 2.5 and hl_range < self.range_norm.mean) or (effort_z > 2.0 and body_to_range < 0.15)
        is_no_demand = (close > open_ and volume < self.volume_norm.mean * 0.7)  # up bar low vol bearish
        is_no_supply = (close < open_ and volume < self.volume_norm.mean * 0.7)  # down bar low vol bullish

        # Muscle strength: volume * close_pos
        muscle_strength = volume * close_pos

        return {
            'effort_z': effort_z,
            'result_z': result_z,
            'body_to_range': body_to_range,
            'close_pos': close_pos,
            'is_absorption': is_absorption,
            'is_no_demand': is_no_demand,
            'is_no_supply': is_no_supply,
            'muscle_strength': muscle_strength,
            'lower_wick': min(open_, close) - low,
            'upper_wick': high - max(open_, close),
        }

# --- 3. Neural Weight Layer - Weights & Biases + Activation ---
class DynamicNeuron:
    """
    خلية عصبية تزن الإشارات كما يزن الرياضي جهده
    Inputs: liquidity_weight, fvg_weight, bos_weight, volume_weight, delta_weight, context_weight
    Output: sigmoid(sum(W_i * x_i) + bias) = probability to trade
    No fixed if/else thresholds, only activation function
    """
    def __init__(self, input_dim=6, learning_rate=0.01):
        # Initialize weights small random - no human guessing
        self.weights = np.random.randn(input_dim) * 0.1
        self.bias = 0.0
        self.lr = learning_rate
        self.weight_history = []

    def sigmoid(self, x):
        return 1 / (1 + np.exp(-np.clip(x, -500, 500)))

    def forward(self, x):
        # x = vector of signals [liquidity, fvg, bos, volume, delta, context]
        linear = np.dot(self.weights, x) + self.bias
        prob = self.sigmoid(linear)
        return prob, linear

    def update(self, x, reward, prob):
        """
        Reinforcement Learning: Gradient Ascent on reward
        If reward positive (win), increase weights of active signals
        If reward negative (loss), decrease weights
        Gradient Descent per your spec: reduce weight of losing signal
        Simplified policy gradient: ΔW = α * reward * (x - baseline) * prob*(1-prob)
        """
        # Baseline = average reward moving
        # For simplicity, use reward directly
        # Derivative of sigmoid: prob*(1-prob)
        grad_factor = prob * (1 - prob) * reward
        dw = self.lr * grad_factor * x
        db = self.lr * grad_factor
        self.weights += dw
        self.bias += db
        self.weight_history.append(self.weights.copy())
        return dw

    def get_weights_dict(self, labels):
        return {label: float(w) for label, w in zip(labels, self.weights)}

# --- 4. Reinforcement Learner - Learning by Trial and Error ---
class ReinforcementWeightLearner:
    """
    يتعامل مع السوق كأنه لعبة فيديو
    آلية المكافأة والعقاب: إذا FVG خسر، قلل وزنه. إذا جلسة NY نجحت، ارفع وزن الجلسة
    Per your spec: آلاف الاختبارات الخلفية السريعة + Gradient Descent
    """
    def __init__(self, labels):
        self.labels = labels
        self.neuron = DynamicNeuron(input_dim=len(labels), learning_rate=0.05)
        self.replay_buffer = deque(maxlen=1000)
        self.avg_reward = 0.0
        self.count = 0

    def signal_to_vector(self, signals):
        """
        Convert dict of signals to vector
        signals: {'liquidity': 0.8 (daily=0.8, 5m=0.2), 'fvg': strength, 'bos': close_pos, 'volume': z_score_norm, 'delta': cvd_slope, 'context': funding_z}
        Each already contextual normalized 0-1, not fixed
        """
        vec = []
        for label in self.labels:
            val = signals.get(label, 0)
            # Normalize to 0-1 via sigmoid of Z or direct
            # Ensure no fixed thresholds, use tanh normalization
            norm = np.tanh(val) if isinstance(val, (int,float)) else 0
            # Map tanh -1..1 to 0..1
            norm01 = (norm + 1)/2 if val!=0 else 0
            vec.append(norm01)
        return np.array(vec)

    def decide(self, signals):
        x = self.signal_to_vector(signals)
        prob, linear = self.neuron.forward(x)
        return prob, linear, x

    def feedback(self, signals, reward):
        """
        reward: profit $ (positive win, negative loss)
        Update weights
        """
        x = self.signal_to_vector(signals)
        prob, _ = self.neuron.forward(x)
        # Normalize reward to -1..1 for stable learning
        reward_norm = np.tanh(reward)  # if profit $10 => ~1, loss -5 => -1
        dw = self.neuron.update(x, reward_norm, prob)

        # Update avg reward
        self.count += 1
        self.avg_reward += (reward - self.avg_reward)/self.count

        # Store in replay buffer
        self.replay_buffer.append((x, reward_norm, prob))

        return dw, reward_norm

    def train_from_history(self, trades_history):
        """
        Supervised pre-training: feed 50,000 historical OB cases
        Per your spec: نعطي الكود 50,000 حالة تاريخية لـ Order Block ونخبره أي نجح وأي فشل
        """
        for trade in trades_history:
            signals = trade['signals']
            result = 1 if trade['result']=='WIN' else -1
            self.feedback(signals, result*2)  # amplify

# --- 5. Genetic Optimizer (Optional per your spec) ---
class GeneticWeightOptimizer:
    """
    يحاكي نظرية التطور: يولد 100 كروموسوم تشكيلة أوزان مختلفة
    البقاء للأقوى: اللي يخسر يموت، اللي يربح يندمج لجيل جديد
    """
    def __init__(self, pop_size=20, input_dim=6):
        self.pop_size = pop_size
        self.population = [np.random.randn(input_dim)*0.5 for _ in range(pop_size)]
        self.fitness = [0]*pop_size

    def evaluate(self, trades_fn):
        # trades_fn(chromosome) returns total PnL
        for i, chrom in enumerate(self.population):
            pnl = trades_fn(chrom)
            self.fitness[i] = pnl

    def evolve(self):
        # Select top 50%
        sorted_idx = np.argsort(self.fitness)[::-1]
        top = [self.population[i] for i in sorted_idx[:self.pop_size//2]]
        # Crossover + mutation
        new_pop = top.copy()
        while len(new_pop) < self.pop_size:
            p1, p2 = np.random.choice(len(top), 2, replace=False)
            parent1 = top[p1]
            parent2 = top[p2]
            # Crossover
            crossover_point = np.random.randint(1, len(parent1)-1)
            child = np.concatenate([parent1[:crossover_point], parent2[crossover_point:]])
            # Mutation
            if np.random.rand() < 0.3:
                mutation = np.random.randn(len(child))*0.1
                child += mutation
            new_pop.append(child)
        self.population = new_pop
        return max(self.fitness)

# --- Demo: Train on last month data ---
if __name__ == "__main__":
    df = pd.read_csv('/home/user/btcusdt_15m_last_month.csv')
    df['timestamp']=pd.to_datetime(df['timestamp'])
    print(f"Training neural weights on {len(df)} candles...")

    labels = ['liquidity', 'fvg', 'bos', 'volume', 'delta', 'context']
    learner = ReinforcementWeightLearner(labels)
    muscle = MuscleMassSensor()

    # Simulate signals walk-forward and mock rewards
    # For demo, create synthetic trades_history from previous backtest
    import pandas as pd
    try:
        trades_hist = pd.read_csv('/home/user/super_backtest_100usd_trades_detailed.csv')
        print(f"Loaded {len(trades_hist)} historical trades for supervised pre-training")
        history = []
        for _, row in trades_hist.iterrows():
            sig = {
                'liquidity': row['protected_low_rej'] if 'protected_low_rej' in row else 1.0,
                'fvg': 1.0 if row['fvg_low']>0 else 0.5,
                'bos': row['bos_cp'] if 'bos_cp' in row else 0.8,
                'volume': row['z_vol'] if 'z_vol' in row else 1.0,
                'delta': row['close_pos'] if 'close_pos' in row else 0.6,
                'context': row['M'] if 'M' in row else 1.0,
            }
            history.append({'signals': sig, 'result': row['result']})
        learner.train_from_history(history)
        print("After supervised pre-training weights:")
        print(learner.neuron.get_weights_dict(labels))
    except Exception as e:
        print(f"No history file, starting random: {e}")

    # Walk-forward reinforcement
    for i in range(100, min(500, len(df))):
        candle = df.iloc[i]
        muscle_out = muscle.analyze(candle)
        # Mock signals contextual
        signals = {
            'liquidity': 0.8 if i%100==0 else 0.2,  # daily vs 5m per your spec: daily 0.8, 5m 0.2
            'fvg': 0.9 if muscle_out['effort_z']>2 else 0.3,
            'bos': muscle_out['close_pos'],
            'volume': muscle_out['effort_z']/5,  # normalize Z to 0-1
            'delta': muscle_out['muscle_strength']/1000,
            'context': 0.5,  # neutral
        }
        prob, linear, x = learner.decide(signals)
        # Mock reward: if prob>0.7 and next candle up, win
        next_close = df.iloc[i+1]['close'] if i+1 < len(df) else candle['close']
        reward = 1 if (prob>0.7 and next_close>candle['close']) or (prob<0.3 and next_close<candle['close']) else -1
        # Only feedback if high confidence
        if prob>0.7 or prob<0.3:
            learner.feedback(signals, reward)

    print("\nFinal learned weights after RL:")
    print(learner.neuron.get_weights_dict(labels))
    print(f"Bias: {learner.neuron.bias:.4f}")
    print(f"Avg reward: {learner.avg_reward:.4f}")

    print("\nInterpretation per your muscle analogy:")
    print("- Weight high = muscle group strong, gives more power to trade")
    print("- If FVG weight decreased after losses, means market currently doesn't respect FVG")
    print("- No fixed numbers: Z-Score normalization makes it work on BTC (60k) and meme coin (0.0001) same logic")
    print("- Activation Sigmoid: sum(W*x)+b >0 => prob>0.5 => muscle contraction = trade")

    # Save weights
    import json
    with open('/home/user/learned_neural_weights.json','w') as f:
        json.dump({
            'weights': learner.neuron.get_weights_dict(labels),
            'bias': float(learner.neuron.bias),
            'avg_reward': float(learner.avg_reward)
        }, f, indent=2)
    print("Saved to learned_neural_weights.json")
