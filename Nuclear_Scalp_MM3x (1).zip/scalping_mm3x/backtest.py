#!/usr/bin/env python3
"""
محرك الباكتست + توليد التقارير
"""
import sys
import os
import csv
from datetime import datetime, timezone
from collections import defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import *
from strategy import run_strategy
from data_loader import load_all


def analyze(trades, account=ACCOUNT_SIZE, risk_pct=RISK_PER_TRADE):
    if not trades:
        return None
    balance = account; peak = account; max_dd = 0
    wins = losses = 0; total_r = 0
    for t in trades:
        risk_amount = balance * risk_pct
        profit = t['r_multiple'] * risk_amount
        balance += profit; total_r += t['r_multiple']
        if t['r_multiple'] > 0: wins += 1
        else: losses += 1
        if balance > peak: peak = balance
        dd = (peak - balance) / peak * 100
        if dd > max_dd: max_dd = dd
    wr = wins / len(trades) * 100
    monthly = (balance / account - 1) * 100
    avg_r = total_r / len(trades)
    win_rs = [t['r_multiple'] for t in trades if t['r_multiple'] > 0]
    loss_rs = [t['r_multiple'] for t in trades if t['r_multiple'] <= 0]
    pf_num = sum(win_rs) if win_rs else 0
    pf_den = abs(sum(loss_rs)) if loss_rs else 1
    pf = pf_num / pf_den if pf_den > 0 else 999
    return {
        'n': len(trades), 'wins': wins, 'losses': losses, 'wr': wr,
        'total_r': total_r, 'avg_r': avg_r, 'balance': balance, 'monthly': monthly,
        'max_dd': max_dd, 'pf': pf,
        'best_r': max(win_rs) if win_rs else 0,
        'worst_r': min(loss_rs) if loss_rs else 0,
        'avg_win': sum(win_rs) / len(win_rs) if win_rs else 0,
        'avg_loss': sum(loss_rs) / len(loss_rs) if loss_rs else 0,
        'targets_hit': sum(1 for t in trades if t['exit_type'] == 'TARGET'),
        'target_pct': sum(1 for t in trades if t['exit_type'] == 'TARGET') / len(trades) * 100,
    }


def generate_reports(trades, stats, report_dir=REPORT_DIR):
    out = []
    out.append("=" * 120)
    out.append(f"NUCLEAR SCALP — MM_{MM_MULTIPLIER}x + SL")
    out.append("OKX BTCUSDT | 5M شمعات | كل الأوقات UTC")
    out.append(f"حساب ${ACCOUNT_SIZE} | خطر {RISK_PER_TRADE*100:.0f}% مركب")
    out.append(f"التارغت: الدخول + (مدى الإزاحة من السويب × {MM_MULTIPLIER})")
    out.append(f"الدخول: {ENTRY_MODE} | الستوب: {SL_MODE} -{SL_BUFFER_PCT}%")
    out.append(f"تخطي أيام: {SKIP_DAYS if SKIP_DAYS else 'لا شيء'}")
    out.append(f"المرجع: ICT Fib SD -2.0 to -2.5 ≈ displacement × {MM_MULTIPLIER}")
    out.append("=" * 120)
    out.append("")
    out.append(f"  عدد الصفقات:         {stats['n']}")
    out.append(f"  رابحه / خاسره:       {stats['wins']} / {stats['losses']}")
    out.append(f"  Win Rate:            {stats['wr']:.0f}%")
    out.append(f"  ─────────────────────────────────")
    out.append(f"  إجمالي R:            {stats['total_r']:+.1f}R")
    out.append(f"  متوسط R:             {stats['avg_r']:+.1f}R")
    out.append(f"  متوسط R رابح:        {stats['avg_win']:+.1f}R")
    out.append(f"  متوسط R خاسر:        {stats['avg_loss']:+.1f}R")
    out.append(f"  أكبر R رابح:         {stats['best_r']:+.1f}R")
    out.append(f"  ─────────────────────────────────")
    out.append(f"  Profit Factor:       {stats['pf']:.2f}")
    out.append(f"  Max Drawdown:        {stats['max_dd']:.1f}%")
    out.append(f"  تارغتات وصلت:        {stats['targets_hit']} / {stats['n']} ({stats['target_pct']:.0f}%)")
    out.append(f"  ─────────────────────────────────")
    out.append(f"  حساب ${ACCOUNT_SIZE} مركب: ${stats['balance']:.2f}")
    out.append(f"  الربح:               {stats['monthly']:+.1f}%")

    out.append("")
    out.append(f"  {'#':>2}  {'تاريخ الدخول':>16}  {'يوم':>3}  {'دخول$':>10}  {'ستوب$':>10}  {'تارغت$':>10}  {'تارغتR':>7}  {'خروجR':>8}  {'أقصىR':>7}  {'نوع':<10}  {'زمن':>6}")
    out.append("  " + "─" * 115)
    balance = ACCOUNT_SIZE
    for i, t in enumerate(trades):
        risk_amount = balance * RISK_PER_TRADE
        balance += t['r_multiple'] * risk_amount
        type_mark = {'TARGET': '🎯', 'SL': '❌', '48H_CLOSE': '⏰'}.get(t['exit_type'], '?')
        hold_h = t['hold_minutes'] // 60
        hold_m = t['hold_minutes'] % 60
        out.append(
            f"  {i+1:>2}  {t['entry_dt'].strftime('%Y-%m-%d %H:%M'):>16}  {t['day_short']:>3}  "
            f"${t['entry_price']:>9.1f}  ${t['sl_price']:>9.2f}  ${t['target_price']:>9.1f}  "
            f"{t['target_r']:>+6.1f}R  {t['r_multiple']:>+7.1f}R  {t['peak_r']:>+6.1f}R  "
            f"{type_mark:<10}  {hold_h:>2}h{hold_m:02d}")

    out.append("")
    for i, t in enumerate(trades):
        out.append("")
        out.append("━" * 100)
        result_mark = "✅" if t['r_multiple'] > 0 else "❌"
        out.append(
            f"  #{i+1:>2} | {t['entry_dt'].strftime('%Y-%m-%d %H:%M')} UTC | {t['day_of_week']} | "
            f"{result_mark} {t['r_multiple']:+.1f}R | {t['exit_type']}")
        out.append("━" * 100)
        out.append(f"  الدخول:     ${t['entry_price']:.2f}  ({t['entry_dt'].strftime('%Y-%m-%d %H:%M')} UTC)")
        out.append(f"  الستوب:     ${t['sl_price']:.2f}  (ذيل - {SL_BUFFER_PCT}%)")
        out.append(f"  المخاطره:   ${t['risk']:.2f} = {t['risk_pct']:.2f}%")
        out.append(f"  ────────────────────────────────")
        out.append(f"  السويب:     ${t['sweep_price']:.2f}")
        out.append(f"  الإزاحه:    ${t['disp_high']:.2f}")
        out.append(f"  المدى:      ${t['move_from_sweep']:.2f}")
        out.append(f"  ────────────────────────────────")
        out.append(f"  MM_1x:      ${t['mm_1x_price']:.2f}  ({t['mm_1x_r']:+.1f}R)")
        out.append(f"  MM_2x:      ${t['mm_2x_price']:.2f}  ({t['mm_2x_r']:+.1f}R)")
        out.append(f"  MM_3x:      ${t['mm_3x_price']:.2f}  ({t['mm_3x_r']:+.1f}R)")
        out.append(f"  MM_3.5x:    ${t['mm_3_5x_price']:.2f}  ({t['mm_3_5x_r']:+.1f}R) ← التارغت")
        out.append(f"  ────────────────────────────────")
        out.append(f"  الخروج:     ${t['exit_price']:.2f}  ({t['exit_dt'].strftime('%Y-%m-%d %H:%M')} UTC)")
        out.append(f"  نوع الخروج: {t['exit_type']}")
        out.append(f"  R:          {t['r_multiple']:+.1f}R")
        out.append(f"  أقصى R:     {t['peak_r']:+.1f}R")
        out.append(f"  زمن الانتظار: {t['hold_minutes'] // 60}h{t['hold_minutes'] % 60:02d}m")

    # تحليل حسب اليوم
    out.append("")
    dow_stats = defaultdict(lambda: {'w': 0, 'l': 0, 'r': 0, 'n': 0})
    for t in trades:
        dow_stats[t['day_short']]['n'] += 1
        if t['r_multiple'] > 0: dow_stats[t['day_short']]['w'] += 1
        else: dow_stats[t['day_short']]['l'] += 1
        dow_stats[t['day_short']]['r'] += t['r_multiple']
    out.append(f"  {'اليوم':<10}  {'عدد':>4}  {'W':>3}  {'L':>3}  {'WR%':>5}  {'R':>8}  {'متوسطR':>7}")
    out.append("  " + "─" * 50)
    for day in ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']:
        if day in dow_stats:
            d = dow_stats[day]
            out.append(f"  {day:<10}  {d['n']:>4}  {d['w']:>3}  {d['l']:>3}  {d['w']/d['n']*100:>4.0f}%  {d['r']:>+7.1f}R  {d['r']/d['n']:>+6.1f}R")

    # نمو الحساب
    out.append("")
    out.append(f"  {'#':>2}  {'تاريخ':>16}  {'خروجR':>8}  {'خطر$':>7}  {'ربح$':>8}  {'رصيد$':>8}  {'ربح%':>7}")
    out.append("  " + "─" * 70)
    balance = ACCOUNT_SIZE
    for i, t in enumerate(trades):
        risk_amount = balance * RISK_PER_TRADE
        profit = t['r_multiple'] * risk_amount
        balance += profit
        out.append(
            f"  {i+1:>2}  {t['entry_dt'].strftime('%Y-%m-%d %H:%M'):>16}  "
            f"{t['r_multiple']:>+7.1f}R  ${risk_amount:>6.2f}  ${profit:>+7.2f}  "
            f"${balance:>7.2f}  {(balance/ACCOUNT_SIZE-1)*100:>+6.1f}%")

    report_text = '\n'.join(out)
    report_path = os.path.join(report_dir, 'REPORT.txt')
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write(report_text)

    csv_path = os.path.join(report_dir, 'TRADES.csv')
    with open(csv_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow([
            'num', 'entry_dt', 'day', 'entry_price', 'sl_price', 'risk', 'risk_pct',
            'sweep_price', 'disp_high', 'move_from_sweep',
            'mm_1x_r', 'mm_2x_r', 'mm_3x_r', 'mm_3.5x_r',
            'exit_type', 'exit_r', 'exit_price', 'exit_dt',
            'peak_r', 'hold_minutes',
        ])
        for i, t in enumerate(trades):
            writer.writerow([
                i + 1, t['entry_dt'].strftime('%Y-%m-%d %H:%M'), t['day_short'],
                f"{t['entry_price']:.2f}", f"{t['sl_price']:.2f}",
                f"{t['risk']:.2f}", f"{t['risk_pct']:.3f}",
                f"{t['sweep_price']:.2f}", f"{t['disp_high']:.2f}",
                f"{t['move_from_sweep']:.2f}",
                f"{t['mm_1x_r']:.1f}", f"{t['mm_2x_r']:.1f}",
                f"{t['mm_3x_r']:.1f}", f"{t['mm_3_5x_r']:.1f}",
                t['exit_type'], f"{t['r_multiple']:.1f}",
                f"{t['exit_price']:.2f}", t['exit_dt'].strftime('%Y-%m-%d %H:%M'),
                f"{t['peak_r']:.1f}", t['hold_minutes'],
            ])

    return report_path, csv_path
