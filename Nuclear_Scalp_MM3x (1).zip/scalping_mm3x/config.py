#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════
  NUCLEAR SCALP — MM_3.5x + SL  (الإصدار النهائي)
  استراتيجية سكالبينغ BTC سبوت (LONG only) 15M
  OKX BTCUSDT | $100 حساب | 1% خطر

  النمط: Liquidity Sweep → Displacement (FVG) → IOFED Entry → MM_3.5x Target

  IOFED = Immediate OFV Entry on Displacement = FVG top edge entry
  MM_3.5x = مدى الإزاحة من السويب × 3.5
  المرجع: ICT Fib SD -2.0 to -2.5 ≈ displacement × 3.5
═══════════════════════════════════════════════════════════
"""

# ─── مسارات البيانات ───
DATA_15M = '/home/user/project/data/BTCUSDT_15m_OKX.csv'
DATA_5M  = '/home/user/project/data/BTCUSDT_5m_OKX_merged.csv'

# ─── إعدادات الحساب ───
ACCOUNT_SIZE     = 100       # دولار
RISK_PER_TRADE   = 0.01     # 1% من الحساب

# ─── إعدادات الاستراتيجية ───
SWING_LEFT       = 5
SWING_RIGHT      = 3
SWEEP_MAX_DIST   = 60
DISP_SEARCH_WINDOW   = 8
MIN_DISP_BODY_PCT    = 0.4
FVG_MIN_SIZE_PCT     = 0.05
MSS_LOOKBACK         = 40
ENTRY_MODE           = 'iofed'
REQUIRE_CONFIRMATION = True
SL_MODE              = 'tail'
SL_BUFFER_PCT        = 0.1
TARGET_MODE          = 'mm_3.5x'
MM_MULTIPLIER        = 3.5
MAX_HOLD_HOURS       = 48
SKIP_DAYS            = []
MIN_R_TARGET         = 3
REQUIRE_OTE_OVERLAP  = False
MIN_DISPLACEMENT_PCT = 0.15
MIN_FVG_SIZE_PCT     = 0.05
REPORT_DIR = '/home/user/project/SCALP_SWEEP_BRANCH/scalping_mm3x/'
