#!/usr/bin/env python3
"""
ICT Golden Entry v3 - MTF APPROACH
15M for SETUP + 5M for PRECISE ENTRY
"""

import csv
from datetime import datetime, timezone
from collections import defaultdict

def load_data(filepath_15m, filepath_5m):
    candles_15m = []
    with open(filepath_15m, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            candles_15m.append({
                'ts': int(row['timestamp']),
                'open': float(row['open']),
                'high': float(row['high']),
                'low': float(row['low']),
                'close': float(row['close']),
                'volume': float(row['volume'])
            })
    candles_15m.sort(key=lambda x: x['ts'])
    for i, c in enumerate(candles_15m):
        c['dt'] = datetime.fromtimestamp(c['ts'], tz=timezone.utc)
        c['idx'] = i
    
    candles_5m = []
    with open(filepath_5m, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            # Parse datetime string
            dt_str = row['datetime'].strip()
            dt = datetime.strptime(dt_str, '%Y-%m-%d %H:%M').replace(tzinfo=timezone.utc)
            ts = int(dt.timestamp())
            candles_5m.append({
                'ts': ts,
                'open': float(row['open']),
                'high': float(row['high']),
                'low': float(row['low']),
                'close': float(row['close']),
                'volume': float(row['volume'])
            })
    candles_5m.sort(key=lambda x: x['ts'])
    for i, c in enumerate(candles_5m):
        c['dt'] = datetime.fromtimestamp(c['ts'], tz=timezone.utc)
        c['idx'] = i
    
    return candles_15m, candles_5m

def find_swing_points(candles, left=5, right=3):
    swing_highs = {}
    swing_lows = {}
    for i in range(left, len(candles) - right):
        is_high = all(candles[i]['high'] >= candles[i-j]['high'] for j in range(1, left+1)) and \
                  all(candles[i]['high'] >= candles[i+j]['high'] for j in range(1, right+1))
        if is_high:
            swing_highs[i] = candles[i]['high']
        is_low = all(candles[i]['low'] <= candles[i-j]['low'] for j in range(1, left+1)) and \
                 all(candles[i]['low'] <= candles[i+j]['low'] for j in range(1, right+1))
        if is_low:
            swing_lows[i] = candles[i]['low']
    return swing_highs, swing_lows

def detect_setups_15m(candles, swing_highs, swing_lows, params):
    fvg_min_pct = params.get('fvg_min_size_pct', 0.05)
    min_body_pct = params.get('min_displacement_body_pct', 0.4)
    setups = []
    for i in range(20, len(candles) - 50):
        c = candles[i]
        best_sweep = None
        for sw_idx, sw_price in swing_lows.items():
            if sw_idx >= i: continue
            if i - sw_idx > 60: continue
            if c['low'] < sw_price:
                if best_sweep is None or sw_idx > best_sweep[0]:
                    best_sweep = (sw_idx, sw_price)
        if best_sweep is None: continue
        sweep_idx, sweep_price = best_sweep
        
        for disp_offset in range(1, 8):
            disp_idx = i + disp_offset
            if disp_idx >= len(candles) - 2: break
            dc = candles[disp_idx]
            body = dc['close'] - dc['open']
            rng = dc['high'] - dc['low']
            if rng == 0 or body <= 0: continue
            if body / rng < min_body_pct: continue
            prev_high = candles[disp_idx - 1]['high']
            next_low = candles[disp_idx + 1]['low']
            if next_low <= prev_high: continue
            fvg = {'bottom': prev_high, 'top': next_low,
                   'mid': (prev_high + next_low) / 2,
                   'size': next_low - prev_high,
                   'size_pct': (next_low - prev_high) / dc['close'] * 100}
            if fvg['size_pct'] < fvg_min_pct: continue
            disp_high = dc['high']
            mss_ok = False
            for sh_idx, sh_price in swing_highs.items():
                if sweep_idx - 40 < sh_idx < sweep_idx and disp_high > sh_price:
                    mss_ok = True; break
            if not mss_ok:
                prev_max = max(candles[j]['high'] for j in range(max(0,disp_idx-5), disp_idx))
                if disp_high > prev_max: mss_ok = True
            if not mss_ok: continue
            total_range = disp_high - sweep_price
            if total_range <= 0: continue
            ote = {'fib_62': disp_high - 0.62 * total_range,
                   'fib_705': disp_high - 0.705 * total_range,
                   'fib_79': disp_high - 0.79 * total_range, 'range': total_range}
            ob = None
            for k in range(disp_idx - 1, max(disp_idx - 5, 0), -1):
                if candles[k]['close'] < candles[k]['open']:
                    ob = {'top': candles[k]['open'], 'bottom': candles[k]['close'], 'idx': k}; break
            ol_bottom = max(ote['fib_79'], fvg['bottom'])
            ol_top = min(ote['fib_62'], fvg['top'])
            ote_fvg_overlap = ol_top > ol_bottom
            setups.append({'sweep_idx': sweep_idx, 'sweep_price': sweep_price,
                'disp_idx': disp_idx, 'disp_high': disp_high, 'fvg': fvg,
                'ote': ote, 'ob': ob, 'ote_fvg_overlap': ote_fvg_overlap,
                'overlap_bottom': ol_bottom if ote_fvg_overlap else 0,
                'overlap_top': ol_top if ote_fvg_overlap else 0, 'setup_idx': i})
            break
    return setups

def execute_trade_mtf(setup, candles_15m, candles_5m, params):
    entry_mode = params.get('entry_mode', 'ote')
    sl_mode = params.get('sl_mode', 'sweep')
    sl_buffer = params.get('sl_buffer_pct', 0.05)
    tp_mode = params.get('tp_mode', 'vhigh_half')
    max_hold_5m = params.get('max_hold_5m', 96)
    require_confirmation = params.get('require_confirmation', False)
    
    fvg = setup['fvg']; ote = setup['ote']; disp_idx = setup['disp_idx']
    
    if entry_mode == 'ote' and setup['ote_fvg_overlap']:
        if setup['overlap_bottom'] <= ote['fib_705'] <= setup['overlap_top']:
            entry_zone_price = ote['fib_705']
        else:
            entry_zone_price = setup['overlap_bottom']
    elif entry_mode == 'iofed':
        entry_zone_price = fvg['top']
    elif entry_mode == 'ce':
        entry_zone_price = fvg['mid']
    elif entry_mode == 'fvg_bottom':
        entry_zone_price = fvg['bottom']
    elif entry_mode == 'ote_simple':
        entry_zone_price = ote['fib_705']
    else:
        entry_zone_price = fvg['mid']
    
    if sl_mode == 'sweep':
        sl_price = setup['sweep_price']
    elif sl_mode == 'sweep_buffer':
        sl_price = setup['sweep_price'] * (1 - sl_buffer / 100)
    elif sl_mode == 'fib79':
        sl_price = ote['fib_79'] * (1 - 0.02 / 100)
    else:
        sl_price = setup['sweep_price']
    
    entry_approx = entry_zone_price
    risk_approx = entry_approx - sl_price
    if risk_approx <= 0: return None
    
    if tp_mode == 'vhigh_half':
        tp1 = entry_approx + risk_approx * 2
        tp2 = setup['disp_high']
        if tp2 <= tp1: tp2 = entry_approx + risk_approx * 5
    elif tp_mode == 'fixed_3r':
        tp1 = entry_approx + risk_approx * 1.5; tp2 = entry_approx + risk_approx * 3
    elif tp_mode == 'fixed_5r':
        tp1 = entry_approx + risk_approx * 2; tp2 = entry_approx + risk_approx * 5
    elif tp_mode == 'vhigh_full':
        tp1 = setup['disp_high']; tp2 = setup['disp_high']
    elif tp_mode == 'smart':
        tp1 = fvg['top']; tp2 = setup['disp_high']
        if tp1 <= entry_approx + risk_approx: tp1 = entry_approx + risk_approx * 1.5
        if tp2 <= tp1: tp2 = entry_approx + risk_approx * 4
    else:
        tp1 = entry_approx + risk_approx * 2; tp2 = setup['disp_high']
    
    disp_15m = candles_15m[disp_idx]
    search_start_ts = disp_15m['ts'] + 900
    search_end_ts = disp_15m['ts'] + 900 * 40
    five_min_candles = [c for c in candles_5m if search_start_ts <= c['ts'] <= search_end_ts]
    if not five_min_candles: return None
    
    entry_5m = None; entry_price = None
    for fc in five_min_candles:
        if fc['low'] <= entry_zone_price:
            if require_confirmation:
                fc_idx = fc['idx']
                if fc_idx + 1 < len(candles_5m):
                    next_c = candles_5m[fc_idx + 1]
                    if next_c['close'] > next_c['open']:
                        entry_5m = next_c; entry_price = next_c['open']
                    else: continue
                else: continue
            else:
                entry_5m = fc; entry_price = entry_zone_price; break
    if entry_5m is None: return None
    
    risk = entry_price - sl_price
    if risk <= 0: return None
    
    tp1_actual = entry_price + risk * ((tp1 - entry_approx) / risk_approx) if risk_approx > 0 else tp1
    tp2_actual = entry_price + risk * ((tp2 - entry_approx) / risk_approx) if risk_approx > 0 else tp2
    if tp_mode in ('vhigh_half', 'vhigh_full', 'smart'):
        tp2_actual = max(tp2, entry_price + risk * 2)
    
    entry_ts = entry_5m['ts']
    sim_candles = [c for c in candles_5m if entry_ts < c['ts'] <= entry_ts + max_hold_5m * 300]
    if not sim_candles: return None
    
    for sc in sim_candles:
        if sc['high'] >= tp1_actual:
            tp1_r = (tp1_actual - entry_price) / risk
            if sc['low'] <= sl_price:
                if sc['close'] >= sc['open']:
                    r = -1.0; result = 'SL_before_TP1'
                else:
                    r = 0.5 * tp1_r - 0.5; result = 'TP1_then_SL'
                return {'r_multiple': r, 'result': result,
                    'entry_price': entry_price, 'exit_price': sl_price if r < 0 else tp1_actual,
                    'entry_dt': entry_5m['dt'], 'exit_dt': sc['dt'],
                    'hold_candles_5m': (sc['ts'] - entry_ts) // 300,
                    'sl_price': sl_price, 'tp1': tp1_actual, 'tp2': tp2_actual,
                    'risk': risk, 'entry_zone': entry_zone_price, 'setup': setup}
            be_price = entry_price
            for sc2 in sim_candles:
                if sc2['ts'] <= sc['ts']: continue
                if sc2['high'] >= tp2_actual:
                    tp2_r = (tp2_actual - entry_price) / risk
                    r = 0.5 * tp1_r + 0.5 * tp2_r
                    return {'r_multiple': r, 'result': 'TP1_TP2',
                        'entry_price': entry_price, 'exit_price': tp2_actual,
                        'entry_dt': entry_5m['dt'], 'exit_dt': sc2['dt'],
                        'hold_candles_5m': (sc2['ts'] - entry_ts) // 300,
                        'sl_price': sl_price, 'tp1': tp1_actual, 'tp2': tp2_actual,
                        'risk': risk, 'entry_zone': entry_zone_price, 'setup': setup}
                if sc2['low'] <= be_price:
                    r = 0.5 * tp1_r
                    return {'r_multiple': r, 'result': 'TP1_BE',
                        'entry_price': entry_price, 'exit_price': be_price,
                        'entry_dt': entry_5m['dt'], 'exit_dt': sc2['dt'],
                        'hold_candles_5m': (sc2['ts'] - entry_ts) // 300,
                        'sl_price': sl_price, 'tp1': tp1_actual, 'tp2': tp2_actual,
                        'risk': risk, 'entry_zone': entry_zone_price, 'setup': setup}
            last = sim_candles[-1]
            force_r = (last['close'] - entry_price) / risk
            r = 0.5 * tp1_r + 0.5 * force_r
            return {'r_multiple': r, 'result': 'TP1_EOD',
                'entry_price': entry_price, 'exit_price': last['close'],
                'entry_dt': entry_5m['dt'], 'exit_dt': last['dt'],
                'hold_candles_5m': (last['ts'] - entry_ts) // 300,
                'sl_price': sl_price, 'tp1': tp1_actual, 'tp2': tp2_actual,
                'risk': risk, 'entry_zone': entry_zone_price, 'setup': setup}
        if sc['low'] <= sl_price:
            return {'r_multiple': -1.0, 'result': 'SL',
                'entry_price': entry_price, 'exit_price': sl_price,
                'entry_dt': entry_5m['dt'], 'exit_dt': sc['dt'],
                'hold_candles_5m': (sc['ts'] - entry_ts) // 300,
                'sl_price': sl_price, 'tp1': tp1_actual, 'tp2': tp2_actual,
                'risk': risk, 'entry_zone': entry_zone_price, 'setup': setup}
    last = sim_candles[-1] if sim_candles else entry_5m
    force_r = (last['close'] - entry_price) / risk
    return {'r_multiple': force_r, 'result': 'MaxHold',
        'entry_price': entry_price, 'exit_price': last['close'],
        'entry_dt': entry_5m['dt'], 'exit_dt': last['dt'],
        'hold_candles_5m': (last['ts'] - entry_ts) // 300,
        'sl_price': sl_price, 'tp1': tp1_actual, 'tp2': tp2_actual,
        'risk': risk, 'entry_zone': entry_zone_price, 'setup': setup}

def run_mtf_strategy(candles_15m, candles_5m, params):
    swing_highs, swing_lows = find_swing_points(candles_15m, left=5, right=3)
    setups = detect_setups_15m(candles_15m, swing_highs, swing_lows, params)
    if not setups: return []
    trades = []; last_exit_ts = 0
    for setup in setups:
        if candles_15m[setup['setup_idx']]['ts'] <= last_exit_ts: continue
        if params.get('require_ote_overlap', True) and not setup['ote_fvg_overlap']: continue
        trade = execute_trade_mtf(setup, candles_15m, candles_5m, params)
        if trade is not None:
            trade['day_of_week'] = trade['entry_dt'].strftime('%A')
            trade['ob_confluence'] = setup['ob'] is not None and setup['ob']['bottom'] >= setup['ote']['fib_79'] and setup['ob']['top'] <= setup['ote']['fib_62']
            trade['fvg_size_pct'] = setup['fvg']['size_pct']
            trade['disp_high'] = setup['disp_high']
            trade['sweep_price'] = setup['sweep_price']
            trades.append(trade)
            last_exit_ts = trade['exit_dt'].timestamp()
    return trades

def analyze_trades(trades, risk_pct=2.0):
    if not trades: print("No trades!"); return {}
    balance = 100; peak = 100; max_dd = 0; wins = losses = 0; total_r = 0
    result_stats = defaultdict(int)
    dow_stats = defaultdict(lambda: {'w': 0, 'l': 0, 'r': 0})
    for t in trades:
        balance += balance * (risk_pct / 100) * t['r_multiple']
        total_r += t['r_multiple']
        if t['r_multiple'] > 0: wins += 1
        else: losses += 1
        if balance > peak: peak = balance
        dd = (peak - balance) / peak * 100
        if dd > max_dd: max_dd = dd
        result_stats[t['result']] += 1
        dow_stats[t['day_of_week']]['w' if t['r_multiple'] > 0 else 'l'] += 1
        dow_stats[t['day_of_week']]['r'] += t['r_multiple']
    wr = wins / len(trades) * 100
    monthly = (balance / 100 - 1) * 100
    avg_r = total_r / len(trades)
    pf_num = sum(t['r_multiple'] for t in trades if t['r_multiple'] > 0)
    pf_den = abs(sum(t['r_multiple'] for t in trades if t['r_multiple'] < 0))
    pf = pf_num / pf_den if pf_den > 0 else 999
    avg_risk = sum(t['risk'] for t in trades) / len(trades)
    print(f"\n{'='*70}")
    print(f"ICT GOLDEN ENTRY v3 (MTF 15M->5M) RESULTS")
    print(f"{'='*70}")
    print(f"  Trades:      {len(trades)}")
    print(f"  Wins/Losses: {wins}/{losses}")
    print(f"  Win Rate:    {wr:.1f}%")
    print(f"  Total R:     {total_r:+.2f}R")
    print(f"  Avg R:       {avg_r:+.2f}R")
    print(f"  Profit Factor: {pf:.2f}")
    print(f"  Max DD:      {max_dd:.1f}%")
    print(f"  Monthly:     {monthly:+.1f}%")
    print(f"  Avg Risk:    ${avg_risk:.1f}")
    print(f"  Balance:     ${balance:.1f}")
    print(f"\n  Result Types:")
    for r, c in sorted(result_stats.items(), key=lambda x: -x[1]):
        print(f"    {r:20s}: {c} ({c/len(trades)*100:.0f}%)")
    print(f"\n  Day of Week:")
    for dow in ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday']:
        if dow in dow_stats:
            d = dow_stats[dow]; total = d['w'] + d['l']; gwr = d['w'] / total * 100
            print(f"    {dow:10s}: {d['w']}W/{d['l']}L = {gwr:.0f}% | R {d['r']:+.2f}")
    return {'balance': balance, 'monthly': monthly, 'wr': wr, 'max_dd': max_dd, 'total_r': total_r}

def comprehensive_test(candles_15m, candles_5m):
    print("=" * 90)
    print("COMPREHENSIVE MTF PARAMETER TEST (15M Setup + 5M Entry)")
    print("=" * 90)
    configs = [
        ("OTE sweet spot", {'entry_mode': 'ote', 'sl_mode': 'sweep_buffer', 'tp_mode': 'vhigh_half', 'require_ote_overlap': True}),
        ("OTE no overlap", {'entry_mode': 'ote', 'sl_mode': 'sweep_buffer', 'tp_mode': 'vhigh_half', 'require_ote_overlap': False}),
        ("IOFED (FVG edge)", {'entry_mode': 'iofed', 'sl_mode': 'sweep_buffer', 'tp_mode': 'vhigh_half', 'require_ote_overlap': False}),
        ("CE (50% FVG)", {'entry_mode': 'ce', 'sl_mode': 'sweep_buffer', 'tp_mode': 'vhigh_half', 'require_ote_overlap': False}),
        ("FVG bottom", {'entry_mode': 'fvg_bottom', 'sl_mode': 'sweep_buffer', 'tp_mode': 'vhigh_half', 'require_ote_overlap': False}),
        ("OTE simple 70.5%", {'entry_mode': 'ote_simple', 'sl_mode': 'sweep_buffer', 'tp_mode': 'vhigh_half', 'require_ote_overlap': False}),
        ("OTE sweep SL", {'entry_mode': 'ote', 'sl_mode': 'sweep', 'tp_mode': 'vhigh_half', 'require_ote_overlap': True}),
        ("OTE tight buffer", {'entry_mode': 'ote', 'sl_mode': 'sweep_buffer', 'sl_buffer_pct': 0.02, 'tp_mode': 'vhigh_half', 'require_ote_overlap': True}),
        ("OTE fib79 SL", {'entry_mode': 'ote', 'sl_mode': 'fib79', 'tp_mode': 'vhigh_half', 'require_ote_overlap': True}),
        ("OTE fixed 3R", {'entry_mode': 'ote', 'sl_mode': 'sweep_buffer', 'tp_mode': 'fixed_3r', 'require_ote_overlap': True}),
        ("OTE fixed 5R", {'entry_mode': 'ote', 'sl_mode': 'sweep_buffer', 'tp_mode': 'fixed_5r', 'require_ote_overlap': True}),
        ("OTE V-High full", {'entry_mode': 'ote', 'sl_mode': 'sweep_buffer', 'tp_mode': 'vhigh_full', 'require_ote_overlap': True}),
        ("OTE smart TPs", {'entry_mode': 'ote', 'sl_mode': 'sweep_buffer', 'tp_mode': 'smart', 'require_ote_overlap': True}),
        ("OTE + confirm", {'entry_mode': 'ote', 'sl_mode': 'sweep_buffer', 'tp_mode': 'vhigh_half', 'require_ote_overlap': True, 'require_confirmation': True}),
        ("IOFED + confirm", {'entry_mode': 'iofed', 'sl_mode': 'sweep_buffer', 'tp_mode': 'vhigh_half', 'require_ote_overlap': False, 'require_confirmation': True}),
        ("IOFED smart TP", {'entry_mode': 'iofed', 'sl_mode': 'sweep_buffer', 'tp_mode': 'smart', 'require_ote_overlap': False}),
        ("CE V-High full", {'entry_mode': 'ce', 'sl_mode': 'sweep_buffer', 'tp_mode': 'vhigh_full', 'require_ote_overlap': False}),
        ("OTE simple smart", {'entry_mode': 'ote_simple', 'sl_mode': 'sweep_buffer', 'tp_mode': 'smart', 'require_ote_overlap': False}),
        ("FVG bt V-High", {'entry_mode': 'fvg_bottom', 'sl_mode': 'sweep_buffer', 'tp_mode': 'vhigh_half', 'require_ote_overlap': False}),
    ]
    print(f"\n{'Config':<25} {'#':>3} {'WR':>5} {'R':>7} {'AvgR':>6} {'Mo%':>7} {'DD':>6} {'PF':>5}")
    print("-" * 75)
    results = []
    for name, params in configs:
        params['fvg_min_size_pct'] = 0.05
        trades = run_mtf_strategy(candles_15m, candles_5m, params)
        if not trades:
            print(f"{name:<25} {'0':>3}")
            results.append((name, 0, 0, 0, 0, 0, 0, params)); continue
        wins = sum(1 for t in trades if t['r_multiple'] > 0)
        total_r = sum(t['r_multiple'] for t in trades)
        avg_r = total_r / len(trades); wr = wins / len(trades) * 100
        balance = 100; peak = 100; max_dd = 0
        for t in trades:
            balance += balance * 0.02 * t['r_multiple']
            if balance > peak: peak = balance
            dd = (peak - balance) / peak * 100
            if dd > max_dd: max_dd = dd
        monthly = (balance / 100 - 1) * 100
        pf_num = sum(t['r_multiple'] for t in trades if t['r_multiple'] > 0)
        pf_den = abs(sum(t['r_multiple'] for t in trades if t['r_multiple'] < 0))
        pf = pf_num / pf_den if pf_den > 0 else 999
        print(f"{name:<25} {len(trades):>3} {wr:>4.0f}% {total_r:>+6.1f}R {avg_r:>+5.2f}R {monthly:>+6.1f}% {max_dd:>5.1f}% {pf:>4.1f}")
        results.append((name, len(trades), wr, total_r, monthly, max_dd, pf, params))
    print(f"\nTOP 3 BY MONTHLY RETURN:")
    valid = [r for r in results if r[1] >= 3]
    for r in sorted(valid, key=lambda x: x[4], reverse=True)[:3]:
        print(f"   {r[0]:25s}: {r[4]:+.1f}% monthly | {r[1]} trades | {r[2]:.0f}% WR | {r[5]:.1f}% DD")
    print(f"\nTOP 3 BY RISK-ADJUSTED (monthly/DD):")
    for r in sorted(valid, key=lambda x: x[4]/max(x[5],0.1), reverse=True)[:3]:
        print(f"   {r[0]:25s}: {r[4]/max(r[5],0.1):.1f} ratio | {r[4]:+.1f}% mo | {r[5]:.1f}% DD")
    return results

def generate_mtf_report(trades, filename):
    with open(filename, 'w') as f:
        f.write("=" * 95 + "\n")
        f.write("ICT GOLDEN ENTRY v3 - MTF 15M->5M TRADE REPORT\n")
        f.write("=" * 95 + "\n")
        f.write("Setup: 15M (Sweep + Displacement + FVG + OTE) | Entry: 5M precision\n")
        f.write("Data: OKX BTCUSDT | All timestamps UTC\n")
        f.write("Verify: TradingView -> BTCUSDT (OKX) -> 15M + 5M charts\n")
        f.write("=" * 95 + "\n\n")
        for i, t in enumerate(trades):
            emoji = 'WIN' if t['r_multiple'] > 0 else 'LOSS'
            f.write(f"TRADE #{i+1:02d} [{emoji}] | {t['r_multiple']:+.2f}R | {t['result']}\n")
            f.write("-" * 65 + "\n")
            f.write(f"  Entry:    {t['entry_dt']} | ${t['entry_price']:.2f}\n")
            f.write(f"  Exit:     {t['exit_dt']} | ${t['exit_price']:.2f}\n")
            f.write(f"  Day:      {t['day_of_week']}\n")
            f.write(f"  SL:       ${t['sl_price']:.2f}\n")
            f.write(f"  TP1:      ${t['tp1']:.2f} | TP2: ${t['tp2']:.2f}\n")
            f.write(f"  Risk:     ${t['risk']:.2f} ({t['risk']/t['entry_price']*100:.3f}% of price)\n")
            f.write(f"  Entry Zone: ${t['entry_zone']:.2f}\n")
            f.write(f"  Sweep:    ${t['sweep_price']:.2f}\n")
            f.write(f"  Disp H:   ${t['disp_high']:.2f}\n")
            f.write(f"  FVG:      {t.get('fvg_size_pct',0):.3f}%\n")
            f.write(f"  OB:       {'YES' if t.get('ob_confluence') else 'NO'}\n")
            f.write(f"  Hold:     {t['hold_candles_5m']} x 5min = {t['hold_candles_5m']*5} min\n")
            f.write(f"  Spot P/L: {t['r_multiple']*2:+.2f}%\n\n")
    print(f"\nReport: {filename}")

if __name__ == '__main__':
    print("Loading data...")
    candles_15m, candles_5m = load_data(
        '/home/user/project/data/BTCUSDT_15m_OKX.csv',
        '/home/user/project/data/BTCUSDT_5m_OKX_merged.csv'
    )
    print(f"15M: {len(candles_15m)} candles | 5M: {len(candles_5m)} candles")
    print(f"15M range: {candles_15m[0]['dt']} -> {candles_15m[-1]['dt']}")
    print(f"5M range: {candles_5m[0]['dt']} -> {candles_5m[-1]['dt']}")
    results = comprehensive_test(candles_15m, candles_5m)
    valid = [r for r in results if r[1] >= 3]
    if valid:
        best = max(valid, key=lambda x: x[4] / max(x[5], 0.1))
        print(f"\n\n{'='*70}")
        print(f"DETAILED ANALYSIS: {best[0]}")
        print(f"{'='*70}")
        best_params = dict(best[7]); best_params['fvg_min_size_pct'] = 0.05
        trades = run_mtf_strategy(candles_15m, candles_5m, best_params)
        analysis = analyze_trades(trades)
        generate_mtf_report(trades, '/home/user/project/SCALP_SWEEP_BRANCH/GOLDEN_ENTRY_V3_MTF_DETAILS.txt')
