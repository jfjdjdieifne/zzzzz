#!/usr/bin/env python3
"""تحميل بيانات OKX — 15M + 5M"""
import csv
from datetime import datetime, timezone


def load_15m(filepath):
    candles = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            candles.append({
                'ts': int(row['timestamp']),
                'open': float(row['open']),
                'high': float(row['high']),
                'low': float(row['low']),
                'close': float(row['close']),
                'volume': float(row['volume']),
            })
    candles.sort(key=lambda x: x['ts'])
    for i, c in enumerate(candles):
        c['dt'] = datetime.fromtimestamp(c['ts'], tz=timezone.utc)
        c['idx'] = i
    return candles


def load_5m(filepath):
    candles = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            dt_str = row['datetime'].strip()
            dt = datetime.strptime(dt_str, '%Y-%m-%d %H:%M').replace(tzinfo=timezone.utc)
            ts = int(dt.timestamp())
            candles.append({
                'ts': ts, 'dt': dt,
                'open': float(row['open']),
                'high': float(row['high']),
                'low': float(row['low']),
                'close': float(row['close']),
                'volume': float(row['volume']),
            })
    candles.sort(key=lambda x: x['ts'])
    for i, c in enumerate(candles):
        c['idx'] = i
    return candles


def load_all(filepath_15m, filepath_5m):
    c15 = load_15m(filepath_15m)
    c5 = load_5m(filepath_5m)
    return c15, c5
