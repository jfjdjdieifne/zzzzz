#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════
  NUCLEAR SCALP — MM_3.5x + SL
  نقطة الدخول الرئيسية

  تشغيل: python3 run.py
═══════════════════════════════════════════════════════════
"""
import sys
import os
import csv
import shutil
import glob
from datetime import datetime, timezone
from collections import defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import *
from verified_trades import VERIFIED_TRADES
from data_loader import load_5m


def run_verified():
    """تشغيل الـ 24 صفقه المتحققه مع تارغت MM_3.5x"""
    candles_5m = load_5m(DATA_5M)
    trades = []

    for vt in VERIFIED_TRADES:
        dt = datetime.strptime(vt['entry_dt'], '%Y-%m-%d %H:%M').replace(tzinfo=timezone.utc)
        entry_ts = dt.timestamp()
        risk = vt['entry'] - vt['sl']

        pre_candles = [c for c in candles_5m if entry_ts - 24 * 3600 <= c['ts'] < entry_ts]
        trade_candles = [c for c in candles_5m if entry_ts + 300 <= c['ts'] <= entry_ts + 48 * 3600]

        best_disp = None
        best_disp_range = 0
        for i in range(2, min(len(pre_candles), 60)):
            c = pre_candles[-i]
            if c['close'] > c['open']:
                r = c['high'] - c['low']
                if r > best_disp_range:
                    best_disp_range = r
                    best_disp = c

        sweep_low = 999999
        for c in pre_candles[-30:]:
            if c['low'] < sweep_low:
                sweep_low = c['low']

        if best_disp and sweep_low < 999999:
            move_from_sweep = best_disp['high'] - sweep_low
            target_mm = vt['entry'] + move_from_sweep * MM_MULTIPLIER
            target_mm_r = (target_mm - vt['entry']) / risk
        else:
            move_from_sweep = 0
            target_mm = 0
            target_mm_r = 0

        peak_r = 0
        exit_r = -1.0
        exit_type = 'SL'
        exit_dt = None
        exit_price = vt['sl']

        for c in trade_candles:
            high_r = (c['high'] - vt['entry']) / risk
            if high_r > peak_r:
                peak_r = high_r

            if target_mm > 0 and c['high'] >= target_mm:
                exit_r = target_mm_r
                exit_type = 'TARGET'
                exit_dt = c['dt']
                exit_price = target_mm
                break

            if c['low'] <= vt['sl']:
                exit_r = -1.0
                exit_type = 'SL'
                exit_dt = c['dt']
                exit_price = vt['sl']
                break
        else:
            close_48h_ts = entry_ts + 48 * 3600
            best_diff = 999999
            close_48h_candle = None
            for c in candles_5m:
                diff = abs(c['ts'] - close_48h_ts)
                if diff < best_diff:
                    best_diff = diff
                    close_48h_candle = c
            if close_48h_candle:
                exit_r = (close_48h_candle['close'] - vt['entry']) / risk
                exit_type = '48H_CLOSE'
                exit_dt = close_48h_candle['dt']
                exit_price = close_48h_candle['close']

        trades.append({
            'num': vt['num'],
            'entry_dt': dt,
            'entry_price': vt['entry'],
            'sl_price': vt['sl'],
            'risk': risk,
            'risk_pct': risk / vt['entry'] * 100,
            'target_price': target_mm,
            'target_r': target_mm_r,
            'move_from_sweep': move_from_sweep,
            'sweep_low': sweep_low if sweep_low < 999999 else 0,
            'disp_high': best_disp['high'] if best_disp else 0,
            'exit_dt': exit_dt,
            'exit_price': exit_price,
            'exit_type': exit_type,
            'r_multiple': exit_r,
            'peak_r': peak_r,
            'day_short': dt.strftime('%a'),
            'day_of_week': dt.strftime('%A'),
            'hold_minutes': (exit_dt.timestamp() - entry_ts) // 60 if exit_dt else 0,
            'mm_1x_price': vt['entry'] + move_from_sweep * 1,
            'mm_1x_r': move_from_sweep / risk if risk > 0 else 0,
            'mm_2x_price': vt['entry'] + move_from_sweep * 2,
            'mm_2x_r': move_from_sweep * 2 / risk if risk > 0 else 0,
        })

    return trades


def analyze(trades):
    balance = ACCOUNT_SIZE
    peak = balance
    max_dd = 0
    wins = losses = 0
    total_r = 0
    win_rs = []
    loss_rs = []

    for t in trades:
        risk_amount = balance * RISK_PER_TRADE
        profit = t['r_multiple'] * risk_amount
        balance += profit
        total_r += t['r_multiple']
        if t['r_multiple'] > 0:
            wins += 1
            win_rs.append(t['r_multiple'])
        else:
            losses += 1
            loss_rs.append(t['r_multiple'])
        if balance > peak:
            peak = balance
        dd = (peak - balance) / peak * 100
        if dd > max_dd:
            max_dd = dd

    n = len(trades)
    wr = wins / n * 100
    pf = sum(win_rs) / abs(sum(loss_rs)) if loss_rs and sum(loss_rs) != 0 else 999

    return {
        'n': n, 'wins': wins, 'losses': losses, 'wr': wr,
        'total_r': total_r, 'avg_r': total_r / n,
        'balance': balance, 'monthly': (balance / ACCOUNT_SIZE - 1) * 100,
        'max_dd': max_dd, 'pf': pf,
        'best_r': max(win_rs) if win_rs else 0,
        'avg_win': sum(win_rs) / len(win_rs) if win_rs else 0,
        'targets_hit': sum(1 for t in trades if t['exit_type'] == 'TARGET'),
        'target_pct': sum(1 for t in trades if t['exit_type'] == 'TARGET') / n * 100,
    }


def generate_reports(trades, stats):
    """توليد التقرير + CSV"""
    out = []
    out.append("=" * 120)
    out.append(f"NUCLEAR SCALP — MM_{MM_MULTIPLIER}x + SL")
    out.append("OKX BTCUSDT | 5M شمعات | كل الأوقات UTC")
    out.append(f"حساب ${ACCOUNT_SIZE} | خطر {RISK_PER_TRADE*100:.0f}% مركب")
    out.append(f"التارغت: الدخول + (مدى الإزاحة من السويب × {MM_MULTIPLIER})")
    out.append(f"الدخول: IOFED (FVG top edge) + تأكيد | الستوب: ذيل شمعة الدخول - {SL_BUFFER_PCT}%")
    out.append(f"الـ 24 صفقه المتحققه يدوياً على TradingView")
    out.append(f"المرجع: ICT Fib SD -2.0 to -2.5 ≈ displacement × {MM_MULTIPLIER}")
    out.append("=" * 120)

    out.append("")
    out.append(f"  عدد الصفقات:         {stats['n']}")
    out.append(f"  رابحه / خاسره:       {stats['wins']} / {stats['losses']}")
    out.append(f"  Win Rate:            {stats['wr']:.0f}%")
    out.append(f"  ─────────────────────────────")
    out.append(f"  إجمالي R:            {stats['total_r']:+.1f}R")
    out.append(f"  متوسط R:             {stats['avg_r']:+.1f}R")
    out.append(f"  متوسط R رابح:        {stats['avg_win']:+.1f}R")
    out.append(f"  أكبر R رابح:         {stats['best_r']:+.1f}R")
    out.append(f"  ─────────────────────────────")
    out.append(f"  Profit Factor:       {stats['pf']:.2f}")
    out.append(f"  Max Drawdown:        {stats['max_dd']:.1f}%")
    out.append(f"  تارغتات وصلت:        {stats['targets_hit']}/{stats['n']} ({stats['target_pct']:.0f}%)")
    out.append(f"  ─────────────────────────────")
    out.append(f"  حساب ${ACCOUNT_SIZE} مركب: ${stats['balance']:.2f}")
    out.append(f"  الربح:               {stats['monthly']:+.1f}%")

    out.append("")
    out.append(f"  {'#':>2}  {'تاريخ الدخول':>16}  {'يوم':>3}  {'دخول$':>10}  {'ستوب$':>10}  {'تارغت$':>10}  {'تارغتR':>7}  {'خروجR':>8}  {'أقصىR':>7}  {'نوع':<10}  {'زمن':>6}")
    out.append("  " + "─" * 115)

    for t in trades:
        type_m = {'TARGET': '🎯 وصل', 'SL': '❌ SL', '48H_CLOSE': '⏰ 48h'}.get(t['exit_type'], '?')
        hold_h = int(t['hold_minutes'] // 60)
        hold_m = int(t['hold_minutes'] % 60)
        out.append(
            f"  {t['num']:>2}  {t['entry_dt'].strftime('%Y-%m-%d %H:%M'):>16}  {t['day_short']:>3}  "
            f"${t['entry_price']:>9.1f}  ${t['sl_price']:>9.2f}  ${t['target_price']:>9.1f}  "
            f"{t['target_r']:>+6.1f}R  {t['r_multiple']:>+7.1f}R  {t['peak_r']:>+6.1f}R  "
            f"{type_m:<10}  {hold_h:>2}h{hold_m:02d}m")

    for t in trades:
        out.append("")
        out.append("━" * 100)
        mark = "✅" if t['r_multiple'] > 0 else "❌"
        out.append(f"  #{t['num']:>2} | {t['entry_dt'].strftime('%Y-%m-%d %H:%M')} UTC | {t['day_of_week']} | {mark} {t['r_multiple']:+.1f}R | {t['exit_type']}")
        out.append("━" * 100)
        out.append(f"  الدخول:      ${t['entry_price']:.2f}")
        out.append(f"  الستوب:      ${t['sl_price']:.2f}  (ذيل -{SL_BUFFER_PCT}%)")
        out.append(f"  المخاطره:    ${t['risk']:.2f} ({t['risk_pct']:.2f}%)")
        out.append(f"  ──────────────────────────")
        out.append(f"  السويب:      ${t['sweep_low']:.2f}")
        out.append(f"  الإزاحه:     ${t['disp_high']:.2f}")
        out.append(f"  المدى:       ${t['move_from_sweep']:.2f}")
        out.append(f"  ──────────────────────────")
        out.append(f"  MM_1x:       ${t['mm_1x_price']:.2f} ({t['mm_1x_r']:+.1f}R)")
        out.append(f"  MM_2x:       ${t['mm_2x_price']:.2f} ({t['mm_2x_r']:+.1f}R)")
        out.append(f"  MM_3.5x:     ${t['target_price']:.2f} ({t['target_r']:+.1f}R) ← التارغت")
        out.append(f"  ──────────────────────────")
        out.append(f"  الخروج:      ${t['exit_price']:.2f}  ({t['exit_dt'].strftime('%Y-%m-%d %H:%M')} UTC)")
        out.append(f"  R:           {t['r_multiple']:+.1f}R")
        out.append(f"  أقصى R:      {t['peak_r']:+.1f}R")

    out.append("")
    out.append("  تحليل حسب اليوم:")
    out.append("")
    dow = defaultdict(lambda: {'w': 0, 'l': 0, 'r': 0, 'n': 0})
    for t in trades:
        d = dow[t['day_short']]
        d['n'] += 1
        if t['r_multiple'] > 0: d['w'] += 1
        else: d['l'] += 1
        d['r'] += t['r_multiple']
    out.append(f"  {'اليوم':<10}  {'عدد':>4}  {'W':>3}  {'L':>3}  {'WR%':>5}  {'R':>8}")
    out.append("  " + "─" * 40)
    for day in ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']:
        if day in dow:
            d = dow[day]
            out.append(f"  {day:<10}  {d['n']:>4}  {d['w']:>3}  {d['l']:>3}  {d['w']/d['n']*100:>4.0f}%  {d['r']:>+7.1f}R")

    out.append("")
    out.append("  نمو الحساب المركب:")
    out.append("")
    out.append(f"  {'#':>2}  {'تاريخ':>16}  {'خروجR':>8}  {'خطر$':>7}  {'ربح$':>8}  {'رصيد$':>8}  {'ربح%':>7}")
    out.append("  " + "─" * 70)
    balance = ACCOUNT_SIZE
    for t in trades:
        risk_amount = balance * RISK_PER_TRADE
        profit = t['r_multiple'] * risk_amount
        balance += profit
        out.append(
            f"  {t['num']:>2}  {t['entry_dt'].strftime('%Y-%m-%d %H:%M'):>16}  "
            f"{t['r_multiple']:>+7.1f}R  ${risk_amount:>6.2f}  ${profit:>+7.2f}  "
            f"${balance:>7.2f}  {(balance/ACCOUNT_SIZE-1)*100:>+6.1f}%")

    report_path = os.path.join(REPORT_DIR, 'REPORT.txt')
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(out))

    csv_path = os.path.join(REPORT_DIR, 'TRADES.csv')
    with open(csv_path, 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['num','entry_dt','day','entry_price','sl_price','risk','target_mm35x','target_r',
                     'exit_type','exit_r','exit_price','exit_dt','peak_r','sweep_low','disp_high','move_from_sweep','hold_minutes'])
        for t in trades:
            w.writerow([
                t['num'], t['entry_dt'].strftime('%Y-%m-%d %H:%M'), t['day_short'],
                f"{t['entry_price']:.2f}", f"{t['sl_price']:.2f}", f"{t['risk']:.2f}",
                f"{t['target_price']:.2f}", f"{t['target_r']:.1f}",
                t['exit_type'], f"{t['r_multiple']:.1f}", f"{t['exit_price']:.2f}",
                t['exit_dt'].strftime('%Y-%m-%d %H:%M') if t['exit_dt'] else '',
                f"{t['peak_r']:.1f}", f"{t['sweep_low']:.2f}", f"{t['disp_high']:.2f}",
                f"{t['move_from_sweep']:.2f}", t['hold_minutes'],
            ])

    return report_path, csv_path


def main():
    print()
    print("═" * 70)
    print(f"  NUCLEAR SCALP — MM_{MM_MULTIPLIER}x + SL")
    print("  OKX BTCUSDT | LONG only | IOFED + تأكيد")
    print("═" * 70)
    print()

    print("  ⏳ تحميل البيانات...")
    trades = run_verified()
    print(f"  ✅ {len(trades)} صفقه متحققه")
    print()

    stats = analyze(trades)

    print("═" * 70)
    print("  النتايج")
    print("═" * 70)
    print()
    print(f"  عدد الصفقات:     {stats['n']}")
    print(f"  رابحه / خاسره:   {stats['wins']} / {stats['losses']}")
    print(f"  Win Rate:        {stats['wr']:.0f}%")
    print(f"  ────────────────────────────")
    print(f"  إجمالي R:        {stats['total_r']:+.1f}R")
    print(f"  متوسط R:         {stats['avg_r']:+.1f}R")
    print(f"  أكبر R رابح:     {stats['best_r']:+.1f}R")
    print(f"  Profit Factor:   {stats['pf']:.2f}")
    print(f"  ────────────────────────────")
    print(f"  تارغتات وصلت:    {stats['targets_hit']}/{stats['n']} ({stats['target_pct']:.0f}%)")
    print(f"  Max Drawdown:    {stats['max_dd']:.1f}%")
    print(f"  ────────────────────────────")
    print(f"  حساب ${ACCOUNT_SIZE} مركب: ${stats['balance']:.2f}")
    print(f"  الربح:           {stats['monthly']:+.1f}%")
    print()

    print("═" * 70)
    print("  كل الصفقات")
    print("═" * 70)
    print()
    print(f"  {'#':>2}  {'تاريخ الدخول':>16}  {'يوم':>3}  {'دخول$':>10}  {'تارغت$':>10}  {'تارغتR':>7}  {'خروجR':>8}  {'أقصىR':>7}  {'نوع':<6}")
    print("  " + "─" * 85)

    for t in trades:
        type_m = {'TARGET': '🎯', 'SL': '❌', '48H_CLOSE': '⏰'}.get(t['exit_type'], '?')
        print(
            f"  {t['num']:>2}  {t['entry_dt'].strftime('%Y-%m-%d %H:%M'):>16}  {t['day_short']:>3}  "
            f"${t['entry_price']:>9.1f}  ${t['target_price']:>9.1f}  "
            f"{t['target_r']:>+6.1f}R  {t['r_multiple']:>+7.1f}R  {t['peak_r']:>+6.1f}R  {type_m:<6}")

    print()
    report_path, csv_path = generate_reports(trades, stats)
    print(f"  ✅ {report_path}")
    print(f"  ✅ {csv_path}")
    print()

    # تنظيف __pycache__
    for pyc in glob.glob(os.path.join(REPORT_DIR, '__pycache__', '*')):
        try: os.remove(pyc)
        except: pass
    try: os.rmdir(os.path.join(REPORT_DIR, '__pycache__'))
    except: pass

    # زيبفايل
    zip_path = '/home/user/project/SCALP_SWEEP_BRANCH/Nuclear_Scalp_MM3x'
    shutil.make_archive(zip_path, 'zip',
                        os.path.dirname(REPORT_DIR.rstrip('/')),
                        'scalping_mm3x')
    print(f"  📦 {zip_path}.zip")
    print()
    print("═" * 70)
    print("  تم!")
    print("═" * 70)


if __name__ == '__main__':
    main()
