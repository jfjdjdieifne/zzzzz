#!/usr/bin/env python3
"""
محرك الاستراتيجية — NUCLEAR SCALP MM_3.5x + SL

متصل بالكود الأساسي (ict_golden_entry_15m_v3.py) — نفس منطق الكشف
مع تعديل: تارغت MM_3.5x بدل التارغت القديم

المرجع: ICT Fibonacci Standard Deviation
  -2.0 to -2.5 SD ≈ displacement × 3.5 من الدخول
  المصدر: innercircletrader.net/tutorials/ict-fibonacci-levels/
"""
import sys
import os
from datetime import datetime, timezone

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import *
from data_loader import load_all


# ═══════════════════════════════════════════════════════════════
# 1. كشف نقاط السوينق (نفس الكود الأساسي)
# ═══════════════════════════════════════════════════════════════

def find_swing_points(candles, left=SWING_LEFT, right=SWING_RIGHT):
    swing_highs = {}
    swing_lows = {}
    for i in range(left, len(candles) - right):
        is_high = all(candles[i]['high'] >= candles[i - j]['high'] for j in range(1, left + 1)) and \
                  all(candles[i]['high'] >= candles[i + j]['high'] for j in range(1, right + 1))
        if is_high:
            swing_highs[i] = candles[i]['high']
        is_low = all(candles[i]['low'] <= candles[i - j]['low'] for j in range(1, left + 1)) and \
                 all(candles[i]['low'] <= candles[i + j]['low'] for j in range(1, right + 1))
        if is_low:
            swing_lows[i] = candles[i]['low']
    return swing_highs, swing_lows


# ═══════════════════════════════════════════════════════════════
# 2. كشف الـ Setups (نفس الكود الأساسي + فلاتر جودة)
# ═══════════════════════════════════════════════════════════════

def detect_setups(candles_15m, swing_highs, swing_lows):
    setups = []
    for i in range(20, len(candles_15m) - 50):
        c = candles_15m[i]

        # ── كشف السويب ──
        best_sweep = None
        for sw_idx, sw_price in swing_lows.items():
            if sw_idx >= i:
                continue
            if i - sw_idx > SWEEP_MAX_DIST:
                continue
            if c['low'] < sw_price:
                if best_sweep is None or sw_idx > best_sweep[0]:
                    best_sweep = (sw_idx, sw_price)
        if best_sweep is None:
            continue
        sweep_idx, sweep_price = best_sweep

        # ── كشف الإزاحة ──
        for disp_offset in range(1, DISP_SEARCH_WINDOW):
            disp_idx = i + disp_offset
            if disp_idx >= len(candles_15m) - 2:
                break
            dc = candles_15m[disp_idx]
            body = dc['close'] - dc['open']
            rng = dc['high'] - dc['low']
            if rng == 0 or body <= 0:
                continue
            if body / rng < MIN_DISP_BODY_PCT:
                continue

            # ── كشف FVG ──
            prev_high = candles_15m[disp_idx - 1]['high']
            next_low = candles_15m[disp_idx + 1]['low']
            if next_low <= prev_high:
                continue
            fvg = {
                'bottom': prev_high, 'top': next_low,
                'mid': (prev_high + next_low) / 2,
                'size': next_low - prev_high,
                'size_pct': (next_low - prev_high) / dc['close'] * 100,
            }
            if fvg['size_pct'] < FVG_MIN_SIZE_PCT:
                continue

            disp_high = dc['high']

            # ── فلتر: أقل حجم إزاحة ──
            disp_pct = (disp_high - sweep_price) / dc['close'] * 100
            if disp_pct < MIN_DISPLACEMENT_PCT:
                continue

            # ── كشف MSS ──
            mss_ok = False
            for sh_idx, sh_price in swing_highs.items():
                if sweep_idx - MSS_LOOKBACK < sh_idx < sweep_idx and disp_high > sh_price:
                    mss_ok = True
                    break
            if not mss_ok:
                prev_max = max(candles_15m[j]['high'] for j in range(max(0, disp_idx - 5), disp_idx))
                if disp_high > prev_max:
                    mss_ok = True
            if not mss_ok:
                continue

            # ── OTE ──
            total_range = disp_high - sweep_price
            if total_range <= 0:
                continue
            ote = {
                'fib_62': disp_high - 0.62 * total_range,
                'fib_705': disp_high - 0.705 * total_range,
                'fib_79': disp_high - 0.79 * total_range,
                'range': total_range,
            }

            # ── Order Block ──
            ob = None
            for k in range(disp_idx - 1, max(disp_idx - 5, 0), -1):
                if candles_15m[k]['close'] < candles_15m[k]['open']:
                    ob = {'top': candles_15m[k]['open'], 'bottom': candles_15m[k]['close'], 'idx': k}
                    break

            ol_bottom = max(ote['fib_79'], fvg['bottom'])
            ol_top = min(ote['fib_62'], fvg['top'])
            ote_fvg_overlap = ol_top > ol_bottom

            if REQUIRE_OTE_OVERLAP and not ote_fvg_overlap:
                continue

            setups.append({
                'sweep_idx': sweep_idx, 'sweep_price': sweep_price,
                'disp_idx': disp_idx, 'disp_high': disp_high,
                'fvg': fvg, 'ote': ote, 'ob': ob,
                'ote_fvg_overlap': ote_fvg_overlap,
                'overlap_bottom': ol_bottom if ote_fvg_overlap else 0,
                'overlap_top': ol_top if ote_fvg_overlap else 0,
                'setup_idx': i, 'disp_pct': disp_pct,
            })
            break

    return setups


# ═══════════════════════════════════════════════════════════════
# 3. تنفيذ الصفقة (IOFED + MM_3.5x target + Tail SL)
# ═══════════════════════════════════════════════════════════════

def execute_trade(setup, candles_15m, candles_5m):
    fvg = setup['fvg']
    disp_idx = setup['disp_idx']

    # ── IOFED = FVG top edge ──
    entry_zone_price = fvg['top']

    # ── بحث 5M عن الدخول ──
    disp_15m = candles_15m[disp_idx]
    search_start_ts = disp_15m['ts'] + 900
    search_end_ts = disp_15m['ts'] + 900 * 40
    five_min_candles = [c for c in candles_5m if search_start_ts <= c['ts'] <= search_end_ts]
    if not five_min_candles:
        return None

    entry_5m = None
    entry_price = None

    for fc in five_min_candles:
        if fc['low'] <= entry_zone_price:
            if REQUIRE_CONFIRMATION:
                fc_idx = fc['idx']
                if fc_idx + 1 < len(candles_5m):
                    next_c = candles_5m[fc_idx + 1]
                    if next_c['close'] > next_c['open']:
                        entry_5m = next_c
                        entry_price = next_c['open']
                        break
            else:
                entry_5m = fc
                entry_price = entry_zone_price
                break

    if entry_5m is None:
        return None

    # ── الستوب: ذيل شمعة الدخول - 0.1% ──
    sl_price = entry_5m['low'] - (entry_price * SL_BUFFER_PCT / 100)
    risk = entry_price - sl_price
    if risk <= 0:
        return None

    # ── التارغت: MM_3.5x ──
    move_from_sweep = setup['disp_high'] - setup['sweep_price']
    target_price = entry_price + move_from_sweep * MM_MULTIPLIER
    target_r = (target_price - entry_price) / risk

    if target_r < MIN_R_TARGET:
        return None

    # ── محاكاة ──
    entry_ts = entry_5m['ts']
    max_hold_seconds = MAX_HOLD_HOURS * 3600
    sim_candles = [c for c in candles_5m if entry_ts < c['ts'] <= entry_ts + max_hold_seconds]
    if not sim_candles:
        return None

    peak_r = 0

    for sc in sim_candles:
        high_r = (sc['high'] - entry_price) / risk
        if high_r > peak_r:
            peak_r = high_r

        if sc['high'] >= target_price:
            return _make_trade(entry_5m, entry_price, sl_price, risk, target_price, target_r,
                               move_from_sweep, setup, sc, 'TARGET', target_r, peak_r, entry_ts)

        if sc['low'] <= sl_price:
            return _make_trade(entry_5m, entry_price, sl_price, risk, target_price, target_r,
                               move_from_sweep, setup, sc, 'SL', -1.0, peak_r, entry_ts)

    last = sim_candles[-1]
    close_r = (last['close'] - entry_price) / risk
    return _make_trade(entry_5m, entry_price, sl_price, risk, target_price, target_r,
                       move_from_sweep, setup, last, '48H_CLOSE', close_r, peak_r, entry_ts)


def _make_trade(entry_5m, entry_price, sl_price, risk, target_price, target_r,
                move_from_sweep, setup, exit_candle, exit_type, r_multiple, peak_r, entry_ts):
    return {
        'entry_dt': entry_5m['dt'],
        'entry_price': entry_price,
        'sl_price': sl_price,
        'target_price': target_price,
        'target_r': target_r,
        'risk': risk,
        'risk_pct': risk / entry_price * 100,
        'exit_dt': exit_candle['dt'],
        'exit_price': target_price if exit_type == 'TARGET' else (sl_price if exit_type == 'SL' else exit_candle['close']),
        'exit_type': exit_type,
        'r_multiple': r_multiple,
        'hold_candles': (exit_candle['ts'] - entry_ts) // 300,
        'hold_minutes': (exit_candle['ts'] - entry_ts) // 60,
        'peak_r': peak_r,
        'day_of_week': entry_5m['dt'].strftime('%A'),
        'day_short': entry_5m['dt'].strftime('%a'),
        'entry_zone': setup['fvg']['top'],
        'sweep_price': setup['sweep_price'],
        'disp_high': setup['disp_high'],
        'move_from_sweep': move_from_sweep,
        'fvg_size_pct': setup['fvg']['size_pct'],
        'mm_1x_price': entry_price + move_from_sweep * 1,
        'mm_1x_r': move_from_sweep / risk,
        'mm_2x_price': entry_price + move_from_sweep * 2,
        'mm_2x_r': move_from_sweep * 2 / risk,
        'mm_3x_price': entry_price + move_from_sweep * 3,
        'mm_3x_r': move_from_sweep * 3 / risk,
        'mm_3_5x_price': target_price,
        'mm_3_5x_r': target_r,
    }


# ═══════════════════════════════════════════════════════════════
# 4. تشغيل الاستراتيجية
# ═══════════════════════════════════════════════════════════════

def run_strategy(candles_15m, candles_5m):
    swing_highs, swing_lows = find_swing_points(candles_15m)
    setups = detect_setups(candles_15m, swing_highs, swing_lows)

    trades = []
    last_exit_ts = 0

    for setup in setups:
        setup_ts = candles_15m[setup['setup_idx']]['ts']
        if setup_ts <= last_exit_ts:
            continue

        setup_dt = datetime.fromtimestamp(setup_ts, tz=timezone.utc)
        if setup_dt.strftime('%a') in SKIP_DAYS:
            continue

        trade = execute_trade(setup, candles_15m, candles_5m)
        if trade is None:
            continue
        if trade['day_short'] in SKIP_DAYS:
            continue

        trades.append(trade)
        last_exit_ts = trade['exit_dt'].timestamp()

    return trades
