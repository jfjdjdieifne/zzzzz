#!/usr/bin/env python3
"""
تحليل وباكتيست — NUCLEAR SCALP MM_3.5x v2
════════════════════════════════════════════════════════════════
يولّد تقرير شامل عن نتائج المحرك الآلي المصلح
"""
import sys
import os
from datetime import datetime, timezone
from collections import defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import *
from data_loader import load_all
from strategy import find_swing_points, detect_setups, execute_trade, run_strategy


def analyze_trades(trades, verbose=True):
    """تحليل شامل للصفقات"""
    if not trades:
        if verbose:
            print("  ❌ لا صفقات!")
        return {}

    balance = ACCOUNT_SIZE
    peak = balance
    max_dd = 0
    wins = losses = 0
    total_r = 0
    result_stats = defaultdict(int)
    dow_stats = defaultdict(lambda: {'w': 0, 'l': 0, 'r': 0})
    hour_stats = defaultdict(lambda: {'w': 0, 'l': 0, 'r': 0})

    for t in trades:
        balance += balance * RISK_PER_TRADE * t['r_multiple']
        total_r += t['r_multiple']
        if t['r_multiple'] > 0:
            wins += 1
        else:
            losses += 1
        if balance > peak:
            peak = balance
        dd = (peak - balance) / peak * 100
        if dd > max_dd:
            max_dd = dd
        result_stats[t['exit_type']] += 1
        dow_stats[t['day_short']]['w' if t['r_multiple'] > 0 else 'l'] += 1
        dow_stats[t['day_short']]['r'] += t['r_multiple']
        hour_stats[t['entry_dt'].hour]['w' if t['r_multiple'] > 0 else 'l'] += 1
        hour_stats[t['entry_dt'].hour]['r'] += t['r_multiple']

    wr = wins / len(trades) * 100
    monthly = (balance / ACCOUNT_SIZE - 1) * 100
    avg_r = total_r / len(trades)
    pf_num = sum(t['r_multiple'] for t in trades if t['r_multiple'] > 0)
    pf_den = abs(sum(t['r_multiple'] for t in trades if t['r_multiple'] < 0))
    pf = pf_num / pf_den if pf_den > 0 else 999
    avg_risk = sum(t['risk'] for t in trades) / len(trades)

    result = {
        'n': len(trades), 'wins': wins, 'losses': losses,
        'wr': wr, 'total_r': total_r, 'avg_r': avg_r,
        'pf': pf, 'max_dd': max_dd, 'monthly': monthly,
        'balance': balance, 'avg_risk': avg_risk,
    }

    if not verbose:
        return result

    print(f"\n{'═' * 70}")
    print(f"  NUCLEAR SCALP MM_3.5x v2 — نتائج المحرك الآلي")
    print(f"{'═' * 70}")
    print(f"  الصفقات:        {len(trades)}")
    print(f"  W/L:            {wins}/{losses}")
    print(f"  Win Rate:       {wr:.1f}%")
    print(f"  Total R:        {total_r:+.1f}R")
    print(f"  Avg R:          {avg_r:+.2f}R")
    print(f"  Profit Factor:  {pf:.2f}")
    print(f"  Max DD:         {max_dd:.1f}%")
    print(f"  Monthly:        {monthly:+.1f}%")
    print(f"  Balance:        ${balance:.2f}")
    print(f"  Avg Risk:       ${avg_risk:.1f}")

    print(f"\n  أنواع الخروج:")
    for r, c in sorted(result_stats.items(), key=lambda x: -x[1]):
        print(f"    {r:15s}: {c} ({c / len(trades) * 100:.0f}%)")

    print(f"\n  حسب اليوم:")
    for dow in ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']:
        if dow in dow_stats:
            d = dow_stats[dow]
            total = d['w'] + d['l']
            gwr = d['w'] / total * 100
            print(f"    {dow:10s}: {d['w']}W/{d['l']}L = {gwr:.0f}% WR | {d['r']:+.1f}R")

    print(f"\n  حسب الساعة (UTC):")
    for h in sorted(hour_stats.keys()):
        d = hour_stats[h]
        total = d['w'] + d['l']
        gwr = d['w'] / total * 100
        print(f"    {h:02d}:00 UTC: {d['w']}W/{d['l']}L = {gwr:.0f}% WR | {d['r']:+.1f}R")

    return result


def generate_report(trades, filename):
    """توليد تقرير مفصّل"""
    with open(filename, 'w') as f:
        f.write("=" * 95 + "\n")
        f.write("NUCLEAR SCALP MM_3.5x v2 — AUTO ENGINE REPORT\n")
        f.write("=" * 95 + "\n")
        f.write("Strategy: Liquidity Sweep -> Displacement (FVG) -> IOFED Entry -> MM_3.5x Target\n")
        f.write("Data: OKX BTCUSDT | All timestamps UTC\n")
        f.write("Verify: TradingView -> BTCUSDT (OKX) -> 15M + 5M charts\n")
        f.write(f"Config: Session={ALLOWED_HOURS} | Skip={SKIP_DAYS} | Retrace<={MAX_RETRACE_PCT}% | Risk<={MAX_RISK_PCT}%\n")
        f.write("=" * 95 + "\n\n")

        for i, t in enumerate(trades):
            emoji = 'WIN' if t['r_multiple'] > 0 else 'LOSS'
            f.write(f"TRADE #{i + 1:02d} [{emoji}] | {t['r_multiple']:+.1f}R | {t['exit_type']}\n")
            f.write("-" * 65 + "\n")
            f.write(f"  Entry:      {t['entry_dt']} | ${t['entry_price']:.2f}\n")
            f.write(f"  Exit:       {t['exit_dt']} | ${t['exit_price']:.2f}\n")
            f.write(f"  Day:        {t['day_of_week']} ({t['entry_dt'].hour}:00 UTC)\n")
            f.write(f"  SL:         ${t['sl_price']:.2f}\n")
            f.write(f"  Target:     ${t['target_price']:.2f} ({t['target_r']:.1f}R)\n")
            f.write(f"  Risk:       ${t['risk']:.2f} ({t['risk_pct']:.3f}%)\n")
            f.write(f"  Entry Zone: ${t['entry_zone']:.2f} (IOFED)\n")
            f.write(f"  Sweep:      ${t['sweep_price']:.2f}\n")
            f.write(f"  Disp High:  ${t['disp_high']:.2f}\n")
            f.write(f"  Disp %:     {t['disp_pct']:.2f}%\n")
            f.write(f"  FVG:        {t['fvg_size_pct']:.3f}%\n")
            f.write(f"  Retrace:    {t['retrace_pct']:.1f}%\n")
            f.write(f"  Peak R:     {t['peak_r']:.1f}R\n")
            f.write(f"  Hold:       {t['hold_candles']} x 5min = {t['hold_minutes']}min ({t['hold_minutes'] / 60:.1f}h)\n")
            f.write(f"  P/L:        {t['r_multiple'] * RISK_PER_TRADE * 100:+.2f}%\n\n")

        result = analyze_trades(trades, verbose=False)
        f.write("\n" + "=" * 95 + "\n")
        f.write("SUMMARY\n")
        f.write("=" * 95 + "\n")
        f.write(f"  Trades:        {result['n']}\n")
        f.write(f"  Win Rate:      {result['wr']:.1f}%\n")
        f.write(f"  Total R:       {result['total_r']:+.1f}R\n")
        f.write(f"  Monthly:       {result['monthly']:+.1f}%\n")
        f.write(f"  Max DD:        {result['max_dd']:.1f}%\n")
        f.write(f"  Profit Factor: {result['pf']:.2f}\n")
        f.write(f"  Balance:       ${result['balance']:.2f}\n")

    print(f"\n  Report: {filename}")


def generate_csv(trades, filename):
    """توليد CSV للصفقات"""
    import csv
    with open(filename, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow([
            '#', 'Entry_Date', 'Day', 'Hour_UTC', 'Entry_Price', 'SL_Price',
            'Target_Price', 'Target_R', 'Result', 'R_Multiple', 'Peak_R',
            'Risk_Dollar', 'Risk_Pct', 'FVG_Pct', 'Retrace_Pct', 'Disp_Pct',
            'Sweep_Price', 'Disp_High', 'Entry_Zone', 'Hold_Min'
        ])
        for i, t in enumerate(trades):
            writer.writerow([
                i + 1,
                t['entry_dt'].strftime('%Y-%m-%d %H:%M'),
                t['day_short'],
                t['entry_dt'].hour,
                f"{t['entry_price']:.2f}",
                f"{t['sl_price']:.2f}",
                f"{t['target_price']:.2f}",
                f"{t['target_r']:.1f}",
                t['exit_type'],
                f"{t['r_multiple']:+.1f}",
                f"{t['peak_r']:.1f}",
                f"{t['risk']:.1f}",
                f"{t['risk_pct']:.3f}",
                f"{t['fvg_size_pct']:.3f}",
                f"{t['retrace_pct']:.1f}",
                f"{t['disp_pct']:.2f}",
                f"{t['sweep_price']:.2f}",
                f"{t['disp_high']:.2f}",
                f"{t['entry_zone']:.2f}",
                t['hold_minutes']
            ])
    print(f"  CSV: {filename}")
