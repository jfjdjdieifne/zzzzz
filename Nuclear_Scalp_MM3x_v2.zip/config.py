#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════
  NUCLEAR SCALP — MM_3.5x + SL  (v2 — المحرك المصلح)
  استراتيجية سكالبينغ BTC سبوت (LONG only) 15M
  OKX BTCUSDT | $100 حساب | 1% خطر

  النمط: Liquidity Sweep → Displacement (FVG) → IOFED Entry → MM_3.5x Target

  IOFED = Immediate OFV Entry on Displacement = FVG top edge entry
  MM_3.5x = مدى الإزاحة من السويب × 3.5
  المرجع: ICT Fib SD -2.0 to -2.5 ≈ displacement × 3.5

  v2 إصلاحات:
  ─ إزالة التكرار (dedup by displacement_idx)
  ─ فلتر الجلسات (أفضل ساعات فقط)
  ─ فلتر أيام (skip Sat/Sun)
  ─ فلتر Retrace (دخول قريب من displacement high)
  ─ فلتر Risk% (ستوب ضيق = دخول أفضل)
═══════════════════════════════════════════════════════════
"""

# ─── مسارات البيانات ───
DATA_15M = '/home/user/project/data/BTCUSDT_15m_OKX.csv'
DATA_5M  = '/home/user/project/data/BTCUSDT_5m_OKX_merged.csv'

# ─── إعدادات الحساب ───
ACCOUNT_SIZE     = 100       # دولار
RISK_PER_TRADE   = 0.01     # 1% من الحساب

# ─── إعدادات كشف السوينق ───
SWING_LEFT       = 5
SWING_RIGHT      = 3

# ─── إعدادات كشف الـ Setup ───
SWEEP_MAX_DIST        = 60    # أقصى مسافة بين السويب والكشف (شموع 15M)
DISP_SEARCH_WINDOW    = 8     # عدد الشموع للبحث عن الإزاحة
MIN_DISP_BODY_PCT     = 0.4   # أقل نسبة جسم/مدى للإزاحة
FVG_MIN_SIZE_PCT      = 0.08  # أقل حجم FVG (% من السعر)
MSS_LOOKBACK          = 40    # مدة البحث عن MSS

# ─── إعدادات الدخول ───
ENTRY_MODE           = 'iofed'
REQUIRE_CONFIRMATION = True   # تأكيد 5M (شمعة صاعدة بعد اللمس)

# ─── إعدادات الستوب ───
SL_MODE              = 'tail'
SL_BUFFER_PCT        = 0.1    # مسافة إضافية تحت ذيل شمعة الدخول (%)

# ─── إعدادات الهدف ───
TARGET_MODE          = 'mm_3.5x'
MM_MULTIPLIER        = 3.5
MAX_HOLD_HOURS       = 48

# ─── فلاتر الجودة (الجديدة في v2) ───

# فلتر الأيام — أيام السبت والأحد = 0% WR
SKIP_DAYS            = ['Sat', 'Sun']

# فلتر الجلسات — أفضل ساعات UTC فقط
#   00-01 UTC: بداية الشمعة اليومية + الجلسة الآسيوية
#   15-17 UTC: London Close + NY AM overlap
#   None = جميع الساعات (أقل ربح لكن أكثر صفقات)
ALLOWED_HOURS        = {0, 1, 15, 16, 17}

# فلتر الـ Retrace — أقصى مسافة دخول تحت displacement high
#   إذا الدخول بعيد عن الـ high = السيت اب ضعيف
#   الفائزين كلهم retrace < 30%
MAX_RETRACE_PCT      = 30.0

# فلتر الـ Risk% — أقصى خطر كنسبة من سعر الدخول
#   risk% < 0.12% = ستوب ضيق = دخول ممتاز
#   risk% > 0.12% = ستوب واسع = دخول سيئ
MAX_RISK_PCT         = 0.12

# فلتر الـ FVG — أقل حجم FVG (%)
MIN_FVG_SIZE_PCT     = 0.08

# فلتر الـ R:R — أقل Target R مقبول
MIN_R_TARGET         = 5

# فلتر الإزاحة — أقل نسبة إزاحة
MIN_DISPLACEMENT_PCT = 0.20

# ─── إعداد Deduplication ───
DEDUP_MODE           = 'largest_range'

# ─── إعداد OTE Overlap ───
REQUIRE_OTE_OVERLAP  = False

# ─── مسار التقارير ───
REPORT_DIR = '/home/user/project/SCALP_SWEEP_BRANCH/scalping_mm3x/'
