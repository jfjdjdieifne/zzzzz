#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════
  NUCLEAR SCALP MM_3.5x v2 — التشغيل الرئيسي
  يشغّل المحرك الآلي المصلح ويولّد التقرير
═══════════════════════════════════════════════════════════
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import *
from data_loader import load_all
from strategy import run_strategy
from backtest import analyze_trades, generate_report, generate_csv


def main():
    print("\n" + "=" * 70)
    print("  NUCLEAR SCALP MM_3.5x v2")
    print("=" * 70)

    # ─── تحميل البيانات ───
    print("\n  Loading data...")
    c15m, c5m = load_all(DATA_15M, DATA_5M)
    print(f"  15M: {len(c15m)} candles | 5M: {len(c5m)} candles")
    print(f"  15M: {c15m[0]['dt']} -> {c15m[-1]['dt']}")

    # ─── الإعدادات ───
    print(f"\n  Config:")
    print(f"     Session:     {ALLOWED_HOURS if ALLOWED_HOURS else 'All hours'}")
    print(f"     Skip days:   {SKIP_DAYS}")
    print(f"     Retrace:     <= {MAX_RETRACE_PCT}%")
    print(f"     Risk%:       <= {MAX_RISK_PCT}%")
    print(f"     FVG:         >= {MIN_FVG_SIZE_PCT}%")
    print(f"     Target R:    >= {MIN_R_TARGET}R")
    print(f"     MM Multi:    {MM_MULTIPLIER}x")

    # ─── تشغيل المحرك ───
    print(f"\n  Running auto engine...")
    trades = run_strategy(c15m, c5m)
    print(f"  {len(trades)} trades found")

    if not trades:
        print("  No trades!")
        return

    # ─── التحليل ───
    result = analyze_trades(trades)

    # ─── التقرير ───
    report_file = os.path.join(REPORT_DIR, 'REPORT_v2.txt')
    generate_report(trades, report_file)

    csv_file = os.path.join(REPORT_DIR, 'TRADES_v2.csv')
    generate_csv(trades, csv_file)

    # ─── المقارنة مع v1 ───
    wr_str = f"{result['wr']:.1f}%"
    tr_str = f"{result['total_r']:+.1f}R"
    mo_str = f"{result['monthly']:+.1f}%"
    dd_str = f"{result['max_dd']:.1f}%"
    bal_str = f"${result['balance']:.2f}"

    print(f"\n{'=' * 70}")
    print("  v1 vs v2 comparison")
    print(f"{'=' * 70}")
    print(f"  {'Metric':<20} {'v1 (old)':<20} {'v2 (fixed)':<20}")
    print(f"  {'-'*20} {'-'*20} {'-'*20}")
    print(f"  {'Trades':<20} {'51':<20} {len(trades):<20}")
    print(f"  {'Win Rate':<20} {'8%':<20} {wr_str:<20}")
    print(f"  {'Total R':<20} {'+4.6R':<20} {tr_str:<20}")
    print(f"  {'Monthly':<20} {'+0.8%':<20} {mo_str:<20}")
    print(f"  {'Max DD':<20} {'~25%':<20} {dd_str:<20}")
    print(f"  {'Balance':<20} {'$100.85':<20} {bal_str:<20}")

    print(f"\n  Done!")


if __name__ == '__main__':
    main()
