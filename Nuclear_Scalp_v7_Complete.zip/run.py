#!/usr/bin/env python3
"""
☢️ NUCLEAR SCALP v7 — مشغّل التيست الحي
=========================================

استعمال:
  python3 run.py                       # تختبر كل البريسيتات
  python3 run.py --preset recommended  # تختبر بريسيت محدد
  python3 run.py --scan                # مسح السوق الحالي بس
  python3 run.py --refresh             # يجيب بيانات حية من OKX
"""

import sys, os, csv, json, urllib.request, time
from datetime import datetime, timezone
from collections import defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from strategy import (
    load_15m, load_5m, find_swing_points,
    detect_setups_15m, detect_setups_5m,
    find_entry_enhanced, execute_trade_v7, passes_filters,
    run_strategy_v7, analyze_dynamic, analyze_fixed
)
from config import PRESETS, BASE_PARAMS


def refresh_okx_data(data_dir):
    """يجيب بيانات حية من OKX API ويدمجها"""
    print("📡 جاري جلب البيانات الحية من OKX...")

    for bar, total in [('15m', 3000), ('5m', 2500)]:
        all_candles = []
        after = ''
        while len(all_candles) < total:
            limit = min(300, total - len(all_candles))
            url = f'https://www.okx.com/api/v5/market/candles?instId=BTC-USDT&bar={bar}&limit={limit}'
            if after: url += f'&after={after}'
            try:
                resp = urllib.request.urlopen(
                    urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'}), timeout=15)
                data = json.loads(resp.read().decode())
            except Exception as e:
                print(f"  ⚠️ خطأ: {e}"); break
            if data.get('code') != '0' or not data['data']: break
            all_candles.extend(data['data'])
            after = data['data'][-1][0]
            if len(data['data']) < limit: break
            time.sleep(0.3)

        all_candles.sort(key=lambda x: int(x[0]))

        if bar == '15m':
            existing = {}
            path = os.path.join(data_dir, 'BTCUSDT_15m_OKX_MERGED_LIVE.csv')
            if os.path.exists(path):
                with open(path) as f:
                    for row in csv.DictReader(f):
                        existing[int(row['timestamp'])] = row
            for c in all_candles:
                ts = int(c[0]) // 1000
                existing[ts] = {'timestamp': ts, 'open': c[1], 'high': c[2],
                                'low': c[3], 'close': c[4], 'volume': c[5]}
            out = os.path.join(data_dir, 'BTCUSDT_15m_OKX_LIVE_LATEST.csv')
            with open(out, 'w', newline='') as f:
                w = csv.DictWriter(f, ['timestamp', 'open', 'high', 'low', 'close', 'volume'])
                w.writeheader()
                for ts in sorted(existing): w.writerow(existing[ts])
            print(f"  ✅ 15M: {len(existing)} شمعة")
        else:
            existing = {}
            path = os.path.join(data_dir, 'BTCUSDT_5m_OKX_MERGED_LIVE.csv')
            if os.path.exists(path):
                with open(path) as f:
                    for row in csv.DictReader(f):
                        dt = datetime.strptime(row['datetime'].strip(), '%Y-%m-%d %H:%M').replace(tzinfo=timezone.utc)
                        existing[int(dt.timestamp())] = row
            for c in all_candles:
                ts = int(c[0]) // 1000
                dt = datetime.fromtimestamp(ts, tz=timezone.utc).strftime('%Y-%m-%d %H:%M')
                existing[ts] = {'datetime': dt, 'open': c[1], 'high': c[2],
                                'low': c[3], 'close': c[4], 'volume': c[5]}
            out = os.path.join(data_dir, 'BTCUSDT_5m_OKX_LIVE_LATEST.csv')
            with open(out, 'w', newline='') as f:
                w = csv.DictWriter(f, ['datetime', 'open', 'high', 'low', 'close', 'volume'])
                w.writeheader()
                for ts in sorted(existing): w.writerow(existing[ts])
            print(f"  ✅ 5M: {len(existing)} شمعة")


def scan_market(c15, c5, params):
    """مسح السوق الحالي"""
    price = c15[-1]['close']
    dt_str = c15[-1]['dt'].strftime('%Y-%m-%d %H:%M')
    print(f"\n🔭 مسح السوق — BTC ${price:,.1f}")
    print(f"   البيانات لغاية: {dt_str} UTC")

    swing_highs, swing_lows = find_swing_points(c15)
    setups = detect_setups_15m(c15, swing_highs, swing_lows, {**BASE_PARAMS, **params})

    recent_ts = c15[-1]['ts'] - 72 * 3600
    recent = [s for s in setups if c15[s['setup_idx']]['ts'] >= recent_ts]

    if recent:
        for s in recent:
            dt = c15[s['setup_idx']]['dt']
            in_fvg = s['fvg']['bottom'] <= price <= s['fvg']['top']
            status = "⚡ داخل FVG — راقب دخول!" if in_fvg else \
                     "⏳ فوق FVG — بانتظار تراجع" if price > s['fvg']['top'] else \
                     "⛔ تحت FVG — فات الأوان"
            print(f"\n  📍 سيت أب {dt.strftime('%m-%d %H:%M')} UTC")
            print(f"     Sweep: ${s['sweep_price']:.0f} → Displacement: ${s['disp_high']:.0f}")
            print(f"     FVG: ${s['fvg']['bottom']:.0f} → ${s['fvg']['top']:.0f}")
            print(f"     الحالة: {status}")
    else:
        if setups:
            last = setups[-1]
            hours = (c15[-1]['ts'] - c15[last['setup_idx']]['ts']) / 3600
            print(f"\n  ℹ️ ما في سيت أبات بآخر 72 ساعة")
            print(f"  آخر سيت أب: {c15[last['setup_idx']]['dt'].strftime('%m-%d %H:%M')} ({hours:.0f} ساعة مضت)")
        else:
            print("\n  ما في سيت أبات")

    print(f"\n  💡 نصيحة: راقب شارت 15M على TradingView (OKX BTCUSDT)")
    print(f"  وانتظر: sweep + displacement + FVG → دخول 5M dip hunter")


if __name__ == '__main__':
    print("☢️ NUCLEAR SCALP v7 — 5 تعديلات جوهرية")
    print("=" * 90)

    do_refresh = '--refresh' in sys.argv
    do_scan = '--scan' in sys.argv
    preset_name = None
    for a in sys.argv[1:]:
        if a.startswith('--preset='): preset_name = a.split('=')[1]

    data_dir = '/home/user/project/data'

    if do_refresh:
        refresh_okx_data(data_dir)

    p15 = os.path.join(data_dir, 'BTCUSDT_15m_OKX_LIVE_LATEST.csv' if do_refresh else 'BTCUSDT_15m_OKX_MERGED_LIVE.csv')
    p5 = os.path.join(data_dir, 'BTCUSDT_5m_OKX_LIVE_LATEST.csv' if do_refresh else 'BTCUSDT_5m_OKX_MERGED_LIVE.csv')

    c15 = load_15m(p15)
    c5 = load_5m(p5)
    print(f"📊 15M: {len(c15)} شمعة | 5M: {len(c5)} شمعة | BTC: ${c15[-1]['close']:,.1f}")

    if do_scan:
        scan_market(c15, c5, PRESETS['recommended'])
        sys.exit(0)

    if preset_name:
        if preset_name not in PRESETS:
            print(f"❌ بريسيت غلط: {preset_name}")
            print(f"   المتوفر: {list(PRESETS.keys())}")
            sys.exit(1)
        presets_to_run = {preset_name: PRESETS[preset_name]}
    else:
        presets_to_run = PRESETS

    # تختبر كل البريسيتات
    print(f"\n  {'البريسيت':<20} {'#':>3} {'WR':>5} {'R':>8} {'شهرياً':>8} {'DD':>6} {'PF':>6} {'Score':>6} {'$100→':>8}")
    print(f"  {'─'*80}")

    all_results = []

    for name, preset in presets_to_run.items():
        params = {**BASE_PARAMS, **preset}
        try:
            trades = run_strategy_v7(c15, c5, params)
            s = analyze_dynamic(trades)

            if s['trades'] == 0:
                print(f"  {name:<20} {'0':>3}")
                continue

            score = s['monthly'] / max(s['max_dd'], 0.1)
            print(f"  {name:<20} {s['trades']:>3} {s['wr']:>4.0f}% {s['total_r']:>+7.1f}R "
                  f"{s['monthly']:>+7.1f}% {s['max_dd']:>5.1f}% {s['pf']:>5.1f} {score:>5.1f} ${s['balance']:>6.1f}")
            all_results.append((name, s, trades, params))
        except Exception as e:
            import traceback
            print(f"  {name:<20} خطأ: {e}")
            traceback.print_exc()

    # أفضل بريسيت بالتفصيل
    if all_results:
        best = sorted(all_results, key=lambda x: x[1]['monthly'], reverse=True)[0]
        name, s, trades, params = best

        print(f"\n{'='*120}")
        print(f"📋 تفاصيل الصفقات — {name} ({s['monthly']:+.1f}% شهرياً)")
        print(f"{'='*120}")

        for i, t in enumerate(trades):
            emoji = "✅" if t['r_multiple'] > 0 else "❌"
            session = "🇯🇵أسيان" if t.get('is_asian') else "🇬🇧لندن" if t.get('is_london') else "🌍أخرى"
            deep = "DEEP" if t.get('deep_dip') else ""
            risk = t.get('risk_per_trade', 1.5)

            print(f"  #{i+1} {emoji} {t['entry_dt'].strftime('%m-%d %H:%M')} {session} "
                  f"دخول=${t['entry_price']:.0f} ستوب=${t['sl_price']:.0f} تارغت=${t['tp_price']:.0f} "
                  f"MFE={t.get('mfe_r',0):.1f}R ريسك={risk:.1f}% "
                  f"نتيجة={t['r_multiple']:+.1f}R {t['result']} {deep}")

    # مسح السوق
    scan_market(c15, c5, PRESETS.get(preset_name, PRESETS['recommended']))

    print(f"\n✅ انتهى — {c15[-1]['dt'].strftime('%Y-%m-%d %H:%M')} UTC")
