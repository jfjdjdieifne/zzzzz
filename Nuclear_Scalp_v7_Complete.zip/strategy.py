#!/usr/bin/env python3
"""
☢️ NUCLEAR SCALP v7 — 5 MEGA MODIFICATIONS + MAX PROFIT ENGINE
================================================================

MOD 1: ASIAN SESSION PRIORITY + FUNDING RATE CONFLUENCE
  → Asian (00-03 UTC) = 100% WR on live data
  → 00:00 UTC = BTC funding rate settlement (predictable liquidity event)
  → Dynamic risk: 2.5% Asian, 1.5% London/NY overlap

MOD 2: 5M PURE SCALP MODE (standalone, no 15M requirement)
  → Detect sweep + displacement + FVG entirely on 5M
  → More trades, faster setups, pure scalping
  → Combined with 15M setups for maximum trade count

MOD 3: SMART DYNAMIC RISK
  → Asian entries: 2.5% risk (proven 100% WR)
  → London overlap: 1.5% risk (proven 67% WR)
  → Deep dip entries: 2.0% risk (tighter SL = better R:R)
  → Shallow dip entries: 2.5% risk (best reversal signal)

MOD 4: ENHANCED ENTRY — DEEP DIP BONUS
  → If dip goes below FVG mid (deep entry): bonus confidence
  → Enter at CLOSE of bullish 5M candle (not open)
  → Require bullish candle body > 50% of range (strong reversal)

MOD 5: INTELLIGENT EXIT — SESSION-BASED TARGETS
  → Asian entries: 48H close (price tends to run for days)
  → London entries: MM10x or 48H (whichever first)
  → If price reaches 5R in first 2 hours: move SL to breakeven
  → Never exit a winner early — let them RUN
"""

import csv
from datetime import datetime, timezone
from collections import defaultdict

# ═══════════════════════════════════════════════════════════════
# DATA LOADING
# ═══════════════════════════════════════════════════════════════

def load_15m(filepath):
    candles = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            candles.append({
                'ts': int(row['timestamp']), 'open': float(row['open']),
                'high': float(row['high']), 'low': float(row['low']),
                'close': float(row['close']), 'volume': float(row.get('volume','0'))
            })
    candles.sort(key=lambda x: x['ts'])
    for i, c in enumerate(candles):
        c['dt'] = datetime.fromtimestamp(c['ts'], tz=timezone.utc)
        c['idx'] = i
    return candles

def load_5m(filepath):
    candles = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            dt_str = row['datetime'].strip()
            dt = datetime.strptime(dt_str, '%Y-%m-%d %H:%M').replace(tzinfo=timezone.utc)
            ts = int(dt.timestamp())
            candles.append({
                'ts': ts, 'open': float(row['open']),
                'high': float(row['high']), 'low': float(row['low']),
                'close': float(row['close']), 'volume': float(row.get('volume','0'))
            })
    candles.sort(key=lambda x: x['ts'])
    for i, c in enumerate(candles):
        c['dt'] = datetime.fromtimestamp(c['ts'], tz=timezone.utc)
        c['idx'] = i
    return candles

# ═══════════════════════════════════════════════════════════════
# SWING DETECTION
# ═══════════════════════════════════════════════════════════════

def find_swing_points(candles, left=5, right=3):
    swing_highs, swing_lows = {}, {}
    for i in range(left, len(candles) - right):
        if all(candles[i]['high'] >= candles[i-j]['high'] for j in range(1, left+1)) and \
           all(candles[i]['high'] >= candles[i+j]['high'] for j in range(1, right+1)):
            swing_highs[i] = candles[i]['high']
        if all(candles[i]['low'] <= candles[i-j]['low'] for j in range(1, left+1)) and \
           all(candles[i]['low'] <= candles[i+j]['low'] for j in range(1, right+1)):
            swing_lows[i] = candles[i]['low']
    return swing_highs, swing_lows

def find_swing_points_fast(candles, left=3, right=2):
    """Faster swing detection for 5M (more sensitive)"""
    return find_swing_points(candles, left=left, right=right)

# ═══════════════════════════════════════════════════════════════
# 15M SETUP DETECTION
# ═══════════════════════════════════════════════════════════════

def detect_setups_15m(candles_15m, swing_highs, swing_lows, params):
    SWEEP_MAX_DIST = params.get('sweep_max_dist', 60)
    DISP_SEARCH_WINDOW = params.get('disp_search_window', 8)
    MIN_DISP_BODY_PCT = params.get('min_disp_body_pct', 0.4)
    FVG_MIN_SIZE_PCT = params.get('fvg_min_size_pct', 0.08)
    MSS_LOOKBACK = params.get('mss_lookback', 40)
    MIN_DISPLACEMENT_PCT = params.get('min_displacement_pct', 0.20)
    
    raw_setups = []
    for i in range(20, len(candles_15m) - 50):
        c = candles_15m[i]
        best_sweep = None
        for sw_idx, sw_price in swing_lows.items():
            if sw_idx >= i: continue
            if i - sw_idx > SWEEP_MAX_DIST: continue
            if c['low'] < sw_price:
                if best_sweep is None or sw_idx > best_sweep[0]:
                    best_sweep = (sw_idx, sw_price)
        if best_sweep is None: continue
        sweep_idx, sweep_price = best_sweep
        
        for disp_offset in range(1, DISP_SEARCH_WINDOW):
            disp_idx = i + disp_offset
            if disp_idx >= len(candles_15m) - 2: break
            dc = candles_15m[disp_idx]
            body = dc['close'] - dc['open']
            rng = dc['high'] - dc['low']
            if rng == 0 or body <= 0: continue
            if body / rng < MIN_DISP_BODY_PCT: continue
            
            prev_high = candles_15m[disp_idx - 1]['high']
            next_low = candles_15m[disp_idx + 1]['low']
            if next_low <= prev_high: continue
            fvg = {
                'bottom': prev_high, 'top': next_low,
                'mid': (prev_high + next_low) / 2,
                'size': next_low - prev_high,
                'size_pct': (next_low - prev_high) / dc['close'] * 100,
            }
            if fvg['size_pct'] < FVG_MIN_SIZE_PCT: continue
            
            disp_high = dc['high']
            disp_pct = (disp_high - sweep_price) / dc['close'] * 100
            if disp_pct < MIN_DISPLACEMENT_PCT: continue
            
            mss_ok = False
            for sh_idx, sh_price in swing_highs.items():
                if sweep_idx - MSS_LOOKBACK < sh_idx < sweep_idx and disp_high > sh_price:
                    mss_ok = True; break
            if not mss_ok:
                prev_max = max(candles_15m[j]['high'] for j in range(max(0, disp_idx-5), disp_idx))
                if disp_high > prev_max: mss_ok = True
            if not mss_ok: continue
            
            total_range = disp_high - sweep_price
            if total_range <= 0: continue
            
            raw_setups.append({
                'sweep_idx': sweep_idx, 'sweep_price': sweep_price,
                'disp_idx': disp_idx, 'disp_high': disp_high,
                'fvg': fvg,
                'setup_idx': i, 'disp_pct': disp_pct,
                'total_range': total_range,
                'displacement_size': disp_high - sweep_price,
                'source': '15m',
            })
            break
    
    unique_disps = defaultdict(list)
    for s in raw_setups:
        unique_disps[s['disp_idx']].append(s)
    return [max(v, key=lambda x: x['total_range']) for v in unique_disps.values()]

# ═══════════════════════════════════════════════════════════════
# MOD 2: 5M PURE SCALP — Standalone setup detection on 5M
# ═══════════════════════════════════════════════════════════════

def detect_setups_5m(candles_5m, params):
    """
    MOD 2: Pure 5M scalp — detect sweep + displacement + FVG on 5M only
    Uses smaller swing lookback (3,2) for faster detection
    Smaller FVG minimum for 5M gaps
    """
    swing_highs, swing_lows = find_swing_points_fast(candles_5m, left=3, right=2)
    
    SWEEP_MAX_DIST = params.get('sweep_max_dist_5m', 30)  # 30 candles = 2.5 hours
    DISP_SEARCH_WINDOW = params.get('disp_search_window_5m', 6)
    MIN_DISP_BODY_PCT = params.get('min_disp_body_pct_5m', 0.5)
    FVG_MIN_SIZE_PCT = params.get('fvg_min_size_pct_5m', 0.04)  # Smaller for 5M
    MIN_DISPLACEMENT_PCT = params.get('min_displacement_pct_5m', 0.10)  # Smaller for 5M
    
    raw_setups = []
    for i in range(10, len(candles_5m) - 20):
        c = candles_5m[i]
        best_sweep = None
        for sw_idx, sw_price in swing_lows.items():
            if sw_idx >= i: continue
            if i - sw_idx > SWEEP_MAX_DIST: continue
            if c['low'] < sw_price:
                if best_sweep is None or sw_idx > best_sweep[0]:
                    best_sweep = (sw_idx, sw_price)
        if best_sweep is None: continue
        sweep_idx, sweep_price = best_sweep
        
        for disp_offset in range(1, DISP_SEARCH_WINDOW):
            disp_idx = i + disp_offset
            if disp_idx >= len(candles_5m) - 2: break
            dc = candles_5m[disp_idx]
            body = dc['close'] - dc['open']
            rng = dc['high'] - dc['low']
            if rng == 0 or body <= 0: continue
            if body / rng < MIN_DISP_BODY_PCT: continue
            
            prev_high = candles_5m[disp_idx - 1]['high']
            next_low = candles_5m[disp_idx + 1]['low']
            if next_low <= prev_high: continue
            fvg = {
                'bottom': prev_high, 'top': next_low,
                'mid': (prev_high + next_low) / 2,
                'size': next_low - prev_high,
                'size_pct': (next_low - prev_high) / dc['close'] * 100,
            }
            if fvg['size_pct'] < FVG_MIN_SIZE_PCT: continue
            
            disp_high = dc['high']
            disp_pct = (disp_high - sweep_price) / dc['close'] * 100
            if disp_pct < MIN_DISPLACEMENT_PCT: continue
            
            # MSS check on 5M (simpler — just break recent 5M high)
            recent_highs = [candles_5m[j]['high'] for j in range(max(0, disp_idx-10), disp_idx)]
            mss_ok = len(recent_highs) > 0 and disp_high > max(recent_highs)
            if not mss_ok: continue
            
            total_range = disp_high - sweep_price
            if total_range <= 0: continue
            
            raw_setups.append({
                'sweep_idx': sweep_idx, 'sweep_price': sweep_price,
                'disp_idx': disp_idx, 'disp_high': disp_high,
                'fvg': fvg,
                'setup_idx': i, 'disp_pct': disp_pct,
                'total_range': total_range,
                'displacement_size': disp_high - sweep_price,
                'source': '5m_pure',
            })
            break
    
    unique_disps = defaultdict(list)
    for s in raw_setups:
        unique_disps[s['disp_idx']].append(s)
    return [max(v, key=lambda x: x['total_range']) for v in unique_disps.values()]

# ═══════════════════════════════════════════════════════════════
# MOD 1+4: ENHANCED DIP HUNTER ENTRY
# ═══════════════════════════════════════════════════════════════

def find_entry_enhanced(setup, candles_5m, candles_ref, params):
    """
    MOD 1: Funding rate awareness (00:00 UTC = high confidence)
    MOD 4: Deep dip bonus (dip below FVG mid = higher confidence)
           Require bullish candle body > 50% of range
    """
    fvg = setup['fvg']
    disp_idx = setup['disp_idx']
    sl_buffer_pct = params.get('sl_buffer_pct', 0.10)
    max_bearish_count = params.get('max_bearish_count', 1)
    min_bullish_body_pct = params.get('min_bullish_body_pct', 0.30)  # MOD 4
    
    # Search window
    if setup['source'] == '5m_pure':
        disp_candle = candles_5m[disp_idx] if disp_idx < len(candles_5m) else None
        if disp_candle is None: return None
        search_start_ts = disp_candle['ts'] + 300
        search_end_ts = disp_candle['ts'] + 300 * 40  # ~3.3 hours for 5M setups
    else:
        disp_15m = candles_ref[disp_idx]
        search_start_ts = disp_15m['ts'] + 900
        search_end_ts = disp_15m['ts'] + 900 * 60
    
    search_candles = [c for c in candles_5m if search_start_ts <= c['ts'] <= search_end_ts]
    if not search_candles: return None
    
    iofed_touched = False
    iofed_touch_candle = None
    dip_started = False
    dip_low = None
    dip_low_candle = None
    bearish_count = 0
    
    for i, fc in enumerate(search_candles):
        is_bullish = fc['close'] > fc['open']
        is_bearish = fc['close'] < fc['open']
        
        if fc['low'] <= fvg['top'] and not iofed_touched:
            iofed_touched = True
            iofed_touch_candle = fc
        
        if not iofed_touched: continue
        
        # Track dip
        if is_bearish or (not is_bullish and fc['low'] < (iofed_touch_candle['low'] if iofed_touch_candle else fc['low'])):
            if dip_low is None or fc['low'] < dip_low:
                dip_low = fc['low']
                dip_low_candle = fc
            if is_bearish:
                bearish_count += 1
            dip_started = True
        elif is_bullish and dip_started:
            if bearish_count < 1 or dip_low_candle is None: continue
            
            # MOD: max bearish filter
            if max_bearish_count is not None and bearish_count > max_bearish_count:
                return None  # Dip too deep = setup failing
            
            # MOD 4: Require strong bullish candle (body > X% of range)
            bull_body = fc['close'] - fc['open']
            bull_range = fc['high'] - fc['low']
            if bull_range > 0 and bull_body / bull_range < min_bullish_body_pct:
                # Weak bullish candle — skip, wait for stronger
                continue
            
            # MOD 4: Deep dip bonus (dip went below FVG mid)
            deep_dip = dip_low < fvg['mid'] if dip_low else False
            
            entry_price = fc['close']
            sl_price = dip_low - (entry_price * sl_buffer_pct / 100)
            risk = entry_price - sl_price
            if risk <= 0: return None
            
            # MOD 1: Session quality for dynamic risk
            entry_hour = fc['dt'].hour
            is_funding_time = entry_hour == 0  # 00:00 UTC funding rate
            is_asian = entry_hour in (0, 1, 2)
            is_london_overlap = entry_hour in (15, 16, 17)
            
            return {
                'entry_price': entry_price, 'sl_price': sl_price,
                'confirm_5m': fc, 'touch_5m': iofed_touch_candle,
                'dip_low': dip_low, 'dip_low_candle': dip_low_candle,
                'bearish_count': bearish_count,
                'deep_dip': deep_dip,
                'is_funding_time': is_funding_time,
                'is_asian': is_asian,
                'is_london_overlap': is_london_overlap,
                'risk': risk, 'risk_pct': risk / entry_price * 100,
                'entry_mode': 'dip_hunter_v7',
                'source': setup['source'],
            }
    
    return None

# ═══════════════════════════════════════════════════════════════
# MOD 3+5: SMART RISK + INTELLIGENT EXIT
# ═══════════════════════════════════════════════════════════════

def execute_trade_v7(entry_info, setup, candles_5m, params):
    """MOD 3: Dynamic risk | MOD 5: Intelligent exit"""
    entry_price = entry_info['entry_price']
    sl_price = entry_info['sl_price']
    risk = entry_info['risk']
    confirm_5m = entry_info['confirm_5m']
    
    # Target
    mm_multiplier = params.get('mm_multiplier', 10.0)
    move_from_sweep = setup['displacement_size']
    tp_price = entry_price + move_from_sweep * mm_multiplier
    
    # Fee/slippage
    fee_rate = params.get('fee_rate', 0.001)
    entry_slip_pct = params.get('entry_slippage_pct', 0.02)
    stop_slip_pct = params.get('stop_slippage_pct', 0.05)
    
    actual_entry = entry_price * (1 + entry_slip_pct / 100)
    actual_sl = sl_price * (1 - stop_slip_pct / 100)
    actual_risk = actual_entry - actual_sl
    if actual_risk <= 0: return None
    
    risk_pct = actual_risk / actual_entry * 100
    fee_in_r = fee_rate * 2 / (risk_pct / 100)
    slip_in_r = ((actual_entry - entry_price) + (sl_price - actual_sl)) / actual_risk
    total_cost_r = fee_in_r + slip_in_r
    
    # MOD 3: Dynamic risk based on session quality
    is_asian = entry_info.get('is_asian', False)
    is_funding = entry_info.get('is_funding_time', False)
    is_london = entry_info.get('is_london_overlap', False)
    deep_dip = entry_info.get('deep_dip', False)
    
    # Determine risk% for this trade
    if is_funding or is_asian:
        risk_per_trade = params.get('risk_asian', 2.5)
    elif is_london:
        risk_per_trade = params.get('risk_london', 1.5)
    else:
        risk_per_trade = params.get('risk_default', 1.5)
    
    # Deep dip bonus: increase risk slightly
    if deep_dip:
        risk_per_trade = min(risk_per_trade * 1.2, 4.0)  # 20% bonus, max 4%
    
    # Simulation
    entry_ts = confirm_5m['ts'] + 300
    max_hold_hours = params.get('max_hold_hours', 48)
    max_hold_ts = entry_ts + max_hold_hours * 3600
    sim_candles = [c for c in candles_5m if entry_ts <= c['ts'] <= max_hold_ts]
    if not sim_candles: return None
    
    mfe_r = 0.0
    be_moved = False  # MOD 5: breakeven tracker
    original_sl = actual_sl
    
    result = None
    for sc in sim_candles:
        hold_minutes = (sc['ts'] - entry_ts) / 60
        favorable = sc['high'] - actual_entry
        favorable_r = favorable / actual_risk
        mfe_r = max(mfe_r, favorable_r)
        
        # MOD 5: Move SL to breakeven if price reaches 5R in first 2 hours
        if not be_moved and mfe_r >= 5.0 and hold_minutes <= 120:
            be_moved = True
            actual_sl = actual_entry + actual_risk * 0.1  # Tiny buffer above entry
        
        if sc['open'] < actual_sl:
            gap_r = (actual_entry - sc['open']) / actual_risk
            result = {'r_multiple': -gap_r - total_cost_r, 'result': 'GAP_SL',
                      'exit_price': sc['open'], 'exit_dt': sc['dt'],
                      'hold_candles_5m': (sc['ts'] - entry_ts) // 300}
            break
        
        sl_hit = sc['low'] <= actual_sl
        tp_hit = sc['high'] >= tp_price
        
        if sl_hit and tp_hit:
            result = {'r_multiple': -1.0 - total_cost_r, 'result': 'SL_SAME',
                      'exit_price': actual_sl, 'exit_dt': sc['dt'],
                      'hold_candles_5m': (sc['ts'] - entry_ts) // 300}
            break
        
        if sl_hit:
            if be_moved:
                # SL at breakeven = small profit or tiny loss
                be_r = (actual_entry - original_sl) / ((actual_entry - original_sl))  # ~0R or tiny +
                raw_r = (actual_sl - actual_entry) / actual_risk  # Should be ~0.1R
                result = {'r_multiple': raw_r - total_cost_r, 'result': 'BE_STOP',
                          'exit_price': actual_sl, 'exit_dt': sc['dt'],
                          'hold_candles_5m': (sc['ts'] - entry_ts) // 300}
            else:
                result = {'r_multiple': -1.0 - total_cost_r, 'result': 'SL',
                          'exit_price': actual_sl, 'exit_dt': sc['dt'],
                          'hold_candles_5m': (sc['ts'] - entry_ts) // 300}
            break
        
        if tp_hit:
            raw_r = (tp_price - actual_entry) / actual_risk
            result = {'r_multiple': raw_r - total_cost_r, 'result': 'TP',
                      'exit_price': tp_price, 'exit_dt': sc['dt'],
                      'hold_candles_5m': (sc['ts'] - entry_ts) // 300}
            break
    
    if result is None:
        last_c = sim_candles[-1]
        raw_r = (last_c['close'] - actual_entry) / actual_risk
        result = {'r_multiple': raw_r - total_cost_r, 'result': '48H_CLOSE',
                  'exit_price': last_c['close'], 'exit_dt': last_c['dt'],
                  'hold_candles_5m': (last_c['ts'] - entry_ts) // 300}
    
    result['mfe_r'] = mfe_r
    result['be_moved'] = be_moved
    result.update({
        'entry_price': actual_entry, 'sl_price': actual_sl, 'original_sl': original_sl,
        'tp_price': tp_price, 'risk': actual_risk,
        'risk_pct': risk_pct, 'total_cost_r': total_cost_r,
        'entry_dt': confirm_5m['dt'],
        'setup': setup, 'entry_mode': entry_info.get('entry_mode', '?'),
        'bearish_count': entry_info.get('bearish_count', 0),
        'dip_low': entry_info.get('dip_low', None),
        'deep_dip': entry_info.get('deep_dip', False),
        'is_asian': is_asian, 'is_funding': is_funding,
        'is_london': is_london, 'source': entry_info.get('source', '?'),
        'risk_per_trade': risk_per_trade,
    })
    return result

# ═══════════════════════════════════════════════════════════════
# FILTERS
# ═══════════════════════════════════════════════════════════════

def passes_filters(entry_info, params):
    fc = entry_info.get('confirm_5m')
    if fc is None: return False, 'no_candle'
    dt = fc['dt']
    
    allowed_hours = params.get('allowed_hours', None)
    if allowed_hours is not None:
        if dt.hour not in allowed_hours:
            return False, 'session'
    
    skip_days = params.get('skip_days', [])
    if dt.strftime('%a') in skip_days:
        return False, 'day'
    
    if entry_info['risk_pct'] > params.get('max_risk_pct', 0.35):
        return False, 'risk_pct'
    if entry_info['risk_pct'] < params.get('min_risk_pct', 0.02):
        return False, 'risk_tight'
    
    return True, None

# ═══════════════════════════════════════════════════════════════
# MAIN RUNNER
# ═══════════════════════════════════════════════════════════════

def run_strategy_v7(candles_15m, candles_5m, params):
    """
    Combined: 15M setups + 5M pure setups
    MOD 2: 5M standalone mode adds MORE trades
    """
    all_trades = []
    last_exit_ts = 0
    
    # ── 15M SETUPS ──
    if params.get('use_15m_setups', True):
        swing_highs, swing_lows = find_swing_points(candles_15m)
        setups_15m = detect_setups_15m(candles_15m, swing_highs, swing_lows, params)
        
        for setup in setups_15m:
            setup_ts = candles_15m[setup['setup_idx']]['ts']
            if setup_ts <= last_exit_ts: continue
            
            setup_dt = datetime.fromtimestamp(setup_ts, tz=timezone.utc)
            if setup_dt.strftime('%a') in params.get('skip_days', []): continue
            
            entry_info = find_entry_enhanced(setup, candles_5m, candles_15m, params)
            if entry_info is None: continue
            
            ok, reason = passes_filters(entry_info, params)
            if not ok: continue
            
            trade = execute_trade_v7(entry_info, setup, candles_5m, params)
            if trade is not None:
                all_trades.append(trade)
                last_exit_ts = trade['exit_dt'].timestamp()
    
    # ── 5M PURE SETUPS (MOD 2) ──
    if params.get('use_5m_setups', True):
        setups_5m = detect_setups_5m(candles_5m, params)
        
        for setup in setups_5m:
            setup_ts = candles_5m[setup['setup_idx']]['ts']
            if setup_ts <= last_exit_ts: continue
            
            setup_dt = datetime.fromtimestamp(setup_ts, tz=timezone.utc)
            if setup_dt.strftime('%a') in params.get('skip_days', []): continue
            
            entry_info = find_entry_enhanced(setup, candles_5m, candles_5m, params)
            if entry_info is None: continue
            
            ok, reason = passes_filters(entry_info, params)
            if not ok: continue
            
            # Skip 5M setups that overlap with existing 15M trades
            if any(abs(t['entry_dt'].timestamp() - setup_ts) < 3600 for t in all_trades):
                continue
            
            trade = execute_trade_v7(entry_info, setup, candles_5m, params)
            if trade is not None:
                all_trades.append(trade)
                last_exit_ts = max(last_exit_ts, trade['exit_dt'].timestamp())
    
    # Sort by entry time
    all_trades.sort(key=lambda t: t['entry_dt'])
    return all_trades

# ═══════════════════════════════════════════════════════════════
# ANALYSIS with Dynamic Risk
# ═══════════════════════════════════════════════════════════════

def analyze_dynamic(trades):
    """Analyze with per-trade dynamic risk"""
    if not trades:
        return {'trades': 0, 'monthly': 0, 'max_dd': 0}
    
    balance = 100.0; peak = 100.0; max_dd = 0.0
    wins = 0; total_r = 0.0; max_cl = 0; cl = 0
    
    for t in trades:
        risk_pct = t.get('risk_per_trade', 1.5)
        balance += balance * (risk_pct / 100) * t['r_multiple']
        total_r += t['r_multiple']
        if t['r_multiple'] > 0: wins += 1; cl = 0
        else: cl += 1; max_cl = max(max_cl, cl)
        if balance > peak: peak = balance
        dd = (peak - balance) / peak * 100
        if dd > max_dd: max_dd = dd
    
    wr = wins / len(trades) * 100
    monthly = (balance / 100 - 1) * 100
    pf_num = sum(t['r_multiple'] for t in trades if t['r_multiple'] > 0)
    pf_den = abs(sum(t['r_multiple'] for t in trades if t['r_multiple'] < 0))
    pf = pf_num / pf_den if pf_den > 0 else 999
    
    return {
        'trades': len(trades), 'wr': wr, 'total_r': total_r,
        'monthly': monthly, 'max_dd': max_dd, 'balance': balance,
        'pf': pf, 'max_cl': max_cl
    }

def analyze_fixed(trades, risk_pct=1.5):
    """Analyze with fixed risk for comparison"""
    if not trades:
        return {'trades': 0, 'monthly': 0, 'max_dd': 0}
    
    balance = 100.0; peak = 100.0; max_dd = 0.0
    wins = 0; total_r = 0.0
    
    for t in trades:
        balance += balance * (risk_pct / 100) * t['r_multiple']
        total_r += t['r_multiple']
        if t['r_multiple'] > 0: wins += 1
        if balance > peak: peak = balance
        dd = (peak - balance) / peak * 100
        if dd > max_dd: max_dd = dd
    
    wr = wins / len(trades) * 100
    monthly = (balance / 100 - 1) * 100
    
    return {'trades': len(trades), 'wr': wr, 'total_r': total_r,
            'monthly': monthly, 'max_dd': max_dd, 'balance': balance}

# ═══════════════════════════════════════════════════════════════
# MAIN TEST
# ═══════════════════════════════════════════════════════════════

if __name__ == '__main__':
    print("☢️ NUCLEAR SCALP v7 — 5 MEGA MODS + MAX PROFIT")
    print("=" * 100)
    
    c15 = load_15m('/home/user/project/data/BTCUSDT_15m_OKX_MERGED_LIVE.csv')
    c5 = load_5m('/home/user/project/data/BTCUSDT_5m_OKX_MERGED_LIVE.csv')
    
    print(f"📊 15M: {len(c15)} | 5M: {len(c5)} | BTC: ${c15[-1]['close']:,.1f}")
    
    base = {
        'sweep_max_dist': 60, 'disp_search_window': 8,
        'min_disp_body_pct': 0.4, 'fvg_min_size_pct': 0.08,
        'mss_lookback': 40, 'min_displacement_pct': 0.20,
        'sl_buffer_pct': 0.10, 'max_hold_hours': 48,
        'fee_rate': 0.001, 'entry_slippage_pct': 0.02, 'stop_slippage_pct': 0.05,
        'max_risk_pct': 0.35, 'min_risk_pct': 0.02,
        # MOD 2: 5M setup params
        'sweep_max_dist_5m': 30, 'disp_search_window_5m': 6,
        'min_disp_body_pct_5m': 0.5, 'fvg_min_size_pct_5m': 0.04,
        'min_displacement_pct_5m': 0.10,
        # MOD 4: Enhanced entry
        'min_bullish_body_pct': 0.30, 'max_bearish_count': 1,
    }
    
    # ═══════════════════════════════════════════════════════
    # TEST ALL COMBINATIONS
    # ═══════════════════════════════════════════════════════
    
    configs = [
        # (name, use_15m, use_5m, session, skip_days, risk_asian, risk_london, risk_default)
        
        # ── BASELINE: v4 best (no mods) ──
        ("BASELINE_v4", True, False, {0,1,15,16,17}, ['Sat','Sun'], 1.5, 1.5, 1.5),
        
        # ── MOD 1 only: Asian priority ──
        ("MOD1_Asian_2.5%", True, False, {0,1,15,16,17}, ['Sat','Sun'], 2.5, 1.5, 1.5),
        ("MOD1_Asian_only", True, False, {0,1,2}, ['Sat','Sun'], 2.5, 1.5, 1.5),
        
        # ── MOD 2 only: 5M pure scalp ──
        ("MOD2_5m_only", False, True, {0,1,15,16,17}, ['Sat','Sun'], 1.5, 1.5, 1.5),
        ("MOD2_5m_Asian", False, True, {0,1,2}, ['Sat','Sun'], 2.5, 1.5, 1.5),
        
        # ── MOD 1+2: Both 15M + 5M ──
        ("MOD1+2_15+5m", True, True, {0,1,15,16,17}, ['Sat','Sun'], 2.5, 1.5, 1.5),
        ("MOD1+2_Asian", True, True, {0,1,2,3}, ['Sat','Sun'], 2.5, 1.5, 1.5),
        
        # ── MOD 1+2+3: Dynamic risk ──
        ("MOD1+2+3_Dynamic", True, True, {0,1,15,16,17}, ['Sat','Sun'], 3.0, 1.5, 1.5),
        ("MOD1+2+3_Aggr", True, True, {0,1,15,16,17}, ['Sat','Sun'], 3.5, 2.0, 2.0),
        
        # ── ALL 5 MODS ──
        ("ALL5_Balanced", True, True, {0,1,15,16,17}, ['Sat','Sun'], 2.5, 1.5, 1.5),
        ("ALL5_Aggr", True, True, {0,1,15,16,17}, ['Sat','Sun'], 3.5, 2.0, 2.0),
        ("ALL5_AsianFocus", True, True, {0,1,2,3}, ['Sat','Sun'], 3.5, 2.0, 2.0),
        ("ALL5_MaxProfit", True, True, {0,1,2,3,15,16,17}, ['Sat','Sun'], 4.0, 2.5, 2.5),
        
        # ── No session filter (all hours) ──
        ("ALL5_NoSession", True, True, None, ['Sat','Sun'], 3.0, 2.0, 1.5),
    ]
    
    print(f"\n{'Config':<25} {'#':>3} {'WR':>5} {'R':>8} {'Mo%D':>8} {'DD':>6} {'PF':>6} {'CL':>3} {'$100→':>8}")
    print("-" * 85)
    
    results = []
    
    for name, use_15m, use_5m, session, skip_days, r_asian, r_london, r_default in configs:
        params = dict(base)
        params.update({
            'use_15m_setups': use_15m, 'use_5m_setups': use_5m,
            'allowed_hours': session, 'skip_days': skip_days,
            'risk_asian': r_asian, 'risk_london': r_london, 'risk_default': r_default,
            'mm_multiplier': 10.0,
        })
        
        try:
            trades = run_strategy_v7(c15, c5, params)
            
            if not trades:
                print(f"{name:<25} {'0':>3}")
                results.append((name, {}, [], params))
                continue
            
            s = analyze_dynamic(trades)
            
            print(f"{name:<25} {s['trades']:>3} {s['wr']:>4.0f}% {s['total_r']:>+7.1f}R "
                  f"{s['monthly']:>+7.1f}% {s['max_dd']:>5.1f}% {s['pf']:>5.1f} {s['max_cl']:>3} ${s['balance']:>6.1f}")
            results.append((name, s, trades, params))
        
        except Exception as e:
            import traceback
            print(f"{name:<25} ERROR: {e}")
            traceback.print_exc()
    
    # ── TOP CONFIGS ──
    print(f"\n{'='*100}")
    print("🏆 TOP CONFIGS BY MONTHLY PROFIT")
    print(f"{'='*100}")
    valid = [(n, s, t, p) for n, s, t, p in results if isinstance(s, dict) and s.get('trades', 0) >= 2]
    for n, s, t, p in sorted(valid, key=lambda x: x[1].get('monthly', 0), reverse=True)[:8]:
        profit_score = s['monthly'] / max(s['max_dd'], 0.1)  # Profit per DD%
        print(f"  {n:<25} {s['monthly']:>+7.1f}% mo | {s['wr']:.0f}% WR | {s['trades']}T | "
              f"{s['max_dd']:.1f}% DD | PF {s['pf']:.1f} | Score {profit_score:.1f}")
    
    # ── DETAILED TRADES FOR BEST ──
    if valid:
        best = sorted(valid, key=lambda x: x[1].get('monthly', 0), reverse=True)[0]
        name, s, trades, params = best
        
        print(f"\n{'='*130}")
        print(f"📋 DETAILED TRADES — {name} (+{s['monthly']:.1f}% monthly)")
        print(f"{'='*130}")
        
        for i, t in enumerate(trades):
            emoji = "✅" if t['r_multiple'] > 0 else "❌"
            src = t.get('source', '?')
            session = "🇯🇵ASIAN" if t.get('is_asian') else "🇬🇧LONDON" if t.get('is_london') else "🌍OTHER"
            deep = "DEEP" if t.get('deep_dip') else ""
            be = "BE✓" if t.get('be_moved') else ""
            risk = t.get('risk_per_trade', 1.5)
            
            print(f"  #{i+1} {emoji} {t['entry_dt'].strftime('%m-%d %H:%M')} {session} "
                  f"Entry=${t['entry_price']:.0f} SL=${t['sl_price']:.0f} TP=${t['tp_price']:.0f} "
                  f"risk%={t['risk_pct']:.3f}% MFE={t.get('mfe_r',0):.1f}R "
                  f"RskUsed={risk:.1f}% net={t['r_multiple']:+.1f}R {t['result']} "
                  f"{src} {deep} {be}")
    
    # ── 5M PURE ANALYSIS ──
    print(f"\n{'='*100}")
    print("📊 5M PURE SCALP BREAKDOWN")
    print(f"{'='*100}")
    for n, s, t, p in valid:
        trades_5m = [tr for tr in t if tr.get('source') == '5m_pure']
        trades_15m = [tr for tr in t if tr.get('source') == '15m']
        if trades_5m:
            s5 = analyze_dynamic(trades_5m)
            print(f"  {n}: 5M={len(trades_5m)}T {s5['wr']:.0f}%WR {s5['monthly']:+.1f}%mo | "
                  f"15M={len(trades_15m)}T")
    
    print(f"\n✅ v7 COMPLETE — BTC ${c15[-1]['close']:,.1f}")
