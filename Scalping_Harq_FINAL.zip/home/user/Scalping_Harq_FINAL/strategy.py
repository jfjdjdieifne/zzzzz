"""
Scalping حارق - 15M بدون غش
1. قاع تم سحب سيولته بنجاح بذيل وأغلق الجسم فوق القاع السابق
2. بعدها بشمعتين أو 3 يكون دخولي
3. الأشكال:
   1- (الأقوى) شمعة ارتدادية شرائية كبيرة + بعدها إما شمعة شرائية ثانية أو شمعة بيعية (هامر مثالي بس مش ضروري)
      لازم ذيلها ما يوصل لنص الشمعة الارتدادية (أقل من النص ولو بنتفة)
      الدخول عند إغلاق شمعة الهامر والستوب تحت قاع الهامر نفسها 0.02%
      التارغت هو أول قمة قبلها يلي أسس قاع سحب السيولة قبل ذيل شمعة القمة السابقة بشوي صغيرة
"""

import csv
from datetime import datetime, timezone
from bisect import bisect_left

def load_15m(p):
    c=[]
    import csv
    with open(p) as f:
        for r in csv.DictReader(f):
            c.append({'ts':int(r['timestamp']),'open':float(r['open']),'high':float(r['high']),'low':float(r['low']),'close':float(r['close']),'volume':float(r.get('volume',0))})
    c.sort(key=lambda x:x['ts'])
    for i,x in enumerate(c): x['dt']=datetime.fromtimestamp(x['ts'], tz=timezone.utc)
    return c

def precompute_swings(candles, left, right):
    lows=[]
    highs=[]
    for i in range(left, len(candles)-right):
        is_low=all(candles[i]['low'] <= candles[i-j]['low'] for j in range(1,left+1)) and all(candles[i]['low'] <= candles[i+j]['low'] for j in range(1,right+1))
        is_high=all(candles[i]['high'] >= candles[i-j]['high'] for j in range(1,left+1)) and all(candles[i]['high'] >= candles[i+j]['high'] for j in range(1,right+1))
        if is_low: lows.append((i,candles[i]['low']))
        if is_high: highs.append((i,candles[i]['high']))
    return highs,lows

c15=load_15m('Nuclear_Scalp_v13_FINAL_COMPLETE/data/BTCUSDT_15m.csv')
end=c15[-1]['ts']
start=end-30*86400

print(f"=== Scalping حارق 15M بدون غش - آخر 30 يوم ===")
print(f"الفترة {datetime.fromtimestamp(start, tz=timezone.utc)} -> {datetime.fromtimestamp(end, tz=timezone.utc)}")
print(f"15M {len(c15)} شمعة")

# Precompute swings with right=1 (تنبؤ مبكر 15 دقيقة)
highs_15,lows_15=precompute_swings(c15, left=5, right=1)

trades=[]
last_exit=0

for i in range(20, len(c15)-20):
    if c15[i]['ts']<=last_exit or c15[i]['ts']<start or c15[i]['ts']>end:
        continue
    
    # 1. هل هذه شمعة سحب سيولة ناجح؟
    # نبحث عن قاع سابق تم سحبه
    # القاع السابق: آخر سوينغ لو قبل i
    valid_lows=[(idx,price) for idx,price in lows_15 if idx+1 < i and i-idx<=60]
    if not valid_lows:
        continue
    
    # ابحث عن أقرب قاع تم سحبه بهذه الشمعة
    sweep_candle=c15[i]
    swept=None
    for idx,price in reversed(sorted(valid_lows)):  # الأقرب أولاً
        # شرط السحب الناجح: ذيل تحت القاع + جسم يغلق فوق القاع السابق
        if sweep_candle['low'] < price and sweep_candle['close'] > price:
            swept=(idx,price)
            break
    if swept is None:
        continue
    
    sw_idx, sw_price = swept
    
    # 2. مراقبة بعدها بشمعتين أو 3 بيكون دخولي
    # نبحث في الشمعتين/الثلاثة التالية عن الشمعة الارتدادية الكبيرة + الهامر
    # الشمعة الارتدادية الكبيرة: شمعة شرائية كبيرة
    reversal_idx=None
    reversal_candle=None
    for r in range(1,4):  # شمعتين أو 3 بعد السحب
        if i+r >= len(c15)-2:
            break
        c=c15[i+r]
        body=c['close']-c['open']
        rng=c['high']-c['low']
        if rng==0: continue
        # شمعة ارتدادية شرائية كبيرة: جسم > 50% من المدى + صاعدة
        if body>0 and body/rng >= 0.50:
            reversal_idx=i+r
            reversal_candle=c
            break
    
    if reversal_idx is None:
        continue
    
    # 3. الأشكال - الأقوى
    # بعد الارتدادية الكبيرة، إما شمعة شرائية ثانية أو شمعة بيعية (هامر)
    # الهامر: ذيلها ما يوصل لنص الشمعة الارتدادية
    # نص الارتدادية = low + 0.5*range
    rev_mid = reversal_candle['low'] + (reversal_candle['high']-reversal_candle['low'])*0.5
    
    hammer_idx=None
    hammer_candle=None
    entry_type=None
    
    # نبحث في الشمعة التالية مباشرة
    next_idx=reversal_idx+1
    if next_idx >= len(c15)-1:
        continue
    next_c=c15[next_idx]
    
    # هل ذيلها ما يوصل لنص الارتدادية؟ الشرط: low > rev_mid
    # حتى لو بنتفة صغيرة (low > mid)
    if next_c['low'] > rev_mid:
        # إما شرائية ثانية أو بيعية - كلاهما مقبول، لكن الهامر البيعية مثالية
        # نتحقق: شمعة الهامر قد يكون جسمها كبير أو صغير - المهم بيعية أو شرائية ثانية
        # إذا بيعية (close < open) مثالية، إذا شرائية ثانية أيضا مقبولة
        hammer_idx=next_idx
        hammer_candle=next_c
        if next_c['close'] < next_c['open']:
            entry_type="bearish_hammer_ideal"
        else:
            entry_type="second_bullish"
    else:
        # ذيلها وصل لنص الارتدادية أو أكثر = فشل
        continue
    
    # 4. الدخول عند إغلاق شمعة الهامر
    entry_price=hammer_candle['close']
    # الستوب تحت قاع الهامر نفسها تقريبا مسافة 0.02%
    sl_price=hammer_candle['low'] * (1 - 0.0002)  # 0.02%
    risk=entry_price - sl_price
    if risk<=0:
        continue
    risk_pct=risk/entry_price*100
    if risk_pct>0.60 or risk_pct<0.01:  # فلتر ريسك سعري
        continue
    
    # 5. التارغت هو أول قمة قبلها يلي أسس قاع سحب السيولة
    # أول قمة قبل القاع المسحوب
    # نبحث عن سوينغ هاي قبل sw_idx
    valid_highs=[(idx,price) for idx,price in highs_15 if idx < sw_idx and sw_idx-idx<=60]
    if not valid_highs:
        continue
    # أول قمة قبل القاع (الأقرب)
    # نرتب تنازلياً: الأقرب للقاع أولاً
    valid_highs_sorted=sorted(valid_highs, key=lambda x: x[0], reverse=True)
    first_peak_idx, first_peak_price = valid_highs_sorted[0]
    
    # التارغت قبل ذيل شمعة القمة السابقة بشوي صغيرة
    # يعني TP = high القمة - buffer صغير (0.05%)
    tp_price=first_peak_price * (1 - 0.0005)  # 0.05% قبل الذيل
    
    # تأكد أن الهدف فوق الدخول
    if tp_price <= entry_price:
        continue
    
    # 6. تارغت RR
    tp_r = (tp_price - entry_price)/risk
    
    # فلتر: RR على الأقل 1.5؟
    if tp_r < 1.2:
        continue
    
    # الآن عندنا سيت أب كامل بدون غش
    # الدخول عند إغلاق الهامر (بدون مستقبل)
    # t_known = إغلاق الهامر
    t_known=c15[hammer_idx]['ts']+900
    if t_known<=last_exit:
        continue
    
    # محاكاة - بدون غش: من الشمعة التالية
    entry_ts=t_known
    # ابحث عن شمعة البداية
    sim_start_idx=hammer_idx+1
    mfe=0
    sl_hit=False
    tp_hit=False
    result=None
    for sim_idx in range(sim_start_idx, min(sim_start_idx+200, len(c15))):  # 200 شمعة 15M = 50 ساعة
        sc=c15[sim_idx]
        # MFE
        if sc['high']>entry_price:
            mfe=max(mfe,(sc['high']-entry_price)/risk)
        # تحقق ستوب
        if sc['low'] <= sl_price:
            sl_hit=True
            result={'r_multiple':-1,'result':'SL','exit_price':sl_price,'exit_dt':sc['dt'],'hold':sim_idx-sim_start_idx,'mfe_r':mfe}
            break
        if sc['high'] >= tp_price:
            tp_hit=True
            result={'r_multiple':tp_r,'result':'TP','exit_price':tp_price,'exit_dt':sc['dt'],'hold':sim_idx-sim_start_idx,'mfe_r':mfe}
            break
    
    if result is None:
        # إغلاق بعد 50 ساعة
        last_c=c15[min(sim_start_idx+200, len(c15)-1)]
        result={'r_multiple':(last_c['close']-entry_price)/risk,'result':'50H_CLOSE','exit_price':last_c['close'],'exit_dt':last_c['dt'],'hold':200,'mfe_r':mfe}
    
    # حفظ
    trades.append({
        'entry_dt': c15[hammer_idx]['dt'],
        'sweep_dt': c15[i]['dt'],
        'reversal_dt': reversal_candle['dt'],
        'hammer_dt': hammer_candle['dt'],
        'sweep_price': sw_price,
        'entry_price': entry_price,
        'sl_price': sl_price,
        'tp_price': tp_price,
        'risk': risk,
        'risk_pct': risk_pct,
        'tp_r': tp_r,
        'first_peak_price': first_peak_price,
        'first_peak_idx': first_peak_idx,
        'rev_mid': rev_mid,
        'hammer_low': hammer_candle['low'],
        'hammer_type': entry_type,
        'result': result['result'],
        'r_multiple': result['r_multiple'],
        'exit_price': result['exit_price'],
        'exit_dt': result['exit_dt'],
        'hold': result['hold'],
        'mfe_r': result['mfe_r'],
        'sweep_idx': sw_idx,
        'reversal_idx': reversal_idx,
        'hammer_idx': hammer_idx,
    })
    last_exit=result['exit_dt'].timestamp()

# تحليل
print(f"\n=== نتائج Scalping الحارق 15M بدون غش آخر 30 يوم ===")
print(f"عدد الصفقات: {len(trades)}")

bal=100
for idx,t in enumerate(trades,1):
    bal+=bal*0.01*t['r_multiple']  # ريسك 1% = $1
    print(f"\n--- صفقة #{idx} {t['result']} {t['r_multiple']:+.2f}R MFE {t['mfe_r']:.1f}R ---")
    print(f"  القاع السابق: idx {t['sweep_idx']} سعر ${t['sweep_price']:.0f}")
    print(f"  شمعة السحب: {t['sweep_dt'].strftime('%m-%d %H:%M')} low ${c15[t['sweep_idx']+1 if t['sweep_idx']+1 < len(c15) else t['sweep_idx']]['low']:.0f} -> close فوق القاع")
    print(f"  الارتدادية الكبيرة: {t['reversal_dt'].strftime('%m-%d %H:%M')} O {c15[t['reversal_idx']]['open']:.0f} H {c15[t['reversal_idx']]['high']:.0f} L {c15[t['reversal_idx']]['low']:.0f} C {c15[t['reversal_idx']]['close']:.0f} body {(c15[t['reversal_idx']]['close']-c15[t['reversal_idx']]['open'])/(c15[t['reversal_idx']]['high']-c15[t['reversal_idx']]['low'])*100:.0f}% mid ${t['rev_mid']:.0f}")
    print(f"  الهامر ({t['hammer_type']}): {t['hammer_dt'].strftime('%m-%d %H:%M')} low ${t['hammer_low']:.0f} > mid ${t['rev_mid']:.0f}? {t['hammer_low']>t['rev_mid']} (ذيل ما وصل لنص)")
    print(f"  الدخول: عند إغلاق الهامر ${t['entry_price']:.0f} | ستوب تحت قاع الهامر ${t['sl_price']:.0f} +0.02% | ريسك {t['risk_pct']:.3f}%")
    print(f"  الهدف: أول قمة قبل القاع idx {t['first_peak_idx']} سعر ${t['first_peak_price']:.0f} -> TP ${t['tp_price']:.0f} (قبل الذيل بشوي) RR {t['tp_r']:.2f}R")
    print(f"  الخروج: {t['exit_dt'].strftime('%m-%d %H:%M')} {t['result']} @ ${t['exit_price']:.0f} بعد {t['hold']} شمعة ({t['hold']*15/60:.1f}h)")
    print(f"  بالانس: ${bal:.2f}")

R=sum(t['r_multiple'] for t in trades)
wins=len([t for t in trades if t['r_multiple']>0])
print(f"\n=== الإجمالي ===")
print(f"صفقات: {len(trades)} WR {wins/len(trades)*100 if trades else 0:.1f}% R {R:+.2f} بالانس ${bal:.2f} شهرياً {(bal/100-1)*100:+.1f}%")
print(f"متوسط Hold: {sum(t['hold'] for t in trades)/len(trades) if trades else 0:.1f} شمعة")
